<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="template-version" content="1.0.0">
    <title>Portfolio Details - ICEF INDIA    </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/favicon-icef.png">
    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/animate.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="assets/css/plugins/flatpickr.min.css">
    <link rel="stylesheet" href="assets/css/plugins/nouislider.min.css">
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/vendor/odometer.min.css">
    <link rel="stylesheet" href="assets/css/vendor/spacing.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css">
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        /* =============================================
           Banner Contact Form — Form Overlaps Girl Image
        ============================================= */

        /* Right column: position:relative so the form can be overlaid */
        .rs-banner-form-wrap {
            position: relative;
            display: block;
        }

        /* Girl image: fully visible, natural width, drives wrapper height */
        .rs-banner-bg-img {
            display: block;
            width: 100%;
            height: auto;
            object-fit: cover;
            object-position: top center;
            opacity: 1;
            position: relative;
            z-index: 0;
        }

        /* Form card: positioned absolutely, centred over the girl image */
        .rs-banner-contact-form {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 3;
            background: #ffffff;
            border-radius: 8px;
            padding: 28px 24px;
            width: calc(100% - 60px);
            max-width: 400px;
            box-shadow: 0 8px 40px rgba(0, 0, 0, 0.28);
        }

        .rs-form-title {
            font-size: 20px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 4px;
            line-height: 1.3;
        }

        .rs-form-subtitle {
            font-size: 12px;
            color: #888;
            margin-bottom: 14px;
        }

        .rs-contact-form-banner .rs-form-row {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }

        .rs-contact-form-banner .rs-form-group {
            flex: 1 1 0%;
            min-width: 0;
            display: flex;
            flex-direction: column;
        }

        .rs-contact-form-banner .rs-form-group-full {
            flex: 1 1 100%;
        }

        .rs-contact-form-banner input,
        .rs-contact-form-banner select,
        .rs-contact-form-banner .nice-select,
        .rs-contact-form-banner textarea {
            width: 100% !important;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            font-size: 14px;
            color: #444;
            background: #fff !important;
            background-image: none !important;
            outline: none;
            transition: border-color 0.3s;
            font-family: inherit;
            appearance: none !important;
            -webkit-appearance: none !important;
            -moz-appearance: none !important;
            box-sizing: border-box;
        }

        .rs-contact-form-banner input,
        .rs-contact-form-banner select,
        .rs-contact-form-banner .nice-select {
            height: 45px !important;
            padding: 0 12px;
            line-height: 43px; /* adjusted for border */
        }

        .rs-contact-form-banner .nice-select {
            display: flex;
            align-items: center;
            float: none;
        }

        .rs-contact-form-banner .nice-select .current {
            display: block;
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            padding-right: 20px;
        }

        .rs-contact-form-banner .nice-select:after {
            content: "" !important;
            border-bottom: 2px solid #AB052D;
            border-right: 2px solid #AB052D;
            height: 8px;
            width: 8px;
            right: 15px;
            top: 40%; 
            transform: rotate(45deg);
        }

        .rs-contact-form-banner input::placeholder,
        .rs-contact-form-banner textarea::placeholder {
            color: #aaa;
        }

        .rs-contact-form-banner input:focus,
        .rs-contact-form-banner select:focus,
        .rs-contact-form-banner .nice-select:focus,
        .rs-contact-form-banner textarea:focus {
            border-color: #AB052D;
        }

        .rs-contact-form-banner select {
            cursor: pointer;
            color: #aaa;
        }

        .rs-contact-form-banner select option:not([disabled]) {
            color: #444;
        }

        .rs-contact-form-banner textarea {
            height: 120px !important;
            padding: 12px;
            resize: none;
            line-height: normal;
        }

        /* Button: maroon matching the site header */
        .rs-banner-form-btn {
            width: 100%;
            background: #AB052D;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 12px;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 1.5px;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            text-transform: uppercase;
        }

        .rs-banner-form-btn:hover {
            background: #8c0424;
            transform: translateY(-1px);
        }

        /* Banner left content: nudge right so it's not touching the left edge */
        .rs-banner-area .rs-banner-content {
            padding-left: 60px;
        }

        /* Hero Left Button: make it maroon */
        .rs-banner-area .rs-banner-content .rs-btn {
            background-color: #AB052D;
            border-color: #AB052D;
        }

        .rs-banner-area .rs-banner-content .rs-btn:hover {
            background-color: #8c0424;
            border-color: #8c0424;
        }

        /* ---- Responsive overrides ---- */
        @media (max-width: 1399px) {
            .rs-banner-area .rs-banner-content { padding-left: 40px; }
        }

        @media (max-width: 1199px) {
            .rs-banner-area .rs-banner-content { padding-left: 24px; }
        }

        @media (max-width: 991px) {
            .rs-banner-area .rs-banner-content { padding-left: 16px; }

            .rs-banner-contact-form {
                position: relative;
                top: auto;
                left: auto;
                transform: none;
                width: 100%;
                max-width: 100%;
                margin-top: 20px;
            }

            .rs-contact-form-banner .rs-form-row {
                flex-direction: column;
                gap: 10px;
            }
        }

        /* =============================================
           Glass Effect — Transparent Header over Banner
        ============================================= */
        @media (min-width: 992px) {

            /* Overlay Header Container — only for main header, not sticky */
            .rs-header-area.header-transparent:not(.rs-sticky-header) {
                position: absolute;
                width: 100%;
                top: 40px; /* leave space for the Top Red Bar */
                left: 0;
                z-index: 1000;
                background: transparent;
            }

            /* Top Red Bar */
            .header-transparent-parent .rs-header-top {
                background: #AB052D !important;
                position: relative;
                z-index: 1002;
                height: 40px;
                display: flex !important;
                align-items: center;
            }

            /* Sticky header — glass while not yet active */
            .header-transparent.rs-sticky-header:not(.active) {
                background: rgba(43, 57, 68, 0.4) !important;
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                position: fixed;
                width: 100%;
                top: -100px;
                z-index: 1001;
                visibility: hidden;
                opacity: 0;
                pointer-events: none;
                transition: all 0.4s ease;
            }

            /* Sticky header — fully visible when active */
            .header-transparent.rs-sticky-header.active {
                background: var(--rs-theme-secondary) !important;
                backdrop-filter: none;
                -webkit-backdrop-filter: none;
                top: 0 !important;
                position: fixed;
                width: 100%;
                visibility: visible;
                opacity: 1;
                pointer-events: auto;
            }
        }

        /* Mobile Menu Fix: hide desktop nav on small screens */
        @media (max-width: 1199px) {
            .header-menu,
            .main-menu,
            #mobile-menu,
            #mobile-menu-two {
                display: none !important;
            }
        }
    </style>
</head>

<body class="rs-smoother-yes">

        <!-- preloader start -->
    <div id="pre-load">
        <div id="loader" class="loader">
            <div class="loader-container">
                <div class="loader-icon"><img src="assets/images/logo/favicon-icef.png" alt="ICEF INDIA"></div>
            </div>
        </div>
    </div>
    <!-- preloader end -->

    <!-- preloader start -->

    <div id="rs-mouse">
        <div id="cursor-ball"></div>
    </div>

    <!-- preloader end -->

    <style>
        /* Custom Mega Menu for Solutions with Feature Image */
        .main-menu .mega-grid-two {
            grid-template-columns: repeat(6, 1fr) 300px !important;
            width: 1550px !important;
            padding: 0 !important;
            overflow: hidden;
            border-radius: 10px !important;
            background-color: var(--rs-theme-secondary) !important;
        }

        @media only screen and (max-width: 1600px) {
            .main-menu .mega-grid-two {
                width: 1350px !important;
                grid-template-columns: repeat(6, 1fr) 250px !important;
            }
        }

        @media only screen and (max-width: 1366px) {
            .main-menu .mega-grid-two {
                width: 1180px !important;
                grid-template-columns: repeat(5, 1fr) !important;
            }
            .mega-menu-feature {
                display: none !important; /* Hide feature on smaller screens to keep navigation clear */
            }
        }

        .main-menu .mega-grid-one > li, .main-menu .mega-grid-two > li {
            padding: 30px 20px !important;
            border-right: 1px solid rgba(255, 255, 255, 0.1) !important;
            position: relative;
        }

        .main-menu .mega-grid-one > li::before, .main-menu .mega-grid-two > li::before {
            content: none !important;
        }

        .main-menu .mega-grid-two > li:last-child {
            border-right: none !important;
        }

        .mega-menu-feature {
            background-color: #243039 !important;
            padding: 40px 30px !important;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
        }

        .mega-menu-feature h6.title {
            color: #AB052D !important;
            font-size: 20px !important;
            margin-bottom: 12px !important;
            font-weight: 700 !important;
            text-transform: capitalize !important;
        }

        .mega-menu-feature p {
            font-size: 14px !important;
            line-height: 1.5 !important;
            color: rgba(255, 255, 255, 0.7) !important;
            margin-bottom: 20px !important;
            white-space: normal !important;
        }

        .mega-menu-feature .feature-thumb {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
        }

        .mega-menu-feature .feature-thumb img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            transition: all 0.4s ease;
        }
        
        .mega-menu-feature:hover .feature-thumb img {
            transform: scale(1.05);
        }

        /* FAQ Section Image Resizing */
        .rs-faq-two .rs-faq-wrapper {
            grid-template-columns: 1fr 480px !important;
            gap: 30px 60px !important;
            align-items: flex-start !important;
        }
        .rs-faq-two .rs-faq-thumb {
            width: 100% !important;
            max-width: 480px !important;
        }
        .rs-faq-two .rs-faq-thumb > img {
            height: 500px !important;
            object-fit: cover !important;
            border-radius: 10px !important;
        }
        .rs-faq-two .rs-faq-award {
            width: auto !important;
            max-width: 360px !important;
            padding: 15px 20px !important;
            bottom: 15px !important;
            inset-inline-start: auto !important;
            inset-inline-end: 15px !important;
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 8px !important;
            background: rgba(255, 255, 255, 0.08) !important;
            background-image: none !important;
            backdrop-filter: blur(12px) !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
        }
        .rs-faq-award-thumb {
            display: none !important;
        }
        .rs-faq-two .rs-faq-award-desc {
            font-size: 13px !important;
            line-height: 1.4 !important;
            margin-bottom: 0 !important;
            border-inline-start: none !important;
            padding-inline-start: 0 !important;
            margin-inline-start: 0 !important;
        }
        @media only screen and (max-width: 1366px) {
            .rs-faq-two .rs-faq-wrapper {
                grid-template-columns: 1fr 400px !important;
            }
            .rs-faq-two .rs-faq-thumb > img {
                height: 450px !important;
            }
        }
        @media only screen and (max-width: 991px) {
            .rs-faq-two .rs-faq-wrapper {
                grid-template-columns: 1fr !important;
            }
            .rs-faq-two .rs-faq-thumb {
                max-width: 100% !important;
            }
        }



        /* Submenu adjustments */
        .main-menu .submenu {
            width: max-content !important;
            min-width: 140px !important;
            max-width: 350px !important;
        }

        .main-menu .submenu li {
            padding-inline-start: 20px !important;
            padding-inline-end: 15px !important;
        }

        .main-menu .submenu li a {
            white-space: nowrap !important;
        }

        /* Mega menu column titles and links */
        .main-menu .mega-grid-two > li .title {
            color: #ffffff !important;
            margin-bottom: 15px !important;
            display: block !important;
        }

        .main-menu .mega-grid-two > li ul li a {
            color: rgba(255, 255, 255, 0.7) !important;
            padding: 5px 0 !important;
        }

        .main-menu .mega-grid-two > li ul li a:hover {
            color: var(--rs-theme-primary) !important;
            padding-left: 5px !important;
        }

        /* Feature Button Styling */
        .mega-menu-feature .rs-btn {
            background-color: var(--rs-theme-primary) !important;
            color: #ffffff !important;
            padding: 14px 28px !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            border-radius: 6px !important;
            font-size: 14px !important;
            font-weight: 700 !important;
            width: fit-content !important;
            height: auto !important;
            line-height: 1 !important;
            margin-bottom: 20px !important;
        }

        .mega-menu-feature .rs-btn:hover {
            background-color: #ffffff !important;
            color: var(--rs-theme-primary) !important;
        }

        /* Sticky Header Styles */
        .rs-sticky-header.active {
            background: var(--rs-theme-secondary) !important;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            top: 0 !important;
        }

        .rs-sticky-header .header-logo img {
            max-height: 50px;
            width: auto;
        }

        .rs-sticky-header .header-wrapper {
            background: transparent !important;
            padding-top: 10px;
            padding-bottom: 10px;
        }

        /* Bridge the gap to prevent dropdown closing when moving mouse from link to menu */
        .main-menu li {
            position: relative;
        }

        .main-menu .submenu,
        .main-menu .mega-menu {
            position: absolute;
            background-color: var(--rs-theme-secondary);
            z-index: 99;
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
            /* Professional transition with slight delay for closing to make it more stable and forgiving */
            transition: opacity 0.3s ease, transform 0.3s ease, visibility 0.3s ease !important;
            transition-delay: 0.2s !important;
        }

        .main-menu li:hover > .submenu,
        .main-menu li:hover > .mega-menu {
            opacity: 1;
            visibility: visible;
            pointer-events: all;
            transition-delay: 0s !important;
        }

        /* The Bridge: Invisible pseudo-element to close the physical gap between link and menu */
        .main-menu .submenu::before,
        .main-menu .mega-menu::before {
            content: "";
            position: absolute;
            top: -50px; /* Ample space to bridge any gap */
            left: 0;
            right: 0;
            height: 50px;
            background: transparent;
            z-index: 10;
            pointer-events: auto !important; /* Forces hover capture in the gap */
        }

        /* More persistent hover colors */
        .main-menu ul li:hover > a {
            color: var(--rs-theme-primary) !important;
        }
    </style>

    <!-- header area start-->
    <header>
        <div class="container-fluid g-0">
            <!-- top start -->
            <div class="rs-header-top rs-header-top-one">
                <div class="header-top-left">
                    <span class="header-top-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="6" height="11" viewBox="0 0 6 11" fill="none">
                            <path
                                d="M0.50204 0.439454C0.811629 0.16438 1.28548 0.192407 1.56063 0.501954L5.56063 5.00195C5.81308 5.28608 5.81308 5.71392 5.56063 5.99805L1.56063 10.498C1.28548 10.8076 0.811629 10.8356 0.50204 10.5605C0.192493 10.2854 0.164466 9.81154 0.43954 9.50195L3.99618 5.5L0.43954 1.49805C0.164466 1.18846 0.192493 0.714606 0.50204 0.439454Z"
                                fill="#AB052D"></path>
                        </svg>
                    </span>
                    <div class="header-top-content">
                        <p>India's Leading Integrated Assessment & Recruitment Platform Since 2000.
                            <a href="about-mission.php">Learn More</a>
                        </p>
                    </div>
                </div>
                <div class="header-top-right">
                    <div class="header-top-meta">
                        <span class="header-top-meta-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
                                <path
                                    d="M12.1641 10.5834C11.6414 10.0673 10.9888 10.0673 10.4694 10.5834C10.0732 10.9762 9.67699 11.3691 9.28744 11.7686C9.1809 11.8785 9.091 11.9018 8.96115 11.8286C8.70479 11.6887 8.43177 11.5755 8.18539 11.4224C7.03673 10.6999 6.07452 9.77097 5.22218 8.72552C4.79934 8.20613 4.42312 7.65011 4.16009 7.02417C4.10682 6.89765 4.11681 6.81442 4.22002 6.7112C4.61622 6.32832 5.00244 5.93544 5.39198 5.54257C5.93469 4.99654 5.93469 4.35728 5.38866 3.80792C5.07902 3.49495 4.76938 3.18865 4.45974 2.87568C4.14011 2.55605 3.82381 2.23309 3.50086 1.9168C2.97813 1.40739 2.32556 1.40739 1.80617 1.92012C1.40663 2.313 1.02375 2.71586 0.617555 3.10208C0.241327 3.45833 0.0515486 3.89449 0.0115952 4.40389C-0.0516643 5.23293 0.151432 6.01535 0.437765 6.77779C1.02375 8.35595 1.91604 9.75765 2.99811 11.0428C4.45974 12.7808 6.20437 14.1558 8.24532 15.148C9.16425 15.5942 10.1165 15.9371 11.1519 15.9937C11.8644 16.0337 12.4837 15.8539 12.9798 15.2979C13.3194 14.9183 13.7023 14.572 14.0619 14.2091C14.5946 13.6697 14.5979 13.0172 14.0685 12.4845C13.4359 11.8485 12.8 11.2159 12.1641 10.5834Z"></path>
                                <path
                                    d="M11.5271 7.92979L12.7557 7.72003C12.5625 6.59135 12.0298 5.56921 11.2208 4.75682C10.3651 3.90116 9.28304 3.36178 8.0911 3.19531L7.91797 4.43054C8.84023 4.56039 9.67925 4.97657 10.3418 5.63913C10.9677 6.26506 11.3773 7.05747 11.5271 7.92979Z"></path>
                                <path
                                    d="M13.4493 2.59031C12.0309 1.17197 10.2363 0.276344 8.25531 0L8.08218 1.23523C9.79352 1.47495 11.345 2.25071 12.5703 3.47262C13.7323 4.63459 14.4947 6.10288 14.771 7.71766L15.9996 7.50791C15.6767 5.63676 14.7943 3.93874 13.4493 2.59031Z"></path>
                            </svg>
                        </span>
                        <div class="header-top-meta-content">
                            <span>Call us:</span>
                            <a href="tel:+911204221735">+91 120 422 1735</a>
                        </div>
                    </div>
                    <div class="header-top-meta">
                        <span class="header-top-meta-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"
                                fill="none">
                                <g clip-path="url(#clip0_28535_99)">
                                    <path
                                        d="M15.8603 3.17969L11.0078 8.00091L15.8603 12.8221C15.948 12.6388 16.0012 12.4361 16.0012 12.2197V3.78216C16.0012 3.56569 15.948 3.36303 15.8603 3.17969Z"
                                        fill="white"></path>
                                    <path
                                        d="M14.5947 2.375H1.40716C1.19069 2.375 0.988031 2.42822 0.804688 2.51594L7.00666 8.68666C7.55503 9.23503 8.44678 9.23503 8.99516 8.68666L15.1971 2.51594C15.0138 2.42822 14.8111 2.375 14.5947 2.375Z"
                                        fill="white"></path>
                                    <path
                                        d="M0.140938 3.17969C0.0532188 3.36303 0 3.56569 0 3.78216V12.2197C0 12.4361 0.0532188 12.6388 0.140938 12.8221L4.99341 8.00091L0.140938 3.17969Z"
                                        fill="white"></path>
                                    <path
                                        d="M10.3447 8.66211L9.658 9.34877C8.74428 10.2625 7.2575 10.2625 6.34378 9.34877L5.65716 8.66211L0.804688 13.4833C0.988031 13.571 1.19069 13.6243 1.40716 13.6243H14.5947C14.8111 13.6243 15.0138 13.571 15.1971 13.4833L10.3447 8.66211Z"
                                        fill="white"></path>
                                </g>
                                <defs>
                                    <clipPath id="clip0_28535_99">
                                        <rect width="16" height="16" fill="white"></rect>
                                    </clipPath>
                                </defs>
                            </svg>
                        </span>
                        <div class="header-top-meta-content">
                            <span>Send mail:</span>
                            <a href="mailto:sales@icefindia.in">
                                sales@icefindia.in
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- top end -->
        </div>

        
        <div class="rs-header-area rs-header-one ">
                    <div class="container-fluid g-0">
            <div class="header-wrapper">
                <div class="header-left">
                    <div class="header-logo">
                        <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA - Integrated Assessment & Recruitment Platform"></a>
                    </div>
                </div>
                <div class="header-right">
                    <div class="header-menu">
                        <nav id="mobile-menu-two" class="main-menu">
                            <ul class="multipage-menu">
                                <li><a href="index.php">Home</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">About Company</a>
                                    <ul class="submenu last-children">
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="about-mission.php#mission">Mission & Vision</a></li>
                                        <li><a href="industry-clients.php">Industry We Work With</a></li>
                                        <li><a href="industry-clients.php#clients">Client Tele</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                        <li><a href="careers-culture.php">Work Culture</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children rs-mega-menu">
                                    <a href="javascript:void(0)">Solutions</a>
                                    <ul class="mega-menu mega-grid-two">
                                        <li class="rs-menu-item" data-image="assets/images/solution/it-emerging.webp">
                                            <a href="it-emerging-tech-enablement.php" class="title">IT & Emerging Tech Enablement</a>
                                            <ul>
                                                <li data-image="assets/images/solution/iot.webp"><a href="iot-and-rfid.php">IOT & RFID Based Products</a></li>
                                                <li data-image="assets/images/solution/app-dev.webp"><a href="application-development.php">Application Development</a></li>
                                                <li data-image="assets/images/solution/software-dev.webp"><a href="customized-software-development.php">Customized Software Development</a></li>
                                                <li data-image="assets/images/solution/emerging-tech.webp"><a href="emerging-tech.php">Emerging Tech</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/assessment-testing.webp">
                                            <a href="assessment-and-testing.php" class="title">Assessment & Testing</a>
                                            <ul>
                                                <li data-image="assets/images/solution/cognitive-domain.webp"><a href="cognitive-domain.php">Cognitive/Domain</a></li>
                                                <li data-image="assets/images/solution/online-offline.webp"><a href="online-offline.php">Online/Offline</a></li>
                                                <li data-image="assets/images/solution/proctoring.webp"><a href="proctoring.php">Proctoring</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/recruitment.webp">
                                            <a href="recruitment-and-hiring.php" class="title">Recruitment & Hiring</a>
                                            <ul>
                                                <li data-image="assets/images/about/33.webp"><a href="screening.php">Screening</a></li>
                                                <li data-image="assets/images/about/37.webp"><a href="assessments.php">Assessments</a></li>
                                                <li data-image="assets/images/solution/merit-list.webp"><a href="merit-lists.php">Merit Lists</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/exam-management.webp">
                                            <a href="exam-management.php" class="title">Exam Management</a>
                                            <ul>
                                                <li data-image="assets/images/solution/question-banks.webp"><a href="question-banks.php">Question Banks</a></li>
                                                <li data-image="assets/images/solution/exam-conduct.webp"><a href="exam-conduct.php">Conduct</a></li>
                                                <li data-image="assets/images/solution/processing.webp"><a href="exam-processing.php">Processing</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/manpower-workforce.webp">
                                            <a href="manpower-and-workforce.php" class="title">Manpower & Workforce</a>
                                            <ul>
                                                <li data-image="assets/images/solution/outsourcing.webp"><a href="outsourcing.php">Outsourcing</a></li>
                                                <li data-image="assets/images/about/31.webp"><a href="staffing.php">Staffing</a></li>
                                                <li data-image="assets/images/solution/deployment.webp"><a href="deployment.php">Deployment</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/call-center.webp">
                                            <a href="call-center-and-bpos.php" class="title">Call Center & BPOs</a>
                                            <ul>
                                                <li data-image="assets/images/solution/inbound.webp"><a href="inbound-outbound.php">Inbound/Outbound</a></li>
                                                <li data-image="assets/images/solution/support.webp"><a href="support.php">Support</a></li>
                                                <li data-image="assets/images/solution/telecalling.webp"><a href="tele-calling.php">Tele-Calling</a></li>
                                            </ul>
                                        </li>
                                        <li class="mega-menu-feature">
                                            <div class="mega-feature-content">
                                                <h6 class="title">Let's Talk Business</h6>
                                                <p>Empowering businesses with smart IT solutions since 2000.</p>
                                                <a href="support.php" class="rs-btn has-icon has-md-radius hover-primary">Request Quote</a>
                                                <div class="feature-thumb mt-20">
                                                    <img id="mega-menu-target-img" src="assets/images/mega-menu-feature.png" alt="Consultation">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="why-choose-us.php">Why Choose Us</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">WhiteBoard</a>
                                    <ul class="submenu last-children">
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="faq.php">FAQs</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                    </ul>
                                </li>
                                
                                
                                <li><a href="contact.php">Support</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="header-content">
                        <div class="header-btn">
                            <a class="rs-btn has-icon is-transparent hover-primary border-hover-primary" href="contact.php">Get Free Quote</a>
                        </div>
                        <div class="header-search-wrapper">
                            <div class="header-search-icon"><i class="ri-search-line"></i></div>
                        </div>
                        <div class="header-hamburger">
                            <div class="sidebar-toggle">
                                <a class="header-bar-icon" href="javascript:void(0)"><span></span><span></span><span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                </div>

        <div id="rs-sticky-header" class="rs-sticky-header rs-header-area rs-header-one ">
                    <div class="container-fluid g-0">
            <div class="header-wrapper">
                <div class="header-left">
                    <div class="header-logo">
                        <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA - Integrated Assessment & Recruitment Platform"></a>
                    </div>
                </div>
                <div class="header-right">
                    <div class="header-menu">
                        <nav id="mobile-menu-two" class="main-menu">
                            <ul class="multipage-menu">
                                <li><a href="index.php">Home</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">About Company</a>
                                    <ul class="submenu last-children">
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="about-mission.php#mission">Mission & Vision</a></li>
                                        <li><a href="industry-clients.php">Industry We Work With</a></li>
                                        <li><a href="industry-clients.php#clients">Client Tele</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                        <li><a href="careers-culture.php">Work Culture</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children rs-mega-menu">
                                    <a href="javascript:void(0)">Solutions</a>
                                    <ul class="mega-menu mega-grid-two">
                                        <li class="rs-menu-item" data-image="assets/images/solution/it-emerging.webp">
                                            <a href="it-emerging-tech-enablement.php" class="title">IT & Emerging Tech Enablement</a>
                                            <ul>
                                                <li data-image="assets/images/solution/iot.webp"><a href="iot-and-rfid.php">IOT & RFID Based Products</a></li>
                                                <li data-image="assets/images/solution/app-dev.webp"><a href="application-development.php">Application Development</a></li>
                                                <li data-image="assets/images/solution/software-dev.webp"><a href="customized-software-development.php">Customized Software Development</a></li>
                                                <li data-image="assets/images/solution/emerging-tech.webp"><a href="emerging-tech.php">Emerging Tech</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/assessment-testing.webp">
                                            <a href="assessment-and-testing.php" class="title">Assessment & Testing</a>
                                            <ul>
                                                <li data-image="assets/images/solution/cognitive-domain.webp"><a href="cognitive-domain.php">Cognitive/Domain</a></li>
                                                <li data-image="assets/images/solution/online-offline.webp"><a href="online-offline.php">Online/Offline</a></li>
                                                <li data-image="assets/images/solution/proctoring.webp"><a href="proctoring.php">Proctoring</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/recruitment.webp">
                                            <a href="recruitment-and-hiring.php" class="title">Recruitment & Hiring</a>
                                            <ul>
                                                <li data-image="assets/images/about/33.webp"><a href="screening.php">Screening</a></li>
                                                <li data-image="assets/images/about/37.webp"><a href="assessments.php">Assessments</a></li>
                                                <li data-image="assets/images/solution/merit-list.webp"><a href="merit-lists.php">Merit Lists</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/exam-management.webp">
                                            <a href="exam-management.php" class="title">Exam Management</a>
                                            <ul>
                                                <li data-image="assets/images/solution/question-banks.webp"><a href="question-banks.php">Question Banks</a></li>
                                                <li data-image="assets/images/solution/exam-conduct.webp"><a href="exam-conduct.php">Conduct</a></li>
                                                <li data-image="assets/images/solution/processing.webp"><a href="exam-processing.php">Processing</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/manpower-workforce.webp">
                                            <a href="manpower-and-workforce.php" class="title">Manpower & Workforce</a>
                                            <ul>
                                                <li data-image="assets/images/solution/outsourcing.webp"><a href="outsourcing.php">Outsourcing</a></li>
                                                <li data-image="assets/images/about/31.webp"><a href="staffing.php">Staffing</a></li>
                                                <li data-image="assets/images/solution/deployment.webp"><a href="deployment.php">Deployment</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/call-center.webp">
                                            <a href="call-center-and-bpos.php" class="title">Call Center & BPOs</a>
                                            <ul>
                                                <li data-image="assets/images/solution/inbound.webp"><a href="inbound-outbound.php">Inbound/Outbound</a></li>
                                                <li data-image="assets/images/solution/support.webp"><a href="support.php">Support</a></li>
                                                <li data-image="assets/images/solution/telecalling.webp"><a href="tele-calling.php">Tele-Calling</a></li>
                                            </ul>
                                        </li>
                                        <li class="mega-menu-feature">
                                            <div class="mega-feature-content">
                                                <h6 class="title">Let's Talk Business</h6>
                                                <p>Empowering businesses with smart IT solutions since 2000.</p>
                                                <a href="support.php" class="rs-btn has-icon has-md-radius hover-primary">Request Quote</a>
                                                <div class="feature-thumb mt-20">
                                                    <img id="mega-menu-target-img" src="assets/images/mega-menu-feature.png" alt="Consultation">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="why-choose-us.php">Why Choose Us</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">WhiteBoard</a>
                                    <ul class="submenu last-children">
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="faq.php">FAQs</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                    </ul>
                                </li>
                                
                                
                                <li><a href="contact.php">Support</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="header-content">
                        <div class="header-btn">
                            <a class="rs-btn has-icon is-transparent hover-primary border-hover-primary" href="contact.php">Get Free Quote</a>
                        </div>
                        <div class="header-search-wrapper">
                            <div class="header-search-icon"><i class="ri-search-line"></i></div>
                        </div>
                        <div class="header-hamburger">
                            <div class="sidebar-toggle">
                                <a class="header-bar-icon" href="javascript:void(0)"><span></span><span></span><span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                </div>
    </header>
    <!-- Header area end -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const targetImg = document.getElementById('mega-menu-target-img');
            if (!targetImg) return;

            const globalDefaultImg = targetImg.getAttribute('src');
            let defaultImg = globalDefaultImg;
            const menuItems = document.querySelectorAll('.rs-mega-menu .mega-menu [data-image]');

            // Detect active page and set its image as default
            const currentPath = window.location.pathname;
            document.querySelectorAll('.rs-mega-menu .mega-menu .rs-menu-item').forEach(item => {
                const links = item.querySelectorAll('a');
                links.forEach(link => {
                    const href = link.getAttribute('href');
                    if (href && href !== '#' && currentPath.endsWith(href)) {
                        const activeImg = link.parentElement.getAttribute('data-image') || item.getAttribute('data-image');
                        if (activeImg) {
                            defaultImg = activeImg;
                            targetImg.setAttribute('src', activeImg);
                        }
                    }
                });
            });

            menuItems.forEach(item => {
                item.addEventListener('mouseenter', function(e) {
                    e.stopPropagation();
                    const newImg = this.getAttribute('data-image');
                    if (newImg && targetImg.getAttribute('src') !== newImg) {
                        targetImg.style.opacity = '0';
                        setTimeout(() => {
                            targetImg.setAttribute('src', newImg);
                            targetImg.style.opacity = '1';
                        }, 200);
                    }
                });
            });

            // Revert to default when leaving the entire mega menu grid
            const megaGrid = document.querySelector('.mega-grid-two');
            if (megaGrid) {
                megaGrid.addEventListener('mouseleave', function() {
                    targetImg.style.opacity = '0';
                    setTimeout(() => {
                        targetImg.setAttribute('src', defaultImg);
                        targetImg.style.opacity = '1';
                    }, 200);
                });
            }
        });
    </script>
    <style>
        #mega-menu-target-img {
            transition: opacity 0.3s ease;
        }
    </style>

        <!-- Offcanvas area start -->
    <div class="fix">
        <div class="offcanvas-area" data-lenis-prevent>
            <div class="offcanvas-wrapper">
                <div class="offcanvas-content">
                    <div class="offcanvas-top d-flex justify-content-between align-items-center mb-20">
                        <div class="offcanvas-logo">
                            <a class="logo-black" href="index.php"><img src="assets/images/logo/logo-icef.png" alt="logo"></a>
                            <a class="logo-white" href="index.php"><img src="assets/images/logo/logo-icef.png" alt="logo"></a>
                        </div>
                        <div class="offcanvas-close">
                            <button class="offcanvas-close-icon animation--flip" style="background: var(--rs-theme-primary); color: white; border: none; padding: 10px; border-radius: 4px; display: flex; align-items: center; justify-content: center; width: 40px; height: 40px;">
                                <i class="ri-close-line" style="font-size: 24px;"></i>
                            </button>
                        </div>
                    </div>
                    <div class="offcanvas-about mb-30 d-none d-xl-block">
                        <p>
                            ICEF INDIA is a premier organization providing end-to-end solutions in Assessment, Recruitment, and Workforce Development since 2000.
                        </p>
                    </div>
                    <div class="offcanvas-gallery d-none d-xl-block">
                        <div class="offcanvas-gallery-thumb-wrapper">
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-01.webp">
                                    <img src="assets/images/gallery/gallery-thumb-01.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-02.webp">
                                    <img src="assets/images/gallery/gallery-thumb-02.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-03.webp">
                                    <img src="assets/images/gallery/gallery-thumb-03.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-04.webp">
                                    <img src="assets/images/gallery/gallery-thumb-04.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-05.webp">
                                    <img src="assets/images/gallery/gallery-thumb-05.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-06.webp">
                                    <img src="assets/images/gallery/gallery-thumb-06.webp" alt="image">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="mobile-menu-container">
                        <div class="rs-offcanvas-menu mb-30" id="sidebar-menu-target">
                            <!-- Menu will be injected here via JS -->
                        </div>
                    </div>
                    <div class="offcanvas-contact mb-30">
                        <h4 class="offcanvas-title-meta">Contact Info</h4>
                        <ul>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="18" viewBox="0 0 14 18" fill="none">
                                        <path d="M11.8768 9.68475C11.3059 10.835 10.5331 11.9818 9.74128 13.0109C8.95198 14.0368 8.15999 14.9249 7.5643 15.5572C7.48514 15.6412 7.40956 15.7206 7.33802 15.7951C7.26648 15.7206 7.1909 15.6412 7.11174 15.5572C6.51605 14.9249 5.72406 14.0368 4.93476 13.0109C4.14299 11.9818 3.37019 10.835 2.79925 9.68475C2.22242 8.52266 1.89032 7.43373 1.89032 6.5C1.89032 3.50846 4.32934 1.08333 7.33802 1.08333C10.3467 1.08333 12.7857 3.50846 12.7857 6.5C12.7857 7.43373 12.4536 8.52266 11.8768 9.68475ZM7.33802 17.3333C7.33802 17.3333 13.8753 11.1732 13.8753 6.5C13.8753 2.91015 10.9484 0 7.33802 0C3.7276 0 0.800781 2.91015 0.800781 6.5C0.800781 11.1732 7.33802 17.3333 7.33802 17.3333Z" fill="#6D6D6D"></path>
                                        <path d="M7.33802 8.66667C6.13455 8.66667 5.15894 7.69662 5.15894 6.5C5.15894 5.30338 6.13455 4.33333 7.33802 4.33333C8.54149 4.33333 9.5171 5.30338 9.5171 6.5C9.5171 7.69662 8.54149 8.66667 7.33802 8.66667ZM7.33802 9.75C9.14323 9.75 10.6066 8.29492 10.6066 6.5C10.6066 4.70507 9.14323 3.25 7.33802 3.25C5.53281 3.25 4.0694 4.70507 4.0694 6.5C4.0694 8.29492 5.53281 9.75 7.33802 9.75Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="#"> Noida, Uttar Pradesh, India</a>
                                </div>
                            </li>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M3.65387 1.32849C3.40343 1.00649 2.92745 0.976861 2.639 1.26531L1.60508 2.29923C1.1216 2.78271 0.94387 3.46766 1.1551 4.06847C2.00338 6.48124 3.39215 8.74671 5.32272 10.6773C7.25329 12.6078 9.51876 13.9966 11.9315 14.8449C12.5323 15.0561 13.2173 14.8784 13.7008 14.3949L14.7347 13.361C15.0231 13.0726 14.9935 12.5966 14.6715 12.3461L12.3653 10.5524C12.2008 10.4245 11.9866 10.3793 11.7845 10.4298L9.59541 10.9771C9.00082 11.1257 8.37183 10.9515 7.93845 10.5181L5.48187 8.06155C5.04849 7.62817 4.87427 6.99919 5.02292 6.40459L5.57019 4.21553C5.62073 4.01336 5.57552 3.79918 5.44758 3.63468L3.65387 1.32849ZM1.88477 0.511076C2.62689 -0.231039 3.8515 -0.154797 4.49583 0.673634L6.28954 2.97983C6.6187 3.40304 6.73502 3.95409 6.60498 4.47423L6.05772 6.66329C5.99994 6.8944 6.06766 7.13888 6.2361 7.30732L8.69268 9.7639C8.86113 9.93235 9.1056 10.0001 9.33671 9.94229L11.5258 9.39502C12.0459 9.26499 12.597 9.3813 13.0202 9.71047L15.3264 11.5042C16.1548 12.1485 16.231 13.3731 15.4889 14.1152L14.455 15.1492C13.7153 15.8889 12.6089 16.2137 11.5778 15.8512C9.01754 14.9511 6.61438 13.4774 4.56849 11.4315C2.5226 9.38562 1.04895 6.98246 0.148838 4.42225C-0.213682 3.39112 0.11113 2.28472 0.85085 1.545L1.88477 0.511076Z" fill="#6D6D6D"></path>
                                        <path d="M11 0.5C11 0.223858 11.2239 0 11.5 0H15.5C15.7761 0 16 0.223858 16 0.5V4.5C16 4.77614 15.7761 5 15.5 5C15.2239 5 15 4.77614 15 4.5V1.70711L10.8536 5.85355C10.6583 6.04882 10.3417 6.04882 10.1464 5.85355C9.95118 5.65829 9.95118 5.34171 10.1464 5.14645L14.2929 1H11.5C11.2239 1 11 0.776142 11 0.5Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="tel:+911204221735"> +91 120 422 1735 </a>
                                </div>
                            </li>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M2 2C0.895431 2 0 2.89543 0 4V12L2.58386e-05 12.0103C0.00555998 13.1101 0.898859 14 2 14H7.5C7.77614 14 8 13.7761 8 13.5C8 13.2239 7.77614 13 7.5 13H2C1.53715 13 1.14774 12.6855 1.03376 12.2586L6.67417 8.7876L8 9.5831L15 5.3831V8.5C15 8.77614 15.2239 9 15.5 9C15.7761 9 16 8.77614 16 8.5V4C16 2.89543 15.1046 2 14 2H2ZM5.70808 8.20794L1 11.1052V5.3831L5.70808 8.20794ZM1 4.2169V4C1 3.44772 1.44772 3 2 3H14C14.5523 3 15 3.44772 15 4V4.2169L8 8.4169L1 4.2169Z" fill="#6D6D6D"></path>
                                        <path d="M14.2467 14.2686C15.2567 14.2686 15.8339 13.4116 15.8339 12.2442V12.0344C15.8339 10.4297 14.6402 9 12.5197 9H12.4847C10.421 9 9 10.3598 9 12.4322V12.6465C9 14.8195 10.4385 16 12.3579 16H12.4016C12.9963 16 13.4204 15.9257 13.639 15.8251V15.0949C13.3941 15.2042 12.9656 15.2742 12.4585 15.2742H12.4147C11.0812 15.2742 9.84385 14.4872 9.84385 12.6202V12.4628C9.84385 10.8057 10.9019 9.73891 12.4847 9.73891H12.524C14.0587 9.73891 15.0075 10.7883 15.0075 12.065V12.183C15.0075 13.158 14.6839 13.5734 14.3691 13.5734C14.1374 13.5734 13.9582 13.4247 13.9582 13.1537V10.9631H13.0531V11.5315H13.0225C12.9394 11.2342 12.6552 10.9019 12.0693 10.9019C11.2911 10.9019 10.8101 11.4572 10.8101 12.3011V12.8301C10.8101 13.722 11.2998 14.2642 12.0693 14.2642C12.5415 14.2642 12.9656 14.0369 13.0837 13.6215H13.1274C13.2455 14.0412 13.7439 14.2686 14.2467 14.2686ZM11.7939 12.6814V12.4541C11.7939 11.9076 12.0212 11.6627 12.3666 11.6627C12.664 11.6627 12.9394 11.8551 12.9394 12.371V12.7383C12.9394 13.3111 12.6858 13.4816 12.3754 13.4816C12.0212 13.4816 11.7939 13.2673 11.7939 12.6814Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="mailto:sales@icefindia.in">sales@icefindia.in</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="offcanvas-social">
                        <h4 class="offcanvas-title-meta">Follow Us</h4>
                        <ul>
                            <li><a href="#"><i class="ri-facebook-fill"></i></a></li>
                            <li><a href="#"><i class="ri-twitter-x-fill"></i></a></li>
                            <li><a href="#"><i class="ri-youtube-fill"></i></a></li>
                            <li><a href="#"><i class="ri-linkedin-box-fill"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas-overlay"></div>
    <div class="offcanvas-overlay-white"></div>
    <!-- Offcanvas area start -->

    <!-- Body main wrapper start -->
    <main>

        <!-- portfolio details area  start -->
        <section class="rs-portfolio-area section-space">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-portfolio-details-wrapper">
                            <div class="rs-portfolio-details-thumb">
                                <img src="assets/images/portfolio/details/portfolio-details-thumb-01.webp" alt="image">
                            </div>
                            <div class="rs-portfolio-details-working-list">
                                <div class="rs-working-list-wrapper">
                                    <div class="rs-working-list-item">
                                        <div class="rs-working-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 40">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M25.3896 27.8182C30.2884 29.1811 33.985 33.4266 34.5391 38.6118C34.5493 38.708 34.5392 38.8054 34.5094 38.8975C34.4796 38.9897 34.4308 39.0745 34.3661 39.1465C34.3013 39.2185 34.2222 39.2761 34.1337 39.3155C34.0453 39.3549 33.9496 39.3753 33.8527 39.3753H10.1504C10.0535 39.3753 9.95773 39.3549 9.86928 39.3154C9.78082 39.276 9.70165 39.2183 9.63692 39.1463C9.57219 39.0742 9.52335 38.9894 9.49356 38.8972C9.46378 38.805 9.45372 38.7076 9.46405 38.6113C10.021 33.4262 13.7182 29.1807 18.6155 27.8181C16.6267 26.6495 15.2872 24.4863 15.2872 22.0208C15.2872 18.3219 18.3025 15.3033 22.0015 15.3033C25.704 15.3033 28.7191 18.322 28.7191 22.0208C28.7191 24.4864 27.3795 26.6497 25.3896 27.8182ZM22.0015 28.7384C16.4741 28.7384 11.8793 32.7339 10.9452 37.9949H33.0582C32.127 32.7338 27.5318 28.7384 22.0015 28.7384ZM22.0015 27.358C24.9432 27.358 27.3387 24.9597 27.3387 22.0208C27.3387 19.0821 24.9432 16.6837 22.0015 16.6837C19.0629 16.6837 16.6676 19.0822 16.6676 22.0208C16.6676 24.9596 19.0629 27.358 22.0015 27.358ZM9.993 23.4694C9.993 23.8504 9.68371 24.1596 9.3028 24.1596C8.9219 24.1596 8.61261 23.8504 8.61261 23.4694C8.61261 16.0799 14.612 10.0804 22.0015 10.0804C29.3911 10.0804 35.3905 16.0799 35.3905 23.4694C35.3905 23.8504 35.0812 24.1596 34.7003 24.1596C34.3194 24.1596 34.0101 23.8504 34.0101 23.4694C34.0101 16.8417 28.6292 11.4608 22.0015 11.4608C15.3739 11.4608 9.993 16.8417 9.993 23.4694ZM21.3114 4.91527V1.31495C21.3114 0.93405 21.6206 0.624756 22.0015 0.624756C22.3825 0.624756 22.6917 0.93405 22.6917 1.31495V4.91527L22.8857 4.74514C23.0233 4.62451 23.2032 4.56343 23.3858 4.57534C23.5684 4.58724 23.7389 4.67116 23.8596 4.80864C23.9803 4.94625 24.0414 5.12615 24.0295 5.3088C24.0176 5.49145 23.9337 5.6619 23.7961 5.78268L22.4568 6.958C22.3309 7.06851 22.1691 7.12944 22.0015 7.12944C21.834 7.12944 21.6722 7.06851 21.5463 6.958L20.207 5.78268C20.0694 5.6619 19.9855 5.49145 19.9736 5.3088C19.9617 5.12615 20.0228 4.94625 20.1435 4.80864C20.2642 4.67116 20.4347 4.58724 20.6173 4.57534C20.7999 4.56343 20.9798 4.62451 21.1174 4.74514L21.3114 4.91527ZM10.3942 9.43735L10.4109 9.17991C10.4358 8.79978 10.7645 8.51128 11.1446 8.53613C11.3272 8.54812 11.4976 8.63213 11.6184 8.76971C11.7391 8.90728 11.8002 9.08716 11.7884 9.26981L11.6724 11.0479C11.6615 11.2151 11.5902 11.3726 11.4718 11.491C11.3533 11.6095 11.1958 11.6808 11.0286 11.6917L9.25043 11.8077C9.06779 11.8195 8.88792 11.7584 8.75035 11.6376C8.61279 11.5169 8.52877 11.3465 8.51676 11.1639C8.50495 10.9812 8.56614 10.8014 8.68687 10.6638C8.8076 10.5263 8.97799 10.4423 9.16062 10.4303L9.41807 10.4135L6.87228 7.86767C6.7429 7.7382 6.67022 7.56265 6.67022 7.37962C6.67022 7.19658 6.7429 7.02104 6.87228 6.89156C7.00175 6.76221 7.17727 6.68955 7.36029 6.68955C7.5433 6.68955 7.71883 6.76221 7.8483 6.89156L10.3942 9.43735ZM4.89599 21.3306L4.72585 21.1368C4.47454 20.8504 4.50301 20.414 4.78935 20.1627C5.0757 19.9115 5.51207 19.94 5.76339 20.2262L6.93871 21.5657C7.0492 21.6916 7.11012 21.8534 7.11012 22.0209C7.11012 22.1884 7.0492 22.3502 6.93871 22.4761L5.76339 23.8155C5.51207 24.1018 5.0757 24.1302 4.78935 23.879C4.50301 23.6278 4.47454 23.1913 4.72585 22.905L4.89599 22.711H1.29566C0.914763 22.711 0.605469 22.4018 0.605469 22.0208C0.605469 21.6399 0.914763 21.3306 1.29566 21.3306H4.89599ZM33.6089 9.43735L36.1548 6.89156C36.2843 6.76221 36.4598 6.68955 36.6428 6.68955C36.8258 6.68955 37.0014 6.76221 37.1308 6.89156C37.2602 7.02104 37.3329 7.19658 37.3329 7.37962C37.3329 7.56265 37.2602 7.7382 37.1308 7.86767L34.585 10.4135L34.8425 10.4303C35.0251 10.4423 35.1955 10.5263 35.3162 10.6638C35.437 10.8014 35.4981 10.9812 35.4863 11.1639C35.4743 11.3465 35.3903 11.5169 35.2527 11.6376C35.1152 11.7584 34.9353 11.8195 34.7527 11.8077L32.9745 11.6917C32.8073 11.6808 32.6498 11.6095 32.5313 11.491C32.4129 11.3726 32.3416 11.2151 32.3307 11.0479L32.2147 9.26981C32.2029 9.08716 32.264 8.90728 32.3847 8.76971C32.5055 8.63213 32.6759 8.54812 32.8585 8.53613C33.2386 8.51128 33.5673 8.79978 33.5922 9.17991L33.6089 9.43735ZM39.1071 21.3306H42.7074C43.0883 21.3306 43.3976 21.6399 43.3976 22.0208C43.3976 22.4018 43.0883 22.711 42.7074 22.711H39.1071L39.2772 22.905C39.5286 23.1913 39.5001 23.6278 39.2137 23.879C38.9274 24.1302 38.491 24.1018 38.2397 23.8155L37.0644 22.4761C36.9539 22.3502 36.893 22.1884 36.893 22.0209C36.893 21.8534 36.9539 21.6916 37.0644 21.5657L38.2397 20.2262C38.491 19.94 38.9274 19.9115 39.2137 20.1627C39.5001 20.414 39.5286 20.8504 39.2772 21.1368L39.1071 21.3306Z">
                                                </path>
                                            </svg>
                                        </div>
                                        <div class="rs-working-list-content">
                                            <h6 class="rs-working-list-title">Clients:</h6>
                                            <p class="rs-working-list-desc"> Loha Ispaat Limited </p>
                                        </div>
                                    </div>
                                    <div class="rs-working-list-item">
                                        <div class="rs-working-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 38">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M10.5959 36.5456C10.0034 36.5456 9.52067 36.0625 9.52067 35.4686C9.52067 34.8755 10.0034 34.3925 10.5959 34.3925C11.1884 34.3925 11.6758 34.8756 11.6758 35.4686C11.6758 36.0626 11.1884 36.5456 10.5959 36.5456ZM10.5959 1.45436C11.1884 1.45436 11.6758 1.93651 11.6758 2.53042C11.6758 3.12345 11.1884 3.60657 10.5959 3.60657C10.0034 3.60657 9.52067 3.12345 9.52067 2.53042C9.52067 1.93651 10.0034 1.45436 10.5959 1.45436ZM10.5959 33.2605C9.97941 33.2605 9.42519 33.5147 9.02373 33.9232L1.98989 29.9241V8.07486L9.02373 4.07676C9.4251 4.48481 9.97941 4.73861 10.5959 4.73861C11.8144 4.73861 12.8035 3.74755 12.8035 2.53051C12.8035 1.3125 11.8144 0.322415 10.5959 0.322415C9.13189 0.322415 8.09401 1.71968 8.45992 3.09248L1.14413 7.25303C1.05726 7.30259 0.985011 7.3742 0.934672 7.46062C0.884332 7.54704 0.857686 7.64521 0.857422 7.74521V30.2539C0.857515 30.354 0.884089 30.4522 0.934446 30.5387C0.984803 30.6251 1.05715 30.6967 1.14413 30.7461L8.45992 34.9067C8.09401 36.2795 9.13215 37.6777 10.5959 37.6777C11.8144 37.6777 12.8035 36.6867 12.8035 35.4687C12.8035 34.2515 11.8143 33.2605 10.5959 33.2605ZM25.3994 36.5456C24.8069 36.5456 24.3242 36.0625 24.3242 35.4686C24.3242 34.8755 24.8068 34.3925 25.3994 34.3925C25.992 34.3925 26.4746 34.8756 26.4746 35.4686C26.4746 36.0626 25.9919 36.5456 25.3994 36.5456ZM25.3994 3.60657C24.8069 3.60657 24.3242 3.12345 24.3242 2.53042C24.3242 1.93651 24.8068 1.45436 25.3994 1.45436C25.992 1.45436 26.4746 1.93651 26.4746 2.53042C26.4746 3.12345 25.9919 3.60657 25.3994 3.60657ZM34.8511 7.25294L27.5353 3.09239C27.9013 1.72012 26.8636 0.322327 25.3994 0.322327C24.1809 0.322327 23.1917 1.31241 23.1917 2.53042C23.1917 3.74746 24.1809 4.73852 25.3994 4.73852C26.0158 4.73852 26.5749 4.48481 26.9763 4.07667L34.0101 8.07477V29.9241L26.9763 33.9232C26.5749 33.5146 26.0158 33.2605 25.3994 33.2605C24.1809 33.2605 23.1917 34.2515 23.1917 35.4686C23.1917 36.6866 24.1809 37.6776 25.3994 37.6776C26.8634 37.6776 27.9013 36.279 27.5353 34.9066L34.8511 30.746C34.9394 30.6977 35.013 30.6265 35.0643 30.5399C35.1155 30.4533 35.1426 30.3545 35.1426 30.2539V7.74513C35.1426 7.54202 35.0327 7.35423 34.8511 7.25294ZM17.9976 30.2194L6.72535 24.6507L11.1693 22.4564L17.7491 25.7063C17.9045 25.785 18.0931 25.7837 18.2509 25.7063L24.826 22.4564L29.2699 24.6507L17.9976 30.2194ZM6.72535 18.9997L11.1693 16.8054L17.7491 20.0547C17.9063 20.1339 18.0918 20.1324 18.2509 20.0547L24.826 16.8054L29.2699 18.9997L17.9976 24.5676L6.72535 18.9997ZM6.72535 13.3483L17.9976 7.78041L29.2699 13.3483L17.9976 18.9161L6.72535 13.3483ZM31.1144 24.6507C31.1144 24.8667 30.9901 25.0626 30.799 25.1587L18.2509 31.3582C18.0922 31.4346 17.9059 31.4361 17.7491 31.3572L5.19617 25.1587C4.77782 24.9503 4.77677 24.3517 5.19617 24.1437L9.8886 21.8252L5.19617 19.5072C4.77756 19.2992 4.77668 18.7008 5.19617 18.4918L9.8886 16.1738L5.19617 13.8553C4.77729 13.6476 4.77729 13.049 5.19617 12.8414L17.7491 6.64187C17.8271 6.60323 17.913 6.58313 18 6.58313C18.087 6.58313 18.1729 6.60323 18.2509 6.64187L30.799 12.8414C31.2179 13.0491 31.2179 13.6476 30.799 13.8553L26.1066 16.1738L30.799 18.4918C31.2185 18.7008 31.2176 19.2992 30.799 19.5072L26.1066 21.8252L30.799 24.1437C30.9901 24.2388 31.1144 24.4356 31.1144 24.6507Z">
                                                </path>
                                            </svg>
                                        </div>
                                        <div class="rs-working-list-content">
                                            <h6 class="rs-working-list-title"> Services:</h6>
                                            <p class="rs-working-list-desc"> Business Consulting</p>
                                        </div>
                                    </div>
                                    <div class="rs-working-list-item">
                                        <div class="rs-working-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 40">
                                                <path d="M34.0803 5.29914H32.4441V3.16102C32.4441 2.52138 32.19 1.90794 31.7377 1.45565C31.2854 1.00336 30.672 0.749268 30.0323 0.749268C29.3927 0.749268 28.7792 1.00336 28.327 1.45565C27.8747 1.90794 27.6206 2.52138 27.6206 3.16102V5.29914H21.4695V3.16102C21.4695 2.8443 21.4071 2.53069 21.2859 2.23808C21.1647 1.94547 20.9871 1.6796 20.7631 1.45565C20.5392 1.2317 20.2733 1.05405 19.9807 0.932851C19.6881 0.811649 19.3745 0.749268 19.0578 0.749268C18.741 0.749268 18.4274 0.811649 18.1348 0.932851C17.8422 1.05405 17.5763 1.2317 17.3524 1.45565C17.1284 1.6796 16.9508 1.94547 16.8296 2.23808C16.7084 2.53069 16.646 2.8443 16.646 3.16102V5.29914H10.4949V3.16102C10.4949 2.52138 10.2409 1.90794 9.78856 1.45565C9.33627 1.00336 8.72283 0.749268 8.0832 0.749268C7.44356 0.749268 6.83012 1.00336 6.37783 1.45565C5.92554 1.90794 5.67145 2.52138 5.67145 3.16102V5.29914H3.92245C2.94941 5.30387 2.01797 5.69434 1.33244 6.3849C0.646911 7.07546 0.263258 8.00972 0.265636 8.98277V35.5663C0.263258 36.5395 0.647006 37.4739 1.33269 38.1644C2.01837 38.855 2.94998 39.2454 3.92314 39.25H34.0803C35.0534 39.2452 35.9848 38.8548 36.6703 38.1642C37.3559 37.4736 37.7395 36.5394 37.7371 35.5663V8.98277C37.7395 8.0096 37.3558 7.07523 36.6701 6.38466C35.9844 5.69408 35.0535 5.30369 34.0803 5.29914ZM28.9956 3.16102C28.9956 2.88605 29.1048 2.62235 29.2992 2.42792C29.4937 2.2335 29.7574 2.12427 30.0323 2.12427C30.3073 2.12427 30.571 2.2335 30.7654 2.42792C30.9598 2.62235 31.0691 2.88605 31.0691 3.16102V5.29914H28.9956V3.16102ZM18.021 3.16102C18.021 2.88605 18.1302 2.62235 18.3247 2.42792C18.5191 2.2335 18.7828 2.12427 19.0578 2.12427C19.3327 2.12427 19.5964 2.2335 19.7909 2.42792C19.9853 2.62235 20.0945 2.88605 20.0945 3.16102V5.29914H18.021V3.16102ZM7.04645 3.16102C7.04645 2.88605 7.15568 2.62235 7.35011 2.42792C7.54453 2.2335 7.80824 2.12427 8.0832 2.12427C8.35816 2.12427 8.62186 2.2335 8.81629 2.42792C9.01072 2.62235 9.11995 2.88605 9.11995 3.16102V5.29914H7.04576L7.04645 3.16102ZM3.92245 6.67414H5.67145V8.00377C5.6741 8.3875 5.7678 8.76512 5.94487 9.10557C6.12193 9.44602 6.37729 9.73957 6.68993 9.96207C7.00258 10.1846 7.36358 10.3297 7.74325 10.3854C8.12292 10.4412 8.5104 10.406 8.87382 10.2828C8.95914 10.2533 9.0378 10.2072 9.10531 10.1472C9.17282 10.0872 9.22785 10.0146 9.26727 9.93333C9.3067 9.8521 9.32973 9.76389 9.33506 9.67375C9.3404 9.58361 9.32792 9.49331 9.29835 9.40799C9.26879 9.32267 9.2227 9.24401 9.16274 9.1765C9.10277 9.10899 9.03009 9.05396 8.94886 9.01453C8.86762 8.97511 8.77941 8.95208 8.68927 8.94675C8.59914 8.94141 8.50883 8.95389 8.42351 8.98346C8.26726 9.0363 8.10071 9.05134 7.93752 9.02732C7.77433 9.00331 7.61917 8.94094 7.48476 8.84532C7.35036 8.7497 7.24056 8.62357 7.16436 8.47728C7.08817 8.33098 7.04776 8.16871 7.04645 8.00377V6.67414H16.646V8.00377C16.6467 8.64318 16.9011 9.2562 17.3532 9.70833C17.8053 10.1605 18.4183 10.4148 19.0578 10.4155C19.6497 10.4451 20.5166 10.1529 20.2733 9.40833C20.2437 9.323 20.1976 9.24433 20.1376 9.17682C20.0775 9.10931 20.0048 9.05429 19.9236 9.0149C19.8423 8.97551 19.754 8.95252 19.6639 8.94724C19.5737 8.94196 19.4834 8.9545 19.3981 8.98414C19.2418 9.03701 19.0752 9.05203 18.9119 9.02799C18.7487 9.00394 18.5935 8.9415 18.4591 8.8458C18.3246 8.75011 18.2148 8.62388 18.1387 8.4775C18.0625 8.33112 18.0222 8.16877 18.021 8.00377V6.67414H27.6206V8.00377C27.6233 8.38742 27.717 8.76495 27.894 9.10533C28.071 9.44571 28.3263 9.73921 28.6389 9.9617C28.9514 10.1842 29.3123 10.3293 29.6919 10.3851C30.0715 10.441 30.4589 10.4059 30.8223 10.2828C30.9934 10.2223 31.1337 10.0966 31.2124 9.93301C31.2912 9.76946 31.3021 9.5814 31.2427 9.40985C31.1834 9.2383 31.0586 9.09719 30.8956 9.01731C30.7326 8.93743 30.5446 8.92526 30.3726 8.98346C30.2164 9.03646 30.0498 9.05162 29.8865 9.02767C29.7233 9.00373 29.5681 8.94136 29.4336 8.84571C29.2992 8.75006 29.1893 8.62386 29.1132 8.47749C29.037 8.33112 28.9967 8.16876 28.9956 8.00377V6.67414H34.0803C34.6888 6.6785 35.2707 6.92399 35.6985 7.35676C36.1262 7.78954 36.3649 8.37428 36.3621 8.98277V12.4443C36.2608 12.3814 36.1445 12.3468 36.0253 12.344L1.64064 12.3797V8.98346C1.63753 8.37461 1.87613 7.78941 2.30406 7.35632C2.732 6.92323 3.31361 6.67832 3.92245 6.67414ZM34.0803 37.875H3.92245C3.31397 37.8706 2.73206 37.6251 2.30431 37.1923C1.87656 36.7596 1.63789 36.1748 1.64064 35.5663V13.7547L36.0266 13.719C36.1454 13.7159 36.2612 13.6812 36.3621 13.6186V35.5663C36.3649 36.1749 36.1261 36.7598 35.6982 37.1926C35.2703 37.6254 34.6889 37.8708 34.0803 37.875Z">
                                                </path>
                                                <path d="M10.7947 16.9096H6.35895C6.17661 16.9096 6.00174 16.9821 5.87281 17.111C5.74388 17.2399 5.67145 17.4148 5.67145 17.5971V21.6039C5.67145 21.7862 5.74388 21.9611 5.87281 22.09C6.00174 22.219 6.17661 22.2914 6.35895 22.2914H10.7947C10.977 22.2914 11.1519 22.219 11.2808 22.09C11.4098 21.9611 11.4822 21.7862 11.4822 21.6039V17.5971C11.4822 17.4148 11.4098 17.2399 11.2808 17.111C11.1519 16.9821 10.977 16.9096 10.7947 16.9096ZM10.1072 20.9164H7.04645V18.2846H10.1072V20.9164ZM20.5503 16.9096H16.1139C15.9315 16.9096 15.7567 16.9821 15.6278 17.111C15.4988 17.2399 15.4264 17.4148 15.4264 17.5971V21.6039C15.4264 21.7862 15.4988 21.9611 15.6278 22.09C15.7567 22.219 15.9315 22.2914 16.1139 22.2914H20.5496C20.732 22.2914 20.9068 22.219 21.0358 22.09C21.1647 21.9611 21.2371 21.7862 21.2371 21.6039V17.5971C21.2371 17.4148 21.1647 17.2399 21.0358 17.111C20.9068 16.9821 20.7327 16.9096 20.5503 16.9096ZM19.8628 20.9164H16.8014V18.2846H19.8621L19.8628 20.9164ZM30.3053 16.9096H25.8695C25.6872 16.9096 25.5123 16.9821 25.3834 17.111C25.2544 17.2399 25.182 17.4148 25.182 17.5971V21.6039C25.182 21.7862 25.2544 21.9611 25.3834 22.09C25.5123 22.219 25.6872 22.2914 25.8695 22.2914H30.306C30.4883 22.2914 30.6632 22.219 30.7921 22.09C30.921 21.9611 30.9935 21.7862 30.9935 21.6039V17.5971C30.9935 17.4148 30.921 17.2399 30.7921 17.111C30.6632 16.9821 30.4876 16.9096 30.3053 16.9096ZM29.6178 20.9164H26.557V18.2846H29.6185L29.6178 20.9164ZM10.7947 26.6646H6.35895C6.17661 26.6646 6.00174 26.737 5.87281 26.8659C5.74388 26.9949 5.67145 27.1697 5.67145 27.3521V31.3588C5.67145 31.5412 5.74388 31.716 5.87281 31.845C6.00174 31.9739 6.17661 32.0463 6.35895 32.0463H10.7947C10.977 32.0463 11.1519 31.9739 11.2808 31.845C11.4098 31.716 11.4822 31.5412 11.4822 31.3588V27.3521C11.4822 27.1697 11.4098 26.9949 11.2808 26.8659C11.1519 26.737 10.977 26.6646 10.7947 26.6646ZM10.1072 30.6713H7.04645V28.0396H10.1072V30.6713ZM20.5503 26.6646H16.1139C15.9315 26.6646 15.7567 26.737 15.6278 26.8659C15.4988 26.9949 15.4264 27.1697 15.4264 27.3521V31.3588C15.4264 31.5412 15.4988 31.716 15.6278 31.845C15.7567 31.9739 15.9315 32.0463 16.1139 32.0463H20.5496C20.732 32.0463 20.9068 31.9739 21.0358 31.845C21.1647 31.716 21.2371 31.5412 21.2371 31.3588V27.3521C21.2371 27.1697 21.1647 26.9949 21.0358 26.8659C20.9068 26.737 20.7327 26.6646 20.5503 26.6646ZM19.8628 30.6713H16.8014V28.0396H19.8621L19.8628 30.6713ZM30.3053 26.6646H25.8695C25.6872 26.6646 25.5123 26.737 25.3834 26.8659C25.2544 26.9949 25.182 27.1697 25.182 27.3521V31.3588C25.182 31.5412 25.2544 31.716 25.3834 31.845C25.5123 31.9739 25.6872 32.0463 25.8695 32.0463H30.306C30.4883 32.0463 30.6632 31.9739 30.7921 31.845C30.921 31.716 30.9935 31.5412 30.9935 31.3588V27.3521C30.9935 27.1697 30.921 26.9949 30.7921 26.8659C30.6632 26.737 30.4876 26.6646 30.3053 26.6646ZM29.6178 30.6713H26.557V28.0396H29.6185L29.6178 30.6713Z">
                                                </path>
                                            </svg>
                                        </div>
                                        <div class="rs-working-list-content">
                                            <h6 class="rs-working-list-title">Date:</h6>
                                            <p class="rs-working-list-desc"> February 24, 2025 </p>
                                        </div>
                                    </div>
                                    <div class="rs-working-list-item">
                                        <div class="rs-working-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 38">
                                                <path d="M31.9634 32.8631H23.6776L22.8106 31.9962L24.9862 29.8207C25.1035 29.7038 25.1895 29.5592 25.2362 29.4002C25.2828 29.2412 25.2886 29.0731 25.2529 28.9113C25.218 28.7494 25.1428 28.599 25.0343 28.4739C24.9258 28.3488 24.7874 28.2531 24.6321 28.1957L13.2764 23.9695C12.8778 23.8211 12.4431 23.9157 12.1422 24.2167C11.8413 24.5176 11.7466 24.9522 11.895 25.3509L14.6908 32.8631H3.30567C2.19364 32.8631 1.28906 31.9586 1.28906 30.8466V16.9426C1.28906 16.5866 1.00057 16.2981 0.644531 16.2981C0.288492 16.2981 0 16.5866 0 16.9426V30.8466C0 32.6693 1.48294 34.1523 3.30567 34.1523H15.1706L16.1212 36.7064C16.1786 36.8618 16.2743 37.0002 16.3994 37.1088C16.5245 37.2174 16.675 37.2926 16.837 37.3275C16.9987 37.3632 17.1669 37.3574 17.3258 37.3108C17.4847 37.2642 17.6293 37.1782 17.7462 37.0608L19.9217 34.8853L22.1363 37.0999C22.236 37.1997 22.3544 37.2788 22.4847 37.3326C22.615 37.3865 22.7547 37.4141 22.8957 37.4138C23.1708 37.4138 23.4459 37.3091 23.6553 37.0999L25.0253 35.73C25.4439 35.3112 25.4439 34.6297 25.0252 34.2109L24.9666 34.1525H31.9633C32.3194 34.1525 32.6079 33.864 32.6079 33.5079C32.6079 33.1519 32.3194 32.8631 31.9634 32.8631ZM22.8958 36.0361L20.3775 33.5178C20.3177 33.4579 20.2466 33.4104 20.1684 33.378C20.0902 33.3456 20.0063 33.329 19.9217 33.3291C19.837 33.329 19.7532 33.3456 19.675 33.378C19.5967 33.4104 19.5257 33.4579 19.4659 33.5178L17.1658 35.8178L13.2669 25.3414L23.7432 29.2404L21.4432 31.5405C21.3834 31.6003 21.3359 31.6714 21.3035 31.7496C21.2711 31.8278 21.2544 31.9116 21.2545 31.9963C21.2545 32.0809 21.2711 32.1647 21.3035 32.2429C21.3359 32.3211 21.3834 32.3922 21.4433 32.452L23.9616 34.9702L22.8958 36.0361Z">
                                                </path>
                                                <path d="M40.6943 0.586304H38.4409C38.0848 0.586304 37.7963 0.874796 37.7963 1.23083C37.7963 1.58687 38.0848 1.87537 38.4409 1.87537H40.6943C41.8063 1.87537 42.7109 2.77994 42.7109 3.89198V7.93026H1.28906V3.89198C1.28906 2.78003 2.19364 1.87537 3.30567 1.87537H35.46C35.816 1.87537 36.1045 1.58687 36.1045 1.23083C36.1045 0.874796 35.816 0.586304 35.46 0.586304H3.30567C1.48294 0.586304 0 2.06924 0 3.89198V14.0422C0 14.3983 0.288492 14.6868 0.644531 14.6868C1.00057 14.6868 1.28906 14.3983 1.28906 14.0422V9.21941H42.7109V30.8466C42.7109 31.9586 41.8064 32.8632 40.6943 32.8632H35.0518C34.6957 32.8632 34.4072 33.1517 34.4072 33.5078C34.4072 33.8638 34.6957 34.1523 35.0518 34.1523H40.6943C42.5171 34.1523 44 32.6693 44 30.8466V3.89198C44 2.06924 42.5171 0.586304 40.6943 0.586304Z">
                                                </path>
                                                <path d="M4.27092 4.90286C4.27092 5.56226 4.80545 6.09679 5.46477 6.09679C6.12408 6.09679 6.65861 5.56226 6.65861 4.90286C6.65861 4.24346 6.12408 3.70901 5.46477 3.70901C4.80545 3.70901 4.27092 4.24346 4.27092 4.90286ZM7.94355 4.90286C7.94355 5.56226 8.47808 6.09679 9.13739 6.09679C9.7967 6.09679 10.3312 5.56226 10.3312 4.90286C10.3312 4.24346 9.7967 3.70901 9.13739 3.70901C8.47808 3.70901 7.94355 4.24346 7.94355 4.90286ZM11.6162 4.90286C11.6162 5.56226 12.1507 6.09679 12.81 6.09679C13.4693 6.09679 14.0039 5.56226 14.0039 4.90286C14.0039 4.24346 13.4693 3.70901 12.81 3.70901C12.1507 3.70901 11.6162 4.24346 11.6162 4.90286ZM7.88975 23.4094H7.89345C8.16587 23.4094 8.40907 23.2381 8.50051 22.9813L10.0971 18.5012L11.6226 22.9731C11.6659 23.1 11.7477 23.2101 11.8565 23.2884C11.9654 23.3666 12.0959 23.4089 12.2299 23.4095H12.2326C12.3662 23.4095 12.4965 23.368 12.6055 23.2907C12.7144 23.2134 12.7967 23.1042 12.8409 22.9781L15.0051 16.8038C15.0617 16.6425 15.0518 16.4653 14.9777 16.3113C14.9036 16.1572 14.7713 16.0389 14.61 15.9823C14.4486 15.9258 14.2715 15.9357 14.1174 16.0098C13.9633 16.0839 13.845 16.2162 13.7885 16.3775L12.2408 20.7929L10.7204 16.3357C10.548 15.7693 9.68292 15.7641 9.50323 16.3275L7.90445 20.8138L6.3837 16.3883C6.35623 16.3082 6.31325 16.2344 6.25722 16.1709C6.20118 16.1075 6.13319 16.0557 6.05713 16.0185C5.98106 15.9814 5.89842 15.9596 5.81393 15.9544C5.72944 15.9492 5.64475 15.9607 5.56471 15.9883C5.48466 16.0158 5.41082 16.0588 5.34739 16.1148C5.28397 16.1709 5.2322 16.2389 5.19505 16.3149C5.15791 16.391 5.1361 16.4736 5.13089 16.5581C5.12568 16.6425 5.13716 16.7272 5.16467 16.8073L7.28389 22.9743C7.32731 23.1007 7.40894 23.2105 7.51749 23.2884C7.62603 23.3664 7.75612 23.4086 7.88975 23.4094ZM19.815 23.4094H19.8187C20.0912 23.4094 20.3344 23.2381 20.4258 22.9813L22.0223 18.5012L23.5479 22.9731C23.5912 23.1 23.673 23.2101 23.7818 23.2884C23.8907 23.3666 24.0212 23.4089 24.1552 23.4095H24.1579C24.2915 23.4095 24.4218 23.368 24.5308 23.2907C24.6397 23.2134 24.722 23.1042 24.7662 22.9781L26.9304 16.8038C26.9869 16.6425 26.9771 16.4653 26.903 16.3113C26.8289 16.1572 26.6966 16.0389 26.5353 15.9823C26.3739 15.9258 26.1967 15.9357 26.0427 16.0098C25.8886 16.0839 25.7703 16.2162 25.7138 16.3775L24.1661 20.7929L22.6456 16.3357C22.4732 15.7692 21.6082 15.7641 21.4285 16.3275L19.8297 20.8138L18.309 16.3884C18.1933 16.0517 17.8265 15.8723 17.49 15.9884C17.41 16.0159 17.3361 16.0589 17.2727 16.1149C17.2093 16.171 17.1575 16.2389 17.1203 16.315C17.0832 16.391 17.0614 16.4737 17.0562 16.5581C17.051 16.6426 17.0624 16.7273 17.09 16.8073L19.2092 22.9744C19.2526 23.1007 19.3343 23.2105 19.4428 23.2884C19.5514 23.3663 19.6814 23.4086 19.815 23.4094ZM31.547 23.4094H31.5506C31.823 23.4094 32.0662 23.2381 32.1576 22.9813L33.7542 18.5012L35.2798 22.9731C35.3231 23.1 35.4048 23.2101 35.5137 23.2884C35.6225 23.3666 35.753 23.4089 35.8871 23.4095H35.8897C36.0233 23.4095 36.1536 23.368 36.2626 23.2907C36.3716 23.2134 36.4538 23.1042 36.498 22.9781L38.6622 16.8038C38.7187 16.6425 38.7088 16.4653 38.6347 16.3113C38.5606 16.1572 38.4284 16.0389 38.267 15.9823C38.1057 15.9258 37.9285 15.9357 37.7745 16.0098C37.6204 16.0839 37.5021 16.2162 37.4455 16.3775L35.8979 20.7929L34.3775 16.3357C34.2052 15.7693 33.34 15.7641 33.1604 16.3275L31.5616 20.8138L30.0407 16.3884C30.0133 16.3083 29.9703 16.2345 29.9142 16.171C29.8582 16.1076 29.7902 16.0558 29.7142 16.0187C29.6381 15.9815 29.5555 15.9597 29.471 15.9545C29.3865 15.9493 29.3018 15.9608 29.2218 15.9884C29.1417 16.0159 29.0679 16.0589 29.0044 16.1149C28.941 16.171 28.8892 16.2389 28.8521 16.315C28.815 16.391 28.7931 16.4737 28.7879 16.5581C28.7827 16.6426 28.7942 16.7273 28.8217 16.8073L30.941 22.9744C30.9845 23.1008 31.0661 23.2105 31.1747 23.2884C31.2832 23.3664 31.4133 23.4086 31.547 23.4094Z">
                                                </path>
                                            </svg>
                                        </div>
                                        <div class="rs-working-list-content">
                                            <h6 class="rs-working-list-title">Website</h6>
                                            <p class="rs-working-list-desc"><a href="#">See Live site</a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h3 class="rs-portfolio-details-title mt-45 mb-15">What we’ve accomplished together</h3>
                            <p class="rs-portfolio-details-desc desc-one">Discover how we’ve helped businesses grow transform
                                and succeed
                                through strategic consulting
                                solutions Explore our portfolio of the impactful projects each tailored to solve unique business
                                challenges From startups to established enterprises our projects demonstrate real-world results
                                and measurable growth Were turn strategies into success See how our work drives innovation,
                                growth, and sustainable change Every project tells a story of transformation dive into the
                                journeys of our clients and the results we delivered.</p>

                            <p class="rs-portfolio-details-desc desc-two">“Projects how we’ve helped businesses grow transform
                                and
                                succeed through strategic consulting
                                solutions. Explore our portfolio of impactful projects each tailored to solve unique business
                                challenges From startups to established enterprises our projects demonstrate real-world
                                measurable growth success”</p>
                            <h3 class="rs-portfolio-details-title mb-10">Project Overview</h3>
                            <p class="rs-portfolio-desc desc-three">succeed how we’ve helped businesses grow transform and
                                succeed through strategic consulting
                                solutions. Explore our portfolio of impactful projects each tailored to solve unique business
                                challenges. From startups to established enterprises our projects demonstrate real-world results
                                and measurable growth We turn strategies into success. See how our work drives innovation,
                                growth, and sustainable change Every project tells a story of transformation dive into the
                                journeys of our clients and the results we delivered.</p>
                            <div class="rs-portfolio-details-content-wrapper">
                                <div class="rs-portfolio-details-content-left">
                                    <div class="rs-portfolio-details-thumb">
                                        <img src="assets/images/services/details/services-details-02.webp" alt="image">
                                    </div>
                                    <h5>Highlight Feature</h5>
                                    <div class="rs-portfolio-details-content-list">
                                        <p>
                                            Projects demonstrate real-world results and measurable for growth We turn strategies
                                            into success. See how our work drives innovation, growth, and
                                        </p>
                                        <p>Discover how we’ve helped businesses grow transform and succeed through strategic
                                            consulting solutions. Explore our portfolio of impactful projects each.</p>
                                    </div>
                                </div>
                                <div class="rs-portfolio-details-content-right">
                                    <div class="rs-portfolio-details-thumb">
                                        <img src="assets/images/services/details/services-details-03.webp" alt="image">
                                        <h5>The Results</h5>
                                        <div class="rs-portfolio-details-content-list">
                                            <p>
                                                Discover how we’ve helped businesses grow transform and succeed through strategic
                                                consulting solutions. Explore our portfolio of impactful projects each
                                            </p>
                                            <p>Explore our portfolio of impactful THE projects each tailored to OUR solve unique
                                                business challenges. From startups to established enterprises our projects</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-postbox-more-navigation">
                            <div class="rs-postbox-more-item">
                                <a href="#">
                                    <i class="ri-arrow-left-s-line"></i>
                                    Prev Post
                                </a>
                            </div>
                            <div class="rs-postbox-more-item">
                                <a href="#">
                                    Next Post
                                    <i class="ri-arrow-right-s-line"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- portfolio details area  end -->

        <!-- faq area start -->
        <section class="rs-faq-area section-space rs-faq-one theme-secondary">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-faq-wrapper">
                            <div class="rs-faq-left">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle is-white">
                              Frequently asked questions
                           </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left is-white mb-20">Frequently Asked
                                        Question</h2>
                                    <p class="rs-section-desc">Find answers to our question about our consulting coverage
                                        options.</p>
                                </div>
                                <div class="rs-faq-contact">
                                    <div class="rs-faq-contact-info">
                                        <h5 class="rs-faq-contact-title">Still Have Questions?</h5>
                                        <p class="rs-faq-contact-desc">We’re here to help you!</p>
                                    </div>
                                    <div class="rs-faq-contact-btn">
                                        <a class="rs-btn has-icon has-bg-white has-bg-secondary" href="contact.php">Contact Us
                                            <span class="icon-box">
                                    <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                       xmlns="http://www.w3.org/2000/svg">
                                       <path
                                          d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                          fill="white" />
                                    </svg>

                                    <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                       xmlns="http://www.w3.org/2000/svg">
                                       <path
                                          d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                          fill="white" />
                                    </svg>
                                 </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-faq-right">
                                <div class="rs-faq-content rs-accordion-one">
                                    <div class="accordion-wrapper">
                                        <div class="accordion" id="accordionExampleOne">
                                            <div class="rs-accordion-item has-bg-active active">
                                                <h4 class="accordion-header" id="headingOne">
                                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                        How do your startups with product
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h4>
                                                <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Launching a startup begins with more than just an
                                                        idea it starts with creating a product that solves a real problem.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingTwo">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                        Can your with fundraising investor
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Securing the right investment is essential for
                                                        fueling growth and scaling a business. Our fundraising approach is designed
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingThree">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                        What makes startup consulting
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Startup consulting helps entrepreneurs turn ideas
                                                        into thriving businesses. By combining market insights, strategy, and
                                                        execution</div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingFour">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                                        Do you provide financial planning
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Financial planning is the foundation of long-term
                                                        stability and growth. It helps businesses and individuals make informed</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- faq area end -->

        <!-- video area start -->
        <div class="rs-video-area rs-video-one rs-video-one">
            <div class="rs-video-bg-thumb include-bg" data-background="assets/images/bg/video-bg-thumb-01.webp">
            </div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-4">
                        <div class="rs-video-wrapper text-center">
                            <div class="rs-video-play-btn rs-tween_max_btn-yes gsap-move-no">
                                <a href="https://www.youtube.com/watch?v=go7QYaQR494" class="rs-play-btn popup-video is-large is-white"><i class="ri-play-large-fill"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- video area end -->

        <!-- cta area start -->
        <div class="rs-cta-area rs-cta-six">
            <div class="container-fluid g-0">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-cta-content-wrapper">
                            <span class="rs-cta-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="6" height="11" viewBox="0 0 6 11" fill="none">
                           <path
                              d="M0.50204 0.439454C0.811629 0.16438 1.28548 0.192407 1.56063 0.501954L5.56063 5.00195C5.81308 5.28608 5.81308 5.71392 5.56063 5.99805L1.56063 10.498C1.28548 10.8076 0.811629 10.8356 0.50204 10.5605C0.192493 10.2854 0.164466 9.81154 0.43954 9.50195L3.99618 5.5L0.43954 1.49805C0.164466 1.18846 0.192493 0.714606 0.50204 0.439454Z"
                              fill="#AB052D"></path>
                        </svg>
                     </span>
                            <div class="rs-cta-content">
                                <p>Real Consulting Success: Inspiring Case Studies for Growth &amp; Innovation.
                                    <a href="contact.php">Got A project in mind?</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- cta area end -->

    </main>
    <!-- Body main wrapper end -->

    <!-- footer area start -->
<footer class="rs-footer-area rs-footer-one theme-secondary">
    <div class="rs-footer-shape-one">
        <img src="assets/images/shape/footer-shape-01.webp" alt="image">
    </div>
    <div class="rs-footer-shape-two">
        <img src="assets/images/shape/footer-shape-02.webp" alt="image">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="rs-footer-wrapper">
                    <div class="rs-footer-left">
                        <div class="rs-footer-widget footer-1-col-1">
                            <div class="rs-footer-widget-logo">
                                <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA"></a>
                            </div>
                            <div class="rs-footer-widget-content">
                                <p class="rs-footer-widget-desc">
                                    ICEF INDIA is a premier organization providing end-to-end solutions in Assessment, Recruitment, and Workforce Development since 2000.
                                </p>
                                <div class="rs-footer-widget-contact-info">
                                    <div class="rs-footer-content-item">
                                        <span>Call us:</span>
                                        <a href="tel:+911204221735">+91 120 422 1735</a>
                                    </div>
                                    <div class="rs-footer-content-item">
                                        <span>Email:</span>
                                        <a href="mailto:sales@icefindia.in">sales@icefindia.in</a>
                                    </div>
                                    <div class="rs-footer-content-item">
                                        <span>Hours: Mon-Fri: 8.00am - 18.00pm</span>
                                    </div>
                                </div>
                                <div class="rs-footer-widget-social">
                                    <div class="rs-footer-social theme-social has-border">
                                        <a href="#"><svg width="14" height="22" viewBox="0 0 14 22" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M11.624 11.9541L12.193 8.54137L8.63572 8.54137V6.32676C8.63572 5.39311 9.13264 4.48303 10.7258 4.48303H12.343V1.57748C12.343 1.57748 10.8755 1.34692 9.47233 1.34692C6.54282 1.34692 4.62796 2.98146 4.62796 5.94041L4.62796 8.54137H1.37158L1.37158 11.9541H4.62796L4.62796 20.2041H8.63572L8.63572 11.9541H11.624Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M17.6045 5.45036C17.5641 4.53485 17.4161 3.9055 17.204 3.3601C16.9852 2.78121 16.6486 2.26294 16.2077 1.83208C15.7768 1.39452 15.2551 1.0545 14.6829 0.839154C14.1344 0.627106 13.5083 0.479009 12.5928 0.438686C11.6705 0.394863 11.3777 0.384766 9.03843 0.384766C6.69917 0.384766 6.40637 0.394863 5.48747 0.435253C4.57199 0.475643 3.94261 0.623808 3.39738 0.835721C2.81832 1.0545 2.30005 1.39108 1.86919 1.83208C1.43163 2.26291 1.09178 2.78461 0.876264 3.3568C0.664216 3.9055 0.516152 4.53148 0.475796 5.44692C0.432006 6.36927 0.421875 6.66206 0.421875 9.00132C0.421875 11.3406 0.432006 11.6334 0.472363 12.5523C0.512753 13.4678 0.660917 14.0971 0.872999 14.6425C1.09178 15.2214 1.43163 15.7397 1.86919 16.1706C2.30005 16.6081 2.82175 16.9481 3.39395 17.1635C3.94258 17.3755 4.56856 17.5236 5.4842 17.564C6.40294 17.6045 6.6959 17.6144 9.03516 17.6144C11.3744 17.6144 11.6672 17.6045 12.5861 17.564C13.5016 17.5236 14.131 17.3756 14.6762 17.1635C15.2489 16.9421 15.7689 16.6035 16.2031 16.1693C16.6372 15.7352 16.9759 15.2152 17.1973 14.6425C17.4092 14.0939 17.5574 13.4678 17.5978 12.5523C17.6382 11.6334 17.6483 11.3406 17.6483 9.00132C17.6483 6.66206 17.6449 6.36923 17.6045 5.45036ZM16.0529 12.485C16.0159 13.3264 15.8745 13.7808 15.7567 14.0837C15.4672 14.8343 14.8715 15.4301 14.1208 15.7196C13.8179 15.8374 13.3603 15.9787 12.5221 16.0157C11.6133 16.0562 11.3408 16.0662 9.04186 16.0662C6.74296 16.0662 6.46699 16.0562 5.56148 16.0157C4.72002 15.9787 4.26563 15.8374 3.96271 15.7196C3.5892 15.5815 3.24922 15.3628 2.97322 15.0767C2.68712 14.7973 2.46834 14.4607 2.33027 14.0872C2.21247 13.7842 2.07114 13.3264 2.03421 12.4884C1.99369 11.5796 1.98373 11.3069 1.98373 9.00802C1.98373 6.70911 1.99369 6.43315 2.03421 5.5278C2.07114 4.68634 2.21247 4.23196 2.33027 3.92903C2.46834 3.55535 2.68712 3.21544 2.97665 2.93937C3.25588 2.65328 3.59246 2.4345 3.96614 2.2966C4.26907 2.17879 4.72689 2.03743 5.56491 2.00037C6.47369 1.95998 6.74639 1.94988 9.04513 1.94988C11.3475 1.94988 11.62 1.95998 12.5255 2.00037C13.367 2.03746 13.8214 2.17876 14.1243 2.29656C14.4978 2.4345 14.8378 2.65328 15.1138 2.93937C15.3999 3.21877 15.6186 3.55535 15.7567 3.92903C15.8745 4.23196 16.0159 4.68961 16.0529 5.5278C16.0933 6.43658 16.1034 6.70911 16.1034 9.00802C16.1034 11.3069 16.0933 11.5762 16.0529 12.485Z"
                                                    fill="white"></path>
                                                <path
                                                    d="M9.0335 4.57741C6.58997 4.57741 4.60742 6.55982 4.60742 9.00349C4.60742 11.4472 6.58997 13.4296 9.0335 13.4296C11.4771 13.4296 13.4596 11.4472 13.4596 9.00349C13.4596 6.55982 11.4771 4.57741 9.0335 4.57741ZM9.0335 11.8746C7.44826 11.8746 6.16237 10.5889 6.16237 9.00349C6.16237 7.41811 7.44826 6.13243 9.03347 6.13243C10.6188 6.13243 11.9046 7.41811 11.9046 9.00349C11.9046 10.5889 10.6188 11.8746 9.0335 11.8746ZM14.668 4.40239C14.668 4.97303 14.2053 5.4357 13.6345 5.4357C13.0639 5.4357 12.6013 4.97303 12.6013 4.40239C12.6013 3.83167 13.0639 3.36914 13.6346 3.36914C14.2053 3.36914 14.668 3.83164 14.668 4.40239Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M9.35332 6.88729L14.6472 0.733521H13.3928L8.79603 6.07675L5.12465 0.733521H0.890137L6.44199 8.81343L0.890137 15.2666H2.1447L6.99896 9.62397L10.8762 15.2666H15.1107L9.35332 6.88729ZM7.63502 8.88462L7.0725 8.08004L2.59674 1.67793H4.52367L8.13567 6.84464L8.69818 7.64922L13.3933 14.3651H11.4664L7.63502 8.88462Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M17.7973 17.7992V11.3532C17.7973 8.18522 17.1153 5.76522 13.4193 5.76522C11.6373 5.76522 10.4493 6.73322 9.96527 7.65722H9.92126V6.05122H6.42326V17.7992H10.0753V11.9692C10.0753 10.4292 10.3613 8.95522 12.2533 8.95522C14.1233 8.95522 14.1453 10.6932 14.1453 12.0572V17.7772H17.7973V17.7992ZM0.483266 6.05122H4.13527V17.7992H0.483266V6.05122ZM2.30927 0.199219C1.14327 0.199219 0.197266 1.14522 0.197266 2.31122C0.197266 3.47722 1.14327 4.44522 2.30927 4.44522C3.47527 4.44522 4.42127 3.47722 4.42127 2.31122C4.42127 1.14522 3.47527 0.199219 2.30927 0.199219Z"
                                                    fill="white"></path>
                                            </svg></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rs-footer-right">
                        <div class="rs-footer-widget-wrapper">
                            <div class="rs-footer-widget footer-1-col-2">
                                <h5 class="rs-footer-widget-title">About​</h5>
                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="industry-clients.php">Industry we work with</a></li>
                                        <li><a href="why-choose-us.php">Why choose us</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                        <li><a href="contact.php">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rs-footer-widget footer-1-col-3">
                                <h5 class="rs-footer-widget-title">Services</h5>
                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="it-emerging-tech-enablement.php">IT & Emerging Tech Enablement</a></li>
                                        <li><a href="assessment-and-testing.php">Assessment & Testing</a></li>
                                        <li><a href="recruitment-and-hiring.php">Recruitment & Hiring</a></li>
                                        <li><a href="exam-management.php">Exam Management</a></li>
                                        <li><a href="manpower-and-workforce.php">Manpower & Workforce</a></li>
                                        <li><a href="call-center-and-bpos.php">Call Center & BPOs</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rs-footer-widget footer-1-col-4">
                                <h5 class="rs-footer-widget-title">Quick Links</h5>

                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="#solutions">Our Solutions</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                        <li><a href="industry-clients.php#clients">Clientele</a></li>
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="rs-footer-subscribe-from">
                            <h5 class="rs-footer-subscribe-title">Subscribe Newsletter</h5>
                            <div class="rs-cta-input">
                                <input id="email2" name="name" type="text" placeholder="Enter your email">
                                <button type="submit" class="rs-btn has-icon has-bg-secondary has-sm-radius">
                                    Send Now
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white"></path>
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white"></path>
                                        </svg>
                                    </span>
                                </button>
                            </div>
                        </div>
                        <div class="rs-footer-brand">
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-07.webp" alt="image">
                            </div>
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-08.webp" alt="image">
                            </div>
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-09.webp" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="rs-footer-copyright-area rs-copyright-one">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="rs-footer-copyright-wrapper">
                        <div class="rs-footer-copyright-left">
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright-link">
                                    <a href="terms-conditions.php">Terms & Agreements</a>
                                </div>
                            </div>
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright-link">
                                    <a href="privacy-policy.php">Privacy policy</a>
                                </div>
                            </div>
                        </div>
                        <div class="rs-footer-copyright-right">
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright">
                                    <p class="underline">Copyright © <span id="year">2025</span> ICEF INDIA. All rights reserved. Designed by <a
                                            target="_blank" href="https://agumentiksoftware.com/">AGUMENTIK.</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer area end -->
    <!-- footer area end -->

        <!-- back to top -->
    <!-- Backtotop start -->
    <div class="backtotop-wrap cursor-pointer">
        <i class="ri-arrow-up-s-line"></i>
    </div>
    <!-- Backtotop end -->

    <!-- JS here -->
    <script src="assets/js/vendor/jquery-3.7.1.min.js"></script>
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/meanmenu@2.0.8/jquery.meanmenu.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/wowjs@1.1.3/dist/wow.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/magnific-popup@1.1.0/dist/jquery.magnific-popup.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/isotope-layout@3.0.6/dist/isotope.pkgd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/imagesloaded@5.0.0/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/vendor/ajax-form.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@studio-freight/lenis@1.0.34/dist/lenis.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
    <script src="assets/js/plugins/rs-scroll-trigger.min.js"></script>
    <script src="assets/js/plugins/rs-splitText.min.js"></script>
    <!-- Custom theme scripts (Restored) -->
    <script src="assets/js/plugins/rs-anim-int.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery.appear@1.0.1/jquery.appear.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-nice-select@1.1.0/js/jquery.nice-select.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/nouislider@15.7.1/dist/nouislider.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/odometer@0.4.8/odometer.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>
