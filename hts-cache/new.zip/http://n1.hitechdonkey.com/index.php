<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="template-version" content="1.0.0">
    <title>Home - ICEF INDIA    </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/favicon-icef.png">
    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/animate.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="assets/css/plugins/flatpickr.min.css">
    <link rel="stylesheet" href="assets/css/plugins/nouislider.min.css">
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/vendor/odometer.min.css">
    <link rel="stylesheet" href="assets/css/vendor/spacing.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css">
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        /* =============================================
           Banner Contact Form — Form Overlaps Girl Image
        ============================================= */

        /* Right column: position:relative so the form can be overlaid */
        .rs-banner-form-wrap {
            position: relative;
            display: block;
        }

        /* Girl image: fully visible, natural width, drives wrapper height */
        .rs-banner-bg-img {
            display: block;
            width: 100%;
            height: auto;
            object-fit: cover;
            object-position: top center;
            opacity: 1;
            position: relative;
            z-index: 0;
        }

        /* Form card: positioned absolutely, centred over the girl image */
        .rs-banner-contact-form {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 3;
            background: #ffffff;
            border-radius: 8px;
            padding: 28px 24px;
            width: calc(100% - 60px);
            max-width: 400px;
            box-shadow: 0 8px 40px rgba(0, 0, 0, 0.28);
        }

        .rs-form-title {
            font-size: 20px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 4px;
            line-height: 1.3;
        }

        .rs-form-subtitle {
            font-size: 12px;
            color: #888;
            margin-bottom: 14px;
        }

        .rs-contact-form-banner .rs-form-row {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }

        .rs-contact-form-banner .rs-form-group {
            flex: 1 1 0%;
            min-width: 0;
            display: flex;
            flex-direction: column;
        }

        .rs-contact-form-banner .rs-form-group-full {
            flex: 1 1 100%;
        }

        .rs-contact-form-banner input,
        .rs-contact-form-banner select,
        .rs-contact-form-banner .nice-select,
        .rs-contact-form-banner textarea {
            width: 100% !important;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            font-size: 14px;
            color: #444;
            background: #fff !important;
            background-image: none !important;
            outline: none;
            transition: border-color 0.3s;
            font-family: inherit;
            appearance: none !important;
            -webkit-appearance: none !important;
            -moz-appearance: none !important;
            box-sizing: border-box;
        }

        .rs-contact-form-banner input,
        .rs-contact-form-banner select,
        .rs-contact-form-banner .nice-select {
            height: 45px !important;
            padding: 0 12px;
            line-height: 43px; /* adjusted for border */
        }

        .rs-contact-form-banner .nice-select {
            display: flex;
            align-items: center;
            float: none;
        }

        .rs-contact-form-banner .nice-select .current {
            display: block;
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            padding-right: 20px;
        }

        .rs-contact-form-banner .nice-select:after {
            content: "" !important;
            border-bottom: 2px solid #AB052D;
            border-right: 2px solid #AB052D;
            height: 8px;
            width: 8px;
            right: 15px;
            top: 40%; 
            transform: rotate(45deg);
        }

        .rs-contact-form-banner input::placeholder,
        .rs-contact-form-banner textarea::placeholder {
            color: #aaa;
        }

        .rs-contact-form-banner input:focus,
        .rs-contact-form-banner select:focus,
        .rs-contact-form-banner .nice-select:focus,
        .rs-contact-form-banner textarea:focus {
            border-color: #AB052D;
        }

        .rs-contact-form-banner select {
            cursor: pointer;
            color: #aaa;
        }

        .rs-contact-form-banner select option:not([disabled]) {
            color: #444;
        }

        .rs-contact-form-banner textarea {
            height: 120px !important;
            padding: 12px;
            resize: none;
            line-height: normal;
        }

        /* Button: maroon matching the site header */
        .rs-banner-form-btn {
            width: 100%;
            background: #AB052D;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 12px;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 1.5px;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            text-transform: uppercase;
        }

        .rs-banner-form-btn:hover {
            background: #8c0424;
            transform: translateY(-1px);
        }

        /* Banner left content: nudge right so it's not touching the left edge */
        .rs-banner-area .rs-banner-content {
            padding-left: 60px;
        }

        /* Hero Left Button: make it maroon */
        .rs-banner-area .rs-banner-content .rs-btn {
            background-color: #AB052D;
            border-color: #AB052D;
        }

        .rs-banner-area .rs-banner-content .rs-btn:hover {
            background-color: #8c0424;
            border-color: #8c0424;
        }

        /* ---- Responsive overrides ---- */
        @media (max-width: 1399px) {
            .rs-banner-area .rs-banner-content { padding-left: 40px; }
        }

        @media (max-width: 1199px) {
            .rs-banner-area .rs-banner-content { padding-left: 24px; }
        }

        @media (max-width: 991px) {
            .rs-banner-area .rs-banner-content { padding-left: 16px; }

            .rs-banner-contact-form {
                position: relative;
                top: auto;
                left: auto;
                transform: none;
                width: 100%;
                max-width: 100%;
                margin-top: 20px;
            }

            .rs-contact-form-banner .rs-form-row {
                flex-direction: column;
                gap: 10px;
            }
        }

        /* =============================================
           Glass Effect — Transparent Header over Banner
        ============================================= */
        @media (min-width: 992px) {

            /* Overlay Header Container — only for main header, not sticky */
            .rs-header-area.header-transparent:not(.rs-sticky-header) {
                position: absolute;
                width: 100%;
                top: 40px; /* leave space for the Top Red Bar */
                left: 0;
                z-index: 1000;
                background: transparent;
            }

            /* Top Red Bar */
            .header-transparent-parent .rs-header-top {
                background: #AB052D !important;
                position: relative;
                z-index: 1002;
                height: 40px;
                display: flex !important;
                align-items: center;
            }

            /* Sticky header — glass while not yet active */
            .header-transparent.rs-sticky-header:not(.active) {
                background: rgba(43, 57, 68, 0.4) !important;
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                position: fixed;
                width: 100%;
                top: -100px;
                z-index: 1001;
                visibility: hidden;
                opacity: 0;
                pointer-events: none;
                transition: all 0.4s ease;
            }

            /* Sticky header — fully visible when active */
            .header-transparent.rs-sticky-header.active {
                background: var(--rs-theme-secondary) !important;
                backdrop-filter: none;
                -webkit-backdrop-filter: none;
                top: 0 !important;
                position: fixed;
                width: 100%;
                visibility: visible;
                opacity: 1;
                pointer-events: auto;
            }
        }

        /* Mobile Menu Fix: hide desktop nav on small screens */
        @media (max-width: 1199px) {
            .header-menu,
            .main-menu,
            #mobile-menu,
            #mobile-menu-two {
                display: none !important;
            }
        }
    </style>
</head>


<body class="rs-smoother-yes">

        <!-- preloader start -->
    <div id="pre-load">
        <div id="loader" class="loader">
            <div class="loader-container">
                <div class="loader-icon"><img src="assets/images/logo/favicon-icef.png" alt="ICEF INDIA"></div>
            </div>
        </div>
    </div>
    <!-- preloader end -->

    <!-- preloader start -->

    <div id="rs-mouse">
        <div id="cursor-ball"></div>
    </div>

    <!-- preloader end -->

    <style>
        /* Custom Mega Menu for Solutions with Feature Image */
        .main-menu .mega-grid-two {
            grid-template-columns: repeat(6, 1fr) 300px !important;
            width: 1550px !important;
            padding: 0 !important;
            overflow: hidden;
            border-radius: 10px !important;
            background-color: var(--rs-theme-secondary) !important;
        }

        @media only screen and (max-width: 1600px) {
            .main-menu .mega-grid-two {
                width: 1350px !important;
                grid-template-columns: repeat(6, 1fr) 250px !important;
            }
        }

        @media only screen and (max-width: 1366px) {
            .main-menu .mega-grid-two {
                width: 1180px !important;
                grid-template-columns: repeat(5, 1fr) !important;
            }
            .mega-menu-feature {
                display: none !important; /* Hide feature on smaller screens to keep navigation clear */
            }
        }

        .main-menu .mega-grid-one > li, .main-menu .mega-grid-two > li {
            padding: 30px 20px !important;
            border-right: 1px solid rgba(255, 255, 255, 0.1) !important;
            position: relative;
        }

        .main-menu .mega-grid-one > li::before, .main-menu .mega-grid-two > li::before {
            content: none !important;
        }

        .main-menu .mega-grid-two > li:last-child {
            border-right: none !important;
        }

        .mega-menu-feature {
            background-color: #243039 !important;
            padding: 40px 30px !important;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
        }

        .mega-menu-feature h6.title {
            color: #AB052D !important;
            font-size: 20px !important;
            margin-bottom: 12px !important;
            font-weight: 700 !important;
            text-transform: capitalize !important;
        }

        .mega-menu-feature p {
            font-size: 14px !important;
            line-height: 1.5 !important;
            color: rgba(255, 255, 255, 0.7) !important;
            margin-bottom: 20px !important;
            white-space: normal !important;
        }

        .mega-menu-feature .feature-thumb {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
        }

        .mega-menu-feature .feature-thumb img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            transition: all 0.4s ease;
        }
        
        .mega-menu-feature:hover .feature-thumb img {
            transform: scale(1.05);
        }

        /* FAQ Section Image Resizing */
        .rs-faq-two .rs-faq-wrapper {
            grid-template-columns: 1fr 480px !important;
            gap: 30px 60px !important;
            align-items: flex-start !important;
        }
        .rs-faq-two .rs-faq-thumb {
            width: 100% !important;
            max-width: 480px !important;
        }
        .rs-faq-two .rs-faq-thumb > img {
            height: 500px !important;
            object-fit: cover !important;
            border-radius: 10px !important;
        }
        .rs-faq-two .rs-faq-award {
            width: auto !important;
            max-width: 360px !important;
            padding: 15px 20px !important;
            bottom: 15px !important;
            inset-inline-start: auto !important;
            inset-inline-end: 15px !important;
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 8px !important;
            background: rgba(255, 255, 255, 0.08) !important;
            background-image: none !important;
            backdrop-filter: blur(12px) !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
        }
        .rs-faq-award-thumb {
            display: none !important;
        }
        .rs-faq-two .rs-faq-award-desc {
            font-size: 13px !important;
            line-height: 1.4 !important;
            margin-bottom: 0 !important;
            border-inline-start: none !important;
            padding-inline-start: 0 !important;
            margin-inline-start: 0 !important;
        }
        @media only screen and (max-width: 1366px) {
            .rs-faq-two .rs-faq-wrapper {
                grid-template-columns: 1fr 400px !important;
            }
            .rs-faq-two .rs-faq-thumb > img {
                height: 450px !important;
            }
        }
        @media only screen and (max-width: 991px) {
            .rs-faq-two .rs-faq-wrapper {
                grid-template-columns: 1fr !important;
            }
            .rs-faq-two .rs-faq-thumb {
                max-width: 100% !important;
            }
        }



        /* Submenu adjustments */
        .main-menu .submenu {
            width: max-content !important;
            min-width: 140px !important;
            max-width: 350px !important;
        }

        .main-menu .submenu li {
            padding-inline-start: 20px !important;
            padding-inline-end: 15px !important;
        }

        .main-menu .submenu li a {
            white-space: nowrap !important;
        }

        /* Mega menu column titles and links */
        .main-menu .mega-grid-two > li .title {
            color: #ffffff !important;
            margin-bottom: 15px !important;
            display: block !important;
        }

        .main-menu .mega-grid-two > li ul li a {
            color: rgba(255, 255, 255, 0.7) !important;
            padding: 5px 0 !important;
        }

        .main-menu .mega-grid-two > li ul li a:hover {
            color: var(--rs-theme-primary) !important;
            padding-left: 5px !important;
        }

        /* Feature Button Styling */
        .mega-menu-feature .rs-btn {
            background-color: var(--rs-theme-primary) !important;
            color: #ffffff !important;
            padding: 14px 28px !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            border-radius: 6px !important;
            font-size: 14px !important;
            font-weight: 700 !important;
            width: fit-content !important;
            height: auto !important;
            line-height: 1 !important;
            margin-bottom: 20px !important;
        }

        .mega-menu-feature .rs-btn:hover {
            background-color: #ffffff !important;
            color: var(--rs-theme-primary) !important;
        }

        /* Sticky Header Styles */
        .rs-sticky-header.active {
            background: var(--rs-theme-secondary) !important;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            top: 0 !important;
        }

        .rs-sticky-header .header-logo img {
            max-height: 50px;
            width: auto;
        }

        .rs-sticky-header .header-wrapper {
            background: transparent !important;
            padding-top: 10px;
            padding-bottom: 10px;
        }

        /* Bridge the gap to prevent dropdown closing when moving mouse from link to menu */
        .main-menu li {
            position: relative;
        }

        .main-menu .submenu,
        .main-menu .mega-menu {
            position: absolute;
            background-color: var(--rs-theme-secondary);
            z-index: 99;
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
            /* Professional transition with slight delay for closing to make it more stable and forgiving */
            transition: opacity 0.3s ease, transform 0.3s ease, visibility 0.3s ease !important;
            transition-delay: 0.2s !important;
        }

        .main-menu li:hover > .submenu,
        .main-menu li:hover > .mega-menu {
            opacity: 1;
            visibility: visible;
            pointer-events: all;
            transition-delay: 0s !important;
        }

        /* The Bridge: Invisible pseudo-element to close the physical gap between link and menu */
        .main-menu .submenu::before,
        .main-menu .mega-menu::before {
            content: "";
            position: absolute;
            top: -50px; /* Ample space to bridge any gap */
            left: 0;
            right: 0;
            height: 50px;
            background: transparent;
            z-index: 10;
            pointer-events: auto !important; /* Forces hover capture in the gap */
        }

        /* More persistent hover colors */
        .main-menu ul li:hover > a {
            color: var(--rs-theme-primary) !important;
        }
    </style>

    <!-- header area start-->
    <header>
        <div class="container-fluid g-0">
            <!-- top start -->
            <div class="rs-header-top rs-header-top-one">
                <div class="header-top-left">
                    <span class="header-top-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="6" height="11" viewBox="0 0 6 11" fill="none">
                            <path
                                d="M0.50204 0.439454C0.811629 0.16438 1.28548 0.192407 1.56063 0.501954L5.56063 5.00195C5.81308 5.28608 5.81308 5.71392 5.56063 5.99805L1.56063 10.498C1.28548 10.8076 0.811629 10.8356 0.50204 10.5605C0.192493 10.2854 0.164466 9.81154 0.43954 9.50195L3.99618 5.5L0.43954 1.49805C0.164466 1.18846 0.192493 0.714606 0.50204 0.439454Z"
                                fill="#AB052D"></path>
                        </svg>
                    </span>
                    <div class="header-top-content">
                        <p>India's Leading Integrated Assessment & Recruitment Platform Since 2000.
                            <a href="about-mission.php">Learn More</a>
                        </p>
                    </div>
                </div>
                <div class="header-top-right">
                    <div class="header-top-meta">
                        <span class="header-top-meta-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
                                <path
                                    d="M12.1641 10.5834C11.6414 10.0673 10.9888 10.0673 10.4694 10.5834C10.0732 10.9762 9.67699 11.3691 9.28744 11.7686C9.1809 11.8785 9.091 11.9018 8.96115 11.8286C8.70479 11.6887 8.43177 11.5755 8.18539 11.4224C7.03673 10.6999 6.07452 9.77097 5.22218 8.72552C4.79934 8.20613 4.42312 7.65011 4.16009 7.02417C4.10682 6.89765 4.11681 6.81442 4.22002 6.7112C4.61622 6.32832 5.00244 5.93544 5.39198 5.54257C5.93469 4.99654 5.93469 4.35728 5.38866 3.80792C5.07902 3.49495 4.76938 3.18865 4.45974 2.87568C4.14011 2.55605 3.82381 2.23309 3.50086 1.9168C2.97813 1.40739 2.32556 1.40739 1.80617 1.92012C1.40663 2.313 1.02375 2.71586 0.617555 3.10208C0.241327 3.45833 0.0515486 3.89449 0.0115952 4.40389C-0.0516643 5.23293 0.151432 6.01535 0.437765 6.77779C1.02375 8.35595 1.91604 9.75765 2.99811 11.0428C4.45974 12.7808 6.20437 14.1558 8.24532 15.148C9.16425 15.5942 10.1165 15.9371 11.1519 15.9937C11.8644 16.0337 12.4837 15.8539 12.9798 15.2979C13.3194 14.9183 13.7023 14.572 14.0619 14.2091C14.5946 13.6697 14.5979 13.0172 14.0685 12.4845C13.4359 11.8485 12.8 11.2159 12.1641 10.5834Z"></path>
                                <path
                                    d="M11.5271 7.92979L12.7557 7.72003C12.5625 6.59135 12.0298 5.56921 11.2208 4.75682C10.3651 3.90116 9.28304 3.36178 8.0911 3.19531L7.91797 4.43054C8.84023 4.56039 9.67925 4.97657 10.3418 5.63913C10.9677 6.26506 11.3773 7.05747 11.5271 7.92979Z"></path>
                                <path
                                    d="M13.4493 2.59031C12.0309 1.17197 10.2363 0.276344 8.25531 0L8.08218 1.23523C9.79352 1.47495 11.345 2.25071 12.5703 3.47262C13.7323 4.63459 14.4947 6.10288 14.771 7.71766L15.9996 7.50791C15.6767 5.63676 14.7943 3.93874 13.4493 2.59031Z"></path>
                            </svg>
                        </span>
                        <div class="header-top-meta-content">
                            <span>Call us:</span>
                            <a href="tel:+911204221735">+91 120 422 1735</a>
                        </div>
                    </div>
                    <div class="header-top-meta">
                        <span class="header-top-meta-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"
                                fill="none">
                                <g clip-path="url(#clip0_28535_99)">
                                    <path
                                        d="M15.8603 3.17969L11.0078 8.00091L15.8603 12.8221C15.948 12.6388 16.0012 12.4361 16.0012 12.2197V3.78216C16.0012 3.56569 15.948 3.36303 15.8603 3.17969Z"
                                        fill="white"></path>
                                    <path
                                        d="M14.5947 2.375H1.40716C1.19069 2.375 0.988031 2.42822 0.804688 2.51594L7.00666 8.68666C7.55503 9.23503 8.44678 9.23503 8.99516 8.68666L15.1971 2.51594C15.0138 2.42822 14.8111 2.375 14.5947 2.375Z"
                                        fill="white"></path>
                                    <path
                                        d="M0.140938 3.17969C0.0532188 3.36303 0 3.56569 0 3.78216V12.2197C0 12.4361 0.0532188 12.6388 0.140938 12.8221L4.99341 8.00091L0.140938 3.17969Z"
                                        fill="white"></path>
                                    <path
                                        d="M10.3447 8.66211L9.658 9.34877C8.74428 10.2625 7.2575 10.2625 6.34378 9.34877L5.65716 8.66211L0.804688 13.4833C0.988031 13.571 1.19069 13.6243 1.40716 13.6243H14.5947C14.8111 13.6243 15.0138 13.571 15.1971 13.4833L10.3447 8.66211Z"
                                        fill="white"></path>
                                </g>
                                <defs>
                                    <clipPath id="clip0_28535_99">
                                        <rect width="16" height="16" fill="white"></rect>
                                    </clipPath>
                                </defs>
                            </svg>
                        </span>
                        <div class="header-top-meta-content">
                            <span>Send mail:</span>
                            <a href="mailto:sales@icefindia.in">
                                sales@icefindia.in
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- top end -->
        </div>

        
        <div class="rs-header-area rs-header-one header-transparent">
                    <div class="container-fluid g-0">
            <div class="header-wrapper">
                <div class="header-left">
                    <div class="header-logo">
                        <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA - Integrated Assessment & Recruitment Platform"></a>
                    </div>
                </div>
                <div class="header-right">
                    <div class="header-menu">
                        <nav id="mobile-menu-two" class="main-menu">
                            <ul class="multipage-menu">
                                <li><a href="index.php">Home</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">About Company</a>
                                    <ul class="submenu last-children">
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="about-mission.php#mission">Mission & Vision</a></li>
                                        <li><a href="industry-clients.php">Industry We Work With</a></li>
                                        <li><a href="industry-clients.php#clients">Client Tele</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                        <li><a href="careers-culture.php">Work Culture</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children rs-mega-menu">
                                    <a href="javascript:void(0)">Solutions</a>
                                    <ul class="mega-menu mega-grid-two">
                                        <li class="rs-menu-item" data-image="assets/images/solution/it-emerging.webp">
                                            <a href="it-emerging-tech-enablement.php" class="title">IT & Emerging Tech Enablement</a>
                                            <ul>
                                                <li data-image="assets/images/solution/iot.webp"><a href="iot-and-rfid.php">IOT & RFID Based Products</a></li>
                                                <li data-image="assets/images/solution/app-dev.webp"><a href="application-development.php">Application Development</a></li>
                                                <li data-image="assets/images/solution/software-dev.webp"><a href="customized-software-development.php">Customized Software Development</a></li>
                                                <li data-image="assets/images/solution/emerging-tech.webp"><a href="emerging-tech.php">Emerging Tech</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/assessment-testing.webp">
                                            <a href="assessment-and-testing.php" class="title">Assessment & Testing</a>
                                            <ul>
                                                <li data-image="assets/images/solution/cognitive-domain.webp"><a href="cognitive-domain.php">Cognitive/Domain</a></li>
                                                <li data-image="assets/images/solution/online-offline.webp"><a href="online-offline.php">Online/Offline</a></li>
                                                <li data-image="assets/images/solution/proctoring.webp"><a href="proctoring.php">Proctoring</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/recruitment.webp">
                                            <a href="recruitment-and-hiring.php" class="title">Recruitment & Hiring</a>
                                            <ul>
                                                <li data-image="assets/images/about/33.webp"><a href="screening.php">Screening</a></li>
                                                <li data-image="assets/images/about/37.webp"><a href="assessments.php">Assessments</a></li>
                                                <li data-image="assets/images/solution/merit-list.webp"><a href="merit-lists.php">Merit Lists</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/exam-management.webp">
                                            <a href="exam-management.php" class="title">Exam Management</a>
                                            <ul>
                                                <li data-image="assets/images/solution/question-banks.webp"><a href="question-banks.php">Question Banks</a></li>
                                                <li data-image="assets/images/solution/exam-conduct.webp"><a href="exam-conduct.php">Conduct</a></li>
                                                <li data-image="assets/images/solution/processing.webp"><a href="exam-processing.php">Processing</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/manpower-workforce.webp">
                                            <a href="manpower-and-workforce.php" class="title">Manpower & Workforce</a>
                                            <ul>
                                                <li data-image="assets/images/solution/outsourcing.webp"><a href="outsourcing.php">Outsourcing</a></li>
                                                <li data-image="assets/images/about/31.webp"><a href="staffing.php">Staffing</a></li>
                                                <li data-image="assets/images/solution/deployment.webp"><a href="deployment.php">Deployment</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/call-center.webp">
                                            <a href="call-center-and-bpos.php" class="title">Call Center & BPOs</a>
                                            <ul>
                                                <li data-image="assets/images/solution/inbound.webp"><a href="inbound-outbound.php">Inbound/Outbound</a></li>
                                                <li data-image="assets/images/solution/support.webp"><a href="support.php">Support</a></li>
                                                <li data-image="assets/images/solution/telecalling.webp"><a href="tele-calling.php">Tele-Calling</a></li>
                                            </ul>
                                        </li>
                                        <li class="mega-menu-feature">
                                            <div class="mega-feature-content">
                                                <h6 class="title">Let's Talk Business</h6>
                                                <p>Empowering businesses with smart IT solutions since 2000.</p>
                                                <a href="support.php" class="rs-btn has-icon has-md-radius hover-primary">Request Quote</a>
                                                <div class="feature-thumb mt-20">
                                                    <img id="mega-menu-target-img" src="assets/images/mega-menu-feature.png" alt="Consultation">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="why-choose-us.php">Why Choose Us</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">WhiteBoard</a>
                                    <ul class="submenu last-children">
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="faq.php">FAQs</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                    </ul>
                                </li>
                                
                                
                                <li><a href="contact.php">Support</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="header-content">
                        <div class="header-btn">
                            <a class="rs-btn has-icon is-transparent hover-primary border-hover-primary" href="contact.php">Get Free Quote</a>
                        </div>
                        <div class="header-search-wrapper">
                            <div class="header-search-icon"><i class="ri-search-line"></i></div>
                        </div>
                        <div class="header-hamburger">
                            <div class="sidebar-toggle">
                                <a class="header-bar-icon" href="javascript:void(0)"><span></span><span></span><span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                </div>

        <div id="rs-sticky-header" class="rs-sticky-header rs-header-area rs-header-one header-transparent">
                    <div class="container-fluid g-0">
            <div class="header-wrapper">
                <div class="header-left">
                    <div class="header-logo">
                        <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA - Integrated Assessment & Recruitment Platform"></a>
                    </div>
                </div>
                <div class="header-right">
                    <div class="header-menu">
                        <nav id="mobile-menu-two" class="main-menu">
                            <ul class="multipage-menu">
                                <li><a href="index.php">Home</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">About Company</a>
                                    <ul class="submenu last-children">
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="about-mission.php#mission">Mission & Vision</a></li>
                                        <li><a href="industry-clients.php">Industry We Work With</a></li>
                                        <li><a href="industry-clients.php#clients">Client Tele</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                        <li><a href="careers-culture.php">Work Culture</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children rs-mega-menu">
                                    <a href="javascript:void(0)">Solutions</a>
                                    <ul class="mega-menu mega-grid-two">
                                        <li class="rs-menu-item" data-image="assets/images/solution/it-emerging.webp">
                                            <a href="it-emerging-tech-enablement.php" class="title">IT & Emerging Tech Enablement</a>
                                            <ul>
                                                <li data-image="assets/images/solution/iot.webp"><a href="iot-and-rfid.php">IOT & RFID Based Products</a></li>
                                                <li data-image="assets/images/solution/app-dev.webp"><a href="application-development.php">Application Development</a></li>
                                                <li data-image="assets/images/solution/software-dev.webp"><a href="customized-software-development.php">Customized Software Development</a></li>
                                                <li data-image="assets/images/solution/emerging-tech.webp"><a href="emerging-tech.php">Emerging Tech</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/assessment-testing.webp">
                                            <a href="assessment-and-testing.php" class="title">Assessment & Testing</a>
                                            <ul>
                                                <li data-image="assets/images/solution/cognitive-domain.webp"><a href="cognitive-domain.php">Cognitive/Domain</a></li>
                                                <li data-image="assets/images/solution/online-offline.webp"><a href="online-offline.php">Online/Offline</a></li>
                                                <li data-image="assets/images/solution/proctoring.webp"><a href="proctoring.php">Proctoring</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/recruitment.webp">
                                            <a href="recruitment-and-hiring.php" class="title">Recruitment & Hiring</a>
                                            <ul>
                                                <li data-image="assets/images/about/33.webp"><a href="screening.php">Screening</a></li>
                                                <li data-image="assets/images/about/37.webp"><a href="assessments.php">Assessments</a></li>
                                                <li data-image="assets/images/solution/merit-list.webp"><a href="merit-lists.php">Merit Lists</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/exam-management.webp">
                                            <a href="exam-management.php" class="title">Exam Management</a>
                                            <ul>
                                                <li data-image="assets/images/solution/question-banks.webp"><a href="question-banks.php">Question Banks</a></li>
                                                <li data-image="assets/images/solution/exam-conduct.webp"><a href="exam-conduct.php">Conduct</a></li>
                                                <li data-image="assets/images/solution/processing.webp"><a href="exam-processing.php">Processing</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/manpower-workforce.webp">
                                            <a href="manpower-and-workforce.php" class="title">Manpower & Workforce</a>
                                            <ul>
                                                <li data-image="assets/images/solution/outsourcing.webp"><a href="outsourcing.php">Outsourcing</a></li>
                                                <li data-image="assets/images/about/31.webp"><a href="staffing.php">Staffing</a></li>
                                                <li data-image="assets/images/solution/deployment.webp"><a href="deployment.php">Deployment</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/call-center.webp">
                                            <a href="call-center-and-bpos.php" class="title">Call Center & BPOs</a>
                                            <ul>
                                                <li data-image="assets/images/solution/inbound.webp"><a href="inbound-outbound.php">Inbound/Outbound</a></li>
                                                <li data-image="assets/images/solution/support.webp"><a href="support.php">Support</a></li>
                                                <li data-image="assets/images/solution/telecalling.webp"><a href="tele-calling.php">Tele-Calling</a></li>
                                            </ul>
                                        </li>
                                        <li class="mega-menu-feature">
                                            <div class="mega-feature-content">
                                                <h6 class="title">Let's Talk Business</h6>
                                                <p>Empowering businesses with smart IT solutions since 2000.</p>
                                                <a href="support.php" class="rs-btn has-icon has-md-radius hover-primary">Request Quote</a>
                                                <div class="feature-thumb mt-20">
                                                    <img id="mega-menu-target-img" src="assets/images/mega-menu-feature.png" alt="Consultation">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="why-choose-us.php">Why Choose Us</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">WhiteBoard</a>
                                    <ul class="submenu last-children">
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="faq.php">FAQs</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                    </ul>
                                </li>
                                
                                
                                <li><a href="contact.php">Support</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="header-content">
                        <div class="header-btn">
                            <a class="rs-btn has-icon is-transparent hover-primary border-hover-primary" href="contact.php">Get Free Quote</a>
                        </div>
                        <div class="header-search-wrapper">
                            <div class="header-search-icon"><i class="ri-search-line"></i></div>
                        </div>
                        <div class="header-hamburger">
                            <div class="sidebar-toggle">
                                <a class="header-bar-icon" href="javascript:void(0)"><span></span><span></span><span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                </div>
    </header>
    <!-- Header area end -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const targetImg = document.getElementById('mega-menu-target-img');
            if (!targetImg) return;

            const globalDefaultImg = targetImg.getAttribute('src');
            let defaultImg = globalDefaultImg;
            const menuItems = document.querySelectorAll('.rs-mega-menu .mega-menu [data-image]');

            // Detect active page and set its image as default
            const currentPath = window.location.pathname;
            document.querySelectorAll('.rs-mega-menu .mega-menu .rs-menu-item').forEach(item => {
                const links = item.querySelectorAll('a');
                links.forEach(link => {
                    const href = link.getAttribute('href');
                    if (href && href !== '#' && currentPath.endsWith(href)) {
                        const activeImg = link.parentElement.getAttribute('data-image') || item.getAttribute('data-image');
                        if (activeImg) {
                            defaultImg = activeImg;
                            targetImg.setAttribute('src', activeImg);
                        }
                    }
                });
            });

            menuItems.forEach(item => {
                item.addEventListener('mouseenter', function(e) {
                    e.stopPropagation();
                    const newImg = this.getAttribute('data-image');
                    if (newImg && targetImg.getAttribute('src') !== newImg) {
                        targetImg.style.opacity = '0';
                        setTimeout(() => {
                            targetImg.setAttribute('src', newImg);
                            targetImg.style.opacity = '1';
                        }, 200);
                    }
                });
            });

            // Revert to default when leaving the entire mega menu grid
            const megaGrid = document.querySelector('.mega-grid-two');
            if (megaGrid) {
                megaGrid.addEventListener('mouseleave', function() {
                    targetImg.style.opacity = '0';
                    setTimeout(() => {
                        targetImg.setAttribute('src', defaultImg);
                        targetImg.style.opacity = '1';
                    }, 200);
                });
            }
        });
    </script>
    <style>
        #mega-menu-target-img {
            transition: opacity 0.3s ease;
        }
    </style>

        <!-- Offcanvas area start -->
    <div class="fix">
        <div class="offcanvas-area" data-lenis-prevent>
            <div class="offcanvas-wrapper">
                <div class="offcanvas-content">
                    <div class="offcanvas-top d-flex justify-content-between align-items-center mb-20">
                        <div class="offcanvas-logo">
                            <a class="logo-black" href="index.php"><img src="assets/images/logo/logo-icef.png" alt="logo"></a>
                            <a class="logo-white" href="index.php"><img src="assets/images/logo/logo-icef.png" alt="logo"></a>
                        </div>
                        <div class="offcanvas-close">
                            <button class="offcanvas-close-icon animation--flip" style="background: var(--rs-theme-primary); color: white; border: none; padding: 10px; border-radius: 4px; display: flex; align-items: center; justify-content: center; width: 40px; height: 40px;">
                                <i class="ri-close-line" style="font-size: 24px;"></i>
                            </button>
                        </div>
                    </div>
                    <div class="offcanvas-about mb-30 d-none d-xl-block">
                        <p>
                            ICEF INDIA is a premier organization providing end-to-end solutions in Assessment, Recruitment, and Workforce Development since 2000.
                        </p>
                    </div>
                    <div class="offcanvas-gallery d-none d-xl-block">
                        <div class="offcanvas-gallery-thumb-wrapper">
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-01.webp">
                                    <img src="assets/images/gallery/gallery-thumb-01.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-02.webp">
                                    <img src="assets/images/gallery/gallery-thumb-02.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-03.webp">
                                    <img src="assets/images/gallery/gallery-thumb-03.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-04.webp">
                                    <img src="assets/images/gallery/gallery-thumb-04.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-05.webp">
                                    <img src="assets/images/gallery/gallery-thumb-05.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-06.webp">
                                    <img src="assets/images/gallery/gallery-thumb-06.webp" alt="image">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="mobile-menu-container">
                        <div class="rs-offcanvas-menu mb-30" id="sidebar-menu-target">
                            <!-- Menu will be injected here via JS -->
                        </div>
                    </div>
                    <div class="offcanvas-contact mb-30">
                        <h4 class="offcanvas-title-meta">Contact Info</h4>
                        <ul>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="18" viewBox="0 0 14 18" fill="none">
                                        <path d="M11.8768 9.68475C11.3059 10.835 10.5331 11.9818 9.74128 13.0109C8.95198 14.0368 8.15999 14.9249 7.5643 15.5572C7.48514 15.6412 7.40956 15.7206 7.33802 15.7951C7.26648 15.7206 7.1909 15.6412 7.11174 15.5572C6.51605 14.9249 5.72406 14.0368 4.93476 13.0109C4.14299 11.9818 3.37019 10.835 2.79925 9.68475C2.22242 8.52266 1.89032 7.43373 1.89032 6.5C1.89032 3.50846 4.32934 1.08333 7.33802 1.08333C10.3467 1.08333 12.7857 3.50846 12.7857 6.5C12.7857 7.43373 12.4536 8.52266 11.8768 9.68475ZM7.33802 17.3333C7.33802 17.3333 13.8753 11.1732 13.8753 6.5C13.8753 2.91015 10.9484 0 7.33802 0C3.7276 0 0.800781 2.91015 0.800781 6.5C0.800781 11.1732 7.33802 17.3333 7.33802 17.3333Z" fill="#6D6D6D"></path>
                                        <path d="M7.33802 8.66667C6.13455 8.66667 5.15894 7.69662 5.15894 6.5C5.15894 5.30338 6.13455 4.33333 7.33802 4.33333C8.54149 4.33333 9.5171 5.30338 9.5171 6.5C9.5171 7.69662 8.54149 8.66667 7.33802 8.66667ZM7.33802 9.75C9.14323 9.75 10.6066 8.29492 10.6066 6.5C10.6066 4.70507 9.14323 3.25 7.33802 3.25C5.53281 3.25 4.0694 4.70507 4.0694 6.5C4.0694 8.29492 5.53281 9.75 7.33802 9.75Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="#"> Noida, Uttar Pradesh, India</a>
                                </div>
                            </li>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M3.65387 1.32849C3.40343 1.00649 2.92745 0.976861 2.639 1.26531L1.60508 2.29923C1.1216 2.78271 0.94387 3.46766 1.1551 4.06847C2.00338 6.48124 3.39215 8.74671 5.32272 10.6773C7.25329 12.6078 9.51876 13.9966 11.9315 14.8449C12.5323 15.0561 13.2173 14.8784 13.7008 14.3949L14.7347 13.361C15.0231 13.0726 14.9935 12.5966 14.6715 12.3461L12.3653 10.5524C12.2008 10.4245 11.9866 10.3793 11.7845 10.4298L9.59541 10.9771C9.00082 11.1257 8.37183 10.9515 7.93845 10.5181L5.48187 8.06155C5.04849 7.62817 4.87427 6.99919 5.02292 6.40459L5.57019 4.21553C5.62073 4.01336 5.57552 3.79918 5.44758 3.63468L3.65387 1.32849ZM1.88477 0.511076C2.62689 -0.231039 3.8515 -0.154797 4.49583 0.673634L6.28954 2.97983C6.6187 3.40304 6.73502 3.95409 6.60498 4.47423L6.05772 6.66329C5.99994 6.8944 6.06766 7.13888 6.2361 7.30732L8.69268 9.7639C8.86113 9.93235 9.1056 10.0001 9.33671 9.94229L11.5258 9.39502C12.0459 9.26499 12.597 9.3813 13.0202 9.71047L15.3264 11.5042C16.1548 12.1485 16.231 13.3731 15.4889 14.1152L14.455 15.1492C13.7153 15.8889 12.6089 16.2137 11.5778 15.8512C9.01754 14.9511 6.61438 13.4774 4.56849 11.4315C2.5226 9.38562 1.04895 6.98246 0.148838 4.42225C-0.213682 3.39112 0.11113 2.28472 0.85085 1.545L1.88477 0.511076Z" fill="#6D6D6D"></path>
                                        <path d="M11 0.5C11 0.223858 11.2239 0 11.5 0H15.5C15.7761 0 16 0.223858 16 0.5V4.5C16 4.77614 15.7761 5 15.5 5C15.2239 5 15 4.77614 15 4.5V1.70711L10.8536 5.85355C10.6583 6.04882 10.3417 6.04882 10.1464 5.85355C9.95118 5.65829 9.95118 5.34171 10.1464 5.14645L14.2929 1H11.5C11.2239 1 11 0.776142 11 0.5Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="tel:+911204221735"> +91 120 422 1735 </a>
                                </div>
                            </li>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M2 2C0.895431 2 0 2.89543 0 4V12L2.58386e-05 12.0103C0.00555998 13.1101 0.898859 14 2 14H7.5C7.77614 14 8 13.7761 8 13.5C8 13.2239 7.77614 13 7.5 13H2C1.53715 13 1.14774 12.6855 1.03376 12.2586L6.67417 8.7876L8 9.5831L15 5.3831V8.5C15 8.77614 15.2239 9 15.5 9C15.7761 9 16 8.77614 16 8.5V4C16 2.89543 15.1046 2 14 2H2ZM5.70808 8.20794L1 11.1052V5.3831L5.70808 8.20794ZM1 4.2169V4C1 3.44772 1.44772 3 2 3H14C14.5523 3 15 3.44772 15 4V4.2169L8 8.4169L1 4.2169Z" fill="#6D6D6D"></path>
                                        <path d="M14.2467 14.2686C15.2567 14.2686 15.8339 13.4116 15.8339 12.2442V12.0344C15.8339 10.4297 14.6402 9 12.5197 9H12.4847C10.421 9 9 10.3598 9 12.4322V12.6465C9 14.8195 10.4385 16 12.3579 16H12.4016C12.9963 16 13.4204 15.9257 13.639 15.8251V15.0949C13.3941 15.2042 12.9656 15.2742 12.4585 15.2742H12.4147C11.0812 15.2742 9.84385 14.4872 9.84385 12.6202V12.4628C9.84385 10.8057 10.9019 9.73891 12.4847 9.73891H12.524C14.0587 9.73891 15.0075 10.7883 15.0075 12.065V12.183C15.0075 13.158 14.6839 13.5734 14.3691 13.5734C14.1374 13.5734 13.9582 13.4247 13.9582 13.1537V10.9631H13.0531V11.5315H13.0225C12.9394 11.2342 12.6552 10.9019 12.0693 10.9019C11.2911 10.9019 10.8101 11.4572 10.8101 12.3011V12.8301C10.8101 13.722 11.2998 14.2642 12.0693 14.2642C12.5415 14.2642 12.9656 14.0369 13.0837 13.6215H13.1274C13.2455 14.0412 13.7439 14.2686 14.2467 14.2686ZM11.7939 12.6814V12.4541C11.7939 11.9076 12.0212 11.6627 12.3666 11.6627C12.664 11.6627 12.9394 11.8551 12.9394 12.371V12.7383C12.9394 13.3111 12.6858 13.4816 12.3754 13.4816C12.0212 13.4816 11.7939 13.2673 11.7939 12.6814Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="mailto:sales@icefindia.in">sales@icefindia.in</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="offcanvas-social">
                        <h4 class="offcanvas-title-meta">Follow Us</h4>
                        <ul>
                            <li><a href="#"><i class="ri-facebook-fill"></i></a></li>
                            <li><a href="#"><i class="ri-twitter-x-fill"></i></a></li>
                            <li><a href="#"><i class="ri-youtube-fill"></i></a></li>
                            <li><a href="#"><i class="ri-linkedin-box-fill"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas-overlay"></div>
    <div class="offcanvas-overlay-white"></div>
    <!-- Offcanvas area start -->

    <!-- Body main wrapper start -->
    <main>

        <!-- banner area start -->
        <section class="rs-banner-area rs-banner-two rs-swiper">
            <div class="rs-banner-slider-wrapper">
                <div class="swiper" id="rs-banner-swiper" data-clone-slides="false" data-loop="true" data-speed="1500"
                    data-autoplay="false" data-dots-dynamic="false" data-center-mode="false" data-effect="fade"
                    data-no-gap="true" data-delay="2000" data-item="1">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="rs-banner-wrapper">
                                <div class="rs-banner-bg-thumb include-bg"
                                    data-background="assets/images/banner/banner-1.webp"></div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-xxl-6 col-xl-7 col-lg-8 offset-xxl-1 offset-xl-1">
                                            <div class="rs-banner-item">
                                                <div class="rs-banner-content-wrapper">
                                                    <span class="rs-banner-subtitle wow fadeInUp" data-wow-delay=".3s">
                                                        Turning Vision Into Reality
                                                    </span>
                                                    <h1 class="rs-banner-title rs-split-text-enable split-in-left">
                                                        India’s First Integrated <br> <span class="rs-typed-text"
                                                            data-typed="Assessment, Recruitment and Workforce Platform"></span>
                                                    </h1>
                                                    <span class="rs-banner-line"></span>
                                                    <p class="rs-banner-desc wow fadeInUp" data-wow-delay=".5s">Assessment | Hiring | Manpower | BPO | Exam Management</p>
                                                    <div class="rs-banner-btn">
                                                        <a class="rs-btn has-icon has-bg-white hover-primary"
                                                            href="support.php">Free
                                                            Consultation
                                                            <span class="icon-box">
                                                                <svg class="icon-first" width="16" height="16"
                                                                    viewBox="0 0 16 16"
                                                                    xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                        fill="white" />
                                                                </svg>

                                                                <svg class="icon-second" width="16" height="16"
                                                                    viewBox="0 0 16 16"
                                                                    xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                        fill="white" />
                                                                </svg>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    <!-- If we need navigation buttons -->
                                                    <div class="rs-banner-tab-wrapper">
                                                        <button class="swiper-button-prev rs-swiper-btn">
                                                            01 Assessment & Testing
                                                        </button>
                                                        <button class="swiper-button-next rs-swiper-btn">
                                                            02 IT & Emerging Tech
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="rs-banner-wrapper">
                                <div class="rs-banner-bg-thumb include-bg"
                                    data-background="assets/images/banner/banner-2.webp"></div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-xxl-6 col-xl-7 col-lg-8 offset-xxl-1 offset-xl-1">
                                            <div class="rs-banner-item">
                                                <div class="rs-banner-content-wrapper">
                                                    <span class="rs-banner-subtitle wow fadeInUp" data-wow-delay=".3s">
                                                        Turning Vision Into Reality
                                                    </span>
                                                    <h1 class="rs-banner-title rs-split-text-enable split-in-left">
                                                        Empowering Excellence through<br> <span class="rs-typed-text"
                                                            data-typed="Precision-Driven Online Examinations"></span>
                                                    </h1>
                                                    <span class="rs-banner-line"></span>
                                                    <p class="rs-banner-desc wow fadeInUp" data-wow-delay=".5s">Assessment | Hiring | Manpower | BPO | Exam Management</p>
                                                    <div class="rs-banner-btn">
                                                        <a class="rs-btn has-icon has-bg-white hover-primary"
                                                            href="contact.php">Free
                                                            Consultation
                                                            <span class="icon-box">
                                                                <svg class="icon-first" width="16" height="16"
                                                                    viewBox="0 0 16 16"
                                                                    xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                        fill="white" />
                                                                </svg>

                                                                <svg class="icon-second" width="16" height="16"
                                                                    viewBox="0 0 16 16"
                                                                    xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                        fill="white" />
                                                                </svg>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    <!-- If we need navigation buttons -->
                                                    <div class="rs-banner-tab-wrapper">
                                                        <button class="swiper-button-prev rs-swiper-btn">
                                                            01 Recruitment & Hiring
                                                        </button>
                                                        <button class="swiper-button-next rs-swiper-btn">
                                                            02 Exam Management
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="rs-banner-wrapper">
                                <div class="rs-banner-bg-thumb include-bg"
                                    data-background="assets/images/banner/banner-3.webp"></div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-xxl-6 col-xl-7 col-lg-8 offset-xxl-1 offset-xl-1">
                                            <div class="rs-banner-item">
                                                <div class="rs-banner-content-wrapper">
                                                    <span class="rs-banner-subtitle wow fadeInUp" data-wow-delay=".3s">
                                                        Turning Vision Into Reality
                                                    </span>
                                                    <h1 class="rs-banner-title rs-split-text-enable split-in-left">
                                                        Strategically Scalable Solutions for<br> <span class="rs-typed-text"
                                                            data-typed="Global Workforce Management"></span>
                                                    </h1>
                                                    <span class="rs-banner-line"></span>
                                                    <p class="rs-banner-desc wow fadeInUp" data-wow-delay=".5s">Assessment | Hiring | Manpower | BPO | Exam Management</p>
                                                    <div class="rs-banner-btn">
                                                        <a class="rs-btn has-icon has-bg-white hover-primary"
                                                            href="contact.php">Free
                                                            Consultation
                                                            <span class="icon-box">
                                                                <svg class="icon-first" width="16" height="16"
                                                                    viewBox="0 0 16 16"
                                                                    xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                        fill="white" />
                                                                </svg>

                                                                <svg class="icon-second" width="16" height="16"
                                                                    viewBox="0 0 16 16"
                                                                    xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                        fill="white" />
                                                                </svg>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    <!-- If we need navigation buttons -->
                                                    <div class="rs-banner-tab-wrapper">
                                                        <button class="swiper-button-prev rs-swiper-btn">
                                                            01 Manpower & Workforce
                                                        </button>
                                                        <button class="swiper-button-next rs-swiper-btn">
                                                            02 Call Centers & BPOs
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container-fluid g-0">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="rs-banner-feature-wrapper">
                                <div class="rs-banner-feature-item item-one">
                                    <div class="rs-banner-feature-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 38">
                                            <path
                                                d="M35.8847 11.5495C35.5146 11.5495 35.1463 11.5762 34.7833 11.6289C34.8477 7.02454 29.8368 4.18955 25.9611 6.46509C24.6953 2.65196 21.1546 0.0604248 17.0599 0.0604248C11.8811 0.0604248 7.66792 4.2736 7.66792 9.45219C7.66792 10.1662 7.74732 10.8695 7.90459 11.5524C3.81104 11.6669 0.516113 15.0302 0.516113 19.1481C0.516113 23.3382 3.92732 26.747 8.12012 26.747L10.5092 26.6906C10.6421 32.9156 15.7436 37.9394 21.9999 37.9394C25.054 37.9394 27.9275 36.7581 30.0912 34.6125C30.1495 34.5547 30.1959 34.4859 30.2277 34.4101C30.2594 34.3344 30.276 34.2531 30.2763 34.1709C30.2767 34.0887 30.2608 34.0073 30.2297 33.9313C30.1985 33.8552 30.1527 33.7861 30.0949 33.7277C30.037 33.6694 29.9682 33.623 29.8925 33.5912C29.8167 33.5595 29.7354 33.5429 29.6532 33.5426C29.571 33.5422 29.4896 33.5581 29.4136 33.5892C29.3375 33.6204 29.2684 33.6662 29.21 33.724C27.2826 35.6353 24.7219 36.6879 22 36.6879C16.3506 36.6879 11.7545 32.0918 11.7545 26.4425C11.7545 20.7931 16.3506 16.197 22 16.197C27.6493 16.197 32.2454 20.7931 32.2454 26.4425C32.2454 28.129 31.8271 29.7981 31.0353 31.2687C30.9589 31.4146 30.9432 31.5848 30.9914 31.7422C31.0397 31.8997 31.1481 32.0318 31.2931 32.1099C31.4381 32.1879 31.6081 32.2057 31.7661 32.1593C31.9241 32.1129 32.0575 32.006 32.1372 31.8619C32.9826 30.2915 33.4439 28.5205 33.4882 26.7237C34.748 26.7521 35.9633 26.7464 36.1052 26.747L36.0604 26.745C40.1697 26.651 43.4837 23.2794 43.4837 19.1481C43.4837 14.9583 40.0749 11.5495 35.8847 11.5495ZM35.8847 25.4956C35.821 25.4959 34.7021 25.4907 33.4566 25.5197C32.9844 19.6105 28.0284 14.9457 21.9999 14.9457C15.9601 14.9457 10.9969 19.6281 10.5407 25.5529L8.12012 25.4957C4.61722 25.4957 1.76762 22.6483 1.76762 19.1483C1.76762 15.3704 5.0696 12.4679 8.67605 12.8285C9.1298 12.8714 9.47536 12.4362 9.3315 12.007C9.05813 11.1915 8.91943 10.3318 8.91943 9.45236C8.91943 4.96385 12.5712 1.31202 17.0599 1.31202C20.8738 1.31202 24.1334 3.90621 24.9864 7.62078C25.0899 8.07126 25.6326 8.25955 25.9928 7.96461C29.2307 5.31241 34.1685 8.04746 33.4688 12.3089C33.3952 12.76 33.8126 13.1313 34.2481 13.0147C34.7819 12.8724 35.3321 12.8005 35.8846 12.8011C39.3846 12.8011 42.232 15.6485 42.232 19.1483C42.2322 22.6482 39.3848 25.4956 35.8847 25.4956Z">
                                            </path>
                                            <path
                                                d="M29.3726 26.4432C29.3726 26.7889 29.6527 27.0689 29.9983 27.0689C30.3439 27.0689 30.624 26.7889 30.624 26.4432C30.624 21.6879 26.7551 17.819 21.9997 17.819C21.6541 17.819 21.374 18.099 21.374 18.4447C21.374 18.7903 21.6541 19.0704 21.9997 19.0704C26.0652 19.0704 29.3726 22.3777 29.3726 26.4432ZM21.9997 33.816C17.9343 33.816 14.6269 30.5087 14.6269 26.4431C14.6269 26.0975 14.3468 25.8174 14.0012 25.8174C13.6556 25.8174 13.3755 26.0975 13.3755 26.4431C13.3755 31.1985 17.2444 35.0674 21.9997 35.0674C22.0819 35.0674 22.1633 35.0512 22.2392 35.0198C22.3151 34.9884 22.3841 34.9423 22.4422 34.8842C22.5003 34.8261 22.5464 34.7571 22.5778 34.6812C22.6093 34.6052 22.6255 34.5239 22.6255 34.4417C22.6255 34.3595 22.6093 34.2781 22.5778 34.2022C22.5464 34.1263 22.5003 34.0573 22.4422 33.9992C22.3841 33.9411 22.3151 33.895 22.2392 33.8636C22.1633 33.8321 22.0819 33.816 21.9997 33.816ZM22.6267 30.8637C23.9871 30.8269 25.0833 29.7113 25.0833 28.3422C25.0833 26.9499 23.9505 25.8174 22.5583 25.8174H21.4413C20.7392 25.8174 20.1678 25.2461 20.1678 24.5439C20.1678 23.8418 20.7391 23.2707 21.4413 23.2707H22.5026C23.2047 23.2707 23.7758 23.8418 23.7758 24.5439C23.7758 24.8896 24.0559 25.1696 24.4015 25.1696C24.7472 25.1696 25.0272 24.8896 25.0272 24.5439C25.0272 23.1936 23.9611 22.0908 22.6267 22.0254V21.2649C22.6267 20.9193 22.3467 20.6392 22.001 20.6392C21.6554 20.6392 21.3753 20.9193 21.3753 21.2649V22.0225C20.0138 22.0579 18.9164 23.1742 18.9164 24.5442C18.9164 25.9365 20.0491 27.0689 21.4413 27.0689H22.5583C23.2604 27.0689 23.8318 27.6401 23.8318 28.3422C23.8318 29.0443 23.2605 29.6157 22.5583 29.6157H21.497C20.7949 29.6157 20.2238 29.0444 20.2238 28.3422C20.2238 27.9965 19.9437 27.7165 19.5981 27.7165C19.2524 27.7165 18.9723 27.9965 18.9723 28.3422C18.9723 29.6933 20.0398 30.7968 21.3753 30.861V31.6215C21.3753 31.9671 21.6554 32.2472 22.001 32.2472C22.3467 32.2472 22.6267 31.9671 22.6267 31.6215V30.8637Z">
                                            </path>
                                        </svg>
                                    </div>
                                    <div class="rs-banner-feature-content">
                                        <h5 class="rs-banner-feature-title">26+ Years of Experience</h5>
                                        <span class="rs-banner-feature-line"></span>
                                        <p class="rs-banner-feature-desc"> With 26+ years of experience and a legacy of trust since 2000, ICEF India provides cost-effective solutions that streamline assessments and maximize workforce potential.
                                        </p>
                                        <div class="rs-banner-feature-btn">
                                            <a href="services.php"
                                                class="rs-square-btn has-icon has-transparent is-white">
                                                <span class="icon-box">
                                                    <svg class="icon-first" width="23" height="23" viewBox="0 0 23 23"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <g>
                                                            <path
                                                                d="M17.532 12.6445L1.33082 12.6445L1.33081 9.98291L17.531 9.98196L10.3923 2.84325L12.2746 0.960927L22.6274 11.3137L12.2746 21.6665L10.3923 19.7842L17.532 12.6445Z" />
                                                        </g>
                                                    </svg>
                                                    <svg class="icon-second" width="23" height="23" viewBox="0 0 23 23"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <g>
                                                            <path
                                                                d="M17.532 12.6445L1.33082 12.6445L1.33081 9.98291L17.531 9.98196L10.3923 2.84325L12.2746 0.960927L22.6274 11.3137L12.2746 21.6665L10.3923 19.7842L17.532 12.6445Z" />
                                                        </g>
                                                    </svg>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="rs-banner-feature-item item-two">
                                    <div class="rs-banner-feature-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 38">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M10.5959 36.5456C10.0034 36.5456 9.52067 36.0625 9.52067 35.4686C9.52067 34.8755 10.0034 34.3925 10.5959 34.3925C11.1884 34.3925 11.6758 34.8756 11.6758 35.4686C11.6758 36.0626 11.1884 36.5456 10.5959 36.5456ZM10.5959 1.45436C11.1884 1.45436 11.6758 1.93651 11.6758 2.53042C11.6758 3.12345 11.1884 3.60657 10.5959 3.60657C10.0034 3.60657 9.52067 3.12345 9.52067 2.53042C9.52067 1.93651 10.0034 1.45436 10.5959 1.45436ZM10.5959 33.2605C9.97941 33.2605 9.42519 33.5147 9.02373 33.9232L1.98989 29.9241V8.07486L9.02373 4.07676C9.4251 4.48481 9.97941 4.73861 10.5959 4.73861C11.8144 4.73861 12.8035 3.74755 12.8035 2.53051C12.8035 1.3125 11.8144 0.322415 10.5959 0.322415C9.13189 0.322415 8.09401 1.71968 8.45992 3.09248L1.14413 7.25303C1.05726 7.30259 0.985011 7.3742 0.934672 7.46062C0.884332 7.54704 0.857686 7.64521 0.857422 7.74521V30.2539C0.857515 30.354 0.884089 30.4522 0.934446 30.5387C0.984803 30.6251 1.05715 30.6967 1.14413 30.7461L8.45992 34.9067C8.09401 36.2795 9.13215 37.6777 10.5959 37.6777C11.8144 37.6777 12.8035 36.6867 12.8035 35.4687C12.8035 34.2515 11.8143 33.2605 10.5959 33.2605ZM25.3994 36.5456C24.8069 36.5456 24.3242 36.0625 24.3242 35.4686C24.3242 34.8755 24.8068 34.3925 25.3994 34.3925C25.992 34.3925 26.4746 34.8756 26.4746 35.4686C26.4746 36.0626 25.9919 36.5456 25.3994 36.5456ZM25.3994 3.60657C24.8069 3.60657 24.3242 3.12345 24.3242 2.53042C24.3242 1.93651 24.8068 1.45436 25.3994 1.45436C25.992 1.45436 26.4746 1.93651 26.4746 2.53042C26.4746 3.12345 25.9919 3.60657 25.3994 3.60657ZM34.8511 7.25294L27.5353 3.09239C27.9013 1.72012 26.8636 0.322327 25.3994 0.322327C24.1809 0.322327 23.1917 1.31241 23.1917 2.53042C23.1917 3.74746 24.1809 4.73852 25.3994 4.73852C26.0158 4.73852 26.5749 4.48481 26.9763 4.07667L34.0101 8.07477V29.9241L26.9763 33.9232C26.5749 33.5146 26.0158 33.2605 25.3994 33.2605C24.1809 33.2605 23.1917 34.2515 23.1917 35.4686C23.1917 36.6866 24.1809 37.6776 25.3994 37.6776C26.8634 37.6776 27.9013 36.279 27.5353 34.9066L34.8511 30.746C34.9394 30.6977 35.013 30.6265 35.0643 30.5399C35.1155 30.4533 35.1426 30.3545 35.1426 30.2539V7.74513C35.1426 7.54202 35.0327 7.35423 34.8511 7.25294ZM17.9976 30.2194L6.72535 24.6507L11.1693 22.4564L17.7491 25.7063C17.9045 25.785 18.0931 25.7837 18.2509 25.7063L24.826 22.4564L29.2699 24.6507L17.9976 30.2194ZM6.72535 18.9997L11.1693 16.8054L17.7491 20.0547C17.9063 20.1339 18.0918 20.1324 18.2509 20.0547L24.826 16.8054L29.2699 18.9997L17.9976 24.5676L6.72535 18.9997ZM6.72535 13.3483L17.9976 7.78041L29.2699 13.3483L17.9976 18.9161L6.72535 13.3483ZM31.1144 24.6507C31.1144 24.8667 30.9901 25.0626 30.799 25.1587L18.2509 31.3582C18.0922 31.4346 17.9059 31.4361 17.7491 31.3572L5.19617 25.1587C4.77782 24.9503 4.77677 24.3517 5.19617 24.1437L9.8886 21.8252L5.19617 19.5072C4.77756 19.2992 4.77668 18.7008 5.19617 18.4918L9.8886 16.1738L5.19617 13.8553C4.77729 13.6476 4.77729 13.049 5.19617 12.8414L17.7491 6.64187C17.8271 6.60323 17.913 6.58313 18 6.58313C18.087 6.58313 18.1729 6.60323 18.2509 6.64187L30.799 12.8414C31.2179 13.0491 31.2179 13.6476 30.799 13.8553L26.1066 16.1738L30.799 18.4918C31.2185 18.7008 31.2176 19.2992 30.799 19.5072L26.1066 21.8252L30.799 24.1437C30.9901 24.2388 31.1144 24.4356 31.1144 24.6507Z">
                                            </path>
                                        </svg>
                                    </div>
                                    <div class="rs-banner-feature-content">
                                        <h5 class="rs-banner-feature-title">25.5K+ Successful Projects</h5>
                                        <span class="rs-banner-feature-line"></span>
                                        <p class="rs-banner-feature-desc"> Having completed over 25.5K+ successful projects, we utilize innovative technology to deliver precision-driven insights and advanced evaluation tools for your business.
                                        </p>
                                        <div class="rs-banner-feature-btn">
                                            <a href="services.php"
                                                class="rs-square-btn has-icon has-transparent is-white">
                                                <span class="icon-box">
                                                    <svg class="icon-first" width="23" height="23" viewBox="0 0 23 23"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <g>
                                                            <path
                                                                d="M17.532 12.6445L1.33082 12.6445L1.33081 9.98291L17.531 9.98196L10.3923 2.84325L12.2746 0.960927L22.6274 11.3137L12.2746 21.6665L10.3923 19.7842L17.532 12.6445Z" />
                                                        </g>
                                                    </svg>
                                                    <svg class="icon-second" width="23" height="23" viewBox="0 0 23 23"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <g>
                                                            <path
                                                                d="M17.532 12.6445L1.33082 12.6445L1.33081 9.98291L17.531 9.98196L10.3923 2.84325L12.2746 0.960927L22.6274 11.3137L12.2746 21.6665L10.3923 19.7842L17.532 12.6445Z" />
                                                        </g>
                                                    </svg>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- banner area end -->

        <!-- about area start -->
        <section class="rs-about-area section-space rs-about-two">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-about-wrapper">
                            <div class="rs-about-thumb rs-image scroll_reveal reveal-active" data-dir="left">
                                <img src="assets/images/about/1.webp" alt="image">
                            </div>
                            <div class="rs-about-content-wrapper">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle">
                                        Welcome to 
                                    </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left mb-30">India's First Integrated Assessment, Recruitment & Workforce Platform</h2>
                                </div>
                                <div class="rs-about-thumb-two rs-image scroll_reveal reveal-active"
                                    data-dir="reveal_right">
                                    <img src="assets/images/about/3.webp" alt="image">
                                </div>
                                <div class="rs-about-list-wrapper">
                                    <h5 class="rs-about-list-title">Data Analysis</h5>
                                    <p class="rs-about-list-desc">India's Leading Consultancy Company Since 2000 for Business Process, Hiring, Assessment and Manpower Deployment. Customised end-to-end assessment tests on hiring and workforce development for the corporate sector, admissions management, online evaluations and administration of examinations for the educational institutions, universities, boards, and government sector.</p>
                                    
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about area end -->

        <!-- services area start — Wisk Aero fan scroll -->
        <div id="servicesFanSection" class="rs-services-fan-scroll">
            <!-- sticky viewport -->
            <div class="rs-services-fan-sticky rs-services-two">

                <!-- shape stays as background decoration -->
                <div class="rs-services-shape rs-services-fan-shape">
                    <img src="assets/images/shape/services-shape-01.webp" alt="image">
                </div>

                <!-- heading -->
                <div class="rs-services-fan-heading">
                    <span class="section-subtitle is-white">
                        Your Business Our Expertise
                    </span>
                    <h2 class="section-title rs-split-text-enable split-in-left is-white mb-10">Service for your
                        development</h2>
                    <p class="section-desc">We believe that every business is uniquids our approach is never growth.</p>
                </div>

                <!-- cards stage: all 4 start stacked center, fan out to row on scroll -->
                <div class="rs-services-fan-stage" id="servicesFanStage">

                    <div class="rs-services-item rs-services-fan-card" id="svc1">
                        <div class="rs-services-thumb">
                            <img src="assets/images/services/services-thumb-03.webp" alt="image">
                            <div class="rs-services-btn">
                                <a class="rs-btn has-icon has-bg-white hover-primary has-md-radius w-100"
                                    href="services-details.php">Explore More
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="rs-services-content">
                            <h5 class="rs-services-title underline is-white"><a href="services-details.php">
                                    Marketing
                                    Consulting</a></h5>
                            <p class="rs-services-desc"> Complex data into clear and strategic insights that
                                improve
                                performance guide growth.</p>
                            <div class="rs-services-list-wrapper">
                                <h6 class="rs-services-list-title">Data Analysis</h6>
                                <div class="rs-services-list-item-wrapper">
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Regulatory Investigations </p>
                                    </div>
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Anit- Competitive Conduct</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="rs-services-item rs-services-fan-card" id="svc2">
                        <div class="rs-services-thumb">
                            <img src="assets/images/services/services-thumb-04.webp" alt="image">
                            <div class="rs-services-btn">
                                <a class="rs-btn has-icon has-bg-white hover-primary has-md-radius w-100"
                                    href="services-details.php">Explore More
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="rs-services-content">
                            <h5 class="rs-services-title underline is-white"><a href="services-details.php">
                                    Financial
                                    Insurance</a></h5>
                            <p class="rs-services-desc"> we analyze structured and unstructured data to help you
                                optimize
                                operations.</p>
                            <div class="rs-services-list-wrapper">
                                <h6 class="rs-services-list-title">Bank Cost</h6>
                                <div class="rs-services-list-item-wrapper">
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Save costs for your development </p>
                                    </div>
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Cancel anytime you want</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="rs-services-item rs-services-fan-card" id="svc3">
                        <div class="rs-services-thumb">
                            <img src="assets/images/services/services-thumb-05.webp" alt="image">
                            <div class="rs-services-btn">
                                <a class="rs-btn has-icon has-bg-white hover-primary has-md-radius w-100"
                                    href="services-details.php">Explore More
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="rs-services-content">
                            <h5 class="rs-services-title underline is-white"><a href="services-details.php">
                                    Portfolio
                                    Management</a></h5>
                            <p class="rs-services-desc"> Every number tells a story We analyze your data to
                                uncover
                                patterns and highlight</p>
                            <div class="rs-services-list-wrapper">
                                <h6 class="rs-services-list-title">CV Solutions</h6>
                                <div class="rs-services-list-item-wrapper">
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Regulatory Investigations</p>
                                    </div>
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Management System</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="rs-services-item rs-services-fan-card" id="svc4">
                        <div class="rs-services-thumb">
                            <img src="assets/images/services/services-thumb-06.webp" alt="image">
                            <div class="rs-services-btn">
                                <a class="rs-btn has-icon has-bg-white hover-primary has-md-radius w-100"
                                    href="services-details.php">Explore More
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="rs-services-content">
                            <h5 class="rs-services-title underline is-white"><a href="services-details.php">
                                    Business
                                    Insurances</a></h5>
                            <p class="rs-services-desc"> We provide the best services ensuring your outstanding
                                growth
                                Lorem ipsum dolor.</p>
                            <div class="rs-services-list-wrapper">
                                <h6 class="rs-services-list-title">Effective Retail</h6>
                                <div class="rs-services-list-item-wrapper">
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Conversion Optimization </p>
                                    </div>
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Anit- Competitive Conduct</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div><!-- /fan-stage -->
            </div><!-- /fan-sticky -->
        </div>
        <!-- services area end -->

        <!-- ══ SERVICES FAN SCROLL CSS ══ -->
        <style>
            /* ── SCROLL WRAPPER ── */
            .rs-services-fan-scroll {
                position: relative;
                height: 380vh;
                /* scroll travel = animation length */
            }

            /* ── STICKY VIEWPORT (pins while scrolling 380vh) ── */
            .rs-services-fan-sticky {
                position: sticky;
                top: 0;
                height: 100vh;
                overflow: hidden;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                /* exact theme-secondary color from --rs-theme-secondary: #2B3944 */
                background: var(--rs-theme-secondary, #2B3944);
            }

            /* ── BACKGROUND SHAPE ── */
            .rs-services-fan-shape {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                pointer-events: none;
                z-index: 0;
            }

            .rs-services-fan-shape img {
                width: 100%;
                height: 100%;
                object-fit: cover;
                opacity: 0.18;
            }

            /* ── HEADING ── */
            .rs-services-fan-heading {
                text-align: center;
                margin-bottom: 32px;
                position: relative;
                z-index: 10;
                padding: 0 20px;
            }

            .rs-services-fan-heading .section-subtitle.is-white {
                display: block;
                margin-bottom: 10px;
            }

            /* ── STAGE: the 4-card absolute canvas ── */
            .rs-services-fan-stage {
                position: relative;
                width: 100%;
                /* auto height — cards are absolute positioned, stage just holds z-context */
                height: 480px;
                z-index: 5;
                flex-shrink: 0;
            }

            /* ── FAN STAGE: cap image height so full card fits within 100vh ── */
            .rs-services-fan-stage .rs-services-thumb {
                height: 160px;
                overflow: hidden;
            }

            .rs-services-fan-stage .rs-services-thumb img {
                width: 100%;
                height: 100%;
                object-fit: cover;
            }

            /* ── FAN CARD base ── */
            .rs-services-fan-card {
                position: absolute !important;
                /* Start stacked center — JS sets width & position */
                left: 50%;
                top: 50%;
                transform: translate(-50%, -50%);
                will-change: transform, left, top;
                margin: 0 !important;
                float: none !important;
                transition: none !important;
                /* CRITICAL: Prevent CSS transitions from fighting GSAP */
            }

            /* ── MOBILE SIMPLE SET ── */
            @media (max-width: 991px) {
                .rs-services-fan-scroll {
                    height: auto !important;
                }

                .rs-services-fan-sticky {
                    position: relative !important;
                    top: auto !important;
                    height: auto !important;
                    padding: 60px 0 !important;
                    display: block !important;
                }

                .rs-services-fan-stage {
                    height: auto !important;
                    display: flex !important;
                    flex-direction: column !important;
                    gap: 30px !important;
                    padding: 0 15px !important;
                }

                .rs-services-fan-card {
                    position: relative !important;
                    left: auto !important;
                    top: auto !important;
                    transform: none !important;
                    width: 100% !important;
                    margin-bottom: 20px !important;
                }

                .rs-services-fan-stage .rs-services-thumb {
                    height: auto !important;
                }
            }
        </style>

        <!-- ══ GSAP + ScrollTrigger for fan animation ══ -->
        <script>
            (function () {
                // Wait for GSAP to load (already loaded on page)
                function initServicesFan() {
                    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
                        setTimeout(initServicesFan, 100);
                        return;
                    }
                    gsap.registerPlugin(ScrollTrigger);

                    var section = document.getElementById('servicesFanSection');
                    var cards = [
                        document.getElementById('svc1'),
                        document.getElementById('svc2'),
                        document.getElementById('svc3'),
                        document.getElementById('svc4')
                    ];

                    if (!section || cards.some(function (c) { return !c; })) return;

                    // Match original rs-services-two grid:
                    // padding: 75px each side (0px on ≤1600px), gap: 30px
                    var GAP = 30; // same as original grid gap

                    function calcCardW() {
                        var vw = window.innerWidth;
                        // mirror the responsive padding from the original CSS
                        var sidePad = vw > 1600 ? 75 : 0;
                        return Math.floor((vw - sidePad * 2 - GAP * 3) / 4);
                    }

                    var tl;

                    function build() {
                        if (tl) tl.kill();
                        ScrollTrigger.getAll().forEach(function (t) {
                            if (t.vars && t.vars.id === 'servicesFan') t.kill();
                        });

                        var vw = window.innerWidth;

                        // Mobile fallback: clear GSAP styles and exit
                        if (vw < 992) {
                            cards.forEach(function (c) {
                                gsap.set(c, { clearProps: "all" });
                                c.style.width = '100%';
                            });
                            return;
                        }

                        var cardW = calcCardW();

                        // Apply the correct width to every card so they look original
                        cards.forEach(function (c) {
                            c.style.width = cardW + 'px';
                        });

                        // side padding mirrors the original wrapper padding
                        var sidePad = vw > 1600 ? 75 : 0;

                        // Final X positions for each card (left edge)
                        var finalX = [0, 1, 2, 3].map(function (i) {
                            return sidePad + i * (cardW + GAP);
                        });

                        // Final vertical center of stage
                        var stageH = document.querySelector('.rs-services-fan-stage').offsetHeight;
                        var cardH = cards[0].offsetHeight;
                        var finalY = (stageH - cardH) / 2;

                        // z-index: last card on bottom, first card on top
                        cards.forEach(function (c, i) {
                            gsap.set(c, { zIndex: cards.length - i });
                        });

                        // reset to center stack
                        cards.forEach(function (c) {
                            gsap.set(c, {
                                left: '50%',
                                top: '50%',
                                xPercent: -50,
                                yPercent: -50
                            });
                        });

                        tl = gsap.timeline({
                            id: 'servicesFan',
                            scrollTrigger: {
                                trigger: section,
                                start: 'top top',
                                end: 'bottom bottom',
                                scrub: 1.5
                            }
                        });

                        // Fan cards out to their row positions
                        cards.forEach(function (card, i) {
                            tl.to(card, {
                                left: finalX[i] + 'px',
                                top: finalY + 'px',
                                xPercent: 0,
                                yPercent: 0,
                                duration: 1,
                                ease: 'power2.inOut'
                            }, i * 0.08);
                        });
                    }

                    build();
                    window.addEventListener('resize', function () {
                        ScrollTrigger.refresh();
                        build();
                    });
                }

                // Delay slightly to ensure GSAP libs are ready
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', initServicesFan);
                } else {
                    initServicesFan();
                }
            })();
        </script>



        <!-- services area start — Timeline Component (scroll-driven animation) -->
        <style>
        /* ── SCROLL WRAPPER ── */
        .timeline-scroll-driver {
            height: 400vh;
            position: relative;
        }

        /* ── STICKY VIEWPORT ── */
        .timeline-sticky-container {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            background-color: #2B3944;
            font-family: 'Outfit', sans-serif;
        }

        .timeline-sticky-container .rs-services-fan-shape-bg {
            position: absolute;
            top: 0; left: 0;
            width: 100%; height: 100%;
            pointer-events: none;
            z-index: 0;
        }
        .timeline-sticky-container .rs-services-fan-shape-bg img {
            width: 100%; height: 100%;
            object-fit: cover;
            opacity: 0.18;
        }

        /* ── INNER CONTAINER ── */
        .timeline-inner-container {
            --primary-bg: #2B3944;
            --accent-theme: #AB052D;
            --accent-hover: #8a0424;
            --text-dark: #FFFFFF;
            --text-muted: rgba(255, 255, 255, 0.7);
            --card-radius: 20px;
            max-width: 1200px;
            width: 100%;
            text-align: center;
            padding: 40px 20px;
            position: relative;
            z-index: 2;
            color: #FFFFFF;
        }

        .timeline-inner-container .header-custom {
            margin-bottom: 60px;
            opacity: 0; /* Hidden by default for JS animation */
            transform: translateY(-20px);
        }
        .timeline-inner-container .header-custom .section-subtitle {
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 10px;
            display: inline-block;
            font-weight: 600;
            color: rgba(255,255,255,0.7);
            font-size: 14px;
        }
        .timeline-inner-container .header-custom h2 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 20px;
            line-height: 1.2;
            color: #fff;
        }
        .timeline-inner-container .header-custom p {
            font-size: 1.1rem;
            color: rgba(255,255,255,0.7);
            max-width: 700px;
            margin: 0 auto;
            line-height: 1.6;
        }

        .timeline-inner-container .timeline {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 15px;
            margin-bottom: 60px;
            position: relative;
            width: 100%;
        }
        .timeline-inner-container .timeline-item {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .timeline-inner-container .card {
            width: 100%;
            aspect-ratio: 4/3;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            margin-bottom: 30px;
            background: rgba(255,255,255,0.08);
            will-change: transform, opacity;
            position: relative;
        }
        .timeline-inner-container .card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .timeline-inner-container .connector {
            width: 1px;
            height: 80px;
            background: linear-gradient(to bottom, rgba(255,255,255,0.3), rgba(255,255,255,0.05));
            margin-bottom: 20px;
        }
        .timeline-inner-container .label { text-align: center; }
        .timeline-inner-container .year {
            font-size: 0.85rem;
            font-weight: 600;
            color: rgba(255,255,255,0.7);
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .timeline-inner-container .gen-name {
            font-size: 0.95rem;
            font-weight: 700;
            color: #FFFFFF;
            text-transform: uppercase;
            letter-spacing: 1px;
            line-height: 1.3;
        }
        .timeline-inner-container .cta-button {
            display: inline-flex;
            align-items: center;
            background-color: #AB052D;
            color: #ffffff;
            padding: 16px 32px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 700;
            font-size: 1rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: none;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(171,5,45,0.3);
            opacity: 0;
            transform: translateY(20px);
        }
        .timeline-inner-container .cta-button span { margin-right: 10px; }
        .timeline-inner-container .cta-button i { font-style: normal; }

        @media (max-width: 1024px) {
            .timeline-inner-container .timeline { flex-wrap: wrap; justify-content: center; gap: 40px 20px; }
            .timeline-inner-container .timeline-item { flex: 0 0 calc(33.333% - 20px); }
        }
        @media (max-width: 768px) {
            .timeline-inner-container .timeline-item { flex: 0 0 calc(50% - 20px); }
            .timeline-inner-container .header-custom h2 { font-size: 2.5rem; }
        }
        @media (max-width: 480px) {
            .timeline-inner-container .timeline-item { flex: 0 0 100%; }
            .timeline-inner-container .connector { height: 40px; }
            .timeline-inner-container .header-custom h2 { font-size: 2rem; }
        }
        </style>

        <!-- Timeline Scroll Driver -->
        <div class="timeline-scroll-driver">
            <div class="timeline-sticky-container">
                <!-- background shape -->
                <div class="rs-services-fan-shape-bg">
                    <img src="assets/images/shape/services-shape-01.webp" alt="">
                </div>

                <div class="timeline-inner-container">
                    <header class="header-custom">
                        <span class="section-subtitle">How It Works</span>
                        <h2>Service for your development</h2>
                        <p>We believe that every business is unique and our approach aims for unparalleled growth. Explore our key offerings below.</p>
                    </header>

                    <div class="timeline" id="howItWorksTimeline" role="list">
                        <!-- Card 1 -->
                        <div class="timeline-item" role="listitem">
                            <div class="card" id="hiw-card-1"><img src="assets/images/banner/banner-thumb-02.webp" alt="IT & Emerging Tech Enablement Solution"></div>
                            <div class="connector"></div>
                            <div class="label"><div class="year">01</div><div class="gen-name">IT & Emerging Tech<br>Enablement</div></div>
                        </div>
                        <!-- Card 2 -->
                        <div class="timeline-item" role="listitem">
                            <div class="card" id="hiw-card-2"><img src="assets/images/banner/assessment-testing.webp" alt="Assessment & Testing Solution"></div>
                            <div class="connector"></div>
                            <div class="label"><div class="year">02</div><div class="gen-name">Assessment &<br>Testing</div></div>
                        </div>
                        <!-- Card 3 -->
                        <div class="timeline-item" role="listitem">
                            <div class="card" id="hiw-card-3"><img src="assets/images/banner/recruitment.webp" alt="Recruitment & Hiring Solution"></div>
                            <div class="connector"></div>
                            <div class="label"><div class="year">03</div><div class="gen-name">Recruitment &<br>Hiring</div></div>
                        </div>
                        <!-- Card 4 -->
                        <div class="timeline-item" role="listitem">
                            <div class="card" id="hiw-card-4"><img src="assets/images/banner/exam-management.webp" alt="Exam Management Solution"></div>
                            <div class="connector"></div>
                            <div class="label"><div class="year">04</div><div class="gen-name">Exam<br>Management</div></div>
                        </div>
                        <!-- Card 5 -->
                        <div class="timeline-item" role="listitem">
                            <div class="card" id="hiw-card-5"><img src="assets/images/banner/manpower.webp" alt="Manpower & Workforce Solution"></div>
                            <div class="connector"></div>
                            <div class="label"><div class="year">05</div><div class="gen-name">Manpower &<br>Workforce</div></div>
                        </div>
                        <!-- Card 6 -->
                        <div class="timeline-item" role="listitem">
                            <div class="card" id="hiw-card-6"><img src="assets/images/banner/call-center.webp" alt="Call Center & BPOs Solution"></div>
                            <div class="connector"></div>
                            <div class="label"><div class="year">06</div><div class="gen-name">Call Center &<br>BPOs</div></div>
                        </div>
                    </div><!-- /timeline -->

                    <a href="solutions.php" class="cta-button" id="hiw-explore-btn">
                        <span>Explore our solutions</span><i>&rarr;</i>
                    </a>
                </div><!-- /timeline-inner-container -->
            </div><!-- /timeline-sticky-container -->
        </div><!-- /timeline-scroll-driver -->
        <!-- services area end -->

        <!-- GSAP Scroll Animation for How It Works Section -->
        <script>
        (function() {
            function buildHIWAnimation() {
                if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
                    setTimeout(buildHIWAnimation, 100);
                    return;
                }

                if (window._hiwCtx) window._hiwCtx.revert();

                var scrollDriver = document.querySelector('.timeline-scroll-driver');
                if (!scrollDriver) return;

                window._hiwCtx = gsap.context(function() {
                    var cards = gsap.utils.toArray('.timeline-scroll-driver .card');
                    var card1 = cards[0];
                    var otherCards = cards.slice(1);
                    var connectors = gsap.utils.toArray('.timeline-scroll-driver .connector');
                    var labels = gsap.utils.toArray('.timeline-scroll-driver .label');
                    var cta = document.getElementById('hiw-explore-btn');

                    var sticky = document.querySelector('.timeline-sticky-container');
                    var vw = window.innerWidth;
                    var vh = window.innerHeight;

                    // Snapshot each card's distance from the center of the STICKY container
                    // This is much safer than viewport-relative bounds which change on scroll
                    var snap = cards.map(function(card) {
                        var cr = card.getBoundingClientRect();
                        var sr = sticky.getBoundingClientRect();
                        return {
                            // Distance from card center to sticky container center
                            xToCenter: (sr.width / 2) - (cr.left - sr.left + cr.width / 2),
                            yToCenter: (sr.height / 2) - (cr.top - sr.top + cr.height / 2),
                            width: cr.width,
                            height: cr.height
                        };
                    });

                    // Ensure Full-screen cover for Card 1 (Exactly 100vh/100vw coverage)
                    // We use the sticky container's dimensions as it is the 100vh view area
                    var coverScale = Math.max(vw / snap[0].width, vh / snap[0].height);

                    // Fade out section headers initially so the fullscreen image is the focus
                    var sectionHeader = document.querySelector('.timeline-inner-container .header-custom');
                    gsap.set(sectionHeader, { opacity: 0, y: -20 });

                    // Hide connectors, labels, CTA
                    gsap.set([connectors, labels, cta], { opacity: 0, y: 20 });

                    // Card 1: Fixed starting state (Fullscreen Covering 100vh)
                    gsap.set(card1, {
                        x: snap[0].xToCenter,
                        y: snap[0].yToCenter,
                        scale: coverScale,
                        borderRadius: '0px',
                        zIndex: 100, // Top layer
                        transformOrigin: '50% 50%'
                    });

                    // Cards 2-6: stacked deck hidden behind card 1
                    otherCards.forEach(function(card, index) {
                        var deckOffsetX = (index + 1) * 6;
                        var deckOffsetY = (index + 1) * 4;
                        var deckScale   = 1 - ((index + 1) * 0.03);
                        gsap.set(card, {
                            x: snap[index + 1].xToCenter + deckOffsetX,
                            y: snap[index + 1].yToCenter + deckOffsetY,
                            scale: deckScale,
                            opacity: 0,
                            zIndex: 90 - index,
                            transformOrigin: '50% 50%'
                        });
                    });

                    // Timeline driven by scroll with precise scrub alignment
                    var tl = gsap.timeline({
                        scrollTrigger: {
                            trigger: '.timeline-scroll-driver',
                            start: 'top top',
                            end: 'bottom bottom',
                            scrub: 1.2, // Smoother scrub
                            invalidateOnRefresh: true, // Handle layout shifts better
                            anticipatePin: 1
                        }
                    });

                    // Phase 1: Card 1 shrinks (Zoom Out)
                    // We use fromTo to ensure GSAP forces the starting state correctly
                    tl.fromTo(card1, {
                        scale: coverScale,
                        borderRadius: '0px'
                    }, {
                        scale: 1,
                        borderRadius: '32px',
                        ease: 'power2.inOut',
                        duration: 0.4
                    }, 0);

                    // Phase 2: Section Header fades in AFTER zoom out starts (staggered)
                    tl.fromTo(sectionHeader, {
                        opacity: 0,
                        y: -20
                    }, {
                        opacity: 1,
                        y: 0,
                        duration: 0.2,
                        ease: 'power1.out'
                    }, 0.35); // Start slightly before zoom ends for smoothness

                    // Phase 3: Other 5 cards appear and all cards spread
                    tl.to(otherCards, { opacity: 1, duration: 0.1 }, 0.55)
                      .to(cards, {
                        x: 0,
                        y: 0,
                        scale: 1,
                        ease: 'power2.inOut',
                        duration: 0.35
                    }, 0.55);

                    // Phase 4: Fade in connectors, labels, CTA (the workflow below)
                    tl.to(connectors, { opacity: 1, y: 0, stagger: 0.02, duration: 0.1, ease: 'power1.out' }, 0.85)
                      .to(labels,     { opacity: 1, y: 0, stagger: 0.02, duration: 0.1, ease: 'power1.out' }, 0.90)
                      .to(cta,        { opacity: 1, y: 0, duration: 0.1, ease: 'power1.out' }, 0.95);
                });
            }

            // Execute on load and refresh
            window.addEventListener('load', function() {
                buildHIWAnimation();
                ScrollTrigger.refresh();
            });

            var _hiwResizeTimer;
            window.addEventListener('resize', function() {
                clearTimeout(_hiwResizeTimer);
                _hiwResizeTimer = setTimeout(function() {
                    buildHIWAnimation();
                    ScrollTrigger.refresh();
                }, 250);
            });
        })();
        </script>

        <!-- (dummy section tag to satisfy original template PHP structure — EMPTY) -->
        <section class="rs-services-area section-space theme-secondary rs-services-two"
            style="display:none !important; height:0 !important; overflow:hidden !important; padding:0 !important; margin:0 !important;">
            <div class="rs-services-wrapper">
                <div class="rs-services-item wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
                    <div class="rs-services-thumb">
                        <img src="assets/images/services/services-thumb-03.webp" alt="image">
                        <div class="rs-services-btn">
                            <a class="rs-btn has-icon has-bg-white hover-primary has-md-radius w-100"
                                href="services-details.php">Explore More
                                <span class="icon-box">
                                    <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                            fill="white" />
                                    </svg>

                                    <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                            fill="white" />
                                    </svg>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="rs-services-content">
                        <h5 class="rs-services-title underline is-white"><a href="services-details.php">
                                Marketing
                                Consulting</a></h5>
                        <p class="rs-services-desc"> Complex data into clear and strategic insights that
                            improve
                            performance guide growth.</p>
                        <div class="rs-services-list-wrapper">
                            <h6 class="rs-services-list-title">Data Analysis</h6>
                            <div class="rs-services-list-item-wrapper">
                                <div class="rs-services-list-item">
                                    <div class="rs-services-list-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                            viewBox="0 0 12 10" fill="none">
                                            <path
                                                d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                fill="black"></path>
                                        </svg>
                                    </div>
                                    <p> Regulatory Investigations </p>
                                </div>
                                <div class="rs-services-list-item">
                                    <div class="rs-services-list-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                            viewBox="0 0 12 10" fill="none">
                                            <path
                                                d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                fill="black"></path>
                                        </svg>
                                    </div>
                                    <p> Anit- Competitive Conduct</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="rs-services-item wow fadeInUp" data-wow-delay=".5s" data-wow-duration="1s">
                    <div class="rs-services-thumb">
                        <img src="assets/images/services/services-thumb-04.webp" alt="image">
                        <div class="rs-services-btn">
                            <a class="rs-btn has-icon has-bg-white hover-primary has-md-radius w-100"
                                href="services-details.php">Explore More
                                <span class="icon-box">
                                    <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                            fill="white" />
                                    </svg>

                                    <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                            fill="white" />
                                    </svg>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="rs-services-content">
                        <h5 class="rs-services-title underline is-white"><a href="services-details.php">
                                Financial
                                Insurance</a></h5>
                        <p class="rs-services-desc"> we analyze structured and unstructured data to help you
                            optimize
                            operations.</p>
                        <div class="rs-services-list-wrapper">
                            <h6 class="rs-services-list-title">Bank Cost</h6>
                            <div class="rs-services-list-item-wrapper">
                                <div class="rs-services-list-item">
                                    <div class="rs-services-list-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                            viewBox="0 0 12 10" fill="none">
                                            <path
                                                d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                fill="black"></path>
                                        </svg>
                                    </div>
                                    <p> Save costs for your development </p>
                                </div>
                                <div class="rs-services-list-item">
                                    <div class="rs-services-list-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                            viewBox="0 0 12 10" fill="none">
                                            <path
                                                d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                fill="black"></path>
                                        </svg>
                                    </div>
                                    <p> Cancel anytime you want</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="rs-services-item wow fadeInUp" data-wow-delay=".7s" data-wow-duration="1s">
                    <div class="rs-services-thumb">
                        <img src="assets/images/services/services-thumb-05.webp" alt="image">
                        <div class="rs-services-btn">
                            <a class="rs-btn has-icon has-bg-white hover-primary has-md-radius w-100"
                                href="services-details.php">Explore More
                                <span class="icon-box">
                                    <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                            fill="white" />
                                    </svg>

                                    <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                            fill="white" />
                                    </svg>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="rs-services-content">
                        <h5 class="rs-services-title underline is-white"><a href="services-details.php">
                                Portfolio
                                Management</a></h5>
                        <p class="rs-services-desc"> Every number tells a story We analyze your data to
                            uncover
                            patterns and highlight</p>
                        <div class="rs-services-list-wrapper">
                            <h6 class="rs-services-list-title">CV Solutions</h6>
                            <div class="rs-services-list-item-wrapper">
                                <div class="rs-services-list-item">
                                    <div class="rs-services-list-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                            viewBox="0 0 12 10" fill="none">
                                            <path
                                                d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                fill="black"></path>
                                        </svg>
                                    </div>
                                    <p> Regulatory Investigations</p>
                                </div>
                                <div class="rs-services-list-item">
                                    <div class="rs-services-list-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                            viewBox="0 0 12 10" fill="none">
                                            <path
                                                d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                fill="black"></path>
                                        </svg>
                                    </div>
                                    <p> Management System</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="rs-services-item wow fadeInUp" data-wow-delay=".9s" data-wow-duration="1s">
                    <div class="rs-services-thumb">
                        <img src="assets/images/services/services-thumb-06.webp" alt="image">
                        <div class="rs-services-btn">
                            <a class="rs-btn has-icon has-bg-white hover-primary has-md-radius w-100"
                                href="services-details.php">Explore More
                                <span class="icon-box">
                                    <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                            fill="white" />
                                    </svg>

                                    <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                            fill="white" />
                                    </svg>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="rs-services-content">
                        <h5 class="rs-services-title underline is-white"><a href="services-details.php">
                                Business
                                Insurances</a></h5>
                        <p class="rs-services-desc"> We provide the best services ensuring your outstanding
                            growth
                            Lorem ipsum dolor.</p>
                        <div class="rs-services-list-wrapper">
                            <h6 class="rs-services-list-title">Effective Retail</h6>
                            <div class="rs-services-list-item-wrapper">
                                <div class="rs-services-list-item">
                                    <div class="rs-services-list-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                            viewBox="0 0 12 10" fill="none">
                                            <path
                                                d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                fill="black"></path>
                                        </svg>
                                    </div>
                                    <p> Conversion Optimization </p>
                                </div>
                                <div class="rs-services-list-item">
                                    <div class="rs-services-list-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                            viewBox="0 0 12 10" fill="none">
                                            <path
                                                d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                fill="black"></path>
                                        </svg>
                                    </div>
                                    <p> Anit- Competitive Conduct</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            </div>
            </div>
        </section>
        <!-- services area end -->

        <!-- video area start -->
        <div class="rs-video-area rs-video-one rs-video-two">
            <div class="rs-video-bg-thumb include-bg" data-background="assets/images/bg/video-bg-thumb-02.webp">
            </div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-4">
                        <div class="rs-video-wrapper text-center">
                            <div class="rs-video-play-btn rs-tween_max_btn-yes gsap-move-no">
                                <a href="https://www.youtube.com/watch?v=go7QYaQR494"
                                    class="rs-play-btn popup-video is-large is-white"><i
                                        class="ri-play-large-fill"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- video area end -->

        <!-- cta area start -->
        <section class="rs-cta-area rs-cta-two">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-cta-wrapper wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
                            <div class="rs-cta-form">
                                <h5 class="rs-cta-title">Get a Consultation Today, it's Free!</h5>
                                <form id="contact-form" action="./assets/mailer.php" method="POST">
                                    <div class="rs-cta-input">
                                        <input id="name" name="name" type="text" placeholder="Enter your email">
                                        <div class="rs-cta-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="12"
                                                viewBox="0 0 16 12" fill="none">
                                                <path
                                                    d="M15.8603 1.17969L11.0078 6.00091L15.8603 10.8221C15.948 10.6388 16.0012 10.4361 16.0012 10.2197V1.78216C16.0012 1.56569 15.948 1.36303 15.8603 1.17969Z"
                                                    fill="white"></path>
                                                <path
                                                    d="M14.5947 0.375H1.40716C1.19069 0.375 0.988031 0.428219 0.804688 0.515938L7.00666 6.68666C7.55503 7.23503 8.44678 7.23503 8.99516 6.68666L15.1971 0.515938C15.0138 0.428219 14.8111 0.375 14.5947 0.375Z"
                                                    fill="white"></path>
                                                <path
                                                    d="M0.140938 1.17969C0.0532188 1.36303 0 1.56569 0 1.78216V10.2197C0 10.4361 0.0532188 10.6388 0.140938 10.8221L4.99341 6.00091L0.140938 1.17969Z"
                                                    fill="white"></path>
                                                <path
                                                    d="M10.3447 6.66211L9.658 7.34877C8.74428 8.26248 7.2575 8.26248 6.34378 7.34877L5.65716 6.66211L0.804688 11.4833C0.988031 11.571 1.19069 11.6243 1.40716 11.6243H14.5947C14.8111 11.6243 15.0138 11.571 15.1971 11.4833L10.3447 6.66211Z"
                                                    fill="white"></path>
                                            </svg>
                                        </div>
                                        <button type="submit" class="rs-btn has-icon has-bg-secondary has-sm-radius">
                                            Let's Talk
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <div class="rs-cta-content">
                                <div class="rs-cta-content-info">
                                    <div class="rs-cta-thumb">
                                        <img src="assets/images/user/indian-experts.png" alt="Indian Experts">
                                    </div>
                                    <h5 class="rs-cta-meta-title">Contact Our Experts</h5>
                                </div>
                                <p class="rs-cta-desc">We provide the best services to ensuring your outstanding growth
                                    Lorem
                                    ipsum dolor sit.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- cta area end -->

        <!-- feature area start -->
        <section class="rs-feature-area rs-feature-three section-space">
            <div class="container" id="solutions">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-feature-wrapper">
                            <div class="rs-feature-sec-wrapper">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle">
                                        Build Your Industries
                                    </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left mb-10">Industries we
                                        help</h2>
                                    <p class="section-desc">We support businesses in tech, retail, real estate, finance,
                                        healthcare, and more providing custom strategies that work in your world.</p>
                                </div>
                                <div class="rs-feature-more-btn">
                                    <a class="rs-btn has-icon hover-secondary border-hover-primary"
                                        href="industry.php">View All
                                        Industries
                                        <span class="icon-box">
                                            <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>

                                            <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="rs-feature-content-wrapper">
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".1s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-05.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="it-emerging-tech-enablement.php">IT & Emerging Tech Enablement </a></h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="it-emerging-tech-enablement.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".2s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-06.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="assessment-and-testing.php">Assessment & Testing
                                            </a></h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="assessment-and-testing.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".3s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-07.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="recruitment-and-hiring.php">Recruitment & Hiring</a></h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="recruitment-and-hiring.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".4s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-08.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="exam-management.php">Exam Management</a>
                                        </h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="exam-management.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".5s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-09.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="manpower-and-workforce.php">Manpower & Workforce</a>
                                        </h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="manpower-and-workforce.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".6s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-10.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="call-center-and-bpos.php">Call Center & BPOs</a>
                                        </h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="call-center-and-bpos.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- feature area end -->

        <!-- text slider area start -->
        <div class="rs-text-slide-area rs-text-slide-one">
            <div class="rs-text-slide-wrapper">
                <div class="gsap-marquee right speed-20 move-to-1000">
                    <div class="rs-text-slide-inner">
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">IT & Emerging Tech Enablement</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Assessment & Testing</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Recruitment & Hiring</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Exam Management</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Manpower & Workforce</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Call Center & BPOs</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">IT & Emerging Tech Enablement</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Assessment & Testing</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Recruitment & Hiring</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Exam Management</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Manpower & Workforce</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Call Center & BPOs</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">IT & Emerging Tech Enablement</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Assessment & Testing</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Recruitment & Hiring</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Exam Management</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Manpower & Workforce</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Call Center & BPOs</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">IT & Emerging Tech Enablement</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Assessment & Testing</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Recruitment & Hiring</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>
                        <div class="rs-text-slide-item">
                            <h5 class="rs-text-slide-title">Exam Management</h5>
                            <div class="rs-text-slide-thumb">
                                <img src="assets/images/shape/multi-line-shape.webp" alt="image">
                            </div>
                        </div>                    
                    </div>
                </div>
            </div>
        </div>
        <!-- text slider area end -->

        <!-- why choose area start -->
        <section class="rs-why-choose-area rs-why-choose-two">
            <div class="rs-why-choose-bg-thumb include-bg"
                data-background="assets/images/bg/why-choose-bg-thumb-01.webp">
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-why-choose-wrapper">
                            <div class="section-title-wrapper text-center section-title-space">
                                <span class="section-subtitle is-white">
                                    Why choose us
                                </span>
                                <h2 class="section-title rs-split-text-enable split-in-left is-white mb-10">Achieving
                                    growth
                                    through collaboration</h2>
                                <p class="section-desc">We believe that every business is uniquids our approach is never
                                    one
                                    size fits all We tailor
                                </p>
                            </div>
                            <div class="rs-why-choose-tab-wrapper">
                                <div class="rs-why-choose-tab">
                                    <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link active" id="pills-item-one-tab"
                                                data-bs-toggle="pill" data-bs-target="#pills-item-one" type="button"
                                                role="tab" aria-controls="pills-item-one" aria-selected="true">
                                                Why Need Marketing
                                            </button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="pills-item-two-tab" data-bs-toggle="pill"
                                                data-bs-target="#pills-item-two" type="button" role="tab"
                                                aria-controls="pills-item-two" aria-selected="false"> Why Choose us
                                            </button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="pills-item-three-tab" data-bs-toggle="pill"
                                                data-bs-target="#pills-item-three" type="button" role="tab"
                                                aria-controls="pills-item-three" aria-selected="false">
                                                How it Works
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                                <div class="rs-why-chyoose-tab-content-wrapper">
                                    <div class="tab-content rs-why-choose-tab-anim" id="pills-tabContent">
                                        <div class="tab-pane fade show active" id="pills-item-one" role="tabpanel"
                                            aria-labelledby="pills-item-one-tab" tabindex="0">
                                            <div class="rs-why-choose-tab-item">
                                                <div class="rs-why-choose-tab-thumb">
                                                    <img src="assets/images/about/4.webp"
                                                        alt="image">
                                                </div>
                                                <div class="rs-why-choose-tab-content">
                                                    <h5 class="rs-why-choose-tab-title">Expert Consulting Proven
                                                        Strategies</h5>
                                                    <p class="rs-why-choose-tab-desc"> We provide the best services
                                                        ensuring your
                                                        outstanding growth Lorem ipsum
                                                        dolor sit amet. Nulla ultrices neque sodales best</p>
                                                    <div class="rs-why-choose-tab-list">
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Outstanding Performance
                                                            </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Strategy Meets
                                                                Technology </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Global Support Network
                                                            </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Exceptional
                                                                Communication </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Rapid Talent
                                                                Acquisition </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> 24/7 Availability
                                                                Across Time </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="pills-item-two" role="tabpanel"
                                            aria-labelledby="pills-item-two-tab" tabindex="0">
                                            <div class="rs-why-choose-tab-item">
                                                <div class="rs-why-choose-tab-thumb">
                                                    <img src="assets/images/about/12.webp"
                                                        alt="image">
                                                </div>
                                                <div class="rs-why-choose-tab-content">
                                                    <h5 class="rs-why-choose-tab-title">Expert Consulting Proven
                                                        Strategies</h5>
                                                    <p class="rs-why-choose-tab-desc"> We provide the best services
                                                        ensuring your
                                                        outstanding growth Lorem ipsum
                                                        dolor sit amet. Nulla ultrices neque sodales best</p>
                                                    <div class="rs-why-choose-tab-list">
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Outstanding Performance
                                                            </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Strategy Meets
                                                                Technology </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Global Support Network
                                                            </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Exceptional
                                                                Communication </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Rapid Talent
                                                                Acquisition </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> 24/7 Availability
                                                                Across Time </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="pills-item-three" role="tabpanel"
                                            aria-labelledby="pills-item-three-tab" tabindex="0">
                                            <div class="rs-why-choose-tab-item">
                                                <div class="rs-why-choose-tab-thumb">
                                                    <img src="assets/images/about/13.webp"
                                                        alt="image">
                                                </div>
                                                <div class="rs-why-choose-tab-content">
                                                    <h5 class="rs-why-choose-tab-title">Expert Consulting Proven
                                                        Strategies</h5>
                                                    <p class="rs-why-choose-tab-desc"> We provide the best services
                                                        ensuring your
                                                        outstanding growth Lorem ipsum
                                                        dolor sit amet. Nulla ultrices neque sodales best</p>
                                                    <div class="rs-why-choose-tab-list">
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Outstanding Performance
                                                            </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Strategy Meets
                                                                Technology </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Global Support Network
                                                            </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Exceptional
                                                                Communication </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> Rapid Talent
                                                                Acquisition </p>
                                                        </div>
                                                        <div class="rs-why-choose-list-item">
                                                            <div class="rs-why-choose-list-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                    height="10" viewBox="0 0 12 10" fill="none">
                                                                    <path
                                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                                        fill="black"></path>
                                                                </svg>
                                                            </div>
                                                            <p class="rs-why-choose-list-title"> 24/7 Availability
                                                                Across Time </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- why choose area end -->

        <!-- counter area start -->
        <div class="rs-counter-area section-space rs-counter-two">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-counter-wrapper">
                            <div class="rs-counter-item wow fadeIn" data-wow-delay=".3s" data-wow-duration="1s">
                                <div class="rs-counter-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 38">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M10.5959 36.5456C10.0034 36.5456 9.52067 36.0625 9.52067 35.4686C9.52067 34.8755 10.0034 34.3925 10.5959 34.3925C11.1884 34.3925 11.6758 34.8756 11.6758 35.4686C11.6758 36.0626 11.1884 36.5456 10.5959 36.5456ZM10.5959 1.45436C11.1884 1.45436 11.6758 1.93651 11.6758 2.53042C11.6758 3.12345 11.1884 3.60657 10.5959 3.60657C10.0034 3.60657 9.52067 3.12345 9.52067 2.53042C9.52067 1.93651 10.0034 1.45436 10.5959 1.45436ZM10.5959 33.2605C9.97941 33.2605 9.42519 33.5147 9.02373 33.9232L1.98989 29.9241V8.07486L9.02373 4.07676C9.4251 4.48481 9.97941 4.73861 10.5959 4.73861C11.8144 4.73861 12.8035 3.74755 12.8035 2.53051C12.8035 1.3125 11.8144 0.322415 10.5959 0.322415C9.13189 0.322415 8.09401 1.71968 8.45992 3.09248L1.14413 7.25303C1.05726 7.30259 0.985011 7.3742 0.934672 7.46062C0.884332 7.54704 0.857686 7.64521 0.857422 7.74521V30.2539C0.857515 30.354 0.884089 30.4522 0.934446 30.5387C0.984803 30.6251 1.05715 30.6967 1.14413 30.7461L8.45992 34.9067C8.09401 36.2795 9.13215 37.6777 10.5959 37.6777C11.8144 37.6777 12.8035 36.6867 12.8035 35.4687C12.8035 34.2515 11.8143 33.2605 10.5959 33.2605ZM25.3994 36.5456C24.8069 36.5456 24.3242 36.0625 24.3242 35.4686C24.3242 34.8755 24.8068 34.3925 25.3994 34.3925C25.992 34.3925 26.4746 34.8756 26.4746 35.4686C26.4746 36.0626 25.9919 36.5456 25.3994 36.5456ZM25.3994 3.60657C24.8069 3.60657 24.3242 3.12345 24.3242 2.53042C24.3242 1.93651 24.8068 1.45436 25.3994 1.45436C25.992 1.45436 26.4746 1.93651 26.4746 2.53042C26.4746 3.12345 25.9919 3.60657 25.3994 3.60657ZM34.8511 7.25294L27.5353 3.09239C27.9013 1.72012 26.8636 0.322327 25.3994 0.322327C24.1809 0.322327 23.1917 1.31241 23.1917 2.53042C23.1917 3.74746 24.1809 4.73852 25.3994 4.73852C26.0158 4.73852 26.5749 4.48481 26.9763 4.07667L34.0101 8.07477V29.9241L26.9763 33.9232C26.5749 33.5146 26.0158 33.2605 25.3994 33.2605C24.1809 33.2605 23.1917 34.2515 23.1917 35.4686C23.1917 36.6866 24.1809 37.6776 25.3994 37.6776C26.8634 37.6776 27.9013 36.279 27.5353 34.9066L34.8511 30.746C34.9394 30.6977 35.013 30.6265 35.0643 30.5399C35.1155 30.4533 35.1426 30.3545 35.1426 30.2539V7.74513C35.1426 7.54202 35.0327 7.35423 34.8511 7.25294ZM17.9976 30.2194L6.72535 24.6507L11.1693 22.4564L17.7491 25.7063C17.9045 25.785 18.0931 25.7837 18.2509 25.7063L24.826 22.4564L29.2699 24.6507L17.9976 30.2194ZM6.72535 18.9997L11.1693 16.8054L17.7491 20.0547C17.9063 20.1339 18.0918 20.1324 18.2509 20.0547L24.826 16.8054L29.2699 18.9997L17.9976 24.5676L6.72535 18.9997ZM6.72535 13.3483L17.9976 7.78041L29.2699 13.3483L17.9976 18.9161L6.72535 13.3483ZM31.1144 24.6507C31.1144 24.8667 30.9901 25.0626 30.799 25.1587L18.2509 31.3582C18.0922 31.4346 17.9059 31.4361 17.7491 31.3572L5.19617 25.1587C4.77782 24.9503 4.77677 24.3517 5.19617 24.1437L9.8886 21.8252L5.19617 19.5072C4.77756 19.2992 4.77668 18.7008 5.19617 18.4918L9.8886 16.1738L5.19617 13.8553C4.77729 13.6476 4.77729 13.049 5.19617 12.8414L17.7491 6.64187C17.8271 6.60323 17.913 6.58313 18 6.58313C18.087 6.58313 18.1729 6.60323 18.2509 6.64187L30.799 12.8414C31.2179 13.0491 31.2179 13.6476 30.799 13.8553L26.1066 16.1738L30.799 18.4918C31.2185 18.7008 31.2176 19.2992 30.799 19.5072L26.1066 21.8252L30.799 24.1437C30.9901 24.2388 31.1144 24.4356 31.1144 24.6507Z">
                                        </path>
                                    </svg>
                                </div>
                                <div class="rs-counter-content">
                                    <div class="rs-counter-number-wrapper">
                                        <span class="rs-counter-number odometer" data-count="25.5">00</span>
                                        <span class="prefix">K</span>
                                    </div>
                                    <span class="rs-counter-title">Projects Completed</span>
                                </div>
                            </div>
                            <div class="rs-counter-item wow fadeIn" data-wow-delay=".5s" data-wow-duration="1s">
                                <div class="rs-counter-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 42">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M10.2804 37.4735C10.3637 37.5929 10.3963 37.7405 10.3708 37.8839C10.3454 38.0272 10.2641 38.1546 10.1447 38.238C10.0253 38.3214 9.87774 38.3539 9.73438 38.3285C9.59101 38.3031 9.46363 38.2217 9.38024 38.1023L9.34698 38.0548C9.26515 37.9354 9.2338 37.7885 9.25974 37.6461C9.28568 37.5037 9.36681 37.3772 9.48549 37.2943C9.60417 37.2114 9.75078 37.1788 9.89343 37.2034C10.0361 37.2281 10.1632 37.3081 10.2472 37.426L10.2804 37.4735ZM17.1957 31.0585C17.0552 31.0191 16.9361 30.9255 16.8647 30.7982C16.7932 30.671 16.7752 30.5206 16.8146 30.3801C16.854 30.2396 16.9476 30.1205 17.0748 30.0491C17.202 29.9776 17.3524 29.9595 17.4929 29.999L24.5166 31.9891C24.9679 32.1176 25.4516 32.0646 25.8644 31.8415C26.0649 31.7338 26.2421 31.5876 26.3858 31.4112C26.5295 31.2348 26.6369 31.0317 26.7017 30.8136C26.7174 30.7609 26.7304 30.708 26.7409 30.6551C26.7421 30.6478 26.7435 30.6405 26.745 30.6333C26.8221 30.2087 26.7402 29.7706 26.515 29.4026C26.2898 29.0345 25.937 28.7622 25.5239 28.6375C23.522 28.0418 21.5543 27.3344 19.6314 26.5187C16.1449 25.0778 15.9232 24.9873 8.99232 28.6527L13.501 35.1588L13.5879 35.0284L13.5895 35.0295L13.5901 35.0284C13.7665 34.7602 14.0256 34.5569 14.3281 34.4495C14.6306 34.342 14.9599 34.3363 15.2659 34.4332L23.6119 37.0182C25.8737 37.719 31.0783 33.8692 34.6205 31.2492C35.6292 30.5031 36.5085 29.8527 37.1512 29.4312C37.7487 29.0392 37.9579 28.6163 37.8999 28.2408C37.8609 28.0287 37.7658 27.831 37.6245 27.6682C37.4375 27.4493 37.2111 27.2675 36.957 27.1322C36.4282 26.8491 35.8325 26.7146 35.2333 26.7431C34.6341 26.7716 34.0539 26.9621 33.5544 27.2942L27.7686 31.0891C27.7649 31.1022 27.7612 31.1153 27.7573 31.1283C27.651 31.4854 27.4751 31.8179 27.2397 32.1067C27.0044 32.3954 26.7142 32.6348 26.3859 32.8109C25.7224 33.1698 24.9449 33.255 24.2194 33.0484L17.1957 31.0585ZM8.36137 27.7413L8.01031 27.2343C7.78531 26.9105 7.44116 26.689 7.05322 26.6184C6.66529 26.5478 6.26518 26.6338 5.94051 26.8575L1.62533 29.8481C1.30152 30.0731 1.08006 30.4173 1.00945 30.8052C0.93884 31.1932 1.02482 31.5933 1.24858 31.9179L7.59163 41.0713C7.81666 41.3951 8.16084 41.6166 8.5488 41.6872C8.93677 41.7578 9.3369 41.6718 9.6616 41.4481L13.9768 38.4574C14.3006 38.2324 14.5221 37.8883 14.5927 37.5003C14.6633 37.1123 14.5773 36.7122 14.3534 36.3875L14.1766 36.1324L14.5056 35.639L14.504 35.638C14.5497 35.5671 14.6177 35.5135 14.6973 35.4855C14.7768 35.4575 14.8635 35.4567 14.9435 35.4833L23.2894 38.0684C26.0802 38.933 31.5518 34.8858 35.2755 32.1313C36.2531 31.4082 37.1052 30.7779 37.7546 30.3524C38.7717 29.6853 39.1118 28.8617 38.9899 28.0723C38.9198 27.6652 38.7414 27.2844 38.4733 26.9701C38.198 26.6427 37.8634 26.3702 37.487 26.167C36.9023 25.8497 36.2526 25.6703 35.5878 25.6428C37.3848 23.2549 38.4701 20.4076 38.7185 17.4294C38.967 14.4513 38.3685 11.4635 36.992 8.81085C35.6156 6.15819 33.5173 3.94867 30.9392 2.43716C28.3611 0.925658 25.4083 0.173748 22.4212 0.26817C19.4342 0.362591 16.5347 1.2995 14.0573 2.97081C11.5798 4.64212 9.62523 6.97976 8.41907 9.71406C7.21292 12.4484 6.80431 15.4679 7.24036 18.4245C7.67641 21.381 8.93937 24.154 10.8835 26.4237C10.1445 26.801 9.31081 27.2387 8.36137 27.7413ZM11.8986 25.9144C10.0116 23.7915 8.77776 21.1687 8.34542 18.3614C7.91308 15.5541 8.30063 12.6816 9.46149 10.0892C10.6223 7.49686 12.5071 5.29487 14.8893 3.74789C17.2715 2.20091 20.0497 1.37476 22.8902 1.36872C25.7306 1.36269 28.5123 2.17703 30.901 3.71387C33.2898 5.25072 35.1839 7.44468 36.3558 10.0321C37.5276 12.6195 37.9274 15.4903 37.507 18.2994C37.0866 21.1086 35.8639 23.7365 33.9859 25.8675C33.621 25.9907 33.2734 26.1602 32.9517 26.3719L27.8152 29.7406C27.7102 29.2363 27.4711 28.7696 27.1232 28.3897C26.7753 28.0098 26.3313 27.7307 25.8381 27.5819C23.8711 26.9972 21.9383 26.3027 20.049 25.5015C16.8364 24.1739 16.0803 23.8622 11.8986 25.9144ZM13.0854 36.4877L13.0768 36.4773L13.0742 36.4734C13.0595 36.4543 13.046 36.4342 13.034 36.4132L7.10591 27.8589C7.07705 27.8173 7.04024 27.7817 6.99761 27.7543C6.95497 27.7269 6.90735 27.7082 6.85746 27.6993C6.80701 27.69 6.75523 27.6908 6.70509 27.7016C6.65495 27.7125 6.60744 27.7331 6.56527 27.7623L2.25009 30.7529C2.20842 30.7817 2.17286 30.8185 2.14544 30.8612C2.11803 30.9038 2.0993 30.9514 2.09034 31.0013C2.0811 31.0518 2.0819 31.1036 2.09271 31.1537C2.10352 31.2038 2.12412 31.2514 2.15333 31.2935L8.49689 40.4477C8.52577 40.4893 8.56257 40.5248 8.60519 40.5521C8.64781 40.5795 8.6954 40.5982 8.74525 40.6072C8.7957 40.6164 8.84748 40.6156 8.89762 40.6048C8.94776 40.594 8.99527 40.5734 9.03744 40.5442L13.3527 37.5535C13.3944 37.5247 13.4299 37.4879 13.4573 37.4453C13.4847 37.4026 13.5034 37.355 13.5124 37.3051C13.5216 37.2547 13.5208 37.2029 13.51 37.1527C13.4992 37.1026 13.4787 37.0551 13.4495 37.0129L13.0854 36.4877ZM27.7782 9.34516C28.2816 9.34509 28.7695 9.51957 29.1587 9.83889C29.5479 10.1582 29.8143 10.6026 29.9126 11.0964C30.0109 11.5901 29.9349 12.1026 29.6976 12.5466C29.4603 12.9907 29.0764 13.3387 28.6114 13.5313C28.1463 13.724 27.6287 13.7495 27.147 13.6034C26.6652 13.4573 26.249 13.1486 25.9693 12.7301C25.6896 12.3115 25.5637 11.8089 25.613 11.3079C25.6624 10.8069 25.8839 10.3385 26.2399 9.98248C26.4417 9.78015 26.6814 9.61969 26.9454 9.51032C27.2094 9.40095 27.4924 9.34482 27.7782 9.34516ZM28.5373 10.762C28.713 10.9376 28.8224 11.1688 28.8468 11.416C28.8712 11.6632 28.8091 11.9113 28.6712 12.1179C28.5332 12.3245 28.3278 12.4769 28.0901 12.549C27.8524 12.6212 27.597 12.6087 27.3675 12.5137C27.1379 12.4186 26.9484 12.2469 26.8313 12.0278C26.7141 11.8088 26.6766 11.5558 26.725 11.3122C26.7735 11.0685 26.9049 10.8491 27.0969 10.6915C27.289 10.5339 27.5297 10.4478 27.7782 10.4477C27.9192 10.4475 28.0588 10.4752 28.1891 10.5291C28.3193 10.5831 28.4377 10.6622 28.5373 10.762ZM17.5659 9.34516C18.0693 9.34509 18.5572 9.51957 18.9464 9.83889C19.3356 10.1582 19.602 10.6026 19.7003 11.0964C19.7986 11.5901 19.7226 12.1026 19.4853 12.5466C19.248 12.9907 18.8641 13.3387 18.3991 13.5313C17.934 13.724 17.4164 13.7495 16.9347 13.6034C16.4529 13.4573 16.0367 13.1486 15.757 12.7301C15.4773 12.3115 15.3514 11.8089 15.4007 11.3079C15.4501 10.8069 15.6716 10.3385 16.0276 9.98248C16.2294 9.78016 16.4692 9.6197 16.7331 9.51033C16.9971 9.40096 17.2801 9.34483 17.5659 9.34516ZM18.3249 10.762C18.5006 10.9376 18.61 11.1687 18.6344 11.4159C18.6588 11.6632 18.5967 11.9112 18.4587 12.1178C18.3208 12.3244 18.1154 12.4767 17.8777 12.5489C17.64 12.621 17.3846 12.6085 17.1551 12.5135C16.9256 12.4184 16.7361 12.2467 16.619 12.0277C16.5019 11.8086 16.4643 11.5557 16.5128 11.312C16.5612 11.0684 16.6927 10.8491 16.8847 10.6915C17.0767 10.5339 17.3175 10.4477 17.5659 10.4477C17.7069 10.4475 17.8465 10.4752 17.9767 10.5291C18.107 10.5831 18.2253 10.6622 18.3249 10.762ZM30.1032 19.2377C30.1832 19.116 30.3082 19.0311 30.4507 19.0016C30.5933 18.9722 30.7417 19.0005 30.8634 19.0805C30.985 19.1604 31.0699 19.2854 31.0994 19.428C31.1289 19.5705 31.1005 19.719 31.0206 19.8406C30.1397 21.1845 28.9383 22.288 27.5245 23.0517C26.1108 23.8154 24.5293 24.2152 22.9224 24.2152C21.3156 24.2152 19.7341 23.8154 18.3203 23.0517C16.9066 22.288 15.7052 21.1845 14.8243 19.8406C14.7443 19.719 14.716 19.5705 14.7455 19.428C14.775 19.2854 14.8599 19.1604 14.9815 19.0805C15.1032 19.0005 15.2516 18.9722 15.3942 19.0016C15.5367 19.0311 15.6617 19.116 15.7417 19.2377C16.5233 20.4286 17.5888 21.4064 18.8423 22.083C20.0958 22.7597 21.498 23.114 22.9224 23.114C24.3469 23.114 25.749 22.7597 27.0026 22.083C28.2561 21.4064 29.3216 20.4286 30.1032 19.2377Z">
                                        </path>
                                    </svg>
                                </div>
                                <div class="rs-counter-content">
                                    <div class="rs-counter-number-wrapper">
                                        <span class="rs-counter-number odometer" data-count="10.5">00</span>
                                        <span class="prefix">K</span>
                                    </div>
                                    <span class="rs-counter-title">Customer Satisfaction</span>
                                </div>
                            </div>
                            <div class="rs-counter-item wow fadeIn" data-wow-delay=".7s" data-wow-duration="1s">
                                <div class="rs-counter-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 44">
                                        <path
                                            d="M34.3153 13.6218C35.6433 12.327 34.9107 10.0681 33.0762 9.79935L25.8828 8.74077C25.7429 8.72011 25.6101 8.66588 25.4958 8.58274C25.3814 8.49959 25.2889 8.38999 25.2261 8.26331L22.0103 1.74469C21.1881 0.0786182 18.8118 0.0792197 17.9899 1.74469L14.7727 8.26331C14.7103 8.3899 14.6182 8.49948 14.5041 8.58264C14.3901 8.6658 14.2576 8.72006 14.118 8.74077L6.92393 9.79935C5.089 10.0681 4.35707 12.3272 5.6848 13.6218L10.8901 18.698C10.9916 18.7967 11.0675 18.9185 11.1113 19.0531C11.1551 19.1877 11.1655 19.3309 11.1416 19.4704L9.9125 26.6076C9.5953 28.4413 11.5237 29.8327 13.1611 28.9742L17.5488 26.6773C17.4082 29.8743 16.9644 32.9448 14.9519 35.6373H14.0659C12.5552 35.6373 11.3268 36.8658 11.3268 38.3764V42.1352H9.43838C9.05991 42.1352 8.75363 42.4415 8.75363 42.82C8.75363 43.1984 9.05991 43.5047 9.43838 43.5047H30.5618C30.9403 43.5047 31.2466 43.1984 31.2466 42.82C31.2466 42.4415 30.9403 42.1352 30.5618 42.1352H28.6733V38.3764C28.6733 36.8658 27.445 35.6373 25.9343 35.6373H25.0482C23.0358 32.9448 22.5919 29.8743 22.4513 26.6773L26.839 28.9742C28.4822 29.8371 30.404 28.4364 30.0876 26.6076L28.8591 19.4704C28.8351 19.331 28.8453 19.1878 28.889 19.0532C28.9327 18.9186 29.0085 18.7967 29.1099 18.698L34.3153 13.6218ZM27.3038 38.3764V42.1352H12.6964V38.3764C12.6964 37.6214 13.3109 37.0069 14.0659 37.0069H25.9343C26.6893 37.0068 27.3038 37.6214 27.3038 38.3764ZM23.3785 35.6373H16.6217C18.525 32.6335 18.8411 29.3388 18.9474 25.9452L19.5955 25.6059C19.7204 25.5407 19.8592 25.5066 20.0001 25.5066C20.141 25.5066 20.2798 25.5407 20.4047 25.6059L21.0528 25.9452C21.1591 29.3388 21.4752 32.6335 23.3785 35.6373ZM27.5098 19.7031L28.7383 26.8403C28.8606 27.5515 28.1211 28.0966 27.4744 27.7612L21.0393 24.3928C20.7186 24.2248 20.3619 24.137 19.9998 24.137C19.6378 24.137 19.2811 24.2248 18.9603 24.3928L12.5259 27.7612C11.8807 28.0973 11.1397 27.5518 11.2621 26.8403L12.4911 19.7031C12.5529 19.3447 12.5264 18.9767 12.4141 18.6308C12.3018 18.2849 12.107 17.9715 11.8465 17.7177L6.64111 12.6415C6.12317 12.1363 6.40762 11.2598 7.12322 11.1542L14.318 10.0957C14.6769 10.0427 15.0175 9.90346 15.3107 9.68984C15.6039 9.47622 15.8408 9.19463 16.0012 8.86925L19.2177 2.35063C19.5388 1.70138 20.4612 1.70077 20.7826 2.35063L23.9984 8.86994C24.1593 9.1951 24.3966 9.47645 24.69 9.68991C24.9833 9.90337 25.324 10.0426 25.6829 10.0957L32.877 11.1542C33.5929 11.2598 33.8769 12.1365 33.3591 12.6415L28.1538 17.7177C27.8934 17.9716 27.6988 18.285 27.5866 18.6309C27.4744 18.9768 27.4481 19.3448 27.5098 19.7031Z">
                                        </path>
                                        <path
                                            d="M22.7037 38.8866H17.2965C16.918 38.8866 16.6118 39.1929 16.6118 39.5714C16.6118 39.9498 16.918 40.2561 17.2965 40.2561H22.7038C23.0822 40.2561 23.3885 39.9498 23.3885 39.5714C23.3885 39.1929 23.0822 38.8866 22.7037 38.8866ZM36.6645 8.1069L35.8915 9.11529C35.6614 9.41556 35.7189 9.8449 36.0192 10.0749C36.3183 10.3044 36.7496 10.2482 36.9788 9.94717L37.7518 8.93878C37.9818 8.63851 37.9243 8.20917 37.6241 7.9792C37.3253 7.74974 36.8933 7.80663 36.6645 8.1069ZM36.9394 11.946C36.9394 12.0359 36.957 12.125 36.9914 12.2081C37.0258 12.2912 37.0763 12.3667 37.1399 12.4303C37.2035 12.4939 37.279 12.5443 37.3621 12.5787C37.4452 12.6131 37.5342 12.6308 37.6242 12.6307H38.8941C39.2725 12.6307 39.5788 12.3245 39.5788 11.946C39.5788 11.5675 39.2725 11.2612 38.8941 11.2612H37.6242C37.5342 11.2612 37.4452 11.2789 37.3621 11.3133C37.279 11.3477 37.2035 11.3981 37.1399 11.4617C37.0763 11.5253 37.0258 11.6008 36.9914 11.6839C36.957 11.767 36.9394 11.8561 36.9394 11.946ZM35.8915 14.776L36.6645 15.7844C36.8936 16.0853 37.3248 16.1418 37.6241 15.9121C37.9243 15.682 37.9818 15.2527 37.7518 14.9525L36.9788 13.9441C36.7501 13.6439 36.3188 13.587 36.0192 13.8164C35.719 14.0465 35.6614 14.4757 35.8915 14.776ZM4.10871 9.11529L3.3357 8.1069C3.10702 7.80663 2.6763 7.74983 2.37612 7.9792C2.07586 8.20925 2.01836 8.63851 2.24842 8.93878L3.02143 9.94717C3.25054 10.248 3.68177 10.3046 3.981 10.0749C4.28118 9.8449 4.33876 9.41556 4.10871 9.11529ZM0.421387 11.946C0.421342 12.0359 0.439022 12.125 0.473418 12.2081C0.507814 12.2912 0.558251 12.3667 0.621845 12.4303C0.685439 12.4939 0.760943 12.5443 0.844041 12.5787C0.927139 12.6131 1.0162 12.6308 1.10614 12.6307H2.37604C2.7545 12.6307 3.06079 12.3245 3.06079 11.946C3.06079 11.5675 2.7545 11.2612 2.37604 11.2612H1.10614C1.0162 11.2612 0.927139 11.2789 0.844041 11.3133C0.760943 11.3477 0.685439 11.3981 0.621845 11.4617C0.558251 11.5253 0.507814 11.6008 0.473418 11.6839C0.439022 11.767 0.421342 11.8561 0.421387 11.946ZM3.02134 13.9441L2.24833 14.9525C2.01828 15.2528 2.07577 15.6821 2.37604 15.9121C2.6751 16.1416 3.10642 16.0854 3.33561 15.7844L4.10862 14.776C4.33868 14.4757 4.28118 14.0464 3.98092 13.8164C3.68271 13.587 3.25071 13.6439 3.02134 13.9441Z">
                                        </path>
                                    </svg>
                                </div>
                                <div class="rs-counter-content">
                                    <div class="rs-counter-number-wrapper">
                                        <span class="rs-counter-number odometer" data-count="1.5">00</span>
                                        <span class="prefix">K</span>
                                    </div>
                                    <span class="rs-counter-title">Consulting Award</span>
                                </div>
                            </div>
                            <div class="rs-counter-item wow fadeIn" data-wow-delay=".9s" data-wow-duration="1s">
                                <div class="rs-counter-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 42 38">
                                        <path
                                            d="M28.7586 31.3881C27.724 31.9585 26.6291 32.4122 25.4941 32.7407C25.4779 32.7454 25.4637 32.7552 25.4537 32.7688C25.4437 32.7824 25.4385 32.799 25.4389 32.8158V37.2317C25.4385 37.3764 25.3808 37.515 25.2785 37.6173C25.1761 37.7195 25.0374 37.7771 24.8927 37.7773H17.1068C16.9621 37.777 16.8234 37.7194 16.7211 37.6171C16.6188 37.5148 16.5612 37.3761 16.5608 37.2314V32.8158C16.5613 32.799 16.5561 32.7824 16.5461 32.7688C16.5361 32.7553 16.5219 32.7454 16.5057 32.7407C15.3707 32.4122 14.2758 31.9585 13.2412 31.3881C13.2264 31.3797 13.2093 31.3765 13.1925 31.3789C13.1757 31.3813 13.1602 31.3892 13.1483 31.4013L10.0254 34.5243C9.92242 34.6261 9.78346 34.6832 9.63866 34.6832C9.49386 34.6832 9.3549 34.6261 9.25194 34.5243L3.74601 29.0188C3.6441 28.9163 3.58689 28.7776 3.58689 28.6331C3.58689 28.4885 3.6441 28.3499 3.74601 28.2474L6.87164 25.1244C6.88331 25.1123 6.89086 25.0968 6.89324 25.0802C6.89562 25.0635 6.89269 25.0465 6.88488 25.0316C6.31336 23.9974 5.8595 22.9024 5.53179 21.7672C5.52738 21.7507 5.51762 21.7361 5.50403 21.7257C5.49044 21.7153 5.47379 21.7097 5.45668 21.7098H1.03855C0.966856 21.7098 0.895857 21.6957 0.829613 21.6683C0.76337 21.6409 0.703179 21.6007 0.652483 21.55C0.601787 21.4993 0.56158 21.4391 0.534159 21.3728C0.506738 21.3066 0.492642 21.2356 0.492676 21.1639V17.2716C0.492994 17.1269 0.550607 16.9883 0.65291 16.886C0.755213 16.7837 0.893874 16.7261 1.03855 16.7257H4.67654C4.69706 16.7257 4.71673 16.7176 4.73123 16.7031C4.74574 16.6886 4.75389 16.6689 4.75389 16.6484V14.0979C4.75731 12.9221 5.22607 11.7955 6.05769 10.9643C6.88931 10.133 8.01617 9.66487 9.19196 9.66203H12.894C13.4984 9.66327 14.0962 9.78802 14.6507 10.0286C15.2052 10.2692 15.7047 10.6205 16.1185 11.0611C16.1318 11.0742 16.1492 11.0822 16.1678 11.0837C16.1864 11.0853 16.2049 11.0803 16.2202 11.0697C17.0238 10.5188 17.9755 10.2245 18.9497 10.2254H23.0496C24.0239 10.2245 24.9756 10.5188 25.7792 11.0697C25.7945 11.0803 25.813 11.0852 25.8316 11.0836C25.8501 11.0821 25.8675 11.0741 25.8808 11.0611C26.2947 10.6205 26.7942 10.2691 27.3487 10.0286C27.9032 9.78797 28.501 9.66324 29.1055 9.66203H32.8076C33.9833 9.66491 35.1102 10.1331 35.9418 10.9643C36.7734 11.7955 37.2421 12.9221 37.2456 14.0979V16.6484C37.2456 16.6689 37.2537 16.6886 37.2682 16.7031C37.2827 16.7176 37.3024 16.7257 37.3229 16.7257H40.9609C41.1056 16.7261 41.2442 16.7837 41.3465 16.886C41.4488 16.9883 41.5065 17.1269 41.5068 17.2716V21.1638C41.5068 21.2355 41.4927 21.3065 41.4653 21.3728C41.4379 21.439 41.3977 21.4992 41.347 21.5499C41.2963 21.6006 41.2361 21.6408 41.1698 21.6682C41.1036 21.6956 41.0326 21.7097 40.9609 21.7097H36.5429C36.5257 21.7096 36.5091 21.7152 36.4955 21.7256C36.4818 21.7359 36.4721 21.7506 36.4677 21.7671C36.1402 22.9024 35.6865 23.9974 35.1151 25.0316C35.1073 25.0465 35.1043 25.0635 35.1067 25.0802C35.1091 25.0968 35.1166 25.1123 35.1283 25.1244L38.2513 28.2474C38.3022 28.2979 38.3427 28.3579 38.3703 28.4241C38.3979 28.4903 38.4121 28.5614 38.4121 28.6331C38.4121 28.7048 38.3979 28.7758 38.3703 28.842C38.3427 28.9082 38.3022 28.9683 38.2513 29.0188L32.7479 34.5243C32.645 34.6261 32.506 34.6832 32.3612 34.6832C32.2164 34.6832 32.0775 34.6261 31.9745 34.5243L28.8515 31.4013C28.8397 31.3892 28.8242 31.3813 28.8074 31.3789C28.7906 31.3765 28.7734 31.3797 28.7586 31.3881ZM5.92521 16.7257H14.0189C14.0393 16.7255 14.0589 16.7173 14.0733 16.7028C14.0878 16.6884 14.096 16.6688 14.0962 16.6484V15.0792C14.0955 13.9031 14.5247 12.7672 15.3031 11.8855C15.3156 11.8705 15.3222 11.8515 15.3218 11.832C15.3214 11.8125 15.3139 11.7938 15.3008 11.7794C14.99 11.4541 14.6165 11.1953 14.2027 11.0187C13.789 10.842 13.3437 10.7512 12.8939 10.7516H9.19196C8.30544 10.7548 7.45613 11.1083 6.82926 11.7352C6.2024 12.362 5.84885 13.2114 5.84572 14.0979V16.6484C5.84611 16.6692 5.85468 16.689 5.86959 16.7035C5.88449 16.7179 5.90443 16.726 5.92521 16.7257ZM26.6963 11.8855C27.4746 12.7672 27.9038 13.9031 27.903 15.0792V16.6484C27.9033 16.6688 27.9115 16.6884 27.926 16.7028C27.9404 16.7172 27.96 16.7255 27.9804 16.7257H36.074C36.0948 16.726 36.1148 16.7179 36.1297 16.7035C36.1446 16.689 36.1532 16.6692 36.1536 16.6484V14.0979C36.1505 13.2114 35.7969 12.3621 35.1701 11.7352C34.5433 11.1084 33.6941 10.7548 32.8076 10.7516H29.1056C28.6557 10.7512 28.2105 10.842 27.7968 11.0187C27.383 11.1953 27.0095 11.4541 26.6987 11.7794C26.6851 11.7935 26.6772 11.8123 26.6768 11.832C26.6764 11.8517 26.6833 11.8708 26.6963 11.8855ZM30.9554 0.659992C31.71 0.659788 32.4478 0.883373 33.0754 1.30247C33.703 1.72157 34.1922 2.31737 34.4812 3.01451C34.7702 3.71165 34.8459 4.47883 34.6989 5.21903C34.5519 5.95923 34.1886 6.63921 33.6552 7.17297C33.1217 7.70674 32.4419 8.07032 31.7018 8.21774C30.9616 8.36515 30.1944 8.28978 29.4971 8.00116C28.7998 7.71254 28.2038 7.22363 27.7844 6.59626C27.3649 5.96889 27.141 5.23123 27.1408 4.47656C27.1406 3.46458 27.5424 2.49396 28.2578 1.77818C28.9732 1.0624 29.9434 0.660402 30.9554 0.659992ZM32.8826 2.54967C32.5016 2.16864 32.0162 1.90914 31.4878 1.80399C30.9593 1.69884 30.4115 1.75276 29.9137 1.95894C29.4159 2.16512 28.9904 2.51429 28.6911 2.96229C28.3917 3.4103 28.2319 3.93701 28.2319 4.47583C28.2319 5.01465 28.3917 5.54137 28.6911 5.98937C28.9904 6.43738 29.4159 6.78655 29.9137 6.99272C30.4115 7.1989 30.9593 7.25282 31.4878 7.14767C32.0162 7.04252 32.5016 6.78302 32.8826 6.40199C33.3932 5.89099 33.68 5.19819 33.68 4.47583C33.68 3.75348 33.3932 3.06067 32.8826 2.54967ZM11.044 0.659992C11.7986 0.660264 12.5361 0.884254 13.1634 1.30364C13.7906 1.72303 14.2795 2.31899 14.5681 3.01618C14.8567 3.71336 14.9321 4.48046 14.7848 5.2205C14.6375 5.96055 14.2741 6.6403 13.7405 7.17382C13.2069 7.70735 12.5271 8.07069 11.7871 8.21791C11.047 8.36513 10.2799 8.28963 9.58278 8.00094C8.88563 7.71224 8.28973 7.22333 7.87041 6.59601C7.45109 5.96869 7.22718 5.23112 7.227 4.47656C7.22683 3.97526 7.32544 3.47884 7.5172 3.01567C7.70897 2.5525 7.99012 2.13166 8.3446 1.77719C8.69907 1.42272 9.11992 1.14158 9.5831 0.949824C10.0463 0.758071 10.5427 0.659812 11.044 0.659992ZM12.969 2.54967C12.588 2.16864 12.1026 1.90914 11.5742 1.80399C11.0457 1.69884 10.4979 1.75276 10.0001 1.95894C9.5023 2.16512 9.07681 2.51429 8.77745 2.96229C8.47809 3.4103 8.31831 3.93701 8.31831 4.47583C8.31831 5.01465 8.47809 5.54137 8.77745 5.98937C9.07681 6.43738 9.5023 6.78655 10.0001 6.99272C10.4979 7.1989 11.0457 7.25282 11.5742 7.14767C12.1026 7.04252 12.588 6.78302 12.969 6.40199C13.4796 5.89099 13.7664 5.19819 13.7664 4.47583C13.7664 3.75348 13.4796 3.06067 12.969 2.54967ZM15.2654 16.7257H26.734C26.7545 16.7255 26.774 16.7172 26.7884 16.7028C26.8029 16.6884 26.8111 16.6688 26.8114 16.6484V15.0792C26.8081 14.0825 26.4107 13.1276 25.706 12.4228C25.0013 11.718 24.0464 11.3206 23.0497 11.3172H18.9498C17.9531 11.3202 16.998 11.7175 16.2932 12.4223C15.5884 13.1271 15.1911 14.0822 15.1881 15.0789V16.6481C15.1883 16.6686 15.1966 16.6881 15.211 16.7025C15.2255 16.717 15.245 16.7255 15.2654 16.7257ZM20.9987 0.222656C21.8555 0.222656 22.693 0.476737 23.4054 0.952767C24.1178 1.4288 24.6731 2.10539 25.0009 2.89699C25.3288 3.68859 25.4145 4.55963 25.2473 5.39997C25.0801 6.2403 24.6675 7.01217 24.0616 7.61798C23.4557 8.22378 22.6837 8.63631 21.8434 8.80338C21.003 8.97045 20.132 8.88456 19.3404 8.55659C18.5489 8.22861 17.8724 7.67326 17.3964 6.96079C16.9205 6.24832 16.6666 5.41071 16.6667 4.55391C16.6674 3.40528 17.124 2.3039 17.9363 1.49176C18.7486 0.679623 19.85 0.223157 20.9987 0.222656ZM23.2906 2.26487C22.8375 1.81176 22.2602 1.50319 21.6318 1.37817C21.0033 1.25315 20.3519 1.31731 19.7598 1.56252C19.1678 1.80773 18.6618 2.22299 18.3058 2.75578C17.9498 3.28857 17.7598 3.91497 17.7598 4.55575C17.7598 5.19654 17.9498 5.82293 18.3058 6.35573C18.6618 6.88852 19.1678 7.30378 19.7598 7.54899C20.3519 7.7942 21.0033 7.85836 21.6318 7.73334C22.2602 7.60832 22.8375 7.29974 23.2906 6.84663C23.5917 6.54595 23.8306 6.18885 23.9936 5.79576C24.1566 5.40266 24.2405 4.9813 24.2405 4.55575C24.2405 4.13021 24.1566 3.70884 23.9936 3.31575C23.8306 2.92266 23.5917 2.56556 23.2906 2.26487ZM1.58443 17.8949V20.5405C1.58442 20.5509 1.58649 20.5611 1.59052 20.5706C1.59455 20.5802 1.60044 20.5888 1.60786 20.596C1.61528 20.6032 1.62408 20.6089 1.63372 20.6126C1.64336 20.6164 1.65366 20.6182 1.664 20.6179H5.92968C6.05879 20.6182 6.18365 20.664 6.28229 20.7474C6.38092 20.8307 6.44702 20.9461 6.46894 21.0733V21.0819C6.81858 22.4097 7.34804 23.6835 8.04263 24.868C8.17961 25.1023 8.17523 25.363 7.97852 25.5597L4.95936 28.5789C4.95203 28.5859 4.94619 28.5943 4.94221 28.6036C4.93822 28.6129 4.93616 28.623 4.93616 28.6331C4.93616 28.6432 4.93822 28.6532 4.94221 28.6625C4.94619 28.6718 4.95203 28.6802 4.95936 28.6872L9.5828 33.3107C9.59 33.318 9.5986 33.3239 9.60809 33.3278C9.61758 33.3318 9.62777 33.3339 9.63806 33.3339C9.64835 33.3339 9.65854 33.3318 9.66803 33.3278C9.67752 33.3239 9.68611 33.318 9.69332 33.3107L12.7102 30.2937C12.9069 30.097 13.1699 30.0904 13.4043 30.2275C14.5881 30.9233 15.862 31.4528 17.1902 31.8011C17.1925 31.8011 17.1947 31.8033 17.1969 31.8033C17.3242 31.8244 17.4398 31.8899 17.5232 31.9883C17.6067 32.0867 17.6524 32.2114 17.6524 32.3404V36.6086C17.6527 36.629 17.6609 36.6486 17.6753 36.663C17.6898 36.6775 17.7093 36.6857 17.7298 36.6859H24.2696C24.29 36.6857 24.3096 36.6775 24.324 36.663C24.3385 36.6486 24.3467 36.629 24.3469 36.6086V32.3407H24.3491C24.3493 32.2201 24.3896 32.103 24.4636 32.0078C24.5377 31.9126 24.6412 31.8446 24.758 31.8147C26.1044 31.4663 27.3957 30.9322 28.5948 30.2277C28.8291 30.0907 29.0899 30.0973 29.2866 30.294L32.3058 33.3109C32.313 33.3183 32.3216 33.3241 32.3311 33.3281C32.3405 33.332 32.3507 33.3341 32.361 33.3341C32.3713 33.3341 32.3815 33.332 32.3909 33.3281C32.4004 33.3241 32.409 33.3183 32.4162 33.3109L37.0397 28.6875C37.0535 28.6729 37.0613 28.6535 37.0613 28.6333C37.0613 28.6132 37.0535 28.5938 37.0397 28.5792L34.021 25.5598C33.8243 25.3631 33.8198 25.1023 33.9548 24.8681C34.6517 23.6837 35.182 22.4089 35.5306 21.0797V21.0731C35.5525 20.9458 35.6186 20.8304 35.7173 20.7471C35.8159 20.6638 35.9407 20.6179 36.0699 20.6176H40.3357C40.3461 20.6179 40.3563 20.6161 40.366 20.6124C40.3756 20.6086 40.3844 20.603 40.3918 20.5958C40.3993 20.5885 40.4052 20.5799 40.4092 20.5704C40.4132 20.5608 40.4153 20.5506 40.4153 20.5403V17.8949C40.4149 17.8741 40.4064 17.8543 40.3914 17.8398C40.3765 17.8254 40.3565 17.8174 40.3357 17.8176H32.1957C32.1761 17.818 32.1573 17.8256 32.143 17.8391C32.1287 17.8526 32.1199 17.8709 32.1184 17.8905C31.9601 20.7322 30.7197 23.4054 28.652 25.3612C26.5843 27.317 23.8462 28.4068 21.0001 28.4068C18.1539 28.4068 15.4158 27.317 13.3481 25.3612C11.2804 23.4054 10.04 20.7322 9.88178 17.8905C9.88026 17.8709 9.8715 17.8525 9.8572 17.8391C9.84289 17.8256 9.82408 17.8179 9.80443 17.8176H1.66383C1.64305 17.8174 1.62303 17.8254 1.60812 17.8399C1.59322 17.8544 1.58481 17.8741 1.58443 17.8949ZM30.9467 17.8176H11.0528C11.0423 17.8176 11.0319 17.8198 11.0223 17.824C11.0126 17.8282 11.0039 17.8343 10.9967 17.8419C10.9895 17.8496 10.9839 17.8586 10.9802 17.8684C10.9766 17.8783 10.975 17.8888 10.9755 17.8993C11.1347 20.4498 12.2601 22.8437 14.1225 24.5935C15.9849 26.3433 18.4443 27.3174 20.9998 27.3174C23.5552 27.3174 26.0146 26.3433 27.877 24.5935C29.7394 22.8437 30.8648 20.4498 31.024 17.8993C31.0246 17.8888 31.0229 17.8783 31.0193 17.8684C31.0157 17.8586 31.01 17.8496 31.0028 17.8419C30.9956 17.8343 30.9869 17.8282 30.9772 17.824C30.9676 17.8198 30.9572 17.8176 30.9467 17.8176Z">
                                        </path>
                                    </svg>
                                </div>
                                <div class="rs-counter-content">
                                    <div class="rs-counter-number-wrapper">
                                        <span class="rs-counter-number odometer" data-count="4.5">00</span>
                                        <span class="prefix">K</span>
                                    </div>
                                    <span class="rs-counter-title">Strategic Partners</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- counter area end -->

        <!-- portfolio area start -->
        <section class="rs-portfolio-area rs-portfolio-two section-space rs-swiper has-tab-black">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-xl-8 col-lg-9">
                        <div class="section-title-wrapper text-center section-title-space">
                            <span class="section-subtitle">
                                Solution Use Cases and Packages
                            </span>
                            <h2 class="section-title rs-split-text-enable split-in-left">Case studies & highlights
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="rs-portfolio-tab-wrapper g-0">
                        <div class="rs-portfolio-tab">
                            <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="pills-item-four-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-item-four" type="button" role="tab"
                                        aria-controls="pills-item-four" aria-selected="true">
                                        All Projects
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-item-five-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-item-five" type="button" role="tab"
                                        aria-controls="pills-item-five" aria-selected="false"> Business (04)
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-item-six-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-item-six" type="button" role="tab"
                                        aria-controls="pills-item-six" aria-selected="false">
                                        Compliance (05)
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-item-seven-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-item-seven" type="button" role="tab"
                                        aria-controls="pills-item-seven" aria-selected="false">
                                        Expansion (04)
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-item-eight-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-item-eight" type="button" role="tab"
                                        aria-controls="pills-item-eight" aria-selected="false">
                                        Startups (05)
                                    </button>
                                </li>
                            </ul>
                        </div>
                        <div class="rs-portfolio-tab-content-wrapper">
                            <div class="tab-content rs-portfolio-tab-anim" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-item-four" role="tabpanel"
                                    aria-labelledby="pills-item-four-tab" tabindex="0">
                                    <div class="rs-portfolio-tab-slider portfolio-slide-active p-relative fix">
                                        <div class=" swiper" data-clone-slides="false" data-loop="false"
                                            data-speed="1500" data-autoplay="true" data-dots-dynamic="false"
                                            data-center-mode="false" data-no-gap="true" data-delay="2000" data-item="4"
                                            data-item-xl="3" data-item-lg="2" data-item-md="2" data-item-sm="1"
                                            data-item-xs="1">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/banner/banner-5.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Bank Credit
                                                                    Collection System</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">Transforming complex IT landscapes into scalable,
                                                                high-performance environments for your business.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/about/37.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Business</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Business
                                                                    Development Planning</a></h5>
                                                            <span class="rs-banner-line"></span>

                                                            <p class="rs-desc-height">Empowering organizations with strategic insights
                                                                and data-driven solutions for digital growth.</p>

                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/about/32.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startup</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Integrated
                                                                    Innovations</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/about/35.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Differentiated
                                                                    Performance</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/about/15.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">FinTech
                                                                    Revolution</a></h5>
                                                            <span class="rs-banner-line"></span>

                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>

                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/about/24.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Digital
                                                                    Transformation</a></h5>
                                                            <span class="rs-banner-line"></span>

                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>

                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-item-five" role="tabpanel"
                                    aria-labelledby="pills-item-five-tab" tabindex="0">
                                    <div class="rs-portfolio-tab-slider portfolio-slide-active p-relative fix">
                                        <div class=" swiper" data-clone-slides="false" data-loop="false"
                                            data-speed="1500" data-autoplay="true" data-dots-dynamic="false"
                                            data-center-mode="false" data-no-gap="true" data-delay="2000" data-item="4"
                                            data-item-xl="3" data-item-lg="2" data-item-md="2" data-item-sm="1"
                                            data-item-xs="1">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-16.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Bank Credit
                                                                    Collection System</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-24.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Business</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Green Energy
                                                                    Hub</a></h5>
                                                            <span class="rs-banner-line"></span>

                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>

                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-23.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startup</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Smart
                                                                    Irrigation Systems</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-19.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Differentiated
                                                                    Performance</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-item-six" role="tabpanel"
                                    aria-labelledby="pills-item-six-tab" tabindex="0">
                                    <div class="rs-portfolio-tab-slider portfolio-slide-active p-relative fix">
                                        <div class=" swiper" data-clone-slides="false" data-loop="false"
                                            data-speed="1500" data-autoplay="true" data-dots-dynamic="false"
                                            data-center-mode="false" data-no-gap="true" data-delay="2000" data-item="4"
                                            data-item-xl="3" data-item-lg="2" data-item-md="2" data-item-sm="1"
                                            data-item-xs="1">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-20.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Bank Credit
                                                                    Collection System</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-24.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Business</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Green Energy
                                                                    Hub</a></h5>
                                                            <span class="rs-banner-line"></span>

                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>

                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-23.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startup</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Smart
                                                                    Irrigation Systems</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-19.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Differentiated
                                                                    Performance</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-20.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">FinTech
                                                                    Revolution</a></h5>
                                                            <span class="rs-banner-line"></span>

                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>

                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-21.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Digital
                                                                    Transformation</a></h5>
                                                            <span class="rs-banner-line"></span>

                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>

                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-item-seven" role="tabpanel"
                                    aria-labelledby="pills-item-seven-tab" tabindex="0">
                                    <div class="rs-portfolio-tab-slider portfolio-slide-active p-relative fix">
                                        <div class=" swiper" data-clone-slides="false" data-loop="false"
                                            data-speed="1500" data-autoplay="true" data-dots-dynamic="false"
                                            data-center-mode="false" data-no-gap="true" data-delay="2000" data-item="4"
                                            data-item-xl="3" data-item-lg="2" data-item-md="2" data-item-sm="1"
                                            data-item-xs="1">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-16.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Bank Credit
                                                                    Collection System</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-24.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Business</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Green Energy
                                                                    Hub</a></h5>
                                                            <span class="rs-banner-line"></span>

                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>

                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-23.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startup</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Smart
                                                                    Irrigation Systems</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-19.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Differentiated
                                                                    Performance</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-20.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">FinTech
                                                                    Revolution</a></h5>
                                                            <span class="rs-banner-line"></span>

                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>

                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-21.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Digital
                                                                    Transformation</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-item-eight" role="tabpanel"
                                    aria-labelledby="pills-item-eight-tab" tabindex="0">
                                    <div class="rs-portfolio-tab-slider portfolio-slide-active p-relative fix">
                                        <div class=" swiper" data-clone-slides="false" data-loop="false"
                                            data-speed="1500" data-autoplay="true" data-dots-dynamic="false"
                                            data-center-mode="false" data-no-gap="true" data-delay="2000" data-item="4"
                                            data-item-xl="3" data-item-lg="2" data-item-md="2" data-item-sm="1"
                                            data-item-xs="1">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-17.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Bank Credit
                                                                    Collection System</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-18.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Business</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Green Energy
                                                                    Hub</a></h5>
                                                            <span class="rs-banner-line"></span>

                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>

                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-23.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startup</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Smart
                                                                    Irrigation Systems</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-19.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Differentiated
                                                                    Performance</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-20.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">FinTech
                                                                    Revolution</a></h5>
                                                            <span class="rs-banner-line"></span>

                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>

                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="swiper-slide"
                                                    data-bg="assets/images/portfolio/portfolio-thumb-21.webp">
                                                    <div class="rs-portfolio-tab-item">
                                                        <div class="rs-portfolio-tab-content">
                                                            <div class="rs-portfolio-tag-wrapper">
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Expansion</a>
                                                                </div>
                                                                <div class="rs-portfolio-tag">
                                                                    <a href="portfolio.php">Startups</a>
                                                                </div>
                                                            </div>
                                                            <h5 class="rs-portfolio-tab-title"><a
                                                                    href="portfolio-details.php">Digital
                                                                    Transformation</a></h5>
                                                            <span class="rs-banner-line"></span>
                                                            <p class="rs-desc-height">collaborations cultivating a
                                                                global community
                                                                diverse individuals who are your dedicated.</p>
                                                            <div class="rs-portfolio-tab-btn">
                                                                <a class="rs-btn has-icon has-text is-white"
                                                                    href="portfolio-details.php">More
                                                                    Details
                                                                    <span class="icon-box">
                                                                        <svg class="icon-first" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>

                                                                        <svg class="icon-second" width="16" height="16"
                                                                            viewBox="0 0 16 16" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path
                                                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                                                fill="white"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- testimonial area start -->
        <section class="rs-testimonial-area section-space-top rs-testimonial-two rs-swiper">
            <div class="rs-testimonial-bg-thumb include-bg"
                data-background="assets/images/bg/testimonial-bg-thumb-02.webp"></div>
            <div class="rs-testimonial-shape">
                <img src="assets/images/shape/testimonial-shape-02.webp" alt="image">
            </div>
            <div class="container">
                <div class="row align-items-center g-5 section-title-space">
                    <div class="col-xl-6 col-lg-6">
                        <div class="section-title-wrapper">
                            <span class="section-subtitle is-white">
                                Our Clients Testimonials
                            </span>
                            <h2 class="section-title rs-split-text-enable split-in-left mb-10 is-white">What our
                                customers say?
                            </h2>
                            <p class="section-desc">Find Answers to our Question about Our Consulting Coverage Options.
                            </p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="rs-testimonial-counter">
                            <div class="rs-counter-item">
                                <div class="rs-counter-number-wrapper">
                                    <span class="rs-counter-number odometer" data-count="98">00</span>
                                    <span class="prefix">%</span>
                                </div>
                                <span class="rs-counter-title">Business Growth Rate</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-testimonial-wrapper">
                            <div class="rs-testimonial-thumb rs-image scroll_reveal reveal-active" data-dir="left">
                                <img src="assets/images/about/8.webp" alt="image">
                            </div>
                            <div class="rs-testimonial-slider-wrapper">
                                <div class="swiper" data-clone-slides="false" data-loop="true" data-speed="1500"
                                    data-autoplay="true" data-dots-dynamic="false" data-effect="false" data-delay="2000"
                                    data-item="1" data-item-xl="1" data-item-lg="1" data-item-md="1" data-item-sm="1"
                                    data-item-xs="1" data-item-mobile="1" data-margin="30">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <div class="rs-testimonial-item">
                                                <div class="rs-testimonial-top">
                                                    <div class="rs-testimonial-title-info">
                                                        <h6 class="rs-testimonial-title">Strategic Advisory</h6>
                                                        <div class="rs-testimonial-icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="60"
                                                                height="44" viewBox="0 0 60 44" fill="none">
                                                                <path
                                                                    d="M12.7244 28.0195C11.6004 34.2343 9.70513 38.7081 8.20652 41.485C7.61148 42.5648 8.82362 43.777 9.88146 43.1599C22.4434 35.8431 27.953 25.1765 28.6362 16.6036C29.2312 9.22068 24.1844 1.61742 16.5591 0.229C8.9338 -1.15942 1.61704 3.90943 0.228614 11.5347C-1.22592 19.5347 4.41591 27.2261 12.7244 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                                <path
                                                                    d="M44.0406 28.0195C42.9166 34.2343 41.0213 38.7081 39.5227 41.485C38.9277 42.5648 40.1398 43.777 41.1976 43.1599C53.7595 35.8431 59.2692 25.1765 59.9524 16.6036C60.5474 9.22068 55.5006 1.61742 47.8753 0.229C40.25 -1.15942 32.9332 3.90943 31.5448 11.5347C30.0902 19.5347 35.7321 27.2261 44.0406 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="rs-testimonial-rating-icon">
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-line"></i>
                                                    </div>
                                                </div>
                                                <p class="rs-testimonial-desc"> “ICEF's team provided exceptional consulting services that truly transformed our business operations. Their strategic insights and dedication helped us achieve our goals faster than we ever anticipated.”
                                                </p>
                                                <div class="rs-testimonial-avater-wrapper">
                                                    <div class="rs-testimonial-avater-thumb">
                                                        <img src="assets/images/user/indian-user-01.png" alt="image">
                                                    </div>
                                                    <div class="rs-testimonial-avater-info">
                                                        <h6 class="rs-testimonial-avater-title">Rahul Sharma</h6>
                                                        <span class="rs-testimonial-avater-designation">Founder &
                                                            CEO</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="rs-testimonial-item">
                                                <div class="rs-testimonial-top">
                                                    <div class="rs-testimonial-title-info">
                                                        <h6 class="rs-testimonial-title">Project Management</h6>
                                                        <div class="rs-testimonial-icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="60"
                                                                height="44" viewBox="0 0 60 44" fill="none">
                                                                <path
                                                                    d="M12.7244 28.0195C11.6004 34.2343 9.70513 38.7081 8.20652 41.485C7.61148 42.5648 8.82362 43.777 9.88146 43.1599C22.4434 35.8431 27.953 25.1765 28.6362 16.6036C29.2312 9.22068 24.1844 1.61742 16.5591 0.229C8.9338 -1.15942 1.61704 3.90943 0.228614 11.5347C-1.22592 19.5347 4.41591 27.2261 12.7244 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                                <path
                                                                    d="M44.0406 28.0195C42.9166 34.2343 41.0213 38.7081 39.5227 41.485C38.9277 42.5648 40.1398 43.777 41.1976 43.1599C53.7595 35.8431 59.2692 25.1765 59.9524 16.6036C60.5474 9.22068 55.5006 1.61742 47.8753 0.229C40.25 -1.15942 32.9332 3.90943 31.5448 11.5347C30.0902 19.5347 35.7321 27.2261 44.0406 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="rs-testimonial-rating-icon">
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-line"></i>
                                                    </div>
                                                </div>
                                                <p class="rs-testimonial-desc"> “Working with this consulting agency has been a game-changer for our projects. Their attention to detail, proactive approach, and deep understanding of the market dynamics have been invaluable.”
                                                </p>
                                                <div class="rs-testimonial-avater-wrapper">
                                                    <div class="rs-testimonial-avater-thumb">
                                                        <img src="assets/images/user/indian-user-02.png" alt="image">
                                                    </div>
                                                    <div class="rs-testimonial-avater-info">
                                                        <h6 class="rs-testimonial-avater-title">Priya Patel</h6>
                                                        <span class="rs-testimonial-avater-designation">Project
                                                            Manager</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="rs-testimonial-item">
                                                <div class="rs-testimonial-top">
                                                    <div class="rs-testimonial-title-info">
                                                        <h6 class="rs-testimonial-title">Digital Transformation</h6>
                                                        <div class="rs-testimonial-icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="60"
                                                                height="44" viewBox="0 0 60 44" fill="none">
                                                                <path
                                                                    d="M12.7244 28.0195C11.6004 34.2343 9.70513 38.7081 8.20652 41.485C7.61148 42.5648 8.82362 43.777 9.88146 43.1599C22.4434 35.8431 27.953 25.1765 28.6362 16.6036C29.2312 9.22068 24.1844 1.61742 16.5591 0.229C8.9338 -1.15942 1.61704 3.90943 0.228614 11.5347C-1.22592 19.5347 4.41591 27.2261 12.7244 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                                <path
                                                                    d="M44.0406 28.0195C42.9166 34.2343 41.0213 38.7081 39.5227 41.485C38.9277 42.5648 40.1398 43.777 41.1976 43.1599C53.7595 35.8431 59.2692 25.1765 59.9524 16.6036C60.5474 9.22068 55.5006 1.61742 47.8753 0.229C40.25 -1.15942 32.9332 3.90943 31.5448 11.5347C30.0902 19.5347 35.7321 27.2261 44.0406 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="rs-testimonial-rating-icon">
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-line"></i>
                                                    </div>
                                                </div>
                                                <p class="rs-testimonial-desc"> “The technology solutions recommended by the consulting team were perfectly tailored to our needs. They provided actionable, scalable strategies that brought real value to our organization.”
                                                </p>
                                                <div class="rs-testimonial-avater-wrapper">
                                                    <div class="rs-testimonial-avater-thumb">
                                                        <img src="assets/images/user/indian-user-03.png" alt="image">
                                                    </div>
                                                    <div class="rs-testimonial-avater-info">
                                                        <h6 class="rs-testimonial-avater-title">Amit Kumar</h6>
                                                        <span class="rs-testimonial-avater-designation">Developer</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- if we need navigation -->
                                    <div class="rs-testimonial-navigation rs-swiper-btn-wrapper">
                                        <div class="rs-swiper-btn swiper-button-prev has-transparent has-border"><i
                                                class="ri-arrow-left-line"></i>
                                        </div>
                                        <div class="rs-swiper-btn swiper-button-next has-transparent has-border"><i
                                                class="ri-arrow-right-line"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- testimonial area end -->

        <style>
            .rs-brand-item .rs-brand-thumb img {
                filter: grayscale(1);
                opacity: 0.6;
                transition: all 0.3s ease;
                max-height: 40px;
                width: auto;
                display: block;
                margin: 0 auto;
            }

            .rs-brand-item .rs-brand-thumb img:hover {
                filter: grayscale(0);
                opacity: 1;
            }
        </style>
        <!-- brand area start -->
        <div class="rs-brand-area rs-brand-two rs-swiper">
            <div class="container-fluid g-0">
                <div class="row">
                    <div class="brand-slider">
                        <div class="swiper" data-clone-slides="false" data-loop="true" data-speed="1500"
                            data-autoplay="true" data-dots-dynamic="false" data-center-mode="false" data-effect="false"
                            data-no-gap="true" data-delay="1500" data-item="6" data-item-xl="5" data-item-lg="4"
                            data-item-md="3" data-item-sm="2" data-item-xs="2" data-item-mobile="1">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-01.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-02.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-03.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-04.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-05.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-06.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-01.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- brand area end -->

        <!-- blog area style override -->
        <style>
            .rs-blog-one .rs-blog-thumb {
                height: 450px !important;
            }

            .rs-blog-one .rs-blog-content-hover .rs-blog-desc {
                margin-bottom: 30px !important;
                font-size: 14px;
                line-height: 1.4;
            }

            .rs-blog-one .rs-blog-content-hover .rs-blog-content {
                padding-top: 80px !important;
            }

            .rs-blog-one .rs-blog-content-hover .rs-blog-title {
                padding-bottom: 15px !important;
                margin-bottom: 15px !important;
                font-size: 20px;
            }

            .rs-blog-one .rs-blog-title {
                font-size: 20px;
            }

            @media only screen and (max-width: 1399px) {
                .rs-blog-one .rs-blog-wrapper {
                    gap: 15px !important;
                }

                .rs-blog-one .rs-blog-thumb {
                    height: 400px !important;
                }
            }

            @media only screen and (max-width: 1199px) {
                .rs-blog-one .rs-blog-wrapper {
                    grid-template-columns: repeat(2, 1fr) !important;
                }
            }

            @media only screen and (max-width: 767px) {
                .rs-blog-one .rs-blog-wrapper {
                    grid-template-columns: repeat(1, 1fr) !important;
                }
            }
        </style>

        <!-- blog area start -->
        <section class="rs-blog-area rs-blog-one section-space">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-7 col-lg-7">
                        <div class="section-title-wrapper text-center section-title-space">
                            <span class="section-subtitle">
                                Read Our Blog & News
                            </span>
                            <h2 class="section-title rs-split-text-enable split-in-left mb-15">Featured news and
                                insights</h2>
                            <p class="section-desc">Stay updated with our latest industry insights, expert strategies, and company news tailored for your success.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-blog-wrapper rs-swiper">
                            <div class="swiper" data-item="3" data-item-lg="3" data-item-md="2" data-item-sm="1" data-loop="true" data-autoplay="true" data-speed="1000">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="rs-blog-item wow fadeInLeft" data-wow-delay=".3s" data-wow-duration="1s">
                                            <div class="rs-blog-thumb">
                                                <img src="assets/images/blog/blog-thumb-01.webp" alt="image">
                                            </div>

                                            <div class="rs-blog-content-wrapper">
                                                <div class="rs-blog-tag">
                                                    <a href="blog-details.php" class="post-tag">September 23, 2025 </a>
                                                </div>
                                                <div class="rs-blog-content">
                                                    <div class="rs-blog-meta-wrapper">
                                                        <div class="rs-blog-meta-item">
                                                            <span> <i class="ri-price-tag-3-line"></i>
                                                                Corporate</span>
                                                        </div>
                                                    </div>
                                                    <h5 class="rs-blog-title">
                                                        <a href="blog-details.php"> Insights That Driven Business Smarter
                                                            Forward</a>
                                                    </h5>
                                                </div>
                                            </div>
                                            <div class="rs-blog-content-hover">
                                                <div class="rs-blog-content">
                                                    <div class="rs-blog-meta-wrapper">
                                                        <div class="rs-blog-meta-item">
                                                            <span> <i class="ri-price-tag-3-line"></i>
                                                                Corporate</span>
                                                        </div>
                                                    </div>
                                                    <h5 class="rs-blog-title">
                                                        <a href="blog-details.php"> Insights That Driven Business Smarter
                                                            Forward</a>
                                                    </h5>
                                                    <p class="rs-blog-desc">Consulting empowers businesses with data-driven
                                                        strategies and
                                                        innovative solutions to achieve sustainable...</p>
                                                    <div class="rs-blog-btn">
                                                        <a class="rs-btn has-text is-white" href="blog-details.php">Read More
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="rs-blog-item wow fadeInLeft" data-wow-delay=".5s" data-wow-duration="1s">
                                            <div class="rs-blog-thumb">
                                                <img src="assets/images/blog/blog-thumb-02.webp" alt="image">
                                            </div>

                                            <div class="rs-blog-content-wrapper">
                                                <div class="rs-blog-tag">
                                                    <a href="blog-details.php" class="post-tag">August 26, 2025</a>
                                                </div>
                                                <div class="rs-blog-content">
                                                    <div class="rs-blog-meta-wrapper">
                                                        <div class="rs-blog-meta-item">
                                                            <span> <i class="ri-price-tag-3-line"></i>
                                                                Consulting</span>
                                                        </div>
                                                    </div>
                                                    <h5 class="rs-blog-title">
                                                        <a href="blog-details.php"> How Strategic Planning Drives Business
                                                            Success</a>
                                                    </h5>
                                                </div>
                                            </div>
                                            <div class="rs-blog-content-hover">
                                                <div class="rs-blog-content">
                                                    <div class="rs-blog-meta-wrapper">
                                                        <div class="rs-blog-meta-item">
                                                            <span> <i class="ri-price-tag-3-line"></i>
                                                                Corporate</span>
                                                        </div>
                                                    </div>
                                                    <h5 class="rs-blog-title">
                                                        <a href="blog-details.php"> How Strategic Planning Drives Business
                                                            Success</a>
                                                    </h5>
                                                    <p class="rs-blog-desc">From insights to execution, we guide businesses to
                                                        smarter
                                                        decisions and better...</p>
                                                    <div class="rs-blog-btn">
                                                        <a class="rs-btn has-text is-white" href="blog-details.php">Read More
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="rs-blog-item wow fadeInLeft" data-wow-delay=".7s" data-wow-duration="1s">
                                            <div class="rs-blog-thumb">
                                                <img src="assets/images/blog/blog-thumb-03.webp" alt="image">
                                            </div>

                                            <div class="rs-blog-content-wrapper">
                                                <div class="rs-blog-tag">
                                                    <a href="blog-details.php" class="post-tag">Feb 17, 2025</a>
                                                </div>
                                                <div class="rs-blog-content">
                                                    <div class="rs-blog-meta-wrapper">
                                                        <div class="rs-blog-meta-item">
                                                            <span> <i class="ri-price-tag-3-line"></i>
                                                                Corporate</span>
                                                        </div>
                                                    </div>
                                                    <h5 class="rs-blog-title">
                                                        <a href="blog-details.php"> Planning Your Business for Long-Term Growth</a>
                                                    </h5>
                                                </div>
                                            </div>
                                            <div class="rs-blog-content-hover">
                                                <div class="rs-blog-content">
                                                    <div class="rs-blog-meta-wrapper">
                                                        <div class="rs-blog-meta-item">
                                                            <span> <i class="ri-price-tag-3-line"></i>
                                                                Corporate</span>
                                                        </div>
                                                    </div>
                                                    <h5 class="rs-blog-title">
                                                        <a href="blog-details.php"> Planning Your Business for Long-Term Growth</a>
                                                    </h5>
                                                    <p class="rs-blog-desc">Consulting transforms challenges into opportunities with
                                                        tailored
                                                        solutions and proven expertise.</p>
                                                    <div class="rs-blog-btn">
                                                        <a class="rs-btn has-text is-white" href="blog-details.php">Read More
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="rs-blog-item wow fadeInLeft" data-wow-delay=".9s" data-wow-duration="1s">
                                            <div class="rs-blog-thumb">
                                                <img src="assets/images/blog/blog-thumb-04.webp" alt="image">
                                            </div>

                                            <div class="rs-blog-content-wrapper">
                                                <div class="rs-blog-tag">
                                                    <a href="blog-details.php" class="post-tag">Jan 10, 2025</a>
                                                </div>
                                                <div class="rs-blog-content">
                                                    <div class="rs-blog-meta-wrapper">
                                                        <div class="rs-blog-meta-item">
                                                            <span> <i class="ri-price-tag-3-line"></i>
                                                                Analysis</span>
                                                        </div>
                                                    </div>
                                                    <h5 class="rs-blog-title">
                                                        <a href="blog-details.php"> Mastering the Art of Market Analysis</a>
                                                    </h5>
                                                </div>
                                            </div>
                                            <div class="rs-blog-content-hover">
                                                <div class="rs-blog-content">
                                                    <div class="rs-blog-meta-wrapper">
                                                        <div class="rs-blog-meta-item">
                                                            <span> <i class="ri-price-tag-3-line"></i>
                                                                Analysis</span>
                                                        </div>
                                                    </div>
                                                    <h5 class="rs-blog-title">
                                                        <a href="blog-details.php"> Mastering the Art of Market Analysis</a>
                                                    </h5>
                                                    <p class="rs-blog-desc">Understand your competitors and market trends to stay
                                                        ahead of the curve and grow.</p>
                                                    <div class="rs-blog-btn">
                                                        <a class="rs-btn has-text is-white" href="blog-details.php">Read More
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- blog area end -->

        <!-- faq area start -->
        <section class="rs-faq-area section-space rs-faq-one theme-secondary">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-faq-wrapper">
                            <div class="rs-faq-left">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle is-white">
                                        Frequently asked questions
                                    </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left is-white mb-20">
                                        Frequently Asked
                                        Question</h2>
                                    <p class="rs-section-desc">Find answers to our question about our consulting
                                        coverage
                                        options.</p>
                                </div>
                                <div class="rs-faq-contact">
                                    <div class="rs-faq-contact-info">
                                        <h5 class="rs-faq-contact-title">Still Have Questions?</h5>
                                        <p class="rs-faq-contact-desc">We're here to help you!</p>
                                    </div>
                                    <div class="rs-faq-contact-btn">
                                        <a class="rs-btn has-icon has-bg-white has-bg-secondary"
                                            href="support.php">Contact Us
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white" />
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white" />
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-faq-right">
                                <div class="rs-faq-content rs-accordion-one">
                                    <div class="accordion-wrapper">
                                        <div class="accordion" id="accordionExampleOne">
                                            <div class="rs-accordion-item has-bg-active active">
                                                <h4 class="accordion-header" id="headingOne">
                                                    <button class="accordion-button" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseOne"
                                                        aria-expanded="true" aria-controls="collapseOne">
                                                        How do your startups with product
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h4>
                                                <div id="collapseOne" class="accordion-collapse collapse show"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Launching a startup begins with more
                                                        than just an
                                                        idea it starts with creating a product that solves a real
                                                        problem.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingTwo">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                                        aria-expanded="false" aria-controls="collapseTwo">
                                                        Can your with fundraising investor
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseTwo" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Securing the right investment is
                                                        essential for
                                                        fueling growth and scaling a business. Our fundraising approach
                                                        is designed
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingThree">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                                        aria-expanded="false" aria-controls="collapseThree">
                                                        What makes startup consulting
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseThree" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Startup consulting helps entrepreneurs
                                                        turn ideas
                                                        into thriving businesses. By combining market insights,
                                                        strategy, and
                                                        execution</div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingFour">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseFour"
                                                        aria-expanded="false" aria-controls="collapseFour">
                                                        Do you provide financial planning
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseFour" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Financial planning is the foundation of
                                                        long-term
                                                        stability and growth. It helps businesses and individuals make
                                                        informed</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- faq area end -->
    </main>
    <!-- Body main wrapper end -->

    <!-- footer area start -->
<footer class="rs-footer-area rs-footer-one theme-secondary">
    <div class="rs-footer-shape-one">
        <img src="assets/images/shape/footer-shape-01.webp" alt="image">
    </div>
    <div class="rs-footer-shape-two">
        <img src="assets/images/shape/footer-shape-02.webp" alt="image">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="rs-footer-wrapper">
                    <div class="rs-footer-left">
                        <div class="rs-footer-widget footer-1-col-1">
                            <div class="rs-footer-widget-logo">
                                <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA"></a>
                            </div>
                            <div class="rs-footer-widget-content">
                                <p class="rs-footer-widget-desc">
                                    ICEF INDIA is a premier organization providing end-to-end solutions in Assessment, Recruitment, and Workforce Development since 2000.
                                </p>
                                <div class="rs-footer-widget-contact-info">
                                    <div class="rs-footer-content-item">
                                        <span>Call us:</span>
                                        <a href="tel:+911204221735">+91 120 422 1735</a>
                                    </div>
                                    <div class="rs-footer-content-item">
                                        <span>Email:</span>
                                        <a href="mailto:sales@icefindia.in">sales@icefindia.in</a>
                                    </div>
                                    <div class="rs-footer-content-item">
                                        <span>Hours: Mon-Fri: 8.00am - 18.00pm</span>
                                    </div>
                                </div>
                                <div class="rs-footer-widget-social">
                                    <div class="rs-footer-social theme-social has-border">
                                        <a href="#"><svg width="14" height="22" viewBox="0 0 14 22" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M11.624 11.9541L12.193 8.54137L8.63572 8.54137V6.32676C8.63572 5.39311 9.13264 4.48303 10.7258 4.48303H12.343V1.57748C12.343 1.57748 10.8755 1.34692 9.47233 1.34692C6.54282 1.34692 4.62796 2.98146 4.62796 5.94041L4.62796 8.54137H1.37158L1.37158 11.9541H4.62796L4.62796 20.2041H8.63572L8.63572 11.9541H11.624Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M17.6045 5.45036C17.5641 4.53485 17.4161 3.9055 17.204 3.3601C16.9852 2.78121 16.6486 2.26294 16.2077 1.83208C15.7768 1.39452 15.2551 1.0545 14.6829 0.839154C14.1344 0.627106 13.5083 0.479009 12.5928 0.438686C11.6705 0.394863 11.3777 0.384766 9.03843 0.384766C6.69917 0.384766 6.40637 0.394863 5.48747 0.435253C4.57199 0.475643 3.94261 0.623808 3.39738 0.835721C2.81832 1.0545 2.30005 1.39108 1.86919 1.83208C1.43163 2.26291 1.09178 2.78461 0.876264 3.3568C0.664216 3.9055 0.516152 4.53148 0.475796 5.44692C0.432006 6.36927 0.421875 6.66206 0.421875 9.00132C0.421875 11.3406 0.432006 11.6334 0.472363 12.5523C0.512753 13.4678 0.660917 14.0971 0.872999 14.6425C1.09178 15.2214 1.43163 15.7397 1.86919 16.1706C2.30005 16.6081 2.82175 16.9481 3.39395 17.1635C3.94258 17.3755 4.56856 17.5236 5.4842 17.564C6.40294 17.6045 6.6959 17.6144 9.03516 17.6144C11.3744 17.6144 11.6672 17.6045 12.5861 17.564C13.5016 17.5236 14.131 17.3756 14.6762 17.1635C15.2489 16.9421 15.7689 16.6035 16.2031 16.1693C16.6372 15.7352 16.9759 15.2152 17.1973 14.6425C17.4092 14.0939 17.5574 13.4678 17.5978 12.5523C17.6382 11.6334 17.6483 11.3406 17.6483 9.00132C17.6483 6.66206 17.6449 6.36923 17.6045 5.45036ZM16.0529 12.485C16.0159 13.3264 15.8745 13.7808 15.7567 14.0837C15.4672 14.8343 14.8715 15.4301 14.1208 15.7196C13.8179 15.8374 13.3603 15.9787 12.5221 16.0157C11.6133 16.0562 11.3408 16.0662 9.04186 16.0662C6.74296 16.0662 6.46699 16.0562 5.56148 16.0157C4.72002 15.9787 4.26563 15.8374 3.96271 15.7196C3.5892 15.5815 3.24922 15.3628 2.97322 15.0767C2.68712 14.7973 2.46834 14.4607 2.33027 14.0872C2.21247 13.7842 2.07114 13.3264 2.03421 12.4884C1.99369 11.5796 1.98373 11.3069 1.98373 9.00802C1.98373 6.70911 1.99369 6.43315 2.03421 5.5278C2.07114 4.68634 2.21247 4.23196 2.33027 3.92903C2.46834 3.55535 2.68712 3.21544 2.97665 2.93937C3.25588 2.65328 3.59246 2.4345 3.96614 2.2966C4.26907 2.17879 4.72689 2.03743 5.56491 2.00037C6.47369 1.95998 6.74639 1.94988 9.04513 1.94988C11.3475 1.94988 11.62 1.95998 12.5255 2.00037C13.367 2.03746 13.8214 2.17876 14.1243 2.29656C14.4978 2.4345 14.8378 2.65328 15.1138 2.93937C15.3999 3.21877 15.6186 3.55535 15.7567 3.92903C15.8745 4.23196 16.0159 4.68961 16.0529 5.5278C16.0933 6.43658 16.1034 6.70911 16.1034 9.00802C16.1034 11.3069 16.0933 11.5762 16.0529 12.485Z"
                                                    fill="white"></path>
                                                <path
                                                    d="M9.0335 4.57741C6.58997 4.57741 4.60742 6.55982 4.60742 9.00349C4.60742 11.4472 6.58997 13.4296 9.0335 13.4296C11.4771 13.4296 13.4596 11.4472 13.4596 9.00349C13.4596 6.55982 11.4771 4.57741 9.0335 4.57741ZM9.0335 11.8746C7.44826 11.8746 6.16237 10.5889 6.16237 9.00349C6.16237 7.41811 7.44826 6.13243 9.03347 6.13243C10.6188 6.13243 11.9046 7.41811 11.9046 9.00349C11.9046 10.5889 10.6188 11.8746 9.0335 11.8746ZM14.668 4.40239C14.668 4.97303 14.2053 5.4357 13.6345 5.4357C13.0639 5.4357 12.6013 4.97303 12.6013 4.40239C12.6013 3.83167 13.0639 3.36914 13.6346 3.36914C14.2053 3.36914 14.668 3.83164 14.668 4.40239Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M9.35332 6.88729L14.6472 0.733521H13.3928L8.79603 6.07675L5.12465 0.733521H0.890137L6.44199 8.81343L0.890137 15.2666H2.1447L6.99896 9.62397L10.8762 15.2666H15.1107L9.35332 6.88729ZM7.63502 8.88462L7.0725 8.08004L2.59674 1.67793H4.52367L8.13567 6.84464L8.69818 7.64922L13.3933 14.3651H11.4664L7.63502 8.88462Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M17.7973 17.7992V11.3532C17.7973 8.18522 17.1153 5.76522 13.4193 5.76522C11.6373 5.76522 10.4493 6.73322 9.96527 7.65722H9.92126V6.05122H6.42326V17.7992H10.0753V11.9692C10.0753 10.4292 10.3613 8.95522 12.2533 8.95522C14.1233 8.95522 14.1453 10.6932 14.1453 12.0572V17.7772H17.7973V17.7992ZM0.483266 6.05122H4.13527V17.7992H0.483266V6.05122ZM2.30927 0.199219C1.14327 0.199219 0.197266 1.14522 0.197266 2.31122C0.197266 3.47722 1.14327 4.44522 2.30927 4.44522C3.47527 4.44522 4.42127 3.47722 4.42127 2.31122C4.42127 1.14522 3.47527 0.199219 2.30927 0.199219Z"
                                                    fill="white"></path>
                                            </svg></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rs-footer-right">
                        <div class="rs-footer-widget-wrapper">
                            <div class="rs-footer-widget footer-1-col-2">
                                <h5 class="rs-footer-widget-title">About​</h5>
                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="industry-clients.php">Industry we work with</a></li>
                                        <li><a href="why-choose-us.php">Why choose us</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                        <li><a href="contact.php">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rs-footer-widget footer-1-col-3">
                                <h5 class="rs-footer-widget-title">Services</h5>
                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="it-emerging-tech-enablement.php">IT & Emerging Tech Enablement</a></li>
                                        <li><a href="assessment-and-testing.php">Assessment & Testing</a></li>
                                        <li><a href="recruitment-and-hiring.php">Recruitment & Hiring</a></li>
                                        <li><a href="exam-management.php">Exam Management</a></li>
                                        <li><a href="manpower-and-workforce.php">Manpower & Workforce</a></li>
                                        <li><a href="call-center-and-bpos.php">Call Center & BPOs</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rs-footer-widget footer-1-col-4">
                                <h5 class="rs-footer-widget-title">Quick Links</h5>

                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="#solutions">Our Solutions</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                        <li><a href="industry-clients.php#clients">Clientele</a></li>
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="rs-footer-subscribe-from">
                            <h5 class="rs-footer-subscribe-title">Subscribe Newsletter</h5>
                            <div class="rs-cta-input">
                                <input id="email2" name="name" type="text" placeholder="Enter your email">
                                <button type="submit" class="rs-btn has-icon has-bg-secondary has-sm-radius">
                                    Send Now
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white"></path>
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white"></path>
                                        </svg>
                                    </span>
                                </button>
                            </div>
                        </div>
                        <div class="rs-footer-brand">
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-07.webp" alt="image">
                            </div>
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-08.webp" alt="image">
                            </div>
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-09.webp" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="rs-footer-copyright-area rs-copyright-one">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="rs-footer-copyright-wrapper">
                        <div class="rs-footer-copyright-left">
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright-link">
                                    <a href="terms-conditions.php">Terms & Agreements</a>
                                </div>
                            </div>
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright-link">
                                    <a href="privacy-policy.php">Privacy policy</a>
                                </div>
                            </div>
                        </div>
                        <div class="rs-footer-copyright-right">
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright">
                                    <p class="underline">Copyright © <span id="year">2025</span> ICEF INDIA. All rights reserved. Designed by <a
                                            target="_blank" href="https://agumentiksoftware.com/">AGUMENTIK.</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer area end -->
    <!-- footer area end -->

    <style>
        /* Typing cursor style */
        .typed-cursor {
            color: var(--rs-theme-primary, #ff0000);
            font-size: inherit;
            margin-left: 5px;
        }

        .rs-typed-text {
            color: var(--rs-theme-primary, #ff0000);
            display: inline-block;
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Wait for main.js to initialize Swiper
            setTimeout(function () {
                const bannerEl = document.querySelector('#rs-banner-swiper');
                if (!bannerEl || !bannerEl.swiper) return;

                const swiper = bannerEl.swiper;
                let typedInstance = null;

                function startTyping(activeIndex) {
                    // Destroy previous instance
                    if (typedInstance) {
                        typedInstance.destroy();
                    }

                    const activeSlide = swiper.slides[activeIndex];
                    const target = activeSlide.querySelector('.rs-typed-text');
                    if (!target) return;

                    const text = target.getAttribute('data-typed');

                    typedInstance = new Typed(target, {
                        strings: [text],
                        typeSpeed: 60,
                        backSpeed: 30,
                        showCursor: true,
                        cursorChar: '|',
                        autoInsertCss: true,
                        onComplete: function () {
                            // Wait for some time after typing completes, then slide
                            setTimeout(function () {
                                if (swiper.activeIndex === activeIndex) {
                                    swiper.slideNext();
                                }
                            }, 2500); // 2.5 seconds pause after typing
                        }
                    });
                }

                // Initial start
                startTyping(swiper.activeIndex);

                // Start on slide change
                swiper.on('slideChangeTransitionEnd', function () {
                    startTyping(swiper.activeIndex);
                });

            }, 500); // Small delay to ensure Swiper is ready
        });
    </script>

        <!-- back to top -->
    <!-- Backtotop start -->
    <div class="backtotop-wrap cursor-pointer">
        <i class="ri-arrow-up-s-line"></i>
    </div>
    <!-- Backtotop end -->

    <!-- JS here -->
    <script src="assets/js/vendor/jquery-3.7.1.min.js"></script>
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/meanmenu@2.0.8/jquery.meanmenu.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/wowjs@1.1.3/dist/wow.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/magnific-popup@1.1.0/dist/jquery.magnific-popup.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/isotope-layout@3.0.6/dist/isotope.pkgd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/imagesloaded@5.0.0/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/vendor/ajax-form.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@studio-freight/lenis@1.0.34/dist/lenis.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
    <script src="assets/js/plugins/rs-scroll-trigger.min.js"></script>
    <script src="assets/js/plugins/rs-splitText.min.js"></script>
    <!-- Custom theme scripts (Restored) -->
    <script src="assets/js/plugins/rs-anim-int.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery.appear@1.0.1/jquery.appear.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-nice-select@1.1.0/js/jquery.nice-select.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/nouislider@15.7.1/dist/nouislider.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/odometer@0.4.8/odometer.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>
