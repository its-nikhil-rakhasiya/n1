<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="template-version" content="1.0.0">
    <title>Careers & Work Culture - ICEF INDIA    </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/favicon-icef.png">
    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/animate.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="assets/css/plugins/flatpickr.min.css">
    <link rel="stylesheet" href="assets/css/plugins/nouislider.min.css">
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/vendor/odometer.min.css">
    <link rel="stylesheet" href="assets/css/vendor/spacing.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css">
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        /* =============================================
           Banner Contact Form — Form Overlaps Girl Image
        ============================================= */

        /* Right column: position:relative so the form can be overlaid */
        .rs-banner-form-wrap {
            position: relative;
            display: block;
        }

        /* Girl image: fully visible, natural width, drives wrapper height */
        .rs-banner-bg-img {
            display: block;
            width: 100%;
            height: auto;
            object-fit: cover;
            object-position: top center;
            opacity: 1;
            position: relative;
            z-index: 0;
        }

        /* Form card: positioned absolutely, centred over the girl image */
        .rs-banner-contact-form {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 3;
            background: #ffffff;
            border-radius: 8px;
            padding: 28px 24px;
            width: calc(100% - 60px);
            max-width: 400px;
            box-shadow: 0 8px 40px rgba(0, 0, 0, 0.28);
        }

        .rs-form-title {
            font-size: 20px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 4px;
            line-height: 1.3;
        }

        .rs-form-subtitle {
            font-size: 12px;
            color: #888;
            margin-bottom: 14px;
        }

        .rs-contact-form-banner .rs-form-row {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }

        .rs-contact-form-banner .rs-form-group {
            flex: 1 1 0%;
            min-width: 0;
            display: flex;
            flex-direction: column;
        }

        .rs-contact-form-banner .rs-form-group-full {
            flex: 1 1 100%;
        }

        .rs-contact-form-banner input,
        .rs-contact-form-banner select,
        .rs-contact-form-banner .nice-select,
        .rs-contact-form-banner textarea {
            width: 100% !important;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            font-size: 14px;
            color: #444;
            background: #fff !important;
            background-image: none !important;
            outline: none;
            transition: border-color 0.3s;
            font-family: inherit;
            appearance: none !important;
            -webkit-appearance: none !important;
            -moz-appearance: none !important;
            box-sizing: border-box;
        }

        .rs-contact-form-banner input,
        .rs-contact-form-banner select,
        .rs-contact-form-banner .nice-select {
            height: 45px !important;
            padding: 0 12px;
            line-height: 43px; /* adjusted for border */
        }

        .rs-contact-form-banner .nice-select {
            display: flex;
            align-items: center;
            float: none;
        }

        .rs-contact-form-banner .nice-select .current {
            display: block;
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            padding-right: 20px;
        }

        .rs-contact-form-banner .nice-select:after {
            content: "" !important;
            border-bottom: 2px solid #AB052D;
            border-right: 2px solid #AB052D;
            height: 8px;
            width: 8px;
            right: 15px;
            top: 40%; 
            transform: rotate(45deg);
        }

        .rs-contact-form-banner input::placeholder,
        .rs-contact-form-banner textarea::placeholder {
            color: #aaa;
        }

        .rs-contact-form-banner input:focus,
        .rs-contact-form-banner select:focus,
        .rs-contact-form-banner .nice-select:focus,
        .rs-contact-form-banner textarea:focus {
            border-color: #AB052D;
        }

        .rs-contact-form-banner select {
            cursor: pointer;
            color: #aaa;
        }

        .rs-contact-form-banner select option:not([disabled]) {
            color: #444;
        }

        .rs-contact-form-banner textarea {
            height: 120px !important;
            padding: 12px;
            resize: none;
            line-height: normal;
        }

        /* Button: maroon matching the site header */
        .rs-banner-form-btn {
            width: 100%;
            background: #AB052D;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 12px;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 1.5px;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            text-transform: uppercase;
        }

        .rs-banner-form-btn:hover {
            background: #8c0424;
            transform: translateY(-1px);
        }

        /* Banner left content: nudge right so it's not touching the left edge */
        .rs-banner-area .rs-banner-content {
            padding-left: 60px;
        }

        /* Hero Left Button: make it maroon */
        .rs-banner-area .rs-banner-content .rs-btn {
            background-color: #AB052D;
            border-color: #AB052D;
        }

        .rs-banner-area .rs-banner-content .rs-btn:hover {
            background-color: #8c0424;
            border-color: #8c0424;
        }

        /* ---- Responsive overrides ---- */
        @media (max-width: 1399px) {
            .rs-banner-area .rs-banner-content { padding-left: 40px; }
        }

        @media (max-width: 1199px) {
            .rs-banner-area .rs-banner-content { padding-left: 24px; }
        }

        @media (max-width: 991px) {
            .rs-banner-area .rs-banner-content { padding-left: 16px; }

            .rs-banner-contact-form {
                position: relative;
                top: auto;
                left: auto;
                transform: none;
                width: 100%;
                max-width: 100%;
                margin-top: 20px;
            }

            .rs-contact-form-banner .rs-form-row {
                flex-direction: column;
                gap: 10px;
            }
        }

        /* =============================================
           Glass Effect — Transparent Header over Banner
        ============================================= */
        @media (min-width: 992px) {

            /* Overlay Header Container — only for main header, not sticky */
            .rs-header-area.header-transparent:not(.rs-sticky-header) {
                position: absolute;
                width: 100%;
                top: 40px; /* leave space for the Top Red Bar */
                left: 0;
                z-index: 1000;
                background: transparent;
            }

            /* Top Red Bar */
            .header-transparent-parent .rs-header-top {
                background: #AB052D !important;
                position: relative;
                z-index: 1002;
                height: 40px;
                display: flex !important;
                align-items: center;
            }

            /* Sticky header — glass while not yet active */
            .header-transparent.rs-sticky-header:not(.active) {
                background: rgba(43, 57, 68, 0.4) !important;
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                position: fixed;
                width: 100%;
                top: -100px;
                z-index: 1001;
                visibility: hidden;
                opacity: 0;
                pointer-events: none;
                transition: all 0.4s ease;
            }

            /* Sticky header — fully visible when active */
            .header-transparent.rs-sticky-header.active {
                background: var(--rs-theme-secondary) !important;
                backdrop-filter: none;
                -webkit-backdrop-filter: none;
                top: 0 !important;
                position: fixed;
                width: 100%;
                visibility: visible;
                opacity: 1;
                pointer-events: auto;
            }
        }

        /* Mobile Menu Fix: hide desktop nav on small screens */
        @media (max-width: 1199px) {
            .header-menu,
            .main-menu,
            #mobile-menu,
            #mobile-menu-two {
                display: none !important;
            }
        }
    </style>
</head>

<body class="rs-smoother-yes">

        <!-- preloader start -->
    <div id="pre-load">
        <div id="loader" class="loader">
            <div class="loader-container">
                <div class="loader-icon"><img src="assets/images/logo/favicon-icef.png" alt="ICEF INDIA"></div>
            </div>
        </div>
    </div>
    <!-- preloader end -->

    <!-- preloader start -->

    <div id="rs-mouse">
        <div id="cursor-ball"></div>
    </div>

    <!-- preloader end -->

    <style>
        /* Custom Mega Menu for Solutions with Feature Image */
        .main-menu .mega-grid-two {
            grid-template-columns: repeat(6, 1fr) 300px !important;
            width: 1550px !important;
            padding: 0 !important;
            overflow: hidden;
            border-radius: 10px !important;
            background-color: var(--rs-theme-secondary) !important;
        }

        @media only screen and (max-width: 1600px) {
            .main-menu .mega-grid-two {
                width: 1350px !important;
                grid-template-columns: repeat(6, 1fr) 250px !important;
            }
        }

        @media only screen and (max-width: 1366px) {
            .main-menu .mega-grid-two {
                width: 1180px !important;
                grid-template-columns: repeat(5, 1fr) !important;
            }
            .mega-menu-feature {
                display: none !important; /* Hide feature on smaller screens to keep navigation clear */
            }
        }

        .main-menu .mega-grid-one > li, .main-menu .mega-grid-two > li {
            padding: 30px 20px !important;
            border-right: 1px solid rgba(255, 255, 255, 0.1) !important;
            position: relative;
        }

        .main-menu .mega-grid-one > li::before, .main-menu .mega-grid-two > li::before {
            content: none !important;
        }

        .main-menu .mega-grid-two > li:last-child {
            border-right: none !important;
        }

        .mega-menu-feature {
            background-color: #243039 !important;
            padding: 40px 30px !important;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
        }

        .mega-menu-feature h6.title {
            color: #AB052D !important;
            font-size: 20px !important;
            margin-bottom: 12px !important;
            font-weight: 700 !important;
            text-transform: capitalize !important;
        }

        .mega-menu-feature p {
            font-size: 14px !important;
            line-height: 1.5 !important;
            color: rgba(255, 255, 255, 0.7) !important;
            margin-bottom: 20px !important;
            white-space: normal !important;
        }

        .mega-menu-feature .feature-thumb {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
        }

        .mega-menu-feature .feature-thumb img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            transition: all 0.4s ease;
        }
        
        .mega-menu-feature:hover .feature-thumb img {
            transform: scale(1.05);
        }

        /* FAQ Section Image Resizing */
        .rs-faq-two .rs-faq-wrapper {
            grid-template-columns: 1fr 480px !important;
            gap: 30px 60px !important;
            align-items: flex-start !important;
        }
        .rs-faq-two .rs-faq-thumb {
            width: 100% !important;
            max-width: 480px !important;
        }
        .rs-faq-two .rs-faq-thumb > img {
            height: 500px !important;
            object-fit: cover !important;
            border-radius: 10px !important;
        }
        .rs-faq-two .rs-faq-award {
            width: auto !important;
            max-width: 360px !important;
            padding: 15px 20px !important;
            bottom: 15px !important;
            inset-inline-start: auto !important;
            inset-inline-end: 15px !important;
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 8px !important;
            background: rgba(255, 255, 255, 0.08) !important;
            background-image: none !important;
            backdrop-filter: blur(12px) !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
        }
        .rs-faq-award-thumb {
            display: none !important;
        }
        .rs-faq-two .rs-faq-award-desc {
            font-size: 13px !important;
            line-height: 1.4 !important;
            margin-bottom: 0 !important;
            border-inline-start: none !important;
            padding-inline-start: 0 !important;
            margin-inline-start: 0 !important;
        }
        @media only screen and (max-width: 1366px) {
            .rs-faq-two .rs-faq-wrapper {
                grid-template-columns: 1fr 400px !important;
            }
            .rs-faq-two .rs-faq-thumb > img {
                height: 450px !important;
            }
        }
        @media only screen and (max-width: 991px) {
            .rs-faq-two .rs-faq-wrapper {
                grid-template-columns: 1fr !important;
            }
            .rs-faq-two .rs-faq-thumb {
                max-width: 100% !important;
            }
        }



        /* Submenu adjustments */
        .main-menu .submenu {
            width: max-content !important;
            min-width: 140px !important;
            max-width: 350px !important;
        }

        .main-menu .submenu li {
            padding-inline-start: 20px !important;
            padding-inline-end: 15px !important;
        }

        .main-menu .submenu li a {
            white-space: nowrap !important;
        }

        /* Mega menu column titles and links */
        .main-menu .mega-grid-two > li .title {
            color: #ffffff !important;
            margin-bottom: 15px !important;
            display: block !important;
        }

        .main-menu .mega-grid-two > li ul li a {
            color: rgba(255, 255, 255, 0.7) !important;
            padding: 5px 0 !important;
        }

        .main-menu .mega-grid-two > li ul li a:hover {
            color: var(--rs-theme-primary) !important;
            padding-left: 5px !important;
        }

        /* Feature Button Styling */
        .mega-menu-feature .rs-btn {
            background-color: var(--rs-theme-primary) !important;
            color: #ffffff !important;
            padding: 14px 28px !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            border-radius: 6px !important;
            font-size: 14px !important;
            font-weight: 700 !important;
            width: fit-content !important;
            height: auto !important;
            line-height: 1 !important;
            margin-bottom: 20px !important;
        }

        .mega-menu-feature .rs-btn:hover {
            background-color: #ffffff !important;
            color: var(--rs-theme-primary) !important;
        }

        /* Sticky Header Styles */
        .rs-sticky-header.active {
            background: var(--rs-theme-secondary) !important;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            top: 0 !important;
        }

        .rs-sticky-header .header-logo img {
            max-height: 50px;
            width: auto;
        }

        .rs-sticky-header .header-wrapper {
            background: transparent !important;
            padding-top: 10px;
            padding-bottom: 10px;
        }

        /* Bridge the gap to prevent dropdown closing when moving mouse from link to menu */
        .main-menu li {
            position: relative;
        }

        .main-menu .submenu,
        .main-menu .mega-menu {
            position: absolute;
            background-color: var(--rs-theme-secondary);
            z-index: 99;
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
            /* Professional transition with slight delay for closing to make it more stable and forgiving */
            transition: opacity 0.3s ease, transform 0.3s ease, visibility 0.3s ease !important;
            transition-delay: 0.2s !important;
        }

        .main-menu li:hover > .submenu,
        .main-menu li:hover > .mega-menu {
            opacity: 1;
            visibility: visible;
            pointer-events: all;
            transition-delay: 0s !important;
        }

        /* The Bridge: Invisible pseudo-element to close the physical gap between link and menu */
        .main-menu .submenu::before,
        .main-menu .mega-menu::before {
            content: "";
            position: absolute;
            top: -50px; /* Ample space to bridge any gap */
            left: 0;
            right: 0;
            height: 50px;
            background: transparent;
            z-index: 10;
            pointer-events: auto !important; /* Forces hover capture in the gap */
        }

        /* More persistent hover colors */
        .main-menu ul li:hover > a {
            color: var(--rs-theme-primary) !important;
        }
    </style>

    <!-- header area start-->
    <header>
        <div class="container-fluid g-0">
            <!-- top start -->
            <div class="rs-header-top rs-header-top-one">
                <div class="header-top-left">
                    <span class="header-top-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="6" height="11" viewBox="0 0 6 11" fill="none">
                            <path
                                d="M0.50204 0.439454C0.811629 0.16438 1.28548 0.192407 1.56063 0.501954L5.56063 5.00195C5.81308 5.28608 5.81308 5.71392 5.56063 5.99805L1.56063 10.498C1.28548 10.8076 0.811629 10.8356 0.50204 10.5605C0.192493 10.2854 0.164466 9.81154 0.43954 9.50195L3.99618 5.5L0.43954 1.49805C0.164466 1.18846 0.192493 0.714606 0.50204 0.439454Z"
                                fill="#AB052D"></path>
                        </svg>
                    </span>
                    <div class="header-top-content">
                        <p>India's Leading Integrated Assessment & Recruitment Platform Since 2000.
                            <a href="about-mission.php">Learn More</a>
                        </p>
                    </div>
                </div>
                <div class="header-top-right">
                    <div class="header-top-meta">
                        <span class="header-top-meta-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
                                <path
                                    d="M12.1641 10.5834C11.6414 10.0673 10.9888 10.0673 10.4694 10.5834C10.0732 10.9762 9.67699 11.3691 9.28744 11.7686C9.1809 11.8785 9.091 11.9018 8.96115 11.8286C8.70479 11.6887 8.43177 11.5755 8.18539 11.4224C7.03673 10.6999 6.07452 9.77097 5.22218 8.72552C4.79934 8.20613 4.42312 7.65011 4.16009 7.02417C4.10682 6.89765 4.11681 6.81442 4.22002 6.7112C4.61622 6.32832 5.00244 5.93544 5.39198 5.54257C5.93469 4.99654 5.93469 4.35728 5.38866 3.80792C5.07902 3.49495 4.76938 3.18865 4.45974 2.87568C4.14011 2.55605 3.82381 2.23309 3.50086 1.9168C2.97813 1.40739 2.32556 1.40739 1.80617 1.92012C1.40663 2.313 1.02375 2.71586 0.617555 3.10208C0.241327 3.45833 0.0515486 3.89449 0.0115952 4.40389C-0.0516643 5.23293 0.151432 6.01535 0.437765 6.77779C1.02375 8.35595 1.91604 9.75765 2.99811 11.0428C4.45974 12.7808 6.20437 14.1558 8.24532 15.148C9.16425 15.5942 10.1165 15.9371 11.1519 15.9937C11.8644 16.0337 12.4837 15.8539 12.9798 15.2979C13.3194 14.9183 13.7023 14.572 14.0619 14.2091C14.5946 13.6697 14.5979 13.0172 14.0685 12.4845C13.4359 11.8485 12.8 11.2159 12.1641 10.5834Z"></path>
                                <path
                                    d="M11.5271 7.92979L12.7557 7.72003C12.5625 6.59135 12.0298 5.56921 11.2208 4.75682C10.3651 3.90116 9.28304 3.36178 8.0911 3.19531L7.91797 4.43054C8.84023 4.56039 9.67925 4.97657 10.3418 5.63913C10.9677 6.26506 11.3773 7.05747 11.5271 7.92979Z"></path>
                                <path
                                    d="M13.4493 2.59031C12.0309 1.17197 10.2363 0.276344 8.25531 0L8.08218 1.23523C9.79352 1.47495 11.345 2.25071 12.5703 3.47262C13.7323 4.63459 14.4947 6.10288 14.771 7.71766L15.9996 7.50791C15.6767 5.63676 14.7943 3.93874 13.4493 2.59031Z"></path>
                            </svg>
                        </span>
                        <div class="header-top-meta-content">
                            <span>Call us:</span>
                            <a href="tel:+911204221735">+91 120 422 1735</a>
                        </div>
                    </div>
                    <div class="header-top-meta">
                        <span class="header-top-meta-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"
                                fill="none">
                                <g clip-path="url(#clip0_28535_99)">
                                    <path
                                        d="M15.8603 3.17969L11.0078 8.00091L15.8603 12.8221C15.948 12.6388 16.0012 12.4361 16.0012 12.2197V3.78216C16.0012 3.56569 15.948 3.36303 15.8603 3.17969Z"
                                        fill="white"></path>
                                    <path
                                        d="M14.5947 2.375H1.40716C1.19069 2.375 0.988031 2.42822 0.804688 2.51594L7.00666 8.68666C7.55503 9.23503 8.44678 9.23503 8.99516 8.68666L15.1971 2.51594C15.0138 2.42822 14.8111 2.375 14.5947 2.375Z"
                                        fill="white"></path>
                                    <path
                                        d="M0.140938 3.17969C0.0532188 3.36303 0 3.56569 0 3.78216V12.2197C0 12.4361 0.0532188 12.6388 0.140938 12.8221L4.99341 8.00091L0.140938 3.17969Z"
                                        fill="white"></path>
                                    <path
                                        d="M10.3447 8.66211L9.658 9.34877C8.74428 10.2625 7.2575 10.2625 6.34378 9.34877L5.65716 8.66211L0.804688 13.4833C0.988031 13.571 1.19069 13.6243 1.40716 13.6243H14.5947C14.8111 13.6243 15.0138 13.571 15.1971 13.4833L10.3447 8.66211Z"
                                        fill="white"></path>
                                </g>
                                <defs>
                                    <clipPath id="clip0_28535_99">
                                        <rect width="16" height="16" fill="white"></rect>
                                    </clipPath>
                                </defs>
                            </svg>
                        </span>
                        <div class="header-top-meta-content">
                            <span>Send mail:</span>
                            <a href="mailto:sales@icefindia.in">
                                sales@icefindia.in
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- top end -->
        </div>

        
        <div class="rs-header-area rs-header-one ">
                    <div class="container-fluid g-0">
            <div class="header-wrapper">
                <div class="header-left">
                    <div class="header-logo">
                        <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA - Integrated Assessment & Recruitment Platform"></a>
                    </div>
                </div>
                <div class="header-right">
                    <div class="header-menu">
                        <nav id="mobile-menu-two" class="main-menu">
                            <ul class="multipage-menu">
                                <li><a href="index.php">Home</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">About Company</a>
                                    <ul class="submenu last-children">
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="about-mission.php#mission">Mission & Vision</a></li>
                                        <li><a href="industry-clients.php">Industry We Work With</a></li>
                                        <li><a href="industry-clients.php#clients">Client Tele</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                        <li><a href="careers-culture.php">Work Culture</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children rs-mega-menu">
                                    <a href="javascript:void(0)">Solutions</a>
                                    <ul class="mega-menu mega-grid-two">
                                        <li class="rs-menu-item" data-image="assets/images/solution/it-emerging.webp">
                                            <a href="it-emerging-tech-enablement.php" class="title">IT & Emerging Tech Enablement</a>
                                            <ul>
                                                <li data-image="assets/images/solution/iot.webp"><a href="iot-and-rfid.php">IOT & RFID Based Products</a></li>
                                                <li data-image="assets/images/solution/app-dev.webp"><a href="application-development.php">Application Development</a></li>
                                                <li data-image="assets/images/solution/software-dev.webp"><a href="customized-software-development.php">Customized Software Development</a></li>
                                                <li data-image="assets/images/solution/emerging-tech.webp"><a href="emerging-tech.php">Emerging Tech</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/assessment-testing.webp">
                                            <a href="assessment-and-testing.php" class="title">Assessment & Testing</a>
                                            <ul>
                                                <li data-image="assets/images/solution/cognitive-domain.webp"><a href="cognitive-domain.php">Cognitive/Domain</a></li>
                                                <li data-image="assets/images/solution/online-offline.webp"><a href="online-offline.php">Online/Offline</a></li>
                                                <li data-image="assets/images/solution/proctoring.webp"><a href="proctoring.php">Proctoring</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/recruitment.webp">
                                            <a href="recruitment-and-hiring.php" class="title">Recruitment & Hiring</a>
                                            <ul>
                                                <li data-image="assets/images/about/33.webp"><a href="screening.php">Screening</a></li>
                                                <li data-image="assets/images/about/37.webp"><a href="assessments.php">Assessments</a></li>
                                                <li data-image="assets/images/solution/merit-list.webp"><a href="merit-lists.php">Merit Lists</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/exam-management.webp">
                                            <a href="exam-management.php" class="title">Exam Management</a>
                                            <ul>
                                                <li data-image="assets/images/solution/question-banks.webp"><a href="question-banks.php">Question Banks</a></li>
                                                <li data-image="assets/images/solution/exam-conduct.webp"><a href="exam-conduct.php">Conduct</a></li>
                                                <li data-image="assets/images/solution/processing.webp"><a href="exam-processing.php">Processing</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/manpower-workforce.webp">
                                            <a href="manpower-and-workforce.php" class="title">Manpower & Workforce</a>
                                            <ul>
                                                <li data-image="assets/images/solution/outsourcing.webp"><a href="outsourcing.php">Outsourcing</a></li>
                                                <li data-image="assets/images/about/31.webp"><a href="staffing.php">Staffing</a></li>
                                                <li data-image="assets/images/solution/deployment.webp"><a href="deployment.php">Deployment</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/call-center.webp">
                                            <a href="call-center-and-bpos.php" class="title">Call Center & BPOs</a>
                                            <ul>
                                                <li data-image="assets/images/solution/inbound.webp"><a href="inbound-outbound.php">Inbound/Outbound</a></li>
                                                <li data-image="assets/images/solution/support.webp"><a href="support.php">Support</a></li>
                                                <li data-image="assets/images/solution/telecalling.webp"><a href="tele-calling.php">Tele-Calling</a></li>
                                            </ul>
                                        </li>
                                        <li class="mega-menu-feature">
                                            <div class="mega-feature-content">
                                                <h6 class="title">Let's Talk Business</h6>
                                                <p>Empowering businesses with smart IT solutions since 2000.</p>
                                                <a href="support.php" class="rs-btn has-icon has-md-radius hover-primary">Request Quote</a>
                                                <div class="feature-thumb mt-20">
                                                    <img id="mega-menu-target-img" src="assets/images/mega-menu-feature.png" alt="Consultation">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="why-choose-us.php">Why Choose Us</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">WhiteBoard</a>
                                    <ul class="submenu last-children">
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="faq.php">FAQs</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                    </ul>
                                </li>
                                
                                
                                <li><a href="contact.php">Support</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="header-content">
                        <div class="header-btn">
                            <a class="rs-btn has-icon is-transparent hover-primary border-hover-primary" href="contact.php">Get Free Quote</a>
                        </div>
                        <div class="header-search-wrapper">
                            <div class="header-search-icon"><i class="ri-search-line"></i></div>
                        </div>
                        <div class="header-hamburger">
                            <div class="sidebar-toggle">
                                <a class="header-bar-icon" href="javascript:void(0)"><span></span><span></span><span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                </div>

        <div id="rs-sticky-header" class="rs-sticky-header rs-header-area rs-header-one ">
                    <div class="container-fluid g-0">
            <div class="header-wrapper">
                <div class="header-left">
                    <div class="header-logo">
                        <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA - Integrated Assessment & Recruitment Platform"></a>
                    </div>
                </div>
                <div class="header-right">
                    <div class="header-menu">
                        <nav id="mobile-menu-two" class="main-menu">
                            <ul class="multipage-menu">
                                <li><a href="index.php">Home</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">About Company</a>
                                    <ul class="submenu last-children">
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="about-mission.php#mission">Mission & Vision</a></li>
                                        <li><a href="industry-clients.php">Industry We Work With</a></li>
                                        <li><a href="industry-clients.php#clients">Client Tele</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                        <li><a href="careers-culture.php">Work Culture</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children rs-mega-menu">
                                    <a href="javascript:void(0)">Solutions</a>
                                    <ul class="mega-menu mega-grid-two">
                                        <li class="rs-menu-item" data-image="assets/images/solution/it-emerging.webp">
                                            <a href="it-emerging-tech-enablement.php" class="title">IT & Emerging Tech Enablement</a>
                                            <ul>
                                                <li data-image="assets/images/solution/iot.webp"><a href="iot-and-rfid.php">IOT & RFID Based Products</a></li>
                                                <li data-image="assets/images/solution/app-dev.webp"><a href="application-development.php">Application Development</a></li>
                                                <li data-image="assets/images/solution/software-dev.webp"><a href="customized-software-development.php">Customized Software Development</a></li>
                                                <li data-image="assets/images/solution/emerging-tech.webp"><a href="emerging-tech.php">Emerging Tech</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/assessment-testing.webp">
                                            <a href="assessment-and-testing.php" class="title">Assessment & Testing</a>
                                            <ul>
                                                <li data-image="assets/images/solution/cognitive-domain.webp"><a href="cognitive-domain.php">Cognitive/Domain</a></li>
                                                <li data-image="assets/images/solution/online-offline.webp"><a href="online-offline.php">Online/Offline</a></li>
                                                <li data-image="assets/images/solution/proctoring.webp"><a href="proctoring.php">Proctoring</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/recruitment.webp">
                                            <a href="recruitment-and-hiring.php" class="title">Recruitment & Hiring</a>
                                            <ul>
                                                <li data-image="assets/images/about/33.webp"><a href="screening.php">Screening</a></li>
                                                <li data-image="assets/images/about/37.webp"><a href="assessments.php">Assessments</a></li>
                                                <li data-image="assets/images/solution/merit-list.webp"><a href="merit-lists.php">Merit Lists</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/exam-management.webp">
                                            <a href="exam-management.php" class="title">Exam Management</a>
                                            <ul>
                                                <li data-image="assets/images/solution/question-banks.webp"><a href="question-banks.php">Question Banks</a></li>
                                                <li data-image="assets/images/solution/exam-conduct.webp"><a href="exam-conduct.php">Conduct</a></li>
                                                <li data-image="assets/images/solution/processing.webp"><a href="exam-processing.php">Processing</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/manpower-workforce.webp">
                                            <a href="manpower-and-workforce.php" class="title">Manpower & Workforce</a>
                                            <ul>
                                                <li data-image="assets/images/solution/outsourcing.webp"><a href="outsourcing.php">Outsourcing</a></li>
                                                <li data-image="assets/images/about/31.webp"><a href="staffing.php">Staffing</a></li>
                                                <li data-image="assets/images/solution/deployment.webp"><a href="deployment.php">Deployment</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/call-center.webp">
                                            <a href="call-center-and-bpos.php" class="title">Call Center & BPOs</a>
                                            <ul>
                                                <li data-image="assets/images/solution/inbound.webp"><a href="inbound-outbound.php">Inbound/Outbound</a></li>
                                                <li data-image="assets/images/solution/support.webp"><a href="support.php">Support</a></li>
                                                <li data-image="assets/images/solution/telecalling.webp"><a href="tele-calling.php">Tele-Calling</a></li>
                                            </ul>
                                        </li>
                                        <li class="mega-menu-feature">
                                            <div class="mega-feature-content">
                                                <h6 class="title">Let's Talk Business</h6>
                                                <p>Empowering businesses with smart IT solutions since 2000.</p>
                                                <a href="support.php" class="rs-btn has-icon has-md-radius hover-primary">Request Quote</a>
                                                <div class="feature-thumb mt-20">
                                                    <img id="mega-menu-target-img" src="assets/images/mega-menu-feature.png" alt="Consultation">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="why-choose-us.php">Why Choose Us</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">WhiteBoard</a>
                                    <ul class="submenu last-children">
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="faq.php">FAQs</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                    </ul>
                                </li>
                                
                                
                                <li><a href="contact.php">Support</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="header-content">
                        <div class="header-btn">
                            <a class="rs-btn has-icon is-transparent hover-primary border-hover-primary" href="contact.php">Get Free Quote</a>
                        </div>
                        <div class="header-search-wrapper">
                            <div class="header-search-icon"><i class="ri-search-line"></i></div>
                        </div>
                        <div class="header-hamburger">
                            <div class="sidebar-toggle">
                                <a class="header-bar-icon" href="javascript:void(0)"><span></span><span></span><span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                </div>
    </header>
    <!-- Header area end -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const targetImg = document.getElementById('mega-menu-target-img');
            if (!targetImg) return;

            const globalDefaultImg = targetImg.getAttribute('src');
            let defaultImg = globalDefaultImg;
            const menuItems = document.querySelectorAll('.rs-mega-menu .mega-menu [data-image]');

            // Detect active page and set its image as default
            const currentPath = window.location.pathname;
            document.querySelectorAll('.rs-mega-menu .mega-menu .rs-menu-item').forEach(item => {
                const links = item.querySelectorAll('a');
                links.forEach(link => {
                    const href = link.getAttribute('href');
                    if (href && href !== '#' && currentPath.endsWith(href)) {
                        const activeImg = link.parentElement.getAttribute('data-image') || item.getAttribute('data-image');
                        if (activeImg) {
                            defaultImg = activeImg;
                            targetImg.setAttribute('src', activeImg);
                        }
                    }
                });
            });

            menuItems.forEach(item => {
                item.addEventListener('mouseenter', function(e) {
                    e.stopPropagation();
                    const newImg = this.getAttribute('data-image');
                    if (newImg && targetImg.getAttribute('src') !== newImg) {
                        targetImg.style.opacity = '0';
                        setTimeout(() => {
                            targetImg.setAttribute('src', newImg);
                            targetImg.style.opacity = '1';
                        }, 200);
                    }
                });
            });

            // Revert to default when leaving the entire mega menu grid
            const megaGrid = document.querySelector('.mega-grid-two');
            if (megaGrid) {
                megaGrid.addEventListener('mouseleave', function() {
                    targetImg.style.opacity = '0';
                    setTimeout(() => {
                        targetImg.setAttribute('src', defaultImg);
                        targetImg.style.opacity = '1';
                    }, 200);
                });
            }
        });
    </script>
    <style>
        #mega-menu-target-img {
            transition: opacity 0.3s ease;
        }
    </style>

        <!-- Offcanvas area start -->
    <div class="fix">
        <div class="offcanvas-area" data-lenis-prevent>
            <div class="offcanvas-wrapper">
                <div class="offcanvas-content">
                    <div class="offcanvas-top d-flex justify-content-between align-items-center mb-20">
                        <div class="offcanvas-logo">
                            <a class="logo-black" href="index.php"><img src="assets/images/logo/logo-icef.png" alt="logo"></a>
                            <a class="logo-white" href="index.php"><img src="assets/images/logo/logo-icef.png" alt="logo"></a>
                        </div>
                        <div class="offcanvas-close">
                            <button class="offcanvas-close-icon animation--flip" style="background: var(--rs-theme-primary); color: white; border: none; padding: 10px; border-radius: 4px; display: flex; align-items: center; justify-content: center; width: 40px; height: 40px;">
                                <i class="ri-close-line" style="font-size: 24px;"></i>
                            </button>
                        </div>
                    </div>
                    <div class="offcanvas-about mb-30 d-none d-xl-block">
                        <p>
                            ICEF INDIA is a premier organization providing end-to-end solutions in Assessment, Recruitment, and Workforce Development since 2000.
                        </p>
                    </div>
                    <div class="offcanvas-gallery d-none d-xl-block">
                        <div class="offcanvas-gallery-thumb-wrapper">
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-01.webp">
                                    <img src="assets/images/gallery/gallery-thumb-01.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-02.webp">
                                    <img src="assets/images/gallery/gallery-thumb-02.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-03.webp">
                                    <img src="assets/images/gallery/gallery-thumb-03.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-04.webp">
                                    <img src="assets/images/gallery/gallery-thumb-04.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-05.webp">
                                    <img src="assets/images/gallery/gallery-thumb-05.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-06.webp">
                                    <img src="assets/images/gallery/gallery-thumb-06.webp" alt="image">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="mobile-menu-container">
                        <div class="rs-offcanvas-menu mb-30" id="sidebar-menu-target">
                            <!-- Menu will be injected here via JS -->
                        </div>
                    </div>
                    <div class="offcanvas-contact mb-30">
                        <h4 class="offcanvas-title-meta">Contact Info</h4>
                        <ul>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="18" viewBox="0 0 14 18" fill="none">
                                        <path d="M11.8768 9.68475C11.3059 10.835 10.5331 11.9818 9.74128 13.0109C8.95198 14.0368 8.15999 14.9249 7.5643 15.5572C7.48514 15.6412 7.40956 15.7206 7.33802 15.7951C7.26648 15.7206 7.1909 15.6412 7.11174 15.5572C6.51605 14.9249 5.72406 14.0368 4.93476 13.0109C4.14299 11.9818 3.37019 10.835 2.79925 9.68475C2.22242 8.52266 1.89032 7.43373 1.89032 6.5C1.89032 3.50846 4.32934 1.08333 7.33802 1.08333C10.3467 1.08333 12.7857 3.50846 12.7857 6.5C12.7857 7.43373 12.4536 8.52266 11.8768 9.68475ZM7.33802 17.3333C7.33802 17.3333 13.8753 11.1732 13.8753 6.5C13.8753 2.91015 10.9484 0 7.33802 0C3.7276 0 0.800781 2.91015 0.800781 6.5C0.800781 11.1732 7.33802 17.3333 7.33802 17.3333Z" fill="#6D6D6D"></path>
                                        <path d="M7.33802 8.66667C6.13455 8.66667 5.15894 7.69662 5.15894 6.5C5.15894 5.30338 6.13455 4.33333 7.33802 4.33333C8.54149 4.33333 9.5171 5.30338 9.5171 6.5C9.5171 7.69662 8.54149 8.66667 7.33802 8.66667ZM7.33802 9.75C9.14323 9.75 10.6066 8.29492 10.6066 6.5C10.6066 4.70507 9.14323 3.25 7.33802 3.25C5.53281 3.25 4.0694 4.70507 4.0694 6.5C4.0694 8.29492 5.53281 9.75 7.33802 9.75Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="#"> Noida, Uttar Pradesh, India</a>
                                </div>
                            </li>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M3.65387 1.32849C3.40343 1.00649 2.92745 0.976861 2.639 1.26531L1.60508 2.29923C1.1216 2.78271 0.94387 3.46766 1.1551 4.06847C2.00338 6.48124 3.39215 8.74671 5.32272 10.6773C7.25329 12.6078 9.51876 13.9966 11.9315 14.8449C12.5323 15.0561 13.2173 14.8784 13.7008 14.3949L14.7347 13.361C15.0231 13.0726 14.9935 12.5966 14.6715 12.3461L12.3653 10.5524C12.2008 10.4245 11.9866 10.3793 11.7845 10.4298L9.59541 10.9771C9.00082 11.1257 8.37183 10.9515 7.93845 10.5181L5.48187 8.06155C5.04849 7.62817 4.87427 6.99919 5.02292 6.40459L5.57019 4.21553C5.62073 4.01336 5.57552 3.79918 5.44758 3.63468L3.65387 1.32849ZM1.88477 0.511076C2.62689 -0.231039 3.8515 -0.154797 4.49583 0.673634L6.28954 2.97983C6.6187 3.40304 6.73502 3.95409 6.60498 4.47423L6.05772 6.66329C5.99994 6.8944 6.06766 7.13888 6.2361 7.30732L8.69268 9.7639C8.86113 9.93235 9.1056 10.0001 9.33671 9.94229L11.5258 9.39502C12.0459 9.26499 12.597 9.3813 13.0202 9.71047L15.3264 11.5042C16.1548 12.1485 16.231 13.3731 15.4889 14.1152L14.455 15.1492C13.7153 15.8889 12.6089 16.2137 11.5778 15.8512C9.01754 14.9511 6.61438 13.4774 4.56849 11.4315C2.5226 9.38562 1.04895 6.98246 0.148838 4.42225C-0.213682 3.39112 0.11113 2.28472 0.85085 1.545L1.88477 0.511076Z" fill="#6D6D6D"></path>
                                        <path d="M11 0.5C11 0.223858 11.2239 0 11.5 0H15.5C15.7761 0 16 0.223858 16 0.5V4.5C16 4.77614 15.7761 5 15.5 5C15.2239 5 15 4.77614 15 4.5V1.70711L10.8536 5.85355C10.6583 6.04882 10.3417 6.04882 10.1464 5.85355C9.95118 5.65829 9.95118 5.34171 10.1464 5.14645L14.2929 1H11.5C11.2239 1 11 0.776142 11 0.5Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="tel:+911204221735"> +91 120 422 1735 </a>
                                </div>
                            </li>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M2 2C0.895431 2 0 2.89543 0 4V12L2.58386e-05 12.0103C0.00555998 13.1101 0.898859 14 2 14H7.5C7.77614 14 8 13.7761 8 13.5C8 13.2239 7.77614 13 7.5 13H2C1.53715 13 1.14774 12.6855 1.03376 12.2586L6.67417 8.7876L8 9.5831L15 5.3831V8.5C15 8.77614 15.2239 9 15.5 9C15.7761 9 16 8.77614 16 8.5V4C16 2.89543 15.1046 2 14 2H2ZM5.70808 8.20794L1 11.1052V5.3831L5.70808 8.20794ZM1 4.2169V4C1 3.44772 1.44772 3 2 3H14C14.5523 3 15 3.44772 15 4V4.2169L8 8.4169L1 4.2169Z" fill="#6D6D6D"></path>
                                        <path d="M14.2467 14.2686C15.2567 14.2686 15.8339 13.4116 15.8339 12.2442V12.0344C15.8339 10.4297 14.6402 9 12.5197 9H12.4847C10.421 9 9 10.3598 9 12.4322V12.6465C9 14.8195 10.4385 16 12.3579 16H12.4016C12.9963 16 13.4204 15.9257 13.639 15.8251V15.0949C13.3941 15.2042 12.9656 15.2742 12.4585 15.2742H12.4147C11.0812 15.2742 9.84385 14.4872 9.84385 12.6202V12.4628C9.84385 10.8057 10.9019 9.73891 12.4847 9.73891H12.524C14.0587 9.73891 15.0075 10.7883 15.0075 12.065V12.183C15.0075 13.158 14.6839 13.5734 14.3691 13.5734C14.1374 13.5734 13.9582 13.4247 13.9582 13.1537V10.9631H13.0531V11.5315H13.0225C12.9394 11.2342 12.6552 10.9019 12.0693 10.9019C11.2911 10.9019 10.8101 11.4572 10.8101 12.3011V12.8301C10.8101 13.722 11.2998 14.2642 12.0693 14.2642C12.5415 14.2642 12.9656 14.0369 13.0837 13.6215H13.1274C13.2455 14.0412 13.7439 14.2686 14.2467 14.2686ZM11.7939 12.6814V12.4541C11.7939 11.9076 12.0212 11.6627 12.3666 11.6627C12.664 11.6627 12.9394 11.8551 12.9394 12.371V12.7383C12.9394 13.3111 12.6858 13.4816 12.3754 13.4816C12.0212 13.4816 11.7939 13.2673 11.7939 12.6814Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="mailto:sales@icefindia.in">sales@icefindia.in</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="offcanvas-social">
                        <h4 class="offcanvas-title-meta">Follow Us</h4>
                        <ul>
                            <li><a href="#"><i class="ri-facebook-fill"></i></a></li>
                            <li><a href="#"><i class="ri-twitter-x-fill"></i></a></li>
                            <li><a href="#"><i class="ri-youtube-fill"></i></a></li>
                            <li><a href="#"><i class="ri-linkedin-box-fill"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas-overlay"></div>
    <div class="offcanvas-overlay-white"></div>
    <!-- Offcanvas area start -->

    <!-- Body main wrapper start -->
    <main>

        <!-- Section 1: Welcome to ICEF team -->
        <section class="rs-working-area rs-working-seven section-space">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-working-wrapper">
                            <div class="rs-working-content-wrapper">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle">
                                        Best BUSINESS Strategy
                                    </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left mb-20">Welcome to ICEF
                                        team
                                    </h2>
                                    <p class="rs-section-desc">Position your agency as the bridge between a client’s
                                        big-picture
                                        vision and achievable action plans. data-driven strategies and your track.</p>
                                </div>
                                <div class="rs-working-list-wrapper">
                                    <div class="rs-working-list-item">
                                        <div class="rs-working-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p class="rs-working-list-desc"> Regulatory Investigations </p>
                                    </div>
                                    <div class="rs-working-list-item">
                                        <div class="rs-working-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p class="rs-working-list-desc"> Competitive Work Analysis </p>
                                    </div>
                                    <div class="rs-working-list-item">
                                        <div class="rs-working-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p class="rs-working-list-desc"> Anit- Competitive Conduct </p>
                                    </div>
                                    <div class="rs-working-list-item">
                                        <div class="rs-working-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p class="rs-working-list-desc">Global Expansion Planning</p>
                                    </div>
                                </div>
                                <div class="rs-working-btn">
                                    <a class="rs-btn has-icon hover-secondary" href="contact.php">Join a global team
                                        <span class="icon-box">
                                            <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>

                                            <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="rs-working-thumb rs-image scroll_reveal reveal-active" data-dir="reveal_right">
                                <img src="assets/images/about/16.webp" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Section 2: Company Values -->
        <!-- value area start -->
        <section class="rs-value-area rs-value-one">
            <div class="rs-value-bg-thumb include-bg" data-background="assets/images/bg/value-bg-thumb-01.webp"></div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-value-content gsap-move-no rs-tween_max_btn-no">
                            <h2 class="rs-split-text-enable split-in-left rs-value-title" data-split-type="words"
                                data-duration="0.8" data-delay="0.02">Company Values</h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- value area end -->

        <!-- feature area start -->
        <section class="rs-feature-area rs-feature-seven">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-feature-wrapper">
                            <div class="rs-feature-item wow fadeIn" data-wow-delay=".3s" data-wow-duration="1s">
                                <div class="rs-feature-top">
                                    <div class="rs-feature-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 44">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M21.3556 18.2501C21.3556 18.0791 21.4235 17.9152 21.5444 17.7943C21.6652 17.6734 21.8292 17.6055 22.0001 17.6055C22.1711 17.6055 22.335 17.6734 22.4559 17.7943C22.5767 17.9152 22.6447 18.0791 22.6447 18.2501V21.3556H25.7502C25.9211 21.3556 26.0851 21.4235 26.2059 21.5444C26.3268 21.6652 26.3947 21.8292 26.3947 22.0001C26.3947 22.1711 26.3268 22.335 26.2059 22.4559C26.0851 22.5767 25.9211 22.6447 25.7502 22.6447H22.6447V25.7502C22.6447 25.9211 22.5767 26.0851 22.4559 26.2059C22.335 26.3268 22.1711 26.3947 22.0001 26.3947C21.8292 26.3947 21.6652 26.3268 21.5444 26.2059C21.4235 26.0851 21.3556 25.9211 21.3556 25.7502V22.6447H18.2501C18.0791 22.6447 17.9152 22.5767 17.7943 22.4559C17.6734 22.335 17.6055 22.1711 17.6055 22.0001C17.6055 21.8292 17.6734 21.6652 17.7943 21.5444C17.9152 21.4235 18.0791 21.3556 18.2501 21.3556H21.3556V18.2501ZM1.37512 14.9197C1.01461 14.9197 0.730591 15.2033 0.730591 15.5863H0.732137C0.731928 15.75 0.794411 15.9077 0.906763 16.0269L6.53876 22.0001L0.937614 27.9407C0.501653 28.3726 0.800114 29.0804 1.37512 29.0804H6.91972C8.57376 32.5972 11.4031 35.4265 14.9198 37.0805V42.6251C14.9198 42.9856 15.2034 43.2697 15.5863 43.2697V43.2681C15.7501 43.2683 15.9078 43.2058 16.027 43.0935L22.0001 37.4615L27.9407 43.0626C28.3726 43.4986 29.0804 43.2001 29.0804 42.6251V37.0806C32.5972 35.4266 35.4265 32.5972 37.0805 29.0805H42.6251C42.9856 29.0805 43.2697 28.7969 43.2697 28.414H43.2681C43.2683 28.2502 43.2058 28.0925 43.0935 27.9734L37.4615 22.0001L43.0626 16.0595C43.4986 15.6277 43.2001 14.9198 42.6251 14.9198H37.0806C35.4266 11.4031 32.5972 8.57376 29.0805 6.91972V1.37512C29.0805 1.01461 28.7969 0.730591 28.414 0.730591V0.732137C28.2502 0.731916 28.0925 0.794435 27.9734 0.906848L22.0001 6.53876L16.0595 0.937614C15.6277 0.501653 14.9198 0.800114 14.9198 1.37512V6.91972C11.4031 8.57376 8.57376 11.4031 6.91972 14.9198L1.37512 14.9197ZM8.3535 14.9197C9.81109 12.1179 12.118 9.811 14.9198 8.3535V9.46588H14.9214C14.9212 9.55362 14.9391 9.64046 14.9739 9.721C15.0087 9.80155 15.0597 9.8741 15.1237 9.93415L17.3897 12.0707C15.0452 13.1614 13.1613 15.0453 12.0706 17.3897L9.96423 15.1557C9.90383 15.0819 9.82778 15.0224 9.74157 14.9816C9.65537 14.9408 9.56117 14.9197 9.46579 14.9198L8.3535 14.9197ZM13.0315 18.4087L16.0023 21.5595C16.1145 21.6788 16.1769 21.8364 16.1769 22.0001C16.1769 22.1639 16.1145 22.3215 16.0023 22.4407L13.0316 25.5915C14.0107 28.0338 15.9666 29.9897 18.4088 30.9688L21.5596 27.998C21.6789 27.8859 21.8365 27.8234 22.0002 27.8234C22.164 27.8234 22.3215 27.8859 22.4408 27.998L25.5916 30.9688C28.0338 29.9898 29.9898 28.0338 30.9689 25.5916L27.9981 22.4408C27.8859 22.3215 27.8235 22.164 27.8235 22.0002C27.8235 21.8365 27.8859 21.6789 27.9981 21.5596L30.9689 18.4088C29.9899 15.9666 28.0339 14.0106 25.5917 13.0315L22.4409 16.0023C22.3216 16.1145 22.164 16.1769 22.0003 16.1769C21.8365 16.1769 21.679 16.1145 21.5597 16.0023L18.4089 13.0315C15.9665 14.0105 14.0105 15.9666 13.0315 18.4087ZM12.0707 26.6105C13.1614 28.955 15.0453 30.8388 17.3897 31.9295L15.1557 34.0359C15.0819 34.0963 15.0224 34.1724 14.9816 34.2586C14.9408 34.3448 14.9197 34.439 14.9198 34.5344V35.6467C12.118 34.1892 9.81118 31.8823 8.35359 29.0805H9.46597V29.079C9.55371 29.0791 9.64054 29.0612 9.72109 29.0264C9.80164 28.9916 9.87418 28.9406 9.93424 28.8767L12.0707 26.6105ZM9.18985 16.2088L14.6502 22.0001L9.18985 27.7915H2.84577L7.89073 22.4407C8.00292 22.3215 8.06539 22.1639 8.06539 22.0001C8.06539 21.8364 8.00292 21.6788 7.89073 21.5595L2.84577 16.2088H9.18985ZM29.0805 8.3535C31.8824 9.81118 34.1892 12.1178 35.6467 14.9197H34.5344V14.9213C34.4466 14.9212 34.3598 14.9391 34.2792 14.9738C34.1987 15.0086 34.1261 15.0596 34.0661 15.1236L31.9295 17.3897C30.8388 15.0452 28.955 13.1613 26.6105 12.0706L28.8445 9.96423C28.9183 9.90383 28.9778 9.82778 29.0186 9.74157C29.0594 9.65537 29.0805 9.56117 29.0804 9.46579L29.0805 8.3535ZM27.7915 9.18985L22.0001 14.6503L16.2088 9.18993V2.84577L21.5595 7.89073C21.6788 8.00292 21.8364 8.06539 22.0001 8.06539C22.1639 8.06539 22.3215 8.00292 22.4407 7.89073L27.7915 2.84577V9.18985ZM35.6467 29.0805C34.1892 31.8824 31.8823 34.1892 29.0805 35.6467V34.5344H29.079C29.0791 34.4466 29.0612 34.3598 29.0264 34.2792C28.9916 34.1987 28.9406 34.1261 28.8767 34.0661L26.6106 31.9295C28.955 30.8388 30.8389 28.955 31.9296 26.6105L34.036 28.8445C34.0964 28.9183 34.1725 28.9778 34.2587 29.0186C34.3449 29.0594 34.4391 29.0805 34.5345 29.0804L35.6467 29.0805ZM34.8104 27.7915L29.35 22.0001L34.8104 16.2088H41.1546L36.1096 21.5595C35.9974 21.6788 35.9349 21.8364 35.9349 22.0001C35.9349 22.1639 35.9974 22.3215 36.1096 22.4407L41.1546 27.7915H34.8104ZM16.2088 34.8104L22.0001 29.35L27.7915 34.8104V41.1546L22.4407 36.1096C22.3215 35.9974 22.1639 35.9349 22.0001 35.9349C21.8364 35.9349 21.6788 35.9974 21.5595 36.1096L16.2088 41.1546V34.8104Z">
                                            </path>
                                        </svg>
                                    </div>
                                </div>
                                <h5 class="rs-feature-title">Celebrate Creativity</h5>
                                <span class="rs-feature-line"></span>
                                <p class="rs-feature-desc"> problem solving, and meaningful expression. By encouraging
                                    fresh
                                    ideas, embracing.</p>
                            </div>
                            <div class="rs-feature-item wow fadeIn" data-wow-delay=".4s" data-wow-duration="1s">
                                <div class="rs-feature-top">
                                    <div class="rs-feature-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 38">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M10.6632 36.5455C10.0707 36.5455 9.58805 36.0624 9.58805 35.4685C9.58805 34.8755 10.0707 34.3924 10.6632 34.3924C11.2557 34.3924 11.7432 34.8756 11.7432 35.4685C11.7432 36.0625 11.2557 36.5455 10.6632 36.5455ZM10.6632 1.4543C11.2557 1.4543 11.7432 1.93645 11.7432 2.53036C11.7432 3.12339 11.2557 3.60651 10.6632 3.60651C10.0707 3.60651 9.58805 3.12339 9.58805 2.53036C9.58805 1.93645 10.0707 1.4543 10.6632 1.4543ZM10.6632 33.2604C10.0468 33.2604 9.49257 33.5146 9.09112 33.9231L2.05728 29.9241V8.0748L9.09112 4.0767C9.49249 4.48475 10.0468 4.73855 10.6632 4.73855C11.8818 4.73855 12.8709 3.74749 12.8709 2.53045C12.8709 1.31244 11.8818 0.322354 10.6632 0.322354C9.19927 0.322354 8.1614 1.71962 8.5273 3.09242L1.21151 7.25297C1.12464 7.30253 1.05239 7.37414 1.00205 7.46056C0.951715 7.54697 0.925068 7.64514 0.924805 7.74515V30.2539C0.924897 30.3539 0.951472 30.4522 1.00183 30.5386C1.05219 30.6251 1.12453 30.6966 1.21151 30.7461L8.5273 34.9066C8.1614 36.2794 9.19953 37.6777 10.6632 37.6777C11.8818 37.6777 12.8709 36.6866 12.8709 35.4686C12.8709 34.2515 11.8817 33.2604 10.6632 33.2604ZM25.4668 36.5455C24.8743 36.5455 24.3916 36.0624 24.3916 35.4685C24.3916 34.8755 24.8742 34.3924 25.4668 34.3924C26.0594 34.3924 26.542 34.8756 26.542 35.4685C26.542 36.0625 26.0593 36.5455 25.4668 36.5455ZM25.4668 3.60651C24.8743 3.60651 24.3916 3.12339 24.3916 2.53036C24.3916 1.93645 24.8742 1.4543 25.4668 1.4543C26.0594 1.4543 26.542 1.93645 26.542 2.53036C26.542 3.12339 26.0593 3.60651 25.4668 3.60651ZM34.9185 7.25288L27.6027 3.09233C27.9687 1.72006 26.931 0.322266 25.4668 0.322266C24.2483 0.322266 23.2591 1.31235 23.2591 2.53036C23.2591 3.7474 24.2482 4.73846 25.4668 4.73846C26.0832 4.73846 26.6423 4.48475 27.0436 4.07661L34.0775 8.07471V29.9241L27.0436 33.9231C26.6423 33.5145 26.0832 33.2604 25.4668 33.2604C24.2483 33.2604 23.2591 34.2515 23.2591 35.4685C23.2591 36.6865 24.2482 37.6776 25.4668 37.6776C26.9307 37.6776 27.9687 36.2789 27.6027 34.9065L34.9185 30.746C35.0067 30.6976 35.0804 30.6264 35.1316 30.5398C35.1829 30.4532 35.21 30.3544 35.21 30.2538V7.74507C35.21 7.54196 35.1 7.35417 34.9185 7.25288ZM18.065 30.2194L6.79273 24.6507L11.2366 22.4564L17.8165 25.7062C17.9719 25.7849 18.1605 25.7837 18.3183 25.7062L24.8934 22.4564L29.3373 24.6507L18.065 30.2194ZM6.79273 18.9997L11.2366 16.8054L17.8165 20.0547C17.9737 20.1338 18.1592 20.1324 18.3183 20.0547L24.8934 16.8054L29.3373 18.9997L18.065 24.5675L6.79273 18.9997ZM6.79273 13.3482L18.065 7.78035L29.3373 13.3482L18.065 18.9161L6.79273 13.3482ZM31.1818 24.6507C31.1818 24.8666 31.0575 25.0626 30.8664 25.1586L18.3183 31.3581C18.1596 31.4346 17.9733 31.4361 17.8165 31.3571L5.26356 25.1586C4.8452 24.9502 4.84415 24.3516 5.26356 24.1436L9.95598 21.8252L5.26356 19.5071C4.84494 19.2991 4.84406 18.7007 5.26356 18.4917L9.95598 16.1737L5.26356 13.8553C4.84468 13.6476 4.84468 13.0489 5.26356 12.8413L17.8165 6.64181C17.8945 6.60317 17.9803 6.58307 18.0674 6.58307C18.1544 6.58307 18.2403 6.60317 18.3183 6.64181L30.8664 12.8413C31.2852 13.049 31.2852 13.6476 30.8664 13.8553L26.1739 16.1737L30.8664 18.4917C31.2859 18.7007 31.285 19.2991 30.8664 19.5071L26.1739 21.8252L30.8664 24.1436C31.0575 24.2387 31.1818 24.4356 31.1818 24.6507Z">
                                            </path>
                                        </svg>
                                    </div>
                                </div>
                                <h5 class="rs-feature-title">Trust & Reliability</h5>
                                <span class="rs-feature-line"></span>
                                <p class="rs-feature-desc"> Confidence and security With trust and reliability at the
                                    core of
                                    our values</p>
                            </div>
                            <div class="rs-feature-item wow fadeIn" data-wow-delay=".5s" data-wow-duration="1s">
                                <div class="rs-feature-top">
                                    <div class="rs-feature-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M27.9059 19.3622L30.0736 23.1145H25.7383L27.9059 19.3622ZM24.7116 24.3005H31.1001C31.5435 24.3005 31.8415 23.8062 31.6084 23.4134L28.4192 17.8821C28.1977 17.4949 27.6195 17.4859 27.3927 17.8821L24.1984 23.4134C23.9679 23.8107 24.2684 24.3005 24.7116 24.3005ZM26.396 10.243C26.5938 10.0439 26.8291 9.88597 27.0882 9.77817C27.3473 9.67037 27.6252 9.61487 27.9059 9.61487C28.1865 9.61487 28.4644 9.67037 28.7235 9.77817C28.9827 9.88597 29.2179 10.0439 29.4158 10.243C30.248 11.0752 30.248 12.4257 29.4158 13.2578C28.5836 14.09 27.2282 14.09 26.396 13.2578C25.5638 12.4256 25.5638 11.0751 26.396 10.243ZM27.9059 15.0666C28.753 15.0666 29.6052 14.7427 30.2529 14.0949C31.5435 12.8043 31.5435 10.6965 30.2529 9.40577C28.9573 8.11015 26.8544 8.11015 25.5588 9.40577C24.2682 10.6964 24.2682 12.8043 25.5588 14.0949C26.2066 14.7428 27.0538 15.0666 27.9059 15.0666ZM20.755 13.8458H16.5692V9.65499H20.755V13.8458ZM21.348 8.47394H15.9762C15.8982 8.47371 15.821 8.48889 15.749 8.5186C15.6769 8.54832 15.6115 8.59199 15.5564 8.64709C15.5013 8.7022 15.4576 8.76766 15.4279 8.8397C15.3982 8.91175 15.383 8.98895 15.3832 9.06689V14.4337C15.383 14.5117 15.3982 14.5889 15.4279 14.6609C15.4576 14.733 15.5013 14.7984 15.5564 14.8535C15.6115 14.9086 15.6769 14.9523 15.749 14.982C15.821 15.0117 15.8982 15.0269 15.9762 15.0267H21.348C21.672 15.0267 21.941 14.7626 21.941 14.4337V9.06689C21.941 8.73803 21.6719 8.47394 21.348 8.47394ZM0.926918 9.95393C0.926918 10.2779 1.19101 10.5419 1.51995 10.5419C1.84388 10.5419 2.10797 10.2779 2.10797 9.95393V1.91108H29.1218C29.2000 1.91131 29.2769 1.89613 29.349 1.86642C29.421 1.8367 29.4865 1.79304 29.5416 1.73793C29.5967 1.68283 29.6404 1.61737 29.6701 1.54532C29.6998 1.47328 29.715 1.39607 29.7148 1.31813C29.715 1.24019 29.6999 1.16296 29.6702 1.0909C29.6404 1.01884 29.5968 0.953368 29.5416 0.898252C29.4865 0.843135 29.4211 0.799462 29.349 0.769745C29.2769 0.740029 29.2000 0.724857 29.1218 0.725101H1.51995C1.442 0.724857 1.36478 0.740029 1.29272 0.769745C1.22066 0.799462 1.15519 0.843135 1.10007 0.898252C1.04495 0.953368 1.00128 1.01884 0.971563 1.0909C0.941847 1.16296 0.926674 1.24019 0.926918 1.31813V9.95393ZM39.5166 6.02226C39.5166 5.69332 39.2475 5.42923 38.9236 5.42923C38.8457 5.42898 38.7685 5.44416 38.6964 5.47387C38.6244 5.50359 38.5589 5.54726 38.5038 5.60238C38.4487 5.6575 38.405 5.72297 38.3753 5.79503C38.3455 5.86709 38.3304 5.94431 38.3306 6.02226V33.031H25.8927C25.5688 33.031 25.3047 33.3002 25.3047 33.6241C25.3047 33.9529 25.5688 34.2171 25.8927 34.2171H38.9236C39.2476 34.2171 39.5166 33.953 39.5166 33.6241V6.02226ZM20.7351 25.5014C21.8065 25.5014 22.6736 26.4283 22.6736 27.5645V29.1491H32.5303C33.7512 29.1491 34.7478 28.1525 34.7478 26.9316V7.74143C34.7478 6.52052 33.7512 5.52392 32.5303 5.52392H7.48987C6.26896 5.52392 5.27236 6.52052 5.27236 7.74143V12.5901H10.9083C11.9548 12.5901 12.8069 13.4422 12.8069 14.4887V15.4554C13.8035 15.5402 14.5859 16.4321 14.5859 17.5135V23.0697C15.6844 22.5789 16.8969 23.2318 17.2071 24.4052C18.2857 23.8553 19.579 24.4826 19.903 25.7008C20.1607 25.5695 20.4459 25.5011 20.7351 25.5014ZM21.4476 30.7786C21.2034 36.29 19.6636 38.1387 15.3382 38.0889C10.8832 38.0441 10.5993 35.6124 10.1707 31.9347C10.1258 31.5511 10.081 31.1524 10.0312 30.7537C10.0312 30.7437 10.0262 30.7387 10.0262 30.7288C9.72718 28.9698 8.86514 27.7438 7.39509 26.9814C5.52861 26.0116 5.70708 24.7888 6.93661 24.7888C7.25051 24.7888 7.61932 24.8735 8.01796 25.0678L10.9979 26.7222C11.3983 26.9416 11.8799 26.6444 11.8799 26.204L11.8899 17.5134C11.8899 17.035 12.2387 16.6314 12.6473 16.6314C13.0609 16.6314 13.4047 17.035 13.4047 17.5134V24.9732C13.4047 25.2971 13.6688 25.5612 13.9976 25.5612C14.3216 25.5612 14.5857 25.2971 14.5857 24.9732C14.5857 24.4948 14.9345 24.0911 15.3431 24.0911C15.7567 24.0911 16.1005 24.4948 16.1005 24.9732V26.2688C16.1003 26.3467 16.1154 26.4239 16.1452 26.496C16.1749 26.568 16.2186 26.6335 16.2737 26.6886C16.3288 26.7437 16.3943 26.7874 16.4663 26.8171C16.5384 26.8468 16.6156 26.862 16.6935 26.8617C17.0175 26.8617 17.2815 26.5976 17.2815 26.2688C17.2815 25.7904 17.6304 25.3868 18.039 25.3868C18.4526 25.3868 18.7964 25.7904 18.7964 26.2688V27.5644C18.7961 27.6423 18.8113 27.7195 18.841 27.7916C18.8708 27.8636 18.9144 27.9291 18.9695 27.9842C19.0246 28.0393 19.0901 28.083 19.1621 28.1127C19.2342 28.1424 19.3114 28.1576 19.3893 28.1573C19.7132 28.1573 19.9773 27.8933 19.9773 27.5644C19.9773 27.086 20.3262 26.6824 20.7348 26.6824C21.1433 26.6824 21.4922 27.086 21.4922 27.5644C21.4925 28.5383 21.5079 29.423 21.4476 30.7786ZM2.382 33.9629C1.98837 33.9629 1.66445 33.639 1.66445 33.2403V14.4887C1.66445 14.0949 1.98837 13.7711 2.382 13.7711H10.9082C11.3019 13.7711 11.6258 14.095 11.6258 14.4887V15.7594C11.0776 16.1281 10.7089 16.7759 10.7089 17.5135L10.694 25.2025L8.58107 24.0264C8.57113 24.0214 8.56611 24.0214 8.55617 24.0165C6.88179 23.1893 5.48153 23.7324 5.00818 24.6644C4.5248 25.6162 4.90848 27.0213 6.84694 28.028C7.98311 28.6209 8.62094 29.5379 8.86012 30.9183C8.90993 31.307 8.95481 31.6956 8.9996 32.0694C9.06938 32.7122 9.14409 33.35 9.2438 33.963L2.382 33.9629ZM32.5302 30.3351C34.4039 30.3351 35.9287 28.8053 35.9287 26.9316V7.74143C35.9287 5.86773 34.4039 4.34287 32.5302 4.34287H7.48978C5.61609 4.34287 4.09122 5.86773 4.09122 7.74143V12.5901H2.382C1.3355 12.5901 0.483398 13.4422 0.483398 14.4887V33.2403C0.483398 34.2917 1.3355 35.1439 2.382 35.1439H9.488C10.1145 37.567 11.5138 39.275 15.4728 39.275C21.3509 39.275 22.4911 35.5511 22.6486 30.3352L32.5302 30.3351Z">
                                            </path>
                                        </svg>
                                    </div>
                                </div>
                                <h5 class="rs-feature-title">Leadership</h5>
                                <span class="rs-feature-line"></span>
                                <p class="rs-feature-desc"> Fostering collaboration, driving innovation, and leading by
                                    example,
                                    effective.</p>
                            </div>
                            <div class="rs-feature-item wow fadeIn" data-wow-delay=".6s" data-wow-duration="1s">
                                <div class="rs-feature-top">
                                    <div class="rs-feature-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40">
                                            <path
                                                d="M32.1852 24.9574C28.1952 24.9574 24.9607 28.1919 24.9607 32.1819C24.9607 36.1719 28.1952 39.4063 32.1852 39.4063C36.1752 39.4063 39.4096 36.1719 39.4096 32.1819C39.4048 28.1938 36.1733 24.9623 32.1852 24.9574ZM32.1852 38.0928C28.9206 38.0928 26.2743 35.4465 26.2743 32.1819C26.2743 28.9173 28.9206 26.271 32.1852 26.271C35.4498 26.271 38.0961 28.9173 38.0961 32.1819C38.0926 35.4449 35.4482 38.0893 32.1852 38.0928ZM13.7957 24.9574H7.88475V18.0049L9.82238 19.9422C10.0798 20.1914 10.4897 20.1876 10.743 19.9342C10.8648 19.8125 10.9339 19.6478 10.9354 19.4757C10.9369 19.3035 10.8707 19.1376 10.7511 19.0138L7.69232 15.955C7.56912 15.832 7.40211 15.7629 7.22798 15.7629C7.05386 15.7629 6.88685 15.832 6.76365 15.955L3.70524 19.0137C3.58564 19.1376 3.51945 19.3034 3.52094 19.4755C3.52243 19.6477 3.59147 19.8123 3.71321 19.934C3.83494 20.0559 3.99968 20.125 4.17191 20.1265C4.34414 20.128 4.51007 20.0618 4.63391 19.9421L6.57122 18.0049V24.9573H0.660299C0.486113 24.9573 0.319061 25.0265 0.195893 25.1497C0.0727252 25.2729 0.00353013 25.4399 0.00353013 25.6141V38.7495C0.00353013 38.9237 0.0727252 39.0907 0.195893 39.2139C0.319061 39.3371 0.486113 39.4062 0.660299 39.4062H13.7957C13.9699 39.4062 14.1369 39.3371 14.2601 39.2139C14.3832 39.0907 14.4524 38.9237 14.4524 38.7495V25.6141C14.4524 25.4399 14.3832 25.2729 14.2601 25.1497C14.1369 25.0265 13.9699 24.9574 13.7957 24.9574ZM13.1389 38.0928H1.31707V26.271H13.1389V38.0928ZM19.7396 3.7016C19.6585 3.61782 19.5567 3.55711 19.4444 3.5257C19.3321 3.49428 19.2135 3.49329 19.1008 3.52283C18.988 3.55237 18.8851 3.61137 18.8027 3.69378C18.7202 3.77619 18.6612 3.87905 18.6316 3.99181C18.6021 4.10457 18.6032 4.22317 18.6347 4.33539C18.6662 4.44762 18.727 4.54943 18.8109 4.63035L20.7481 6.5679H14.4191C14.0679 2.72194 10.7539 -0.168084 6.89582 0.00760134C3.03772 0.183287 0 3.36262 0 7.22467C0 11.0867 3.03756 14.266 6.89574 14.4417C10.7539 14.6174 14.0679 11.7275 14.419 7.88144H20.7481L18.8109 9.81907C18.727 9.89998 18.6662 10.0018 18.6347 10.114C18.6032 10.2262 18.6021 10.3448 18.6316 10.4575C18.6612 10.5703 18.7203 10.6732 18.8027 10.7556C18.8852 10.8381 18.988 10.8971 19.1008 10.9267C19.2136 10.9562 19.3322 10.9551 19.4445 10.9236C19.5567 10.8921 19.6586 10.8313 19.7396 10.7474L22.7981 7.689C22.8591 7.62804 22.9075 7.55565 22.9405 7.47598C22.9735 7.3963 22.9905 7.31091 22.9905 7.22467C22.9905 7.13843 22.9735 7.05303 22.9405 6.97336C22.9075 6.89369 22.8591 6.8213 22.7981 6.76033L19.7396 3.7016ZM7.22798 13.1356C3.96335 13.1356 1.31707 10.4893 1.31707 7.22467C1.31707 3.96012 3.96335 1.31375 7.22798 1.31375C10.4926 1.31375 13.1389 3.96012 13.1389 7.22467C13.1354 10.4877 10.491 13.1321 7.22798 13.1356ZM39.7591 6.71641L32.6002 0.87117C32.4829 0.775205 32.3361 0.722773 32.1846 0.722773C32.0331 0.722773 31.8862 0.775205 31.769 0.87117L24.6102 6.71641C24.5348 6.77797 24.4741 6.8555 24.4324 6.94341C24.3907 7.03131 24.3691 7.12738 24.3691 7.22467C24.3691 7.32197 24.3907 7.41806 24.4324 7.50597C24.4741 7.59389 24.5348 7.67144 24.6102 7.73301L31.5284 13.3812V21.4017L29.5911 19.464C29.4674 19.3439 29.3013 19.2772 29.1287 19.2785C28.9562 19.2797 28.7911 19.3488 28.6691 19.4708C28.5472 19.5928 28.4781 19.7579 28.4768 19.9304C28.4756 20.103 28.5422 20.269 28.6624 20.3928L31.7209 23.4515C31.8441 23.5745 32.0111 23.6436 32.1852 23.6436C32.3593 23.6436 32.5263 23.5745 32.6495 23.4515L35.7083 20.3928C35.8285 20.269 35.8951 20.103 35.8939 19.9304C35.8926 19.7579 35.8236 19.5928 35.7016 19.4708C35.5796 19.3488 35.4145 19.2797 35.242 19.2785C35.0695 19.2772 34.9034 19.3439 34.7796 19.464L32.842 21.4017V13.3812L39.7592 7.73301C39.8345 7.67137 39.8951 7.5938 39.9367 7.5059C39.9784 7.41799 40 7.32194 40 7.22467C40 7.12741 39.9784 7.03137 39.9367 6.94348C39.8951 6.85559 39.8344 6.77804 39.7591 6.71641ZM32.1852 12.2213L26.0655 7.22467L32.1852 2.22805L38.3049 7.22467L32.1852 12.2213Z">
                                            </path>
                                        </svg>
                                    </div>
                                </div>
                                <h5 class="rs-feature-title">Respect & Inclusion</h5>
                                <span class="rs-feature-line"></span>
                                <p class="rs-feature-desc"> Innovation, and build communities where people can
                                    contribute their
                                    best.</p>
                            </div>
                            <div class="rs-feature-item wow fadeIn" data-wow-delay=".7s" data-wow-duration="1s">
                                <div class="rs-feature-top">
                                    <div class="rs-feature-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 42">
                                            <path
                                                d="M32.8483 25.1542V15.1923C34.4425 14.944 35.6671 13.5612 35.6671 11.8984C35.6671 10.0602 34.1718 8.56484 32.3327 8.56484C31.286 8.56484 30.3518 9.04953 29.74 9.80664L21.1101 4.82313C21.2545 4.45016 21.3344 4.04625 21.3344 3.62344C21.3344 1.78437 19.8382 0.289062 18 0.289062C16.1618 0.289062 14.6657 1.78438 14.6657 3.62258C14.6657 4.04539 14.7456 4.45016 14.89 4.82227L6.26012 9.80492C5.64824 9.04867 4.71324 8.56312 3.66738 8.56312C1.82918 8.56312 0.333008 10.0584 0.333008 11.8966C0.333008 13.5595 1.55676 14.9423 3.15176 15.1906V25.1525C1.55762 25.4009 0.333008 26.7836 0.333008 28.4465C0.333008 30.2847 1.82832 31.7809 3.66738 31.7809C4.7141 31.7809 5.64824 31.2962 6.26012 30.5391L12.2182 33.9783V36.1319H12.0953C11.1843 36.1319 10.4436 36.8727 10.4436 37.7836V38.4041H9.3573C9.07285 38.4041 8.84168 38.6352 8.84168 38.9197V41.1953C8.84168 41.4798 9.07285 41.7109 9.3573 41.7109H26.4382C26.7227 41.7109 26.9539 41.4798 26.9539 41.1953V38.9223C26.9539 38.6378 26.7227 38.4066 26.4382 38.4066H25.352V37.7862C25.352 36.8812 24.6207 36.1448 23.7183 36.1353V34.0178L29.7408 30.5408C30.3527 31.297 31.2877 31.7826 32.3336 31.7826C34.1718 31.7826 35.6679 30.2873 35.6679 28.4482C35.6671 26.7853 34.4425 25.4026 32.8483 25.1542ZM32.3327 9.59523C33.602 9.59523 34.6358 10.6282 34.6358 11.8975C34.6358 13.1677 33.6029 14.2006 32.3327 14.2006C31.0625 14.2006 30.0296 13.1677 30.0296 11.8975C30.0296 10.6282 31.0634 9.59523 32.3327 9.59523ZM18 1.32031C19.2693 1.32031 20.3032 2.35328 20.3032 3.62258C20.3032 4.89273 19.2702 5.9257 18 5.9257C16.7299 5.9257 15.6969 4.89273 15.6969 3.62258C15.6969 2.35328 16.7307 1.32031 18 1.32031ZM1.36426 11.8984C1.36426 10.6291 2.39723 9.59609 3.66738 9.59609C4.93668 9.59609 5.97051 10.6291 5.97051 11.8984C5.97051 13.1685 4.93754 14.2015 3.66738 14.2015C2.39723 14.2006 1.36426 13.1677 1.36426 11.8984ZM3.66738 30.7505C2.39723 30.7505 1.36426 29.7175 1.36426 28.4473C1.36426 27.1772 2.39723 26.1442 3.66738 26.1442C4.93668 26.1442 5.97051 27.1772 5.97051 28.4473C5.97051 29.7175 4.93668 30.7505 3.66738 30.7505ZM12.2577 30.9868L11.0013 29.7304C10.5759 29.305 10.3516 28.8023 10.3155 28.1955L10.0568 23.8007C10.0646 18.8361 14.1698 14.4842 18.8491 14.4842C20.8179 14.4842 22.7223 15.1425 24.2657 16.3465L22.7438 18.1795L21.5596 17.1715C21.343 16.9867 21.0173 17.0134 20.8325 17.2299C20.6478 17.4465 20.6744 17.7722 20.891 17.957L25.2609 21.6763C25.8229 22.1541 26.1134 22.8253 26.1263 23.6709C26.1375 24.4427 25.8736 25.1138 25.3417 25.6647C25.3047 25.7034 25.2704 25.7171 25.2171 25.7137C25.1638 25.7102 25.1311 25.6939 25.0985 25.6509L24.087 24.3352C23.8472 24.0233 23.4983 23.848 23.1047 23.8394L18.2733 23.744C17.8479 23.7354 17.5016 23.3822 17.5016 22.9568V22.4463C17.5016 22.1619 17.2704 21.9307 16.986 21.9307C16.7015 21.9307 16.4704 22.1619 16.4704 22.4463V22.9568C16.4704 23.9399 17.2704 24.7555 18.2527 24.7752L19.705 24.8036V27.8183C18.6377 27.2743 17.4062 26.9538 16.0003 26.8515C15.7158 26.8309 15.4692 27.0448 15.4486 27.3284C15.4279 27.612 15.6419 27.8595 15.9255 27.8802C18.9978 28.1027 21.1282 29.4949 22.4387 32.1349C22.6089 32.477 22.6845 32.7992 22.6845 33.1816V36.1327H13.2494V33.3793C13.2494 32.4503 12.916 31.6451 12.2577 30.9868ZM25.9226 40.6797H9.87207V39.4379H25.9218L25.9226 40.6797ZM24.3199 37.7862V38.4066H11.4748V37.7862C11.4748 37.4441 11.7532 37.1657 12.0953 37.1657H23.6994C24.0414 37.1648 24.3199 37.4433 24.3199 37.7862ZM23.7003 32.8362C23.6616 32.4314 23.5525 32.0567 23.3643 31.6769C22.6854 30.3096 21.8139 29.2388 20.738 28.4534V24.8242L23.085 24.8706C23.1657 24.8723 23.2207 24.8998 23.2697 24.9634L24.2812 26.2791C24.4961 26.5584 24.808 26.7226 25.1595 26.7423C25.1827 26.7441 25.2059 26.7441 25.2291 26.7441C25.5548 26.7441 25.8556 26.616 26.0842 26.3788C26.8112 25.6243 27.1721 24.7082 27.1575 23.6546C27.1412 22.5151 26.7167 21.5595 25.9295 20.89L23.5293 18.8464L25.3889 16.606C25.5677 16.3912 25.5419 16.0732 25.3322 15.8893C23.5384 14.3172 21.2343 13.4507 18.8491 13.4513C16.2443 13.4513 13.7719 14.5727 11.8856 16.6095C10.068 18.5731 9.02473 21.1994 9.02473 23.8145C9.02473 23.8248 9.02473 23.8351 9.02559 23.8445L9.28512 28.2548C9.33582 29.1134 9.66754 29.855 10.2708 30.4583L11.5272 31.7147C11.8314 32.0189 12.0325 32.3584 12.1357 32.7408L6.77574 29.6462C6.92012 29.2732 7.00004 28.8693 7.00004 28.4465C7.00004 26.7836 5.77629 25.4009 4.18129 25.1525V15.1923C5.77543 14.944 7.00004 13.5612 7.00004 11.8984C7.00004 11.4755 6.92012 11.0708 6.77574 10.6987L15.4056 5.71602C16.0175 6.47227 16.9525 6.95781 17.9983 6.95781C19.0442 6.95781 19.9792 6.47312 20.5911 5.71602L29.2209 10.6987C29.0725 11.0812 28.9965 11.488 28.9966 11.8984C28.9966 13.5612 30.2204 14.944 31.8154 15.1923V25.1542C30.2212 25.4026 28.9966 26.7853 28.9966 28.4482C28.9966 28.871 29.0765 29.2758 29.2209 29.6479L23.7003 32.8362ZM32.3327 30.7505C31.0625 30.7505 30.0296 29.7175 30.0296 28.4473C30.0296 27.1772 31.0625 26.1442 32.3327 26.1442C33.602 26.1442 34.6358 27.1772 34.6358 28.4473C34.6358 29.7175 33.6029 30.7505 32.3327 30.7505ZM12.8653 22.7884C12.8546 22.9171 12.7959 23.0372 12.7009 23.1247C12.6059 23.2122 12.4814 23.2609 12.3522 23.261C12.3376 23.261 12.3239 23.2602 12.3093 23.2593C12.2418 23.2538 12.1761 23.235 12.1159 23.2041C12.0557 23.1731 12.0022 23.1306 11.9585 23.079C11.9147 23.0273 11.8816 22.9676 11.861 22.9031C11.8404 22.8386 11.8327 22.7707 11.8383 22.7033C12.1142 19.3706 14.7258 16.6773 18.0482 16.2992C18.3309 16.2674 18.587 16.4702 18.6188 16.753C18.6506 17.0357 18.4478 17.2909 18.165 17.3236C15.3291 17.6467 13.1007 19.9447 12.8653 22.7884Z">
                                            </path>
                                        </svg>
                                    </div>
                                </div>
                                <h5 class="rs-feature-title">Accountability</h5>
                                <span class="rs-feature-line"></span>
                                <p class="rs-feature-desc"> Accountability is the cornerstone of trust and performance.
                                    It means
                                    taking.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- feature area end -->

        <!-- Section 3: Our Guiding Principles & Chart -->
        <section class="rs-feature-area section-space rs-feature-twelve">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-feature-wrapper">
                            <div class="rs-feature-left">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle">OUR VISION & PURPOSE</span>
                                    <h2 class="section-title rs-split-text-enable split-in-left mb-20">Our guiding
                                        principles</h2>
                                    <p class="rs-section-desc">Our vision is to empower businesses to realize their full
                                        potential through strategic clarity, innovation, and measurable impact.</p>
                                </div>
                                <div class="rs-feature-thumb rs-image scroll_reveal reveal-active" data-dir="left">
                                    <img src="assets/images/work/working-thumb-03.webp" alt="chart">
                                </div>
                            </div>
                            <div class="rs-feature-right">
                                <div class="rs-feature-list-wrapper">
                                    <div class="rs-feature-list-item wow fadeInUp" data-wow-delay=".3s"
                                        data-wow-duration="1s">
                                        <div class="rs-feature-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M24.2669 20.7386C24.2669 20.5444 24.344 20.3581 24.4814 20.2207C24.6188 20.0833 24.805 20.0062 24.9993 20.0062C25.1935 20.0062 25.3798 20.0833 25.5172 20.2207C25.6546 20.3581 25.7317 20.5444 25.7317 20.7386V24.2676H29.2607C29.455 24.2676 29.6413 24.3448 29.7786 24.4821C29.916 24.6195 29.9931 24.8058 29.9931 25C29.9931 25.1943 29.916 25.3806 29.7786 25.5179C29.6413 25.6553 29.455 25.7325 29.2607 25.7325H25.7317V29.2615C25.7317 29.4557 25.6546 29.642 25.5172 29.7794C25.3798 29.9167 25.1935 29.9939 24.9993 29.9939C24.805 29.9939 24.6188 29.9167 24.4814 29.7794C24.344 29.642 24.2669 29.4557 24.2669 29.2615V25.7325H20.7379C20.5436 25.7325 20.3573 25.6553 20.22 25.5179C20.0826 25.3806 20.0054 25.1943 20.0054 25C20.0054 24.8058 20.0826 24.6195 20.22 24.4821C20.3573 24.3448 20.5436 24.2676 20.7379 24.2676H24.2669V20.7386ZM1.5618 16.9541C1.15213 16.9541 0.829373 17.2764 0.829373 17.7116H0.831131C0.830893 17.8977 0.901896 18.0768 1.02957 18.2122L7.42957 25L1.06463 31.7507C0.569217 32.2414 0.908377 33.0458 1.5618 33.0458H7.86248C9.74206 37.0421 12.9572 40.2573 16.9535 42.1368V48.4375C16.9535 48.8472 17.2758 49.1699 17.7109 49.1699V49.1682C17.897 49.1684 18.0762 49.0974 18.2116 48.9698L24.9993 42.5698L31.75 48.9347C32.2407 49.4301 33.0451 49.0909 33.0451 48.4375V42.1369C37.0414 40.2574 40.2565 37.0422 42.1361 33.0459H48.4368C48.8465 33.0459 49.1692 32.7237 49.1692 32.2885H49.1675C49.1677 32.1024 49.0967 31.9232 48.969 31.7878L42.569 25L48.934 18.2493C49.4294 17.7586 49.0902 16.9542 48.4368 16.9542H42.1362C40.2566 12.9579 37.0415 9.74279 33.0452 7.86321V1.56253C33.0452 1.15286 32.7229 0.830106 32.2878 0.830106V0.831863C32.1016 0.831612 31.9225 0.902656 31.7871 1.0304L24.9993 7.4303L18.2486 1.06536C17.7579 0.569949 16.9535 0.90911 16.9535 1.56253V7.86321C12.9572 9.74279 9.74206 12.9579 7.86248 16.9542L1.5618 16.9541ZM9.49178 16.9541C11.1481 13.7702 13.7696 11.1488 16.9535 9.49251V10.7566H16.9553C16.9551 10.8563 16.9754 10.955 17.015 11.0465C17.0545 11.138 17.1124 11.2205 17.1851 11.2887L19.7601 13.7166C17.096 14.9561 14.9552 17.0968 13.7158 19.761L11.3221 17.2223C11.2535 17.1384 11.1671 17.0708 11.0691 17.0245C10.9712 16.9781 10.8641 16.9541 10.7557 16.9542L9.49178 16.9541ZM14.8077 20.9189L18.1836 24.4993C18.3111 24.6349 18.382 24.814 18.382 25C18.382 25.1861 18.3111 25.3652 18.1836 25.5007L14.8078 29.0812C15.9204 31.8565 18.143 34.0791 20.9182 35.1917L24.4987 31.8158C24.6342 31.6884 24.8133 31.6174 24.9994 31.6174C25.1855 31.6174 25.3645 31.6884 25.5001 31.8158L29.0805 35.1917C31.8557 34.0792 34.0785 31.8565 35.1911 29.0813L31.8152 25.5008C31.6877 25.3653 31.6167 25.1862 31.6167 25.0001C31.6167 24.814 31.6877 24.635 31.8152 24.4994L35.1911 20.919C34.0786 18.1438 31.8558 15.921 29.0806 14.8084L25.5002 18.1843C25.3646 18.3118 25.1856 18.3828 24.9995 18.3828C24.8134 18.3828 24.6343 18.3118 24.4988 18.1843L20.9183 14.8084C18.1429 15.9209 15.9202 18.1438 14.8077 20.9189ZM13.7159 30.2391C14.9553 32.9033 17.096 35.044 19.7602 36.2834L17.2216 38.6771C17.1377 38.7457 17.0701 38.8321 17.0238 38.9301C16.9774 39.0281 16.9534 39.1351 16.9535 39.2435V40.5075C13.7696 38.8512 11.1482 36.2298 9.49187 33.0459H10.7559V33.0442C10.8556 33.0443 10.9543 33.024 11.0458 32.9844C11.1374 32.9449 11.2198 32.887 11.2881 32.8143L13.7159 30.2391ZM10.4422 18.419L16.6471 25L10.4422 31.5811H3.23299L8.9659 25.5007C9.09339 25.3652 9.16437 25.1861 9.16437 25C9.16437 24.814 9.09339 24.6349 8.9659 24.4993L3.23299 18.419H10.4422ZM33.0452 9.49251C36.2292 11.149 38.8505 13.7701 40.5068 16.9541H39.2428V16.9559C39.143 16.9558 39.0444 16.9761 38.9528 17.0156C38.8613 17.0552 38.7789 17.1131 38.7106 17.1858L36.2827 19.7609C35.0433 17.0967 32.9025 14.956 30.2384 13.7165L32.777 11.3229C32.8609 11.2542 32.9285 11.1678 32.9748 11.0699C33.0212 10.9719 33.0452 10.8649 33.0451 10.7565L33.0452 9.49251ZM31.5804 10.4429L24.9993 16.648L18.4182 10.443V3.23372L24.4986 8.96663C24.6341 9.09412 24.8132 9.1651 24.9993 9.1651C25.1854 9.1651 25.3644 9.09412 25.5 8.96663L31.5804 3.23372V10.4429ZM40.5068 33.0459C38.8505 36.2299 36.2291 38.8512 33.0452 40.5075V39.2435H33.0434C33.0436 39.1438 33.0232 39.0451 32.9837 38.9536C32.9442 38.862 32.8862 38.7796 32.8136 38.7114L30.2385 36.2834C32.9026 35.044 35.0433 32.9033 36.2828 30.2391L38.6764 32.7778C38.7451 32.8616 38.8315 32.9292 38.9295 32.9756C39.0274 33.0219 39.1345 33.0459 39.2429 33.0458L40.5068 33.0459ZM39.5564 31.5811L33.3514 25L39.5564 18.419H46.7657L41.0328 24.4993C40.9053 24.6349 40.8343 24.814 40.8343 25C40.8343 25.1861 40.9053 25.3652 41.0328 25.5007L46.7657 31.5811H39.5564ZM18.4182 39.5572L24.9993 33.3522L31.5804 39.5572V46.7664L25.5 41.0335C25.3644 40.906 25.1854 40.835 24.9993 40.835C24.8132 40.835 24.6341 40.906 24.4986 41.0335L18.4182 46.7664V39.5572Z">
                                                </path>
                                            </svg>
                                        </div>
                                        <div class="rs-feature-list-content">
                                            <h5 class="rs-feature-list-title">Drive Inspired Impact</h5>
                                            <p class="rs-feature-list-desc"> Our marketing strategy focuses on building
                                                brand
                                                awareness </p>
                                        </div>
                                    </div>
                                    <div class="rs-feature-list-item wow fadeInUp" data-wow-delay=".5s"
                                        data-wow-duration="1s">
                                        <div class="rs-feature-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40">
                                                <path
                                                    d="M32.1852 24.9574C28.1952 24.9574 24.9607 28.1919 24.9607 32.1819C24.9607 36.1719 28.1952 39.4063 32.1852 39.4063C36.1752 39.4063 39.4096 36.1719 39.4096 32.1819C39.4048 28.1938 36.1733 24.9623 32.1852 24.9574ZM32.1852 38.0928C28.9206 38.0928 26.2743 35.4465 26.2743 32.1819C26.2743 28.9173 28.9206 26.271 32.1852 26.271C35.4498 26.271 38.0961 28.9173 38.0961 32.1819C38.0926 35.4449 35.4482 38.0893 32.1852 38.0928ZM13.7957 24.9574H7.88475V18.0049L9.82238 19.9422C10.0798 20.1914 10.4897 20.1876 10.743 19.9342C10.8648 19.8125 10.9339 19.6478 10.9354 19.4757C10.9369 19.3035 10.8707 19.1376 10.7511 19.0138L7.69232 15.955C7.56912 15.832 7.40211 15.7629 7.22798 15.7629C7.05386 15.7629 6.88685 15.832 6.76365 15.955L3.70524 19.0137C3.58564 19.1376 3.51945 19.3034 3.52094 19.4755C3.52243 19.6477 3.59147 19.8123 3.71321 19.934C3.83494 20.0559 3.99968 20.125 4.17191 20.1265C4.34414 20.128 4.51007 20.0618 4.63391 19.9421L6.57122 18.0049V24.9573H0.660299C0.486113 24.9573 0.319061 25.0265 0.195893 25.1497C0.0727252 25.2729 0.00353013 25.4399 0.00353013 25.6141V38.7495C0.00353013 38.9237 0.0727252 39.0907 0.195893 39.2139C0.319061 39.3371 0.486113 39.4062 0.660299 39.4062H13.7957C13.9699 39.4062 14.1369 39.3371 14.2601 39.2139C14.3832 39.0907 14.4524 38.9237 14.4524 38.7495V25.6141C14.4524 25.4399 14.3832 25.2729 14.2601 25.1497C14.1369 25.0265 13.9699 24.9574 13.7957 24.9574ZM13.1389 38.0928H1.31707V26.271H13.1389V38.0928ZM19.7396 3.7016C19.6585 3.61782 19.5567 3.55711 19.4444 3.5257C19.3321 3.49428 19.2135 3.49329 19.1008 3.52283C18.988 3.55237 18.8851 3.61137 18.8027 3.69378C18.7202 3.77619 18.6612 3.87905 18.6316 3.99181C18.6021 4.10457 18.6032 4.22317 18.6347 4.33539C18.6662 4.44762 18.727 4.54943 18.8109 4.63035L20.7481 6.5679H14.4191C14.0679 2.72194 10.7539 -0.168084 6.89582 0.00760134C3.03772 0.183287 0 3.36262 0 7.22467C0 11.0867 3.03756 14.266 6.89574 14.4417C10.7539 14.6174 14.0679 11.7275 14.419 7.88144H20.7481L18.8109 9.81907C18.727 9.89998 18.6662 10.0018 18.6347 10.114C18.6032 10.2262 18.6021 10.3448 18.6316 10.4575C18.6612 10.5703 18.7203 10.6732 18.8027 10.7556C18.8852 10.8381 18.988 10.8971 19.1008 10.9267C19.2136 10.9562 19.3322 10.9551 19.4445 10.9236C19.5567 10.8921 19.6586 10.8313 19.7396 10.7474L22.7981 7.689C22.8591 7.62804 22.9075 7.55565 22.9405 7.47598C22.9735 7.3963 22.9905 7.31091 22.9905 7.22467C22.9905 7.13843 22.9735 7.05303 22.9405 6.97336C22.9075 6.89369 22.8591 6.8213 22.7981 6.76033L19.7396 3.7016ZM7.22798 13.1356C3.96335 13.1356 1.31707 10.4893 1.31707 7.22467C1.31707 3.96012 3.96335 1.31375 7.22798 1.31375C10.4926 1.31375 13.1389 3.96012 13.1389 7.22467C13.1354 10.4877 10.491 13.1321 7.22798 13.1356ZM39.7591 6.71641L32.6002 0.87117C32.4829 0.775205 32.3361 0.722773 32.1846 0.722773C32.0331 0.722773 31.8862 0.775205 31.769 0.87117L24.6102 6.71641C24.5348 6.77797 24.4741 6.8555 24.4324 6.94341C24.3907 7.03131 24.3691 7.12738 24.3691 7.22467C24.3691 7.32197 24.3907 7.41806 24.4324 7.50597C24.4741 7.59389 24.5348 7.67144 24.6102 7.73301L31.5284 13.3812V21.4017L29.5911 19.464C29.4674 19.3439 29.3013 19.2772 29.1287 19.2785C28.9562 19.2797 28.7911 19.3488 28.6691 19.4708C28.5472 19.5928 28.4781 19.7579 28.4768 19.9304C28.4756 20.103 28.5422 20.269 28.6624 20.3928L31.7209 23.4515C31.8441 23.5745 32.0111 23.6436 32.1852 23.6436C32.3593 23.6436 32.5263 23.5745 32.6495 23.4515L35.7083 20.3928C35.8285 20.269 35.8951 20.103 35.8939 19.9304C35.8926 19.7579 35.8236 19.5928 35.7016 19.4708C35.5796 19.3488 35.4145 19.2797 35.242 19.2785C35.0695 19.2772 34.9034 19.3439 34.7796 19.464L32.842 21.4017V13.3812L39.7592 7.73301C39.8345 7.67137 39.8951 7.5938 39.9367 7.5059C39.9784 7.41799 40 7.32194 40 7.22467C40 7.12741 39.9784 7.03137 39.9367 6.94348C39.8951 6.85559 39.8344 6.77804 39.7591 6.71641ZM32.1852 12.2213L26.0655 7.22467L32.1852 2.22805L38.3049 7.22467L32.1852 12.2213Z">
                                                </path>
                                            </svg>
                                        </div>
                                        <div class="rs-feature-list-content">
                                            <h5 class="rs-feature-list-title"> Focused On The Future</h5>
                                            <p class="rs-feature-list-desc"> Workflow optimization is the process of
                                                analyzing,
                                                redesigning </p>
                                        </div>
                                    </div>
                                    <div class="rs-feature-list-item wow fadeInUp" data-wow-delay=".7s"
                                        data-wow-duration="1s">
                                        <div class="rs-feature-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 38">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M10.5959 36.5456C10.0034 36.5456 9.52067 36.0625 9.52067 35.4686C9.52067 34.8755 10.0034 34.3925 10.5959 34.3925C11.1884 34.3925 11.6758 34.8756 11.6758 35.4686C11.6758 36.0626 11.1884 36.5456 10.5959 36.5456ZM10.5959 1.45436C11.1884 1.45436 11.6758 1.93651 11.6758 2.53042C11.6758 3.12345 11.1884 3.60657 10.5959 3.60657C10.0034 3.60657 9.52067 3.12345 9.52067 2.53042C9.52067 1.93651 10.0034 1.45436 10.5959 1.45436ZM10.5959 33.2605C9.97941 33.2605 9.42519 33.5147 9.02373 33.9232L1.98989 29.9241V8.07486L9.02373 4.07676C9.4251 4.48481 9.97941 4.73861 10.5959 4.73861C11.8144 4.73861 12.8035 3.74755 12.8035 2.53051C12.8035 1.3125 11.8144 0.322415 10.5959 0.322415C9.13189 0.322415 8.09401 1.71968 8.45992 3.09248L1.14413 7.25303C1.05726 7.30259 0.985011 7.3742 0.934672 7.46062C0.884332 7.54704 0.857686 7.64521 0.857422 7.74521V30.2539C0.857515 30.354 0.884089 30.4522 0.934446 30.5387C0.984803 30.6251 1.05715 30.6967 1.14413 30.7461L8.45992 34.9067C8.09401 36.2795 9.13215 37.6777 10.5959 37.6777C11.8144 37.6777 12.8035 36.6867 12.8035 35.4687C12.8035 34.2515 11.8143 33.2605 10.5959 33.2605ZM25.3994 36.5456C24.8069 36.5456 24.3242 36.0625 24.3242 35.4686C24.3242 34.8755 24.8068 34.3925 25.3994 34.3925C25.992 34.3925 26.4746 34.8756 26.4746 35.4686C26.4746 36.0626 25.9919 36.5456 25.3994 36.5456ZM25.3994 3.60657C24.8069 3.60657 24.3242 3.12345 24.3242 2.53042C24.3242 1.93651 24.8068 1.45436 25.3994 1.45436C25.992 1.45436 26.4746 1.93651 26.4746 2.53042C26.4746 3.12345 25.9919 3.60657 25.3994 3.60657ZM34.8511 7.25294L27.5353 3.09239C27.9013 1.72012 26.8636 0.322327 25.3994 0.322327C24.1809 0.322327 23.1917 1.31241 23.1917 2.53042C23.1917 3.74746 24.1809 4.73852 25.3994 4.73852C26.0158 4.73852 26.5749 4.48481 26.9763 4.07667L34.0101 8.07477V29.9241L26.9763 33.9232C26.5749 33.5146 26.0158 33.2605 25.3994 33.2605C24.1809 33.2605 23.1917 34.2515 23.1917 35.4686C23.1917 36.6866 24.1809 37.6776 25.3994 37.6776C26.8634 37.6776 27.9013 36.279 27.5353 34.9066L34.8511 30.746C34.9394 30.6977 35.013 30.6265 35.0643 30.5399C35.1155 30.4533 35.1426 30.3545 35.1426 30.2539V7.74513C35.1426 7.54202 35.0327 7.35423 34.8511 7.25294ZM17.9976 30.2194L6.72535 24.6507L11.1693 22.4564L17.7491 25.7063C17.9045 25.785 18.0931 25.7837 18.2509 25.7063L24.826 22.4564L29.2699 24.6507L17.9976 30.2194ZM6.72535 18.9997L11.1693 16.8054L17.7491 20.0547C17.9063 20.1339 18.0918 20.1324 18.2509 20.0547L24.826 16.8054L29.2699 18.9997L17.9976 24.5676L6.72535 18.9997ZM6.72535 13.3483L17.9976 7.78041L29.2699 13.3483L17.9976 18.9161L6.72535 13.3483ZM31.1144 24.6507C31.1144 24.8667 30.9901 25.0626 30.799 25.1587L18.2509 31.3582C18.0922 31.4346 17.9059 31.4361 17.7491 31.3572L5.19617 25.1587C4.77782 24.9503 4.77677 24.3517 5.19617 24.1437L9.8886 21.8252L5.19617 19.5072C4.77756 19.2992 4.77668 18.7008 5.19617 18.4918L9.8886 16.1738L5.19617 13.8553C4.77729 13.6476 4.77729 13.049 5.19617 12.8414L17.7491 6.64187C17.8271 6.60323 17.913 6.58313 18 6.58313C18.087 6.58313 18.1729 6.60323 18.2509 6.64187L30.799 12.8414C31.2179 13.0491 31.2179 13.6476 30.799 13.8553L26.1066 16.1738L30.799 18.4918C31.2185 18.7008 31.2176 19.2992 30.799 19.5072L26.1066 21.8252L30.799 24.1437C30.9901 24.2388 31.1144 24.4356 31.1144 24.6507Z">
                                                </path>
                                            </svg>
                                        </div>
                                        <div class="rs-feature-list-content">
                                            <h5 class="rs-feature-list-title">Excellence in Everything</h5>
                                            <p class="rs-feature-list-desc"> Growth planning is the strategic process of
                                                setting
                                                clear </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- cta area start -->
        <section class="rs-cta-area rs-cta-three">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-cta-wrapper">
                            <div class="rs-cta-shape">
                                <img src="assets/images/shape/cta-shape-01.webp" alt="image">
                            </div>
                            <div class="rs-cta-shape-two">
                                <img src="assets/images/shape/squre-shape.webp" alt="image">
                            </div>
                            <div class="rs-cta-thumb">
                                <img src="assets/images/cta/cta-thumb-01.webp" alt="image">
                            </div>
                            <div class="rs-cta-content-wrapper">
                                <div class="rs-cta-rotate-btn rs-tween_max_btn-yes gsap-move-no">
                                    <div class="rs-rotate-btn"
                                        data-background="assets/images/shape/half-rotate-shape.webp">
                                        <div class="rs-meta-shape">
                                            <img src="assets/images/logo/favicon-icef.png" alt="image">
                                        </div>
                                        <div class="rs-circle-title rs-text-circle-wrapper">
                                            <div class="rs-text-circle" data-rotate-degree="8.5"> ICEF India!
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle is-white">Best Business Strategy</span>
                                    <h2 class="section-title rs-split-text-enable split-in-left is-white">Navigate the
                                        complex world of business!</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- cta area end -->
        <!-- video area start -->
        <div class="rs-video-area rs-video-three">
            <div class="rs-video-bg-thumb include-bg" data-background="assets/images/bg/testimonial-bg-thumb-02.webp">
            </div>
        </div>
        <!-- video area end -->

        <!-- brand slider area start -->
        <div class="rs-brand-area rs-brand-two rs-swiper">
            <div class="container-fluid g-0">
                <div class="row">
                    <div class="brand-slider">
                        <div class="swiper" data-clone-slides="false" data-loop="true" data-speed="1500"
                            data-autoplay="true" data-dots-dynamic="false" data-center-mode="false" data-effect="false"
                            data-no-gap="true" data-delay="1500" data-item="6" data-item-xl="4" data-item-lg="4"
                            data-item-md="3" data-item-sm="2" data-item-xs="2" data-item-mobile="1">
                            <div class="swiper-wrapper">
                                                                    <div class="swiper-slide">
                                        <div class="rs-brand-item">
                                            <div class="rs-brand-thumb">
                                                <img src="assets/images/brand/brand-thumb-01.webp"
                                                    alt="brand">
                                            </div>
                                        </div>
                                    </div>
                                                                    <div class="swiper-slide">
                                        <div class="rs-brand-item">
                                            <div class="rs-brand-thumb">
                                                <img src="assets/images/brand/brand-thumb-02.webp"
                                                    alt="brand">
                                            </div>
                                        </div>
                                    </div>
                                                                    <div class="swiper-slide">
                                        <div class="rs-brand-item">
                                            <div class="rs-brand-thumb">
                                                <img src="assets/images/brand/brand-thumb-03.webp"
                                                    alt="brand">
                                            </div>
                                        </div>
                                    </div>
                                                                    <div class="swiper-slide">
                                        <div class="rs-brand-item">
                                            <div class="rs-brand-thumb">
                                                <img src="assets/images/brand/brand-thumb-04.webp"
                                                    alt="brand">
                                            </div>
                                        </div>
                                    </div>
                                                                    <div class="swiper-slide">
                                        <div class="rs-brand-item">
                                            <div class="rs-brand-thumb">
                                                <img src="assets/images/brand/brand-thumb-05.webp"
                                                    alt="brand">
                                            </div>
                                        </div>
                                    </div>
                                                                    <div class="swiper-slide">
                                        <div class="rs-brand-item">
                                            <div class="rs-brand-thumb">
                                                <img src="assets/images/brand/brand-thumb-06.webp"
                                                    alt="brand">
                                            </div>
                                        </div>
                                    </div>
                                                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- brand slider area end -->

        <!-- Section 5: Job Listings -->
        <section id="careers" class="rs-career-area rs-career-two section-space">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-8">
                        <div class="section-title-wrapper text-center section-title-space">
                            <span class="section-subtitle">Career Opportunities</span>
                            <h2 class="section-title rs-split-text-enable split-in-left mb-15">Join our career driven
                                culture</h2>
                            <p class="section-desc">Explore open positions and join a team that values growth and
                                innovation.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-career-wrapper">
                            <div class="rs-career-item wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
                                <div class="rs-career-info">
                                    <span class="rs-career-type">Full Time</span>
                                    <h5 class="rs-career-title">HR Automation & Transformation</h5>
                                    <span class="rs-career-company">ICEF India</span>
                                </div>
                                <p class="rs-career-desc">Streamline your HR operations advanced automation and digital
                                    transformation
                                    solutions. Our consulting services help organizations optimize.</p>
                                <div class="rs-career-btn">
                                    <a class="rs-btn has-icon hover-primary has-theme-secondary border-hover-primary"
                                        href="contact.php">Apply Job Now
                                        <span class="icon-box">
                                            <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>

                                            <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="rs-career-item wow fadeInUp" data-wow-delay=".5s" data-wow-duration="1s">
                                <div class="rs-career-info">
                                    <span class="rs-career-type">Remote</span>
                                    <h5 class="rs-career-title">Project Manager Consulting</h5>
                                    <span class="rs-career-company">ICEF India</span>
                                </div>
                                <p class="rs-career-desc">Delivering expert guidance to ensure your projects are
                                    completed on
                                    time, within scope, and on budget. Our consulting services help organizations
                                    optimize.</p>
                                <div class="rs-career-btn">
                                    <a class="rs-btn has-icon hover-primary has-theme-secondary border-hover-primary"
                                        href="contact.php">Apply Job Now
                                        <span class="icon-box">
                                            <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>

                                            <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="rs-career-item wow fadeInUp" data-wow-delay=".7s" data-wow-duration="1s">
                                <div class="rs-career-info">
                                    <span class="rs-career-type">Full Time</span>
                                    <h5 class="rs-career-title">Business - Analyst Manager</h5>
                                    <span class="rs-career-company">ICEF India</span>
                                </div>
                                <p class="rs-career-desc">As a Business Analyst Manager, we specialize in analyzing
                                    business
                                    needs, identifying opportunities, and delivering data-driven solutions that align
                                    with
                                    organizational goals.</p>
                                <div class="rs-career-btn">
                                    <a class="rs-btn has-icon hover-primary has-theme-secondary border-hover-primary"
                                        href="contact.php">Apply Job Now
                                        <span class="icon-box">
                                            <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>

                                            <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="rs-career-item wow fadeInUp" data-wow-delay=".9s" data-wow-duration="1s">
                                <div class="rs-career-info">
                                    <span class="rs-career-type">Remote</span>
                                    <h5 class="rs-career-title">Growth Management - Manager</h5>
                                    <span class="rs-career-company">ICEF India</span>
                                </div>
                                <p class="rs-career-desc">We aim to help businesses achieve sustainable growth through
                                    effective
                                    strategies innovative thinking, and measurable results. Our goals the center around.
                                </p>
                                <div class="rs-career-btn">
                                    <a class="rs-btn has-icon hover-primary has-theme-secondary border-hover-primary"
                                        href="contact.php">Apply Job Now
                                        <span class="icon-box">
                                            <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>

                                            <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- testimonial area start -->
        <section class="rs-testimonial-area section-space-top rs-testimonial-two rs-swiper">
            <div class="rs-testimonial-bg-thumb include-bg"
                data-background="assets/images/bg/testimonial-bg-thumb-02.webp"></div>
            <div class="rs-testimonial-shape">
                <img src="assets/images/shape/testimonial-shape-02.webp" alt="image">
            </div>
            <div class="container">
                <div class="row align-items-center g-5 section-title-space">
                    <div class="col-xl-6 col-lg-6">
                        <div class="section-title-wrapper">
                            <span class="section-subtitle is-white">
                                Our Clients Testimonials
                            </span>
                            <h2 class="section-title rs-split-text-enable split-in-left mb-10 is-white">What our
                                customers say?
                            </h2>
                            <p class="section-desc">Find Answers to our Question about Our Consulting Coverage Options.
                            </p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="rs-testimonial-counter">
                            <div class="rs-counter-item">
                                <div class="rs-counter-number-wrapper">
                                    <span class="rs-counter-number odometer" data-count="98">00</span>
                                    <span class="prefix">%</span>
                                </div>
                                <span class="rs-counter-title">Business Growth Rate</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-testimonial-wrapper">
                            <div class="rs-testimonial-thumb rs-image scroll_reveal reveal-active" data-dir="left">
                                <img src="assets/images/about/8.webp" alt="image">
                            </div>
                            <div class="rs-testimonial-slider-wrapper">
                                <div class="swiper" data-clone-slides="false" data-loop="true" data-speed="1500"
                                    data-autoplay="true" data-dots-dynamic="false" data-effect="false" data-delay="2000"
                                    data-item="1" data-item-xl="1" data-item-lg="1" data-item-md="1" data-item-sm="1"
                                    data-item-xs="1" data-item-mobile="1" data-margin="30">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <div class="rs-testimonial-item">
                                                <div class="rs-testimonial-top">
                                                    <div class="rs-testimonial-title-info">
                                                        <h6 class="rs-testimonial-title">Business Consulting</h6>
                                                        <div class="rs-testimonial-icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="60"
                                                                height="44" viewBox="0 0 60 44" fill="none">
                                                                <path
                                                                    d="M12.7244 28.0195C11.6004 34.2343 9.70513 38.7081 8.20652 41.485C7.61148 42.5648 8.82362 43.777 9.88146 43.1599C22.4434 35.8431 27.953 25.1765 28.6362 16.6036C29.2312 9.22068 24.1844 1.61742 16.5591 0.229C8.9338 -1.15942 1.61704 3.90943 0.228614 11.5347C-1.22592 19.5347 4.41591 27.2261 12.7244 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                                <path
                                                                    d="M44.0406 28.0195C42.9166 34.2343 41.0213 38.7081 39.5227 41.485C38.9277 42.5648 40.1398 43.777 41.1976 43.1599C53.7595 35.8431 59.2692 25.1765 59.9524 16.6036C60.5474 9.22068 55.5006 1.61742 47.8753 0.229C40.25 -1.15942 32.9332 3.90943 31.5448 11.5347C30.0902 19.5347 35.7321 27.2261 44.0406 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="rs-testimonial-rating-icon">
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-line"></i>
                                                    </div>
                                                </div>
                                                <p class="rs-testimonial-desc"> &ldquo;ICEF's assessment solutions have simplified our hiring process immensely. The platform is intuitive, and the results are incredibly accurate, helping us find the best talent across India.&rdquo;
                                                </p>
                                                <div class="rs-testimonial-avater-wrapper">
                                                    <div class="rs-testimonial-avater-thumb">
                                                        <img src="assets/images/user/indian-user-01.png" alt="image">
                                                    </div>
                                                    <div class="rs-testimonial-avater-info">
                                                        <h6 class="rs-testimonial-avater-title">Rajesh Kumar</h6>
                                                        <span class="rs-testimonial-avater-designation">HR Lead</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="rs-testimonial-item">
                                                <div class="rs-testimonial-top">
                                                    <div class="rs-testimonial-title-info">
                                                        <h6 class="rs-testimonial-title">Business Consulting</h6>
                                                        <div class="rs-testimonial-icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="60"
                                                                height="44" viewBox="0 0 60 44" fill="none">
                                                                <path
                                                                    d="M12.7244 28.0195C11.6004 34.2343 9.70513 38.7081 8.20652 41.485C7.61148 42.5648 8.82362 43.777 9.88146 43.1599C22.4434 35.8431 27.953 25.1765 28.6362 16.6036C29.2312 9.22068 24.1844 1.61742 16.5591 0.229C8.9338 -1.15942 1.61704 3.90943 0.228614 11.5347C-1.22592 19.5347 4.41591 27.2261 12.7244 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                                <path
                                                                    d="M44.0406 28.0195C42.9166 34.2343 41.0213 38.7081 39.5227 41.485C38.9277 42.5648 40.1398 43.777 41.1976 43.1599C53.7595 35.8431 59.2692 25.1765 59.9524 16.6036C60.5474 9.22068 55.5006 1.61742 47.8753 0.229C40.25 -1.15942 32.9332 3.90943 31.5448 11.5347C30.0902 19.5347 35.7321 27.2261 44.0406 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="rs-testimonial-rating-icon">
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-line"></i>
                                                    </div>
                                                </div>
                                                <p class="rs-testimonial-desc"> &ldquo;Working with ICEF has been a seamless experience. Their dedication to quality and prompt support during high-volume assessment cycles is truly commendable. They are a reliable partner for our large-scale projects.&rdquo;
                                                </p>
                                                <div class="rs-testimonial-avater-wrapper">
                                                    <div class="rs-testimonial-avater-thumb">
                                                        <img src="assets/images/user/indian-user-02.png" alt="image">
                                                    </div>
                                                    <div class="rs-testimonial-avater-info">
                                                        <h6 class="rs-testimonial-avater-title">Ananya Iyer</h6>
                                                        <span class="rs-testimonial-avater-designation">Project Coordinator</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="rs-testimonial-item">
                                                <div class="rs-testimonial-top">
                                                    <div class="rs-testimonial-title-info">
                                                        <h6 class="rs-testimonial-title">Business Consulting</h6>
                                                        <div class="rs-testimonial-icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="60"
                                                                height="44" viewBox="0 0 60 44" fill="none">
                                                                <path
                                                                    d="M12.7244 28.0195C11.6004 34.2343 9.70513 38.7081 8.20652 41.485C7.61148 42.5648 8.82362 43.777 9.88146 43.1599C22.4434 35.8431 27.953 25.1765 28.6362 16.6036C29.2312 9.22068 24.1844 1.61742 16.5591 0.229C8.9338 -1.15942 1.61704 3.90943 0.228614 11.5347C-1.22592 19.5347 4.41591 27.2261 12.7244 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                                <path
                                                                    d="M44.0406 28.0195C42.9166 34.2343 41.0213 38.7081 39.5227 41.485C38.9277 42.5648 40.1398 43.777 41.1976 43.1599C53.7595 35.8431 59.2692 25.1765 59.9524 16.6036C60.5474 9.22068 55.5006 1.61742 47.8753 0.229C40.25 -1.15942 32.9332 3.90943 31.5448 11.5347C30.0902 19.5347 35.7321 27.2261 44.0406 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="rs-testimonial-rating-icon">
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-line"></i>
                                                    </div>
                                                </div>
                                                <p class="rs-testimonial-desc"> &ldquo;The technology integration provided by ICEF is top-notch. Their robust systems handled our peak traffic without any glitches, making the entire examination process smooth for both the administrators and the candidates.&rdquo;
                                                </p>
                                                <div class="rs-testimonial-avater-wrapper">
                                                    <div class="rs-testimonial-avater-thumb">
                                                        <img src="assets/images/user/indian-user-03.png" alt="image">
                                                    </div>
                                                    <div class="rs-testimonial-avater-info">
                                                        <h6 class="rs-testimonial-avater-title">Sandeep Singh</h6>
                                                        <span class="rs-testimonial-avater-designation">Software Architect</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- if we need navigation -->
                                    <div class="rs-testimonial-navigation rs-swiper-btn-wrapper">
                                        <div class="rs-swiper-btn swiper-button-prev has-transparent has-border"><i
                                                class="ri-arrow-left-line"></i>
                                        </div>
                                        <div class="rs-swiper-btn swiper-button-next has-transparent has-border"><i
                                                class="ri-arrow-right-line"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- testimonial area end -->

        <!-- faq area start -->
        <section class="rs-faq-area section-space rs-faq-one theme-secondary">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-faq-wrapper">
                            <div class="rs-faq-left">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle is-white">
                                        Frequently asked questions
                                    </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left is-white mb-20">
                                        Frequently Asked
                                        Question</h2>
                                    <p class="rs-section-desc">Find answers to our question about our consulting
                                        coverage
                                        options.</p>
                                </div>
                                <div class="rs-faq-contact">
                                    <div class="rs-faq-contact-info">
                                        <h5 class="rs-faq-contact-title">Still Have Questions?</h5>
                                        <p class="rs-faq-contact-desc">We're here to help you!</p>
                                    </div>
                                    <div class="rs-faq-contact-btn">
                                        <a class="rs-btn has-icon has-bg-white has-bg-secondary"
                                            href="contact.php">Contact Us
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white" />
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white" />
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-faq-right">
                                <div class="rs-faq-content rs-accordion-one">
                                    <div class="accordion-wrapper">
                                        <div class="accordion" id="accordionExampleOne">
                                            <div class="rs-accordion-item has-bg-active active">
                                                <h4 class="accordion-header" id="headingOne">
                                                    <button class="accordion-button" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseOne"
                                                        aria-expanded="true" aria-controls="collapseOne">
                                                        How do your startups with product
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h4>
                                                <div id="collapseOne" class="accordion-collapse collapse show"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Launching a startup begins with more
                                                        than just an
                                                        idea it starts with creating a product that solves a real
                                                        problem.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingTwo">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                                        aria-expanded="false" aria-controls="collapseTwo">
                                                        Can your with fundraising investor
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseTwo" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Securing the right investment is
                                                        essential for
                                                        fueling growth and scaling a business. Our fundraising approach
                                                        is designed
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingThree">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                                        aria-expanded="false" aria-controls="collapseThree">
                                                        What makes startup consulting
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseThree" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Startup consulting helps entrepreneurs
                                                        turn ideas
                                                        into thriving businesses. By combining market insights,
                                                        strategy, and
                                                        execution</div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingFour">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseFour"
                                                        aria-expanded="false" aria-controls="collapseFour">
                                                        Do you provide financial planning
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseFour" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Financial planning is the foundation of
                                                        long-term
                                                        stability and growth. It helps businesses and individuals make
                                                        informed</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- faq area end -->


    </main>


    <!-- footer area start -->
<footer class="rs-footer-area rs-footer-one theme-secondary">
    <div class="rs-footer-shape-one">
        <img src="assets/images/shape/footer-shape-01.webp" alt="image">
    </div>
    <div class="rs-footer-shape-two">
        <img src="assets/images/shape/footer-shape-02.webp" alt="image">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="rs-footer-wrapper">
                    <div class="rs-footer-left">
                        <div class="rs-footer-widget footer-1-col-1">
                            <div class="rs-footer-widget-logo">
                                <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA"></a>
                            </div>
                            <div class="rs-footer-widget-content">
                                <p class="rs-footer-widget-desc">
                                    ICEF INDIA is a premier organization providing end-to-end solutions in Assessment, Recruitment, and Workforce Development since 2000.
                                </p>
                                <div class="rs-footer-widget-contact-info">
                                    <div class="rs-footer-content-item">
                                        <span>Call us:</span>
                                        <a href="tel:+911204221735">+91 120 422 1735</a>
                                    </div>
                                    <div class="rs-footer-content-item">
                                        <span>Email:</span>
                                        <a href="mailto:sales@icefindia.in">sales@icefindia.in</a>
                                    </div>
                                    <div class="rs-footer-content-item">
                                        <span>Hours: Mon-Fri: 8.00am - 18.00pm</span>
                                    </div>
                                </div>
                                <div class="rs-footer-widget-social">
                                    <div class="rs-footer-social theme-social has-border">
                                        <a href="#"><svg width="14" height="22" viewBox="0 0 14 22" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M11.624 11.9541L12.193 8.54137L8.63572 8.54137V6.32676C8.63572 5.39311 9.13264 4.48303 10.7258 4.48303H12.343V1.57748C12.343 1.57748 10.8755 1.34692 9.47233 1.34692C6.54282 1.34692 4.62796 2.98146 4.62796 5.94041L4.62796 8.54137H1.37158L1.37158 11.9541H4.62796L4.62796 20.2041H8.63572L8.63572 11.9541H11.624Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M17.6045 5.45036C17.5641 4.53485 17.4161 3.9055 17.204 3.3601C16.9852 2.78121 16.6486 2.26294 16.2077 1.83208C15.7768 1.39452 15.2551 1.0545 14.6829 0.839154C14.1344 0.627106 13.5083 0.479009 12.5928 0.438686C11.6705 0.394863 11.3777 0.384766 9.03843 0.384766C6.69917 0.384766 6.40637 0.394863 5.48747 0.435253C4.57199 0.475643 3.94261 0.623808 3.39738 0.835721C2.81832 1.0545 2.30005 1.39108 1.86919 1.83208C1.43163 2.26291 1.09178 2.78461 0.876264 3.3568C0.664216 3.9055 0.516152 4.53148 0.475796 5.44692C0.432006 6.36927 0.421875 6.66206 0.421875 9.00132C0.421875 11.3406 0.432006 11.6334 0.472363 12.5523C0.512753 13.4678 0.660917 14.0971 0.872999 14.6425C1.09178 15.2214 1.43163 15.7397 1.86919 16.1706C2.30005 16.6081 2.82175 16.9481 3.39395 17.1635C3.94258 17.3755 4.56856 17.5236 5.4842 17.564C6.40294 17.6045 6.6959 17.6144 9.03516 17.6144C11.3744 17.6144 11.6672 17.6045 12.5861 17.564C13.5016 17.5236 14.131 17.3756 14.6762 17.1635C15.2489 16.9421 15.7689 16.6035 16.2031 16.1693C16.6372 15.7352 16.9759 15.2152 17.1973 14.6425C17.4092 14.0939 17.5574 13.4678 17.5978 12.5523C17.6382 11.6334 17.6483 11.3406 17.6483 9.00132C17.6483 6.66206 17.6449 6.36923 17.6045 5.45036ZM16.0529 12.485C16.0159 13.3264 15.8745 13.7808 15.7567 14.0837C15.4672 14.8343 14.8715 15.4301 14.1208 15.7196C13.8179 15.8374 13.3603 15.9787 12.5221 16.0157C11.6133 16.0562 11.3408 16.0662 9.04186 16.0662C6.74296 16.0662 6.46699 16.0562 5.56148 16.0157C4.72002 15.9787 4.26563 15.8374 3.96271 15.7196C3.5892 15.5815 3.24922 15.3628 2.97322 15.0767C2.68712 14.7973 2.46834 14.4607 2.33027 14.0872C2.21247 13.7842 2.07114 13.3264 2.03421 12.4884C1.99369 11.5796 1.98373 11.3069 1.98373 9.00802C1.98373 6.70911 1.99369 6.43315 2.03421 5.5278C2.07114 4.68634 2.21247 4.23196 2.33027 3.92903C2.46834 3.55535 2.68712 3.21544 2.97665 2.93937C3.25588 2.65328 3.59246 2.4345 3.96614 2.2966C4.26907 2.17879 4.72689 2.03743 5.56491 2.00037C6.47369 1.95998 6.74639 1.94988 9.04513 1.94988C11.3475 1.94988 11.62 1.95998 12.5255 2.00037C13.367 2.03746 13.8214 2.17876 14.1243 2.29656C14.4978 2.4345 14.8378 2.65328 15.1138 2.93937C15.3999 3.21877 15.6186 3.55535 15.7567 3.92903C15.8745 4.23196 16.0159 4.68961 16.0529 5.5278C16.0933 6.43658 16.1034 6.70911 16.1034 9.00802C16.1034 11.3069 16.0933 11.5762 16.0529 12.485Z"
                                                    fill="white"></path>
                                                <path
                                                    d="M9.0335 4.57741C6.58997 4.57741 4.60742 6.55982 4.60742 9.00349C4.60742 11.4472 6.58997 13.4296 9.0335 13.4296C11.4771 13.4296 13.4596 11.4472 13.4596 9.00349C13.4596 6.55982 11.4771 4.57741 9.0335 4.57741ZM9.0335 11.8746C7.44826 11.8746 6.16237 10.5889 6.16237 9.00349C6.16237 7.41811 7.44826 6.13243 9.03347 6.13243C10.6188 6.13243 11.9046 7.41811 11.9046 9.00349C11.9046 10.5889 10.6188 11.8746 9.0335 11.8746ZM14.668 4.40239C14.668 4.97303 14.2053 5.4357 13.6345 5.4357C13.0639 5.4357 12.6013 4.97303 12.6013 4.40239C12.6013 3.83167 13.0639 3.36914 13.6346 3.36914C14.2053 3.36914 14.668 3.83164 14.668 4.40239Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M9.35332 6.88729L14.6472 0.733521H13.3928L8.79603 6.07675L5.12465 0.733521H0.890137L6.44199 8.81343L0.890137 15.2666H2.1447L6.99896 9.62397L10.8762 15.2666H15.1107L9.35332 6.88729ZM7.63502 8.88462L7.0725 8.08004L2.59674 1.67793H4.52367L8.13567 6.84464L8.69818 7.64922L13.3933 14.3651H11.4664L7.63502 8.88462Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M17.7973 17.7992V11.3532C17.7973 8.18522 17.1153 5.76522 13.4193 5.76522C11.6373 5.76522 10.4493 6.73322 9.96527 7.65722H9.92126V6.05122H6.42326V17.7992H10.0753V11.9692C10.0753 10.4292 10.3613 8.95522 12.2533 8.95522C14.1233 8.95522 14.1453 10.6932 14.1453 12.0572V17.7772H17.7973V17.7992ZM0.483266 6.05122H4.13527V17.7992H0.483266V6.05122ZM2.30927 0.199219C1.14327 0.199219 0.197266 1.14522 0.197266 2.31122C0.197266 3.47722 1.14327 4.44522 2.30927 4.44522C3.47527 4.44522 4.42127 3.47722 4.42127 2.31122C4.42127 1.14522 3.47527 0.199219 2.30927 0.199219Z"
                                                    fill="white"></path>
                                            </svg></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rs-footer-right">
                        <div class="rs-footer-widget-wrapper">
                            <div class="rs-footer-widget footer-1-col-2">
                                <h5 class="rs-footer-widget-title">About​</h5>
                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="industry-clients.php">Industry we work with</a></li>
                                        <li><a href="why-choose-us.php">Why choose us</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                        <li><a href="contact.php">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rs-footer-widget footer-1-col-3">
                                <h5 class="rs-footer-widget-title">Services</h5>
                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="it-emerging-tech-enablement.php">IT & Emerging Tech Enablement</a></li>
                                        <li><a href="assessment-and-testing.php">Assessment & Testing</a></li>
                                        <li><a href="recruitment-and-hiring.php">Recruitment & Hiring</a></li>
                                        <li><a href="exam-management.php">Exam Management</a></li>
                                        <li><a href="manpower-and-workforce.php">Manpower & Workforce</a></li>
                                        <li><a href="call-center-and-bpos.php">Call Center & BPOs</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rs-footer-widget footer-1-col-4">
                                <h5 class="rs-footer-widget-title">Quick Links</h5>

                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="#solutions">Our Solutions</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                        <li><a href="industry-clients.php#clients">Clientele</a></li>
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="rs-footer-subscribe-from">
                            <h5 class="rs-footer-subscribe-title">Subscribe Newsletter</h5>
                            <div class="rs-cta-input">
                                <input id="email2" name="name" type="text" placeholder="Enter your email">
                                <button type="submit" class="rs-btn has-icon has-bg-secondary has-sm-radius">
                                    Send Now
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white"></path>
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white"></path>
                                        </svg>
                                    </span>
                                </button>
                            </div>
                        </div>
                        <div class="rs-footer-brand">
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-07.webp" alt="image">
                            </div>
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-08.webp" alt="image">
                            </div>
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-09.webp" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="rs-footer-copyright-area rs-copyright-one">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="rs-footer-copyright-wrapper">
                        <div class="rs-footer-copyright-left">
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright-link">
                                    <a href="terms-conditions.php">Terms & Agreements</a>
                                </div>
                            </div>
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright-link">
                                    <a href="privacy-policy.php">Privacy policy</a>
                                </div>
                            </div>
                        </div>
                        <div class="rs-footer-copyright-right">
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright">
                                    <p class="underline">Copyright © <span id="year">2025</span> ICEF INDIA. All rights reserved. Designed by <a
                                            target="_blank" href="https://agumentiksoftware.com/">AGUMENTIK.</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer area end -->

        <!-- back to top -->
    <!-- Backtotop start -->
    <div class="backtotop-wrap cursor-pointer">
        <i class="ri-arrow-up-s-line"></i>
    </div>
    <!-- Backtotop end -->

    <!-- JS here -->
    <script src="assets/js/vendor/jquery-3.7.1.min.js"></script>
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/meanmenu@2.0.8/jquery.meanmenu.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/wowjs@1.1.3/dist/wow.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/magnific-popup@1.1.0/dist/jquery.magnific-popup.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/isotope-layout@3.0.6/dist/isotope.pkgd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/imagesloaded@5.0.0/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/vendor/ajax-form.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@studio-freight/lenis@1.0.34/dist/lenis.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
    <script src="assets/js/plugins/rs-scroll-trigger.min.js"></script>
    <script src="assets/js/plugins/rs-splitText.min.js"></script>
    <!-- Custom theme scripts (Restored) -->
    <script src="assets/js/plugins/rs-anim-int.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery.appear@1.0.1/jquery.appear.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-nice-select@1.1.0/js/jquery.nice-select.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/nouislider@15.7.1/dist/nouislider.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/odometer@0.4.8/odometer.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>

</body>

</html>
