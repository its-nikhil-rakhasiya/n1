<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="template-version" content="1.0.0">
    <title>ICEF INDIA - Integrated Assessment & Recruitment Platform    </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/favicon-icef.png">
    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/animate.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="assets/css/plugins/flatpickr.min.css">
    <link rel="stylesheet" href="assets/css/plugins/nouislider.min.css">
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/vendor/odometer.min.css">
    <link rel="stylesheet" href="assets/css/vendor/spacing.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css">
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        /* =============================================
           Banner Contact Form — Form Overlaps Girl Image
        ============================================= */

        /* Right column: position:relative so the form can be overlaid */
        .rs-banner-form-wrap {
            position: relative;
            display: block;
        }

        /* Girl image: fully visible, natural width, drives wrapper height */
        .rs-banner-bg-img {
            display: block;
            width: 100%;
            height: auto;
            object-fit: cover;
            object-position: top center;
            opacity: 1;
            position: relative;
            z-index: 0;
        }

        /* Form card: positioned absolutely, centred over the girl image */
        .rs-banner-contact-form {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 3;
            background: #ffffff;
            border-radius: 8px;
            padding: 28px 24px;
            width: calc(100% - 60px);
            max-width: 400px;
            box-shadow: 0 8px 40px rgba(0, 0, 0, 0.28);
        }

        .rs-form-title {
            font-size: 20px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 4px;
            line-height: 1.3;
        }

        .rs-form-subtitle {
            font-size: 12px;
            color: #888;
            margin-bottom: 14px;
        }

        .rs-contact-form-banner .rs-form-row {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }

        .rs-contact-form-banner .rs-form-group {
            flex: 1 1 0%;
            min-width: 0;
            display: flex;
            flex-direction: column;
        }

        .rs-contact-form-banner .rs-form-group-full {
            flex: 1 1 100%;
        }

        .rs-contact-form-banner input,
        .rs-contact-form-banner select,
        .rs-contact-form-banner .nice-select,
        .rs-contact-form-banner textarea {
            width: 100% !important;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            font-size: 14px;
            color: #444;
            background: #fff !important;
            background-image: none !important;
            outline: none;
            transition: border-color 0.3s;
            font-family: inherit;
            appearance: none !important;
            -webkit-appearance: none !important;
            -moz-appearance: none !important;
            box-sizing: border-box;
        }

        .rs-contact-form-banner input,
        .rs-contact-form-banner select,
        .rs-contact-form-banner .nice-select {
            height: 45px !important;
            padding: 0 12px;
            line-height: 43px; /* adjusted for border */
        }

        .rs-contact-form-banner .nice-select {
            display: flex;
            align-items: center;
            float: none;
        }

        .rs-contact-form-banner .nice-select .current {
            display: block;
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            padding-right: 20px;
        }

        .rs-contact-form-banner .nice-select:after {
            content: "" !important;
            border-bottom: 2px solid #AB052D;
            border-right: 2px solid #AB052D;
            height: 8px;
            width: 8px;
            right: 15px;
            top: 40%; 
            transform: rotate(45deg);
        }

        .rs-contact-form-banner input::placeholder,
        .rs-contact-form-banner textarea::placeholder {
            color: #aaa;
        }

        .rs-contact-form-banner input:focus,
        .rs-contact-form-banner select:focus,
        .rs-contact-form-banner .nice-select:focus,
        .rs-contact-form-banner textarea:focus {
            border-color: #AB052D;
        }

        .rs-contact-form-banner select {
            cursor: pointer;
            color: #aaa;
        }

        .rs-contact-form-banner select option:not([disabled]) {
            color: #444;
        }

        .rs-contact-form-banner textarea {
            height: 120px !important;
            padding: 12px;
            resize: none;
            line-height: normal;
        }

        /* Button: maroon matching the site header */
        .rs-banner-form-btn {
            width: 100%;
            background: #AB052D;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 12px;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 1.5px;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            text-transform: uppercase;
        }

        .rs-banner-form-btn:hover {
            background: #8c0424;
            transform: translateY(-1px);
        }

        /* Banner left content: nudge right so it's not touching the left edge */
        .rs-banner-area .rs-banner-content {
            padding-left: 60px;
        }

        /* Hero Left Button: make it maroon */
        .rs-banner-area .rs-banner-content .rs-btn {
            background-color: #AB052D;
            border-color: #AB052D;
        }

        .rs-banner-area .rs-banner-content .rs-btn:hover {
            background-color: #8c0424;
            border-color: #8c0424;
        }

        /* ---- Responsive overrides ---- */
        @media (max-width: 1399px) {
            .rs-banner-area .rs-banner-content { padding-left: 40px; }
        }

        @media (max-width: 1199px) {
            .rs-banner-area .rs-banner-content { padding-left: 24px; }
        }

        @media (max-width: 991px) {
            .rs-banner-area .rs-banner-content { padding-left: 16px; }

            .rs-banner-contact-form {
                position: relative;
                top: auto;
                left: auto;
                transform: none;
                width: 100%;
                max-width: 100%;
                margin-top: 20px;
            }

            .rs-contact-form-banner .rs-form-row {
                flex-direction: column;
                gap: 10px;
            }
        }

        /* =============================================
           Glass Effect — Transparent Header over Banner
        ============================================= */
        @media (min-width: 992px) {

            /* Overlay Header Container — only for main header, not sticky */
            .rs-header-area.header-transparent:not(.rs-sticky-header) {
                position: absolute;
                width: 100%;
                top: 40px; /* leave space for the Top Red Bar */
                left: 0;
                z-index: 1000;
                background: transparent;
            }

            /* Top Red Bar */
            .header-transparent-parent .rs-header-top {
                background: #AB052D !important;
                position: relative;
                z-index: 1002;
                height: 40px;
                display: flex !important;
                align-items: center;
            }

            /* Sticky header — glass while not yet active */
            .header-transparent.rs-sticky-header:not(.active) {
                background: rgba(43, 57, 68, 0.4) !important;
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                position: fixed;
                width: 100%;
                top: -100px;
                z-index: 1001;
                visibility: hidden;
                opacity: 0;
                pointer-events: none;
                transition: all 0.4s ease;
            }

            /* Sticky header — fully visible when active */
            .header-transparent.rs-sticky-header.active {
                background: var(--rs-theme-secondary) !important;
                backdrop-filter: none;
                -webkit-backdrop-filter: none;
                top: 0 !important;
                position: fixed;
                width: 100%;
                visibility: visible;
                opacity: 1;
                pointer-events: auto;
            }
        }

        /* Mobile Menu Fix: hide desktop nav on small screens */
        @media (max-width: 1199px) {
            .header-menu,
            .main-menu,
            #mobile-menu,
            #mobile-menu-two {
                display: none !important;
            }
        }
    </style>
</head>
    <!-- preloader start -->
    <div id="pre-load">
        <div id="loader" class="loader">
            <div class="loader-container">
                <div class="loader-icon"><img src="assets/images/logo/favicon-icef.png" alt="ICEF INDIA"></div>
            </div>
        </div>
    </div>
    <!-- preloader end -->

    <!-- preloader start -->

    <div id="rs-mouse">
        <div id="cursor-ball"></div>
    </div>

    <!-- preloader end -->

    <style>
        /* Custom Mega Menu for Solutions with Feature Image */
        .main-menu .mega-grid-two {
            grid-template-columns: repeat(6, 1fr) 300px !important;
            width: 1550px !important;
            padding: 0 !important;
            overflow: hidden;
            border-radius: 10px !important;
            background-color: var(--rs-theme-secondary) !important;
        }

        @media only screen and (max-width: 1600px) {
            .main-menu .mega-grid-two {
                width: 1350px !important;
                grid-template-columns: repeat(6, 1fr) 250px !important;
            }
        }

        @media only screen and (max-width: 1366px) {
            .main-menu .mega-grid-two {
                width: 1180px !important;
                grid-template-columns: repeat(5, 1fr) !important;
            }
            .mega-menu-feature {
                display: none !important; /* Hide feature on smaller screens to keep navigation clear */
            }
        }

        .main-menu .mega-grid-one > li, .main-menu .mega-grid-two > li {
            padding: 30px 20px !important;
            border-right: 1px solid rgba(255, 255, 255, 0.1) !important;
            position: relative;
        }

        .main-menu .mega-grid-one > li::before, .main-menu .mega-grid-two > li::before {
            content: none !important;
        }

        .main-menu .mega-grid-two > li:last-child {
            border-right: none !important;
        }

        .mega-menu-feature {
            background-color: #243039 !important;
            padding: 40px 30px !important;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
        }

        .mega-menu-feature h6.title {
            color: #AB052D !important;
            font-size: 20px !important;
            margin-bottom: 12px !important;
            font-weight: 700 !important;
            text-transform: capitalize !important;
        }

        .mega-menu-feature p {
            font-size: 14px !important;
            line-height: 1.5 !important;
            color: rgba(255, 255, 255, 0.7) !important;
            margin-bottom: 20px !important;
            white-space: normal !important;
        }

        .mega-menu-feature .feature-thumb {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
        }

        .mega-menu-feature .feature-thumb img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            transition: all 0.4s ease;
        }
        
        .mega-menu-feature:hover .feature-thumb img {
            transform: scale(1.05);
        }

        /* FAQ Section Image Resizing */
        .rs-faq-two .rs-faq-wrapper {
            grid-template-columns: 1fr 480px !important;
            gap: 30px 60px !important;
            align-items: flex-start !important;
        }
        .rs-faq-two .rs-faq-thumb {
            width: 100% !important;
            max-width: 480px !important;
        }
        .rs-faq-two .rs-faq-thumb > img {
            height: 500px !important;
            object-fit: cover !important;
            border-radius: 10px !important;
        }
        .rs-faq-two .rs-faq-award {
            width: auto !important;
            max-width: 360px !important;
            padding: 15px 20px !important;
            bottom: 15px !important;
            inset-inline-start: auto !important;
            inset-inline-end: 15px !important;
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 8px !important;
            background: rgba(255, 255, 255, 0.08) !important;
            background-image: none !important;
            backdrop-filter: blur(12px) !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
        }
        .rs-faq-award-thumb {
            display: none !important;
        }
        .rs-faq-two .rs-faq-award-desc {
            font-size: 13px !important;
            line-height: 1.4 !important;
            margin-bottom: 0 !important;
            border-inline-start: none !important;
            padding-inline-start: 0 !important;
            margin-inline-start: 0 !important;
        }
        @media only screen and (max-width: 1366px) {
            .rs-faq-two .rs-faq-wrapper {
                grid-template-columns: 1fr 400px !important;
            }
            .rs-faq-two .rs-faq-thumb > img {
                height: 450px !important;
            }
        }
        @media only screen and (max-width: 991px) {
            .rs-faq-two .rs-faq-wrapper {
                grid-template-columns: 1fr !important;
            }
            .rs-faq-two .rs-faq-thumb {
                max-width: 100% !important;
            }
        }



        /* Submenu adjustments */
        .main-menu .submenu {
            width: max-content !important;
            min-width: 140px !important;
            max-width: 350px !important;
        }

        .main-menu .submenu li {
            padding-inline-start: 20px !important;
            padding-inline-end: 15px !important;
        }

        .main-menu .submenu li a {
            white-space: nowrap !important;
        }

        /* Mega menu column titles and links */
        .main-menu .mega-grid-two > li .title {
            color: #ffffff !important;
            margin-bottom: 15px !important;
            display: block !important;
        }

        .main-menu .mega-grid-two > li ul li a {
            color: rgba(255, 255, 255, 0.7) !important;
            padding: 5px 0 !important;
        }

        .main-menu .mega-grid-two > li ul li a:hover {
            color: var(--rs-theme-primary) !important;
            padding-left: 5px !important;
        }

        /* Feature Button Styling */
        .mega-menu-feature .rs-btn {
            background-color: var(--rs-theme-primary) !important;
            color: #ffffff !important;
            padding: 14px 28px !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            border-radius: 6px !important;
            font-size: 14px !important;
            font-weight: 700 !important;
            width: fit-content !important;
            height: auto !important;
            line-height: 1 !important;
            margin-bottom: 20px !important;
        }

        .mega-menu-feature .rs-btn:hover {
            background-color: #ffffff !important;
            color: var(--rs-theme-primary) !important;
        }

        /* Sticky Header Styles */
        .rs-sticky-header.active {
            background: var(--rs-theme-secondary) !important;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            top: 0 !important;
        }

        .rs-sticky-header .header-logo img {
            max-height: 50px;
            width: auto;
        }

        .rs-sticky-header .header-wrapper {
            background: transparent !important;
            padding-top: 10px;
            padding-bottom: 10px;
        }

        /* Bridge the gap to prevent dropdown closing when moving mouse from link to menu */
        .main-menu li {
            position: relative;
        }

        .main-menu .submenu,
        .main-menu .mega-menu {
            position: absolute;
            background-color: var(--rs-theme-secondary);
            z-index: 99;
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
            /* Professional transition with slight delay for closing to make it more stable and forgiving */
            transition: opacity 0.3s ease, transform 0.3s ease, visibility 0.3s ease !important;
            transition-delay: 0.2s !important;
        }

        .main-menu li:hover > .submenu,
        .main-menu li:hover > .mega-menu {
            opacity: 1;
            visibility: visible;
            pointer-events: all;
            transition-delay: 0s !important;
        }

        /* The Bridge: Invisible pseudo-element to close the physical gap between link and menu */
        .main-menu .submenu::before,
        .main-menu .mega-menu::before {
            content: "";
            position: absolute;
            top: -50px; /* Ample space to bridge any gap */
            left: 0;
            right: 0;
            height: 50px;
            background: transparent;
            z-index: 10;
            pointer-events: auto !important; /* Forces hover capture in the gap */
        }

        /* More persistent hover colors */
        .main-menu ul li:hover > a {
            color: var(--rs-theme-primary) !important;
        }
    </style>

    <!-- header area start-->
    <header>
        <div class="container-fluid g-0">
            <!-- top start -->
            <div class="rs-header-top rs-header-top-one">
                <div class="header-top-left">
                    <span class="header-top-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="6" height="11" viewBox="0 0 6 11" fill="none">
                            <path
                                d="M0.50204 0.439454C0.811629 0.16438 1.28548 0.192407 1.56063 0.501954L5.56063 5.00195C5.81308 5.28608 5.81308 5.71392 5.56063 5.99805L1.56063 10.498C1.28548 10.8076 0.811629 10.8356 0.50204 10.5605C0.192493 10.2854 0.164466 9.81154 0.43954 9.50195L3.99618 5.5L0.43954 1.49805C0.164466 1.18846 0.192493 0.714606 0.50204 0.439454Z"
                                fill="#AB052D"></path>
                        </svg>
                    </span>
                    <div class="header-top-content">
                        <p>India's Leading Integrated Assessment & Recruitment Platform Since 2000.
                            <a href="about-mission.php">Learn More</a>
                        </p>
                    </div>
                </div>
                <div class="header-top-right">
                    <div class="header-top-meta">
                        <span class="header-top-meta-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
                                <path
                                    d="M12.1641 10.5834C11.6414 10.0673 10.9888 10.0673 10.4694 10.5834C10.0732 10.9762 9.67699 11.3691 9.28744 11.7686C9.1809 11.8785 9.091 11.9018 8.96115 11.8286C8.70479 11.6887 8.43177 11.5755 8.18539 11.4224C7.03673 10.6999 6.07452 9.77097 5.22218 8.72552C4.79934 8.20613 4.42312 7.65011 4.16009 7.02417C4.10682 6.89765 4.11681 6.81442 4.22002 6.7112C4.61622 6.32832 5.00244 5.93544 5.39198 5.54257C5.93469 4.99654 5.93469 4.35728 5.38866 3.80792C5.07902 3.49495 4.76938 3.18865 4.45974 2.87568C4.14011 2.55605 3.82381 2.23309 3.50086 1.9168C2.97813 1.40739 2.32556 1.40739 1.80617 1.92012C1.40663 2.313 1.02375 2.71586 0.617555 3.10208C0.241327 3.45833 0.0515486 3.89449 0.0115952 4.40389C-0.0516643 5.23293 0.151432 6.01535 0.437765 6.77779C1.02375 8.35595 1.91604 9.75765 2.99811 11.0428C4.45974 12.7808 6.20437 14.1558 8.24532 15.148C9.16425 15.5942 10.1165 15.9371 11.1519 15.9937C11.8644 16.0337 12.4837 15.8539 12.9798 15.2979C13.3194 14.9183 13.7023 14.572 14.0619 14.2091C14.5946 13.6697 14.5979 13.0172 14.0685 12.4845C13.4359 11.8485 12.8 11.2159 12.1641 10.5834Z"></path>
                                <path
                                    d="M11.5271 7.92979L12.7557 7.72003C12.5625 6.59135 12.0298 5.56921 11.2208 4.75682C10.3651 3.90116 9.28304 3.36178 8.0911 3.19531L7.91797 4.43054C8.84023 4.56039 9.67925 4.97657 10.3418 5.63913C10.9677 6.26506 11.3773 7.05747 11.5271 7.92979Z"></path>
                                <path
                                    d="M13.4493 2.59031C12.0309 1.17197 10.2363 0.276344 8.25531 0L8.08218 1.23523C9.79352 1.47495 11.345 2.25071 12.5703 3.47262C13.7323 4.63459 14.4947 6.10288 14.771 7.71766L15.9996 7.50791C15.6767 5.63676 14.7943 3.93874 13.4493 2.59031Z"></path>
                            </svg>
                        </span>
                        <div class="header-top-meta-content">
                            <span>Call us:</span>
                            <a href="tel:+911204221735">+91 120 422 1735</a>
                        </div>
                    </div>
                    <div class="header-top-meta">
                        <span class="header-top-meta-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"
                                fill="none">
                                <g clip-path="url(#clip0_28535_99)">
                                    <path
                                        d="M15.8603 3.17969L11.0078 8.00091L15.8603 12.8221C15.948 12.6388 16.0012 12.4361 16.0012 12.2197V3.78216C16.0012 3.56569 15.948 3.36303 15.8603 3.17969Z"
                                        fill="white"></path>
                                    <path
                                        d="M14.5947 2.375H1.40716C1.19069 2.375 0.988031 2.42822 0.804688 2.51594L7.00666 8.68666C7.55503 9.23503 8.44678 9.23503 8.99516 8.68666L15.1971 2.51594C15.0138 2.42822 14.8111 2.375 14.5947 2.375Z"
                                        fill="white"></path>
                                    <path
                                        d="M0.140938 3.17969C0.0532188 3.36303 0 3.56569 0 3.78216V12.2197C0 12.4361 0.0532188 12.6388 0.140938 12.8221L4.99341 8.00091L0.140938 3.17969Z"
                                        fill="white"></path>
                                    <path
                                        d="M10.3447 8.66211L9.658 9.34877C8.74428 10.2625 7.2575 10.2625 6.34378 9.34877L5.65716 8.66211L0.804688 13.4833C0.988031 13.571 1.19069 13.6243 1.40716 13.6243H14.5947C14.8111 13.6243 15.0138 13.571 15.1971 13.4833L10.3447 8.66211Z"
                                        fill="white"></path>
                                </g>
                                <defs>
                                    <clipPath id="clip0_28535_99">
                                        <rect width="16" height="16" fill="white"></rect>
                                    </clipPath>
                                </defs>
                            </svg>
                        </span>
                        <div class="header-top-meta-content">
                            <span>Send mail:</span>
                            <a href="mailto:sales@icefindia.in">
                                sales@icefindia.in
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- top end -->
        </div>

        
        <div class="rs-header-area rs-header-one ">
                    <div class="container-fluid g-0">
            <div class="header-wrapper">
                <div class="header-left">
                    <div class="header-logo">
                        <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA - Integrated Assessment & Recruitment Platform"></a>
                    </div>
                </div>
                <div class="header-right">
                    <div class="header-menu">
                        <nav id="mobile-menu-two" class="main-menu">
                            <ul class="multipage-menu">
                                <li><a href="index.php">Home</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">About Company</a>
                                    <ul class="submenu last-children">
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="about-mission.php#mission">Mission & Vision</a></li>
                                        <li><a href="industry-clients.php">Industry We Work With</a></li>
                                        <li><a href="industry-clients.php#clients">Client Tele</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                        <li><a href="careers-culture.php">Work Culture</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children rs-mega-menu">
                                    <a href="javascript:void(0)">Solutions</a>
                                    <ul class="mega-menu mega-grid-two">
                                        <li class="rs-menu-item" data-image="assets/images/solution/it-emerging.webp">
                                            <a href="it-emerging-tech-enablement.php" class="title">IT & Emerging Tech Enablement</a>
                                            <ul>
                                                <li data-image="assets/images/solution/iot.webp"><a href="iot-and-rfid.php">IOT & RFID Based Products</a></li>
                                                <li data-image="assets/images/solution/app-dev.webp"><a href="application-development.php">Application Development</a></li>
                                                <li data-image="assets/images/solution/software-dev.webp"><a href="customized-software-development.php">Customized Software Development</a></li>
                                                <li data-image="assets/images/solution/emerging-tech.webp"><a href="emerging-tech.php">Emerging Tech</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/assessment-testing.webp">
                                            <a href="assessment-and-testing.php" class="title">Assessment & Testing</a>
                                            <ul>
                                                <li data-image="assets/images/solution/cognitive-domain.webp"><a href="cognitive-domain.php">Cognitive/Domain</a></li>
                                                <li data-image="assets/images/solution/online-offline.webp"><a href="online-offline.php">Online/Offline</a></li>
                                                <li data-image="assets/images/solution/proctoring.webp"><a href="proctoring.php">Proctoring</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/recruitment.webp">
                                            <a href="recruitment-and-hiring.php" class="title">Recruitment & Hiring</a>
                                            <ul>
                                                <li data-image="assets/images/about/33.webp"><a href="screening.php">Screening</a></li>
                                                <li data-image="assets/images/about/37.webp"><a href="assessments.php">Assessments</a></li>
                                                <li data-image="assets/images/solution/merit-list.webp"><a href="merit-lists.php">Merit Lists</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/exam-management.webp">
                                            <a href="exam-management.php" class="title">Exam Management</a>
                                            <ul>
                                                <li data-image="assets/images/solution/question-banks.webp"><a href="question-banks.php">Question Banks</a></li>
                                                <li data-image="assets/images/solution/exam-conduct.webp"><a href="exam-conduct.php">Conduct</a></li>
                                                <li data-image="assets/images/solution/processing.webp"><a href="exam-processing.php">Processing</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/manpower-workforce.webp">
                                            <a href="manpower-and-workforce.php" class="title">Manpower & Workforce</a>
                                            <ul>
                                                <li data-image="assets/images/solution/outsourcing.webp"><a href="outsourcing.php">Outsourcing</a></li>
                                                <li data-image="assets/images/about/31.webp"><a href="staffing.php">Staffing</a></li>
                                                <li data-image="assets/images/solution/deployment.webp"><a href="deployment.php">Deployment</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/call-center.webp">
                                            <a href="call-center-and-bpos.php" class="title">Call Center & BPOs</a>
                                            <ul>
                                                <li data-image="assets/images/solution/inbound.webp"><a href="inbound-outbound.php">Inbound/Outbound</a></li>
                                                <li data-image="assets/images/solution/support.webp"><a href="support.php">Support</a></li>
                                                <li data-image="assets/images/solution/telecalling.webp"><a href="tele-calling.php">Tele-Calling</a></li>
                                            </ul>
                                        </li>
                                        <li class="mega-menu-feature">
                                            <div class="mega-feature-content">
                                                <h6 class="title">Let's Talk Business</h6>
                                                <p>Empowering businesses with smart IT solutions since 2000.</p>
                                                <a href="support.php" class="rs-btn has-icon has-md-radius hover-primary">Request Quote</a>
                                                <div class="feature-thumb mt-20">
                                                    <img id="mega-menu-target-img" src="assets/images/mega-menu-feature.png" alt="Consultation">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="why-choose-us.php">Why Choose Us</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">WhiteBoard</a>
                                    <ul class="submenu last-children">
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="faq.php">FAQs</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                    </ul>
                                </li>
                                
                                
                                <li><a href="contact.php">Support</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="header-content">
                        <div class="header-btn">
                            <a class="rs-btn has-icon is-transparent hover-primary border-hover-primary" href="contact.php">Get Free Quote</a>
                        </div>
                        <div class="header-search-wrapper">
                            <div class="header-search-icon"><i class="ri-search-line"></i></div>
                        </div>
                        <div class="header-hamburger">
                            <div class="sidebar-toggle">
                                <a class="header-bar-icon" href="javascript:void(0)"><span></span><span></span><span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                </div>

        <div id="rs-sticky-header" class="rs-sticky-header rs-header-area rs-header-one ">
                    <div class="container-fluid g-0">
            <div class="header-wrapper">
                <div class="header-left">
                    <div class="header-logo">
                        <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA - Integrated Assessment & Recruitment Platform"></a>
                    </div>
                </div>
                <div class="header-right">
                    <div class="header-menu">
                        <nav id="mobile-menu-two" class="main-menu">
                            <ul class="multipage-menu">
                                <li><a href="index.php">Home</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">About Company</a>
                                    <ul class="submenu last-children">
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="about-mission.php#mission">Mission & Vision</a></li>
                                        <li><a href="industry-clients.php">Industry We Work With</a></li>
                                        <li><a href="industry-clients.php#clients">Client Tele</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                        <li><a href="careers-culture.php">Work Culture</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children rs-mega-menu">
                                    <a href="javascript:void(0)">Solutions</a>
                                    <ul class="mega-menu mega-grid-two">
                                        <li class="rs-menu-item" data-image="assets/images/solution/it-emerging.webp">
                                            <a href="it-emerging-tech-enablement.php" class="title">IT & Emerging Tech Enablement</a>
                                            <ul>
                                                <li data-image="assets/images/solution/iot.webp"><a href="iot-and-rfid.php">IOT & RFID Based Products</a></li>
                                                <li data-image="assets/images/solution/app-dev.webp"><a href="application-development.php">Application Development</a></li>
                                                <li data-image="assets/images/solution/software-dev.webp"><a href="customized-software-development.php">Customized Software Development</a></li>
                                                <li data-image="assets/images/solution/emerging-tech.webp"><a href="emerging-tech.php">Emerging Tech</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/assessment-testing.webp">
                                            <a href="assessment-and-testing.php" class="title">Assessment & Testing</a>
                                            <ul>
                                                <li data-image="assets/images/solution/cognitive-domain.webp"><a href="cognitive-domain.php">Cognitive/Domain</a></li>
                                                <li data-image="assets/images/solution/online-offline.webp"><a href="online-offline.php">Online/Offline</a></li>
                                                <li data-image="assets/images/solution/proctoring.webp"><a href="proctoring.php">Proctoring</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/recruitment.webp">
                                            <a href="recruitment-and-hiring.php" class="title">Recruitment & Hiring</a>
                                            <ul>
                                                <li data-image="assets/images/about/33.webp"><a href="screening.php">Screening</a></li>
                                                <li data-image="assets/images/about/37.webp"><a href="assessments.php">Assessments</a></li>
                                                <li data-image="assets/images/solution/merit-list.webp"><a href="merit-lists.php">Merit Lists</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/exam-management.webp">
                                            <a href="exam-management.php" class="title">Exam Management</a>
                                            <ul>
                                                <li data-image="assets/images/solution/question-banks.webp"><a href="question-banks.php">Question Banks</a></li>
                                                <li data-image="assets/images/solution/exam-conduct.webp"><a href="exam-conduct.php">Conduct</a></li>
                                                <li data-image="assets/images/solution/processing.webp"><a href="exam-processing.php">Processing</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/manpower-workforce.webp">
                                            <a href="manpower-and-workforce.php" class="title">Manpower & Workforce</a>
                                            <ul>
                                                <li data-image="assets/images/solution/outsourcing.webp"><a href="outsourcing.php">Outsourcing</a></li>
                                                <li data-image="assets/images/about/31.webp"><a href="staffing.php">Staffing</a></li>
                                                <li data-image="assets/images/solution/deployment.webp"><a href="deployment.php">Deployment</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/call-center.webp">
                                            <a href="call-center-and-bpos.php" class="title">Call Center & BPOs</a>
                                            <ul>
                                                <li data-image="assets/images/solution/inbound.webp"><a href="inbound-outbound.php">Inbound/Outbound</a></li>
                                                <li data-image="assets/images/solution/support.webp"><a href="support.php">Support</a></li>
                                                <li data-image="assets/images/solution/telecalling.webp"><a href="tele-calling.php">Tele-Calling</a></li>
                                            </ul>
                                        </li>
                                        <li class="mega-menu-feature">
                                            <div class="mega-feature-content">
                                                <h6 class="title">Let's Talk Business</h6>
                                                <p>Empowering businesses with smart IT solutions since 2000.</p>
                                                <a href="support.php" class="rs-btn has-icon has-md-radius hover-primary">Request Quote</a>
                                                <div class="feature-thumb mt-20">
                                                    <img id="mega-menu-target-img" src="assets/images/mega-menu-feature.png" alt="Consultation">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="why-choose-us.php">Why Choose Us</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">WhiteBoard</a>
                                    <ul class="submenu last-children">
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="faq.php">FAQs</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                    </ul>
                                </li>
                                
                                
                                <li><a href="contact.php">Support</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="header-content">
                        <div class="header-btn">
                            <a class="rs-btn has-icon is-transparent hover-primary border-hover-primary" href="contact.php">Get Free Quote</a>
                        </div>
                        <div class="header-search-wrapper">
                            <div class="header-search-icon"><i class="ri-search-line"></i></div>
                        </div>
                        <div class="header-hamburger">
                            <div class="sidebar-toggle">
                                <a class="header-bar-icon" href="javascript:void(0)"><span></span><span></span><span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                </div>
    </header>
    <!-- Header area end -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const targetImg = document.getElementById('mega-menu-target-img');
            if (!targetImg) return;

            const globalDefaultImg = targetImg.getAttribute('src');
            let defaultImg = globalDefaultImg;
            const menuItems = document.querySelectorAll('.rs-mega-menu .mega-menu [data-image]');

            // Detect active page and set its image as default
            const currentPath = window.location.pathname;
            document.querySelectorAll('.rs-mega-menu .mega-menu .rs-menu-item').forEach(item => {
                const links = item.querySelectorAll('a');
                links.forEach(link => {
                    const href = link.getAttribute('href');
                    if (href && href !== '#' && currentPath.endsWith(href)) {
                        const activeImg = link.parentElement.getAttribute('data-image') || item.getAttribute('data-image');
                        if (activeImg) {
                            defaultImg = activeImg;
                            targetImg.setAttribute('src', activeImg);
                        }
                    }
                });
            });

            menuItems.forEach(item => {
                item.addEventListener('mouseenter', function(e) {
                    e.stopPropagation();
                    const newImg = this.getAttribute('data-image');
                    if (newImg && targetImg.getAttribute('src') !== newImg) {
                        targetImg.style.opacity = '0';
                        setTimeout(() => {
                            targetImg.setAttribute('src', newImg);
                            targetImg.style.opacity = '1';
                        }, 200);
                    }
                });
            });

            // Revert to default when leaving the entire mega menu grid
            const megaGrid = document.querySelector('.mega-grid-two');
            if (megaGrid) {
                megaGrid.addEventListener('mouseleave', function() {
                    targetImg.style.opacity = '0';
                    setTimeout(() => {
                        targetImg.setAttribute('src', defaultImg);
                        targetImg.style.opacity = '1';
                    }, 200);
                });
            }
        });
    </script>
    <style>
        #mega-menu-target-img {
            transition: opacity 0.3s ease;
        }
    </style>
    <!-- Offcanvas area start -->
    <div class="fix">
        <div class="offcanvas-area" data-lenis-prevent>
            <div class="offcanvas-wrapper">
                <div class="offcanvas-content">
                    <div class="offcanvas-top d-flex justify-content-between align-items-center mb-20">
                        <div class="offcanvas-logo">
                            <a class="logo-black" href="index.php"><img src="assets/images/logo/logo-icef.png" alt="logo"></a>
                            <a class="logo-white" href="index.php"><img src="assets/images/logo/logo-icef.png" alt="logo"></a>
                        </div>
                        <div class="offcanvas-close">
                            <button class="offcanvas-close-icon animation--flip" style="background: var(--rs-theme-primary); color: white; border: none; padding: 10px; border-radius: 4px; display: flex; align-items: center; justify-content: center; width: 40px; height: 40px;">
                                <i class="ri-close-line" style="font-size: 24px;"></i>
                            </button>
                        </div>
                    </div>
                    <div class="offcanvas-about mb-30 d-none d-xl-block">
                        <p>
                            ICEF INDIA is a premier organization providing end-to-end solutions in Assessment, Recruitment, and Workforce Development since 2000.
                        </p>
                    </div>
                    <div class="offcanvas-gallery d-none d-xl-block">
                        <div class="offcanvas-gallery-thumb-wrapper">
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-01.webp">
                                    <img src="assets/images/gallery/gallery-thumb-01.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-02.webp">
                                    <img src="assets/images/gallery/gallery-thumb-02.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-03.webp">
                                    <img src="assets/images/gallery/gallery-thumb-03.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-04.webp">
                                    <img src="assets/images/gallery/gallery-thumb-04.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-05.webp">
                                    <img src="assets/images/gallery/gallery-thumb-05.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-06.webp">
                                    <img src="assets/images/gallery/gallery-thumb-06.webp" alt="image">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="mobile-menu-container">
                        <div class="rs-offcanvas-menu mb-30" id="sidebar-menu-target">
                            <!-- Menu will be injected here via JS -->
                        </div>
                    </div>
                    <div class="offcanvas-contact mb-30">
                        <h4 class="offcanvas-title-meta">Contact Info</h4>
                        <ul>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="18" viewBox="0 0 14 18" fill="none">
                                        <path d="M11.8768 9.68475C11.3059 10.835 10.5331 11.9818 9.74128 13.0109C8.95198 14.0368 8.15999 14.9249 7.5643 15.5572C7.48514 15.6412 7.40956 15.7206 7.33802 15.7951C7.26648 15.7206 7.1909 15.6412 7.11174 15.5572C6.51605 14.9249 5.72406 14.0368 4.93476 13.0109C4.14299 11.9818 3.37019 10.835 2.79925 9.68475C2.22242 8.52266 1.89032 7.43373 1.89032 6.5C1.89032 3.50846 4.32934 1.08333 7.33802 1.08333C10.3467 1.08333 12.7857 3.50846 12.7857 6.5C12.7857 7.43373 12.4536 8.52266 11.8768 9.68475ZM7.33802 17.3333C7.33802 17.3333 13.8753 11.1732 13.8753 6.5C13.8753 2.91015 10.9484 0 7.33802 0C3.7276 0 0.800781 2.91015 0.800781 6.5C0.800781 11.1732 7.33802 17.3333 7.33802 17.3333Z" fill="#6D6D6D"></path>
                                        <path d="M7.33802 8.66667C6.13455 8.66667 5.15894 7.69662 5.15894 6.5C5.15894 5.30338 6.13455 4.33333 7.33802 4.33333C8.54149 4.33333 9.5171 5.30338 9.5171 6.5C9.5171 7.69662 8.54149 8.66667 7.33802 8.66667ZM7.33802 9.75C9.14323 9.75 10.6066 8.29492 10.6066 6.5C10.6066 4.70507 9.14323 3.25 7.33802 3.25C5.53281 3.25 4.0694 4.70507 4.0694 6.5C4.0694 8.29492 5.53281 9.75 7.33802 9.75Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="#"> Noida, Uttar Pradesh, India</a>
                                </div>
                            </li>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M3.65387 1.32849C3.40343 1.00649 2.92745 0.976861 2.639 1.26531L1.60508 2.29923C1.1216 2.78271 0.94387 3.46766 1.1551 4.06847C2.00338 6.48124 3.39215 8.74671 5.32272 10.6773C7.25329 12.6078 9.51876 13.9966 11.9315 14.8449C12.5323 15.0561 13.2173 14.8784 13.7008 14.3949L14.7347 13.361C15.0231 13.0726 14.9935 12.5966 14.6715 12.3461L12.3653 10.5524C12.2008 10.4245 11.9866 10.3793 11.7845 10.4298L9.59541 10.9771C9.00082 11.1257 8.37183 10.9515 7.93845 10.5181L5.48187 8.06155C5.04849 7.62817 4.87427 6.99919 5.02292 6.40459L5.57019 4.21553C5.62073 4.01336 5.57552 3.79918 5.44758 3.63468L3.65387 1.32849ZM1.88477 0.511076C2.62689 -0.231039 3.8515 -0.154797 4.49583 0.673634L6.28954 2.97983C6.6187 3.40304 6.73502 3.95409 6.60498 4.47423L6.05772 6.66329C5.99994 6.8944 6.06766 7.13888 6.2361 7.30732L8.69268 9.7639C8.86113 9.93235 9.1056 10.0001 9.33671 9.94229L11.5258 9.39502C12.0459 9.26499 12.597 9.3813 13.0202 9.71047L15.3264 11.5042C16.1548 12.1485 16.231 13.3731 15.4889 14.1152L14.455 15.1492C13.7153 15.8889 12.6089 16.2137 11.5778 15.8512C9.01754 14.9511 6.61438 13.4774 4.56849 11.4315C2.5226 9.38562 1.04895 6.98246 0.148838 4.42225C-0.213682 3.39112 0.11113 2.28472 0.85085 1.545L1.88477 0.511076Z" fill="#6D6D6D"></path>
                                        <path d="M11 0.5C11 0.223858 11.2239 0 11.5 0H15.5C15.7761 0 16 0.223858 16 0.5V4.5C16 4.77614 15.7761 5 15.5 5C15.2239 5 15 4.77614 15 4.5V1.70711L10.8536 5.85355C10.6583 6.04882 10.3417 6.04882 10.1464 5.85355C9.95118 5.65829 9.95118 5.34171 10.1464 5.14645L14.2929 1H11.5C11.2239 1 11 0.776142 11 0.5Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="tel:+911204221735"> +91 120 422 1735 </a>
                                </div>
                            </li>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M2 2C0.895431 2 0 2.89543 0 4V12L2.58386e-05 12.0103C0.00555998 13.1101 0.898859 14 2 14H7.5C7.77614 14 8 13.7761 8 13.5C8 13.2239 7.77614 13 7.5 13H2C1.53715 13 1.14774 12.6855 1.03376 12.2586L6.67417 8.7876L8 9.5831L15 5.3831V8.5C15 8.77614 15.2239 9 15.5 9C15.7761 9 16 8.77614 16 8.5V4C16 2.89543 15.1046 2 14 2H2ZM5.70808 8.20794L1 11.1052V5.3831L5.70808 8.20794ZM1 4.2169V4C1 3.44772 1.44772 3 2 3H14C14.5523 3 15 3.44772 15 4V4.2169L8 8.4169L1 4.2169Z" fill="#6D6D6D"></path>
                                        <path d="M14.2467 14.2686C15.2567 14.2686 15.8339 13.4116 15.8339 12.2442V12.0344C15.8339 10.4297 14.6402 9 12.5197 9H12.4847C10.421 9 9 10.3598 9 12.4322V12.6465C9 14.8195 10.4385 16 12.3579 16H12.4016C12.9963 16 13.4204 15.9257 13.639 15.8251V15.0949C13.3941 15.2042 12.9656 15.2742 12.4585 15.2742H12.4147C11.0812 15.2742 9.84385 14.4872 9.84385 12.6202V12.4628C9.84385 10.8057 10.9019 9.73891 12.4847 9.73891H12.524C14.0587 9.73891 15.0075 10.7883 15.0075 12.065V12.183C15.0075 13.158 14.6839 13.5734 14.3691 13.5734C14.1374 13.5734 13.9582 13.4247 13.9582 13.1537V10.9631H13.0531V11.5315H13.0225C12.9394 11.2342 12.6552 10.9019 12.0693 10.9019C11.2911 10.9019 10.8101 11.4572 10.8101 12.3011V12.8301C10.8101 13.722 11.2998 14.2642 12.0693 14.2642C12.5415 14.2642 12.9656 14.0369 13.0837 13.6215H13.1274C13.2455 14.0412 13.7439 14.2686 14.2467 14.2686ZM11.7939 12.6814V12.4541C11.7939 11.9076 12.0212 11.6627 12.3666 11.6627C12.664 11.6627 12.9394 11.8551 12.9394 12.371V12.7383C12.9394 13.3111 12.6858 13.4816 12.3754 13.4816C12.0212 13.4816 11.7939 13.2673 11.7939 12.6814Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="mailto:sales@icefindia.in">sales@icefindia.in</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="offcanvas-social">
                        <h4 class="offcanvas-title-meta">Follow Us</h4>
                        <ul>
                            <li><a href="#"><i class="ri-facebook-fill"></i></a></li>
                            <li><a href="#"><i class="ri-twitter-x-fill"></i></a></li>
                            <li><a href="#"><i class="ri-youtube-fill"></i></a></li>
                            <li><a href="#"><i class="ri-linkedin-box-fill"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas-overlay"></div>
    <div class="offcanvas-overlay-white"></div>
    <!-- Offcanvas area start -->

<!-- main area start -->
<main>

        <!-- price cta area start -->
        <section class="rs-pricing-cta-area section-space">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-8 col-lg-10">
                        <div class="section-title-wrapper text-center section-title-space">
                            <span class="section-subtitle">
                        Our Flexible Pricing Plan
                     </span>
                            <h2 class="section-title rs-split-text-enable split-in-left mb-15">Flexible coverage pricing plans
                            </h2>
                            <p class="section-desc">Choose from affordable insurance packages with transparent pricing and no
                                hidden fees.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-pricing-cta-wrapper">
                            <div class="rs-pricing-wrapper">
                                <div class="rs-pricing-tab-wrapper">
                                    <div class="rs-pricing-tab">
                                        <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                            <li class="nav-item" role="presentation">
                                                <button class="nav-link active" id="pills-item-one-tab" data-bs-toggle="pill" data-bs-target="#pills-item-one" type="button" role="tab" aria-controls="pills-item-one" aria-selected="true">
                                                    Financial Insurance
                                                </button>
                                            </li>
                                            <li class="nav-item" role="presentation">
                                                <button class="nav-link" id="pills-item-two-tab" data-bs-toggle="pill" data-bs-target="#pills-item-two" type="button" role="tab" aria-controls="pills-item-two" aria-selected="false"> Startup Insurance
                                                </button>
                                            </li>
                                            <li class="nav-item" role="presentation">
                                                <button class="nav-link" id="pills-item-three-tab" data-bs-toggle="pill" data-bs-target="#pills-item-three" type="button" role="tab" aria-controls="pills-item-three" aria-selected="false">
                                                    Risk Insurance
                                                </button>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="rs-pricing-tab-content-wrapper">
                                    <div class="tab-content rs-pricing-tab-anim" id="pills-tabContent">
                                        <div class="tab-pane fade show active" id="pills-item-one" role="tabpanel" aria-labelledby="pills-item-one-tab" tabindex="0">
                                            <div class="rs-pricing-item">
                                                <h6 class="rs-pricing-title">Basic Plan</h6>
                                                <div class="rs-pricing-amount-wrapper">
                                                    <h3 class="rs-pricing-amount">$49</h3>
                                                    <span class="rs-pricing-duration">/monthly</span>
                                                </div>
                                                <p class="rs-pricing-desc">Provide the best services, ensuring undibo outstanding
                                                    growth Lorem
                                                    ipsum dolor.</p>
                                                <div class="rs-pricing-btn">
                                                    <a class="rs-btn has-icon has-bg-white w-100 radius-6" href="contact.php">Choose
                                                        Your
                                                        Plan
                                                        <span class="icon-box">
                                             <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                   d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                   fill="white" />
                                             </svg>

                                             <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                   d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                   fill="white" />
                                             </svg>
                                          </span>
                                                    </a>
                                                </div>
                                                <div class="rs-pricing-feature">
                                                    <ul>
                                                        <li>
                                                            <span class="rs-pricing-feature-icon">
                                                <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                                   xmlns="http://www.w3.org/2000/svg">
                                                   <path
                                                      d="M4.79969 9.26957C4.76786 9.26957 4.73638 9.26298 4.70721 9.25022C4.67805 9.23746 4.65184 9.2188 4.63024 9.19543L0.0613102 4.25316C0.0308525 4.22021 0.010661 4.17909 0.00320687 4.13485C-0.00424728 4.0906 0.00135924 4.04514 0.0193403 4.00403C0.0373214 3.96292 0.066897 3.92795 0.104447 3.90339C0.141998 3.87883 0.185894 3.86574 0.230764 3.86574H2.42999C2.46301 3.86575 2.49565 3.87283 2.5257 3.88652C2.55575 3.90021 2.58251 3.92019 2.60418 3.9451L4.13113 5.70181C4.29616 5.34906 4.61561 4.7617 5.17619 4.046C6.00493 2.98792 7.54642 1.43182 10.1837 0.0270806C10.2347 -6.42817e-05 10.294 -0.00710946 10.3499 0.0073363C10.4059 0.0217821 10.4543 0.0566687 10.4858 0.105107C10.5172 0.153546 10.5294 0.212016 10.5198 0.268971C10.5102 0.325926 10.4797 0.377226 10.4341 0.412742C10.4241 0.420611 9.40721 1.22138 8.23693 2.68813C7.15989 4.0379 5.72815 6.24497 5.02363 9.09428C5.01126 9.14434 4.98247 9.18881 4.94187 9.2206C4.90127 9.25239 4.85126 9.26957 4.79969 9.26957Z"
                                                      fill="black" />
                                                </svg>
                                             </span>

                                                            <span class="rs-feature-title">Business Plan Creation</span>
                                                        </li>
                                                        <li>
                                                            <span class="rs-pricing-feature-icon">
                                                <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                                   xmlns="http://www.w3.org/2000/svg">
                                                   <path
                                                      d="M4.79969 9.26957C4.76786 9.26957 4.73638 9.26298 4.70721 9.25022C4.67805 9.23746 4.65184 9.2188 4.63024 9.19543L0.0613102 4.25316C0.0308525 4.22021 0.010661 4.17909 0.00320687 4.13485C-0.00424728 4.0906 0.00135924 4.04514 0.0193403 4.00403C0.0373214 3.96292 0.066897 3.92795 0.104447 3.90339C0.141998 3.87883 0.185894 3.86574 0.230764 3.86574H2.42999C2.46301 3.86575 2.49565 3.87283 2.5257 3.88652C2.55575 3.90021 2.58251 3.92019 2.60418 3.9451L4.13113 5.70181C4.29616 5.34906 4.61561 4.7617 5.17619 4.046C6.00493 2.98792 7.54642 1.43182 10.1837 0.0270806C10.2347 -6.42817e-05 10.294 -0.00710946 10.3499 0.0073363C10.4059 0.0217821 10.4543 0.0566687 10.4858 0.105107C10.5172 0.153546 10.5294 0.212016 10.5198 0.268971C10.5102 0.325926 10.4797 0.377226 10.4341 0.412742C10.4241 0.420611 9.40721 1.22138 8.23693 2.68813C7.15989 4.0379 5.72815 6.24497 5.02363 9.09428C5.01126 9.14434 4.98247 9.18881 4.94187 9.2206C4.90127 9.25239 4.85126 9.26957 4.79969 9.26957Z"
                                                      fill="black" />
                                                </svg>
                                             </span>
                                                            <span class="rs-feature-title">Cost Efficiency Audits</span>
                                                        </li>
                                                        <li>
                                                            <span class="rs-pricing-feature-icon">
                                                <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                                   xmlns="http://www.w3.org/2000/svg">
                                                   <path
                                                      d="M4.79969 9.26957C4.76786 9.26957 4.73638 9.26298 4.70721 9.25022C4.67805 9.23746 4.65184 9.2188 4.63024 9.19543L0.0613102 4.25316C0.0308525 4.22021 0.010661 4.17909 0.00320687 4.13485C-0.00424728 4.0906 0.00135924 4.04514 0.0193403 4.00403C0.0373214 3.96292 0.066897 3.92795 0.104447 3.90339C0.141998 3.87883 0.185894 3.86574 0.230764 3.86574H2.42999C2.46301 3.86575 2.49565 3.87283 2.5257 3.88652C2.55575 3.90021 2.58251 3.92019 2.60418 3.9451L4.13113 5.70181C4.29616 5.34906 4.61561 4.7617 5.17619 4.046C6.00493 2.98792 7.54642 1.43182 10.1837 0.0270806C10.2347 -6.42817e-05 10.294 -0.00710946 10.3499 0.0073363C10.4059 0.0217821 10.4543 0.0566687 10.4858 0.105107C10.5172 0.153546 10.5294 0.212016 10.5198 0.268971C10.5102 0.325926 10.4797 0.377226 10.4341 0.412742C10.4241 0.420611 9.40721 1.22138 8.23693 2.68813C7.15989 4.0379 5.72815 6.24497 5.02363 9.09428C5.01126 9.14434 4.98247 9.18881 4.94187 9.2206C4.90127 9.25239 4.85126 9.26957 4.79969 9.26957Z"
                                                      fill="black" />
                                                </svg>
                                             </span>
                                                            <span class="rs-feature-title">24/7 Support at Andy Time</span>
                                                        </li>
                                                        <li>
                                                            <span class="rs-pricing-feature-icon">
                                                <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                                   xmlns="http://www.w3.org/2000/svg">
                                                   <path
                                                      d="M4.79969 9.26957C4.76786 9.26957 4.73638 9.26298 4.70721 9.25022C4.67805 9.23746 4.65184 9.2188 4.63024 9.19543L0.0613102 4.25316C0.0308525 4.22021 0.010661 4.17909 0.00320687 4.13485C-0.00424728 4.0906 0.00135924 4.04514 0.0193403 4.00403C0.0373214 3.96292 0.066897 3.92795 0.104447 3.90339C0.141998 3.87883 0.185894 3.86574 0.230764 3.86574H2.42999C2.46301 3.86575 2.49565 3.87283 2.5257 3.88652C2.55575 3.90021 2.58251 3.92019 2.60418 3.9451L4.13113 5.70181C4.29616 5.34906 4.61561 4.7617 5.17619 4.046C6.00493 2.98792 7.54642 1.43182 10.1837 0.0270806C10.2347 -6.42817e-05 10.294 -0.00710946 10.3499 0.0073363C10.4059 0.0217821 10.4543 0.0566687 10.4858 0.105107C10.5172 0.153546 10.5294 0.212016 10.5198 0.268971C10.5102 0.325926 10.4797 0.377226 10.4341 0.412742C10.4241 0.420611 9.40721 1.22138 8.23693 2.68813C7.15989 4.0379 5.72815 6.24497 5.02363 9.09428C5.01126 9.14434 4.98247 9.18881 4.94187 9.2206C4.90127 9.25239 4.85126 9.26957 4.79969 9.26957Z"
                                                      fill="black" />
                                                </svg>
                                             </span>
                                                            <span class="rs-feature-title">Power and Predictive Dialing</span>
                                                        </li>
                                                        <li class="close">
                                                            <span class="rs-pricing-feature-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                   fill="currentColor">
                                                   <path
                                                      d="M11.9997 10.5865L16.9495 5.63672L18.3637 7.05093L13.4139 12.0007L18.3637 16.9504L16.9495 18.3646L11.9997 13.4149L7.04996 18.3646L5.63574 16.9504L10.5855 12.0007L5.63574 7.05093L7.04996 5.63672L11.9997 10.5865Z">
                                                   </path>
                                                </svg>
                                             </span>
                                                            <span class="rs-feature-title">Profitability Optimization</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="pills-item-two" role="tabpanel" aria-labelledby="pills-item-two-tab" tabindex="0">
                                            <div class="rs-pricing-item">
                                                <h6 class="rs-pricing-title">Business Plan</h6>
                                                <div class="rs-pricing-amount-wrapper">
                                                    <h3 class="rs-pricing-amount">$69</h3>
                                                    <span class="rs-pricing-duration">/monthly</span>
                                                </div>
                                                <p class="rs-pricing-desc">Provide the best services, ensuring undibo outstanding
                                                    growth Lorem
                                                    ipsum dolor.</p>
                                                <div class="rs-pricing-btn">
                                                    <a class="rs-btn has-icon has-bg-white w-100 radius-6" href="contact.php">Choose
                                                        Your
                                                        Plan
                                                        <span class="icon-box">
                                             <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                   d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                   fill="white" />
                                             </svg>

                                             <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                   d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                   fill="white" />
                                             </svg>
                                          </span>
                                                    </a>
                                                </div>
                                                <div class="rs-pricing-feature">
                                                    <ul>
                                                        <li>
                                                            <span class="rs-pricing-feature-icon">
                                                <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                                   xmlns="http://www.w3.org/2000/svg">
                                                   <path
                                                      d="M4.79969 9.26957C4.76786 9.26957 4.73638 9.26298 4.70721 9.25022C4.67805 9.23746 4.65184 9.2188 4.63024 9.19543L0.0613102 4.25316C0.0308525 4.22021 0.010661 4.17909 0.00320687 4.13485C-0.00424728 4.0906 0.00135924 4.04514 0.0193403 4.00403C0.0373214 3.96292 0.066897 3.92795 0.104447 3.90339C0.141998 3.87883 0.185894 3.86574 0.230764 3.86574H2.42999C2.46301 3.86575 2.49565 3.87283 2.5257 3.88652C2.55575 3.90021 2.58251 3.92019 2.60418 3.9451L4.13113 5.70181C4.29616 5.34906 4.61561 4.7617 5.17619 4.046C6.00493 2.98792 7.54642 1.43182 10.1837 0.0270806C10.2347 -6.42817e-05 10.294 -0.00710946 10.3499 0.0073363C10.4059 0.0217821 10.4543 0.0566687 10.4858 0.105107C10.5172 0.153546 10.5294 0.212016 10.5198 0.268971C10.5102 0.325926 10.4797 0.377226 10.4341 0.412742C10.4241 0.420611 9.40721 1.22138 8.23693 2.68813C7.15989 4.0379 5.72815 6.24497 5.02363 9.09428C5.01126 9.14434 4.98247 9.18881 4.94187 9.2206C4.90127 9.25239 4.85126 9.26957 4.79969 9.26957Z"
                                                      fill="black" />
                                                </svg>
                                             </span>

                                                            <span class="rs-feature-title">Business Plan Creation</span>
                                                        </li>
                                                        <li>
                                                            <span class="rs-pricing-feature-icon">
                                                <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                                   xmlns="http://www.w3.org/2000/svg">
                                                   <path
                                                      d="M4.79969 9.26957C4.76786 9.26957 4.73638 9.26298 4.70721 9.25022C4.67805 9.23746 4.65184 9.2188 4.63024 9.19543L0.0613102 4.25316C0.0308525 4.22021 0.010661 4.17909 0.00320687 4.13485C-0.00424728 4.0906 0.00135924 4.04514 0.0193403 4.00403C0.0373214 3.96292 0.066897 3.92795 0.104447 3.90339C0.141998 3.87883 0.185894 3.86574 0.230764 3.86574H2.42999C2.46301 3.86575 2.49565 3.87283 2.5257 3.88652C2.55575 3.90021 2.58251 3.92019 2.60418 3.9451L4.13113 5.70181C4.29616 5.34906 4.61561 4.7617 5.17619 4.046C6.00493 2.98792 7.54642 1.43182 10.1837 0.0270806C10.2347 -6.42817e-05 10.294 -0.00710946 10.3499 0.0073363C10.4059 0.0217821 10.4543 0.0566687 10.4858 0.105107C10.5172 0.153546 10.5294 0.212016 10.5198 0.268971C10.5102 0.325926 10.4797 0.377226 10.4341 0.412742C10.4241 0.420611 9.40721 1.22138 8.23693 2.68813C7.15989 4.0379 5.72815 6.24497 5.02363 9.09428C5.01126 9.14434 4.98247 9.18881 4.94187 9.2206C4.90127 9.25239 4.85126 9.26957 4.79969 9.26957Z"
                                                      fill="black" />
                                                </svg>
                                             </span>
                                                            <span class="rs-feature-title">Cost Efficiency Audits</span>
                                                        </li>
                                                        <li>
                                                            <span class="rs-pricing-feature-icon">
                                                <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                                   xmlns="http://www.w3.org/2000/svg">
                                                   <path
                                                      d="M4.79969 9.26957C4.76786 9.26957 4.73638 9.26298 4.70721 9.25022C4.67805 9.23746 4.65184 9.2188 4.63024 9.19543L0.0613102 4.25316C0.0308525 4.22021 0.010661 4.17909 0.00320687 4.13485C-0.00424728 4.0906 0.00135924 4.04514 0.0193403 4.00403C0.0373214 3.96292 0.066897 3.92795 0.104447 3.90339C0.141998 3.87883 0.185894 3.86574 0.230764 3.86574H2.42999C2.46301 3.86575 2.49565 3.87283 2.5257 3.88652C2.55575 3.90021 2.58251 3.92019 2.60418 3.9451L4.13113 5.70181C4.29616 5.34906 4.61561 4.7617 5.17619 4.046C6.00493 2.98792 7.54642 1.43182 10.1837 0.0270806C10.2347 -6.42817e-05 10.294 -0.00710946 10.3499 0.0073363C10.4059 0.0217821 10.4543 0.0566687 10.4858 0.105107C10.5172 0.153546 10.5294 0.212016 10.5198 0.268971C10.5102 0.325926 10.4797 0.377226 10.4341 0.412742C10.4241 0.420611 9.40721 1.22138 8.23693 2.68813C7.15989 4.0379 5.72815 6.24497 5.02363 9.09428C5.01126 9.14434 4.98247 9.18881 4.94187 9.2206C4.90127 9.25239 4.85126 9.26957 4.79969 9.26957Z"
                                                      fill="black" />
                                                </svg>
                                             </span>
                                                            <span class="rs-feature-title">24/7 Support at Andy Time</span>
                                                        </li>
                                                        <li>
                                                            <span class="rs-pricing-feature-icon">
                                                <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                                   xmlns="http://www.w3.org/2000/svg">
                                                   <path
                                                      d="M4.79969 9.26957C4.76786 9.26957 4.73638 9.26298 4.70721 9.25022C4.67805 9.23746 4.65184 9.2188 4.63024 9.19543L0.0613102 4.25316C0.0308525 4.22021 0.010661 4.17909 0.00320687 4.13485C-0.00424728 4.0906 0.00135924 4.04514 0.0193403 4.00403C0.0373214 3.96292 0.066897 3.92795 0.104447 3.90339C0.141998 3.87883 0.185894 3.86574 0.230764 3.86574H2.42999C2.46301 3.86575 2.49565 3.87283 2.5257 3.88652C2.55575 3.90021 2.58251 3.92019 2.60418 3.9451L4.13113 5.70181C4.29616 5.34906 4.61561 4.7617 5.17619 4.046C6.00493 2.98792 7.54642 1.43182 10.1837 0.0270806C10.2347 -6.42817e-05 10.294 -0.00710946 10.3499 0.0073363C10.4059 0.0217821 10.4543 0.0566687 10.4858 0.105107C10.5172 0.153546 10.5294 0.212016 10.5198 0.268971C10.5102 0.325926 10.4797 0.377226 10.4341 0.412742C10.4241 0.420611 9.40721 1.22138 8.23693 2.68813C7.15989 4.0379 5.72815 6.24497 5.02363 9.09428C5.01126 9.14434 4.98247 9.18881 4.94187 9.2206C4.90127 9.25239 4.85126 9.26957 4.79969 9.26957Z"
                                                      fill="black" />
                                                </svg>
                                             </span>
                                                            <span class="rs-feature-title">Power and Predictive Dialing</span>
                                                        </li>
                                                        <li class="close">
                                                            <span class="rs-pricing-feature-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                   fill="currentColor">
                                                   <path
                                                      d="M11.9997 10.5865L16.9495 5.63672L18.3637 7.05093L13.4139 12.0007L18.3637 16.9504L16.9495 18.3646L11.9997 13.4149L7.04996 18.3646L5.63574 16.9504L10.5855 12.0007L5.63574 7.05093L7.04996 5.63672L11.9997 10.5865Z">
                                                   </path>
                                                </svg>
                                             </span>
                                                            <span class="rs-feature-title">Profitability Optimization</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="pills-item-three" role="tabpanel" aria-labelledby="pills-item-three-tab" tabindex="0">
                                            <div class="rs-pricing-item">
                                                <h6 class="rs-pricing-title">Premium Plan</h6>
                                                <div class="rs-pricing-amount-wrapper">
                                                    <h3 class="rs-pricing-amount">$99</h3>
                                                    <span class="rs-pricing-duration">/monthly</span>
                                                </div>
                                                <p class="rs-pricing-desc">Provide the best services, ensuring undibo outstanding
                                                    growth Lorem
                                                    ipsum dolor.</p>
                                                <div class="rs-pricing-btn">
                                                    <a class="rs-btn has-icon has-bg-white w-100 radius-6" href="contact.php">Choose
                                                        Your
                                                        Plan
                                                        <span class="icon-box">
                                             <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                   d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                   fill="white" />
                                             </svg>

                                             <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                   d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                   fill="white" />
                                             </svg>
                                          </span>
                                                    </a>
                                                </div>
                                                <div class="rs-pricing-feature">
                                                    <ul>
                                                        <li>
                                                            <span class="rs-pricing-feature-icon">
                                                <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                                   xmlns="http://www.w3.org/2000/svg">
                                                   <path
                                                      d="M4.79969 9.26957C4.76786 9.26957 4.73638 9.26298 4.70721 9.25022C4.67805 9.23746 4.65184 9.2188 4.63024 9.19543L0.0613102 4.25316C0.0308525 4.22021 0.010661 4.17909 0.00320687 4.13485C-0.00424728 4.0906 0.00135924 4.04514 0.0193403 4.00403C0.0373214 3.96292 0.066897 3.92795 0.104447 3.90339C0.141998 3.87883 0.185894 3.86574 0.230764 3.86574H2.42999C2.46301 3.86575 2.49565 3.87283 2.5257 3.88652C2.55575 3.90021 2.58251 3.92019 2.60418 3.9451L4.13113 5.70181C4.29616 5.34906 4.61561 4.7617 5.17619 4.046C6.00493 2.98792 7.54642 1.43182 10.1837 0.0270806C10.2347 -6.42817e-05 10.294 -0.00710946 10.3499 0.0073363C10.4059 0.0217821 10.4543 0.0566687 10.4858 0.105107C10.5172 0.153546 10.5294 0.212016 10.5198 0.268971C10.5102 0.325926 10.4797 0.377226 10.4341 0.412742C10.4241 0.420611 9.40721 1.22138 8.23693 2.68813C7.15989 4.0379 5.72815 6.24497 5.02363 9.09428C5.01126 9.14434 4.98247 9.18881 4.94187 9.2206C4.90127 9.25239 4.85126 9.26957 4.79969 9.26957Z"
                                                      fill="black" />
                                                </svg>
                                             </span>

                                                            <span class="rs-feature-title">Business Plan Creation</span>
                                                        </li>
                                                        <li>
                                                            <span class="rs-pricing-feature-icon">
                                                <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                                   xmlns="http://www.w3.org/2000/svg">
                                                   <path
                                                      d="M4.79969 9.26957C4.76786 9.26957 4.73638 9.26298 4.70721 9.25022C4.67805 9.23746 4.65184 9.2188 4.63024 9.19543L0.0613102 4.25316C0.0308525 4.22021 0.010661 4.17909 0.00320687 4.13485C-0.00424728 4.0906 0.00135924 4.04514 0.0193403 4.00403C0.0373214 3.96292 0.066897 3.92795 0.104447 3.90339C0.141998 3.87883 0.185894 3.86574 0.230764 3.86574H2.42999C2.46301 3.86575 2.49565 3.87283 2.5257 3.88652C2.55575 3.90021 2.58251 3.92019 2.60418 3.9451L4.13113 5.70181C4.29616 5.34906 4.61561 4.7617 5.17619 4.046C6.00493 2.98792 7.54642 1.43182 10.1837 0.0270806C10.2347 -6.42817e-05 10.294 -0.00710946 10.3499 0.0073363C10.4059 0.0217821 10.4543 0.0566687 10.4858 0.105107C10.5172 0.153546 10.5294 0.212016 10.5198 0.268971C10.5102 0.325926 10.4797 0.377226 10.4341 0.412742C10.4241 0.420611 9.40721 1.22138 8.23693 2.68813C7.15989 4.0379 5.72815 6.24497 5.02363 9.09428C5.01126 9.14434 4.98247 9.18881 4.94187 9.2206C4.90127 9.25239 4.85126 9.26957 4.79969 9.26957Z"
                                                      fill="black" />
                                                </svg>
                                             </span>
                                                            <span class="rs-feature-title">Cost Efficiency Audits</span>
                                                        </li>
                                                        <li>
                                                            <span class="rs-pricing-feature-icon">
                                                <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                                   xmlns="http://www.w3.org/2000/svg">
                                                   <path
                                                      d="M4.79969 9.26957C4.76786 9.26957 4.73638 9.26298 4.70721 9.25022C4.67805 9.23746 4.65184 9.2188 4.63024 9.19543L0.0613102 4.25316C0.0308525 4.22021 0.010661 4.17909 0.00320687 4.13485C-0.00424728 4.0906 0.00135924 4.04514 0.0193403 4.00403C0.0373214 3.96292 0.066897 3.92795 0.104447 3.90339C0.141998 3.87883 0.185894 3.86574 0.230764 3.86574H2.42999C2.46301 3.86575 2.49565 3.87283 2.5257 3.88652C2.55575 3.90021 2.58251 3.92019 2.60418 3.9451L4.13113 5.70181C4.29616 5.34906 4.61561 4.7617 5.17619 4.046C6.00493 2.98792 7.54642 1.43182 10.1837 0.0270806C10.2347 -6.42817e-05 10.294 -0.00710946 10.3499 0.0073363C10.4059 0.0217821 10.4543 0.0566687 10.4858 0.105107C10.5172 0.153546 10.5294 0.212016 10.5198 0.268971C10.5102 0.325926 10.4797 0.377226 10.4341 0.412742C10.4241 0.420611 9.40721 1.22138 8.23693 2.68813C7.15989 4.0379 5.72815 6.24497 5.02363 9.09428C5.01126 9.14434 4.98247 9.18881 4.94187 9.2206C4.90127 9.25239 4.85126 9.26957 4.79969 9.26957Z"
                                                      fill="black" />
                                                </svg>
                                             </span>
                                                            <span class="rs-feature-title">24/7 Support at Andy Time</span>
                                                        </li>
                                                        <li>
                                                            <span class="rs-pricing-feature-icon">
                                                <svg width="11" height="10" viewBox="0 0 11 10" fill="none"
                                                   xmlns="http://www.w3.org/2000/svg">
                                                   <path
                                                      d="M4.79969 9.26957C4.76786 9.26957 4.73638 9.26298 4.70721 9.25022C4.67805 9.23746 4.65184 9.2188 4.63024 9.19543L0.0613102 4.25316C0.0308525 4.22021 0.010661 4.17909 0.00320687 4.13485C-0.00424728 4.0906 0.00135924 4.04514 0.0193403 4.00403C0.0373214 3.96292 0.066897 3.92795 0.104447 3.90339C0.141998 3.87883 0.185894 3.86574 0.230764 3.86574H2.42999C2.46301 3.86575 2.49565 3.87283 2.5257 3.88652C2.55575 3.90021 2.58251 3.92019 2.60418 3.9451L4.13113 5.70181C4.29616 5.34906 4.61561 4.7617 5.17619 4.046C6.00493 2.98792 7.54642 1.43182 10.1837 0.0270806C10.2347 -6.42817e-05 10.294 -0.00710946 10.3499 0.0073363C10.4059 0.0217821 10.4543 0.0566687 10.4858 0.105107C10.5172 0.153546 10.5294 0.212016 10.5198 0.268971C10.5102 0.325926 10.4797 0.377226 10.4341 0.412742C10.4241 0.420611 9.40721 1.22138 8.23693 2.68813C7.15989 4.0379 5.72815 6.24497 5.02363 9.09428C5.01126 9.14434 4.98247 9.18881 4.94187 9.2206C4.90127 9.25239 4.85126 9.26957 4.79969 9.26957Z"
                                                      fill="black" />
                                                </svg>
                                             </span>
                                                            <span class="rs-feature-title">Power and Predictive Dialing</span>
                                                        </li>
                                                        <li class="close">
                                                            <span class="rs-pricing-feature-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                   fill="currentColor">
                                                   <path
                                                      d="M11.9997 10.5865L16.9495 5.63672L18.3637 7.05093L13.4139 12.0007L18.3637 16.9504L16.9495 18.3646L11.9997 13.4149L7.04996 18.3646L5.63574 16.9504L10.5855 12.0007L5.63574 7.05093L7.04996 5.63672L11.9997 10.5865Z">
                                                   </path>
                                                </svg>
                                             </span>
                                                            <span class="rs-feature-title">Profitability Optimization</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-contact-form-wrapper">
                                <div class="rs-contact-two">
                                    <div class="section-title-wrapper">
                                        <div class="contact-shape">
                                            <img src="assets/images/shape/squre-shape-03.webp" alt="image">
                                        </div>
                                        <span class="section-subtitle is-white">
                                 Contact with us now
                              </span>
                                        <h2 class="section-title rs-split-text-enable split-in-left is-white mb-10">Let’s
                                            Collaborate
                                            with Us!</h2>
                                        <p class="rs-section-desc">Read and update the latest news from us. done eu magna quis
                                            felis.
                                        </p>
                                    </div>
                                    <div class="rs-contact-form">
                                        <form id="contact-form" action="./assets/mailer.php" method="POST">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="rs-contact-input-box">
                                                        <div class="rs-contact-input">
                                                            <input id="name" name="name" type="text" placeholder="Full name*">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="rs-contact-input-box">
                                                        <div class="rs-contact-input">
                                                            <input id="email" name="email" type="email" placeholder="Email Address*">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="rs-contact-input-box">
                                                        <div class="rs-contact-input">
                                                            <input id="phone" name="phone" type="text" placeholder="Phone Number*">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="rs-contact-input-box">
                                                        <div class="rs-contact-input">
                                                            <select id="subject" name="subject">
                                                                <option>Your Business</option>
                                                                <option value="one">Business Strategy</option>
                                                                <option value="two">Market Analysis</option>
                                                                <option value="three">Financial Planing</option>
                                                                <option value="four">Risk Management</option>
                                                                <option value="five">Digital Transformation</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="rs-contact-input-box">
                                                        <div class="rs-contact-input">
                                                            <textarea id="message" name="message" placeholder="Message*"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="rs-contact-btn">
                                                        <button type="submit" class="rs-btn has-md-radius has-theme-secondary w-100">
                                                            Send Massage
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- price cta area end -->
        <!-- about area start -->
        <section class="rs-about-area rs-about-eight section-space-bottom">
            <div class="about-shape">
                <img src="assets/images/shape/about-shape-01.webp" alt="image">
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-about-wrapper">
                            <div class="rs-about-content-wrapper">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle is-white">
                              About Our Immigration
                           </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left mb-20 is-white">Reliable
                                        insurance for every family</h2>
                                    <p class="section-desc is-white">We are a trusted insurance provider with years of
                                        experience, helping individuals and businesses secure their future with the right coverage
                                    </p>
                                </div>
                                <div class="rs-about-list-wrapper">
                                    <div class="rs-about-list-item">
                                        <div class="rs-about-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10" viewBox="0 0 12 10" fill="none">
                                                <path d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z" fill="black"></path>
                                            </svg>
                                        </div>
                                        <p class="rs-about-list-desc"> Regulatory Investigations </p>
                                    </div>
                                    <div class="rs-about-list-item">
                                        <div class="rs-about-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10" viewBox="0 0 12 10" fill="none">
                                                <path d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z" fill="black"></path>
                                            </svg>
                                        </div>
                                        <p class="rs-about-list-desc"> Competitive Work Analysis </p>
                                    </div>
                                    <div class="rs-about-list-item">
                                        <div class="rs-about-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10" viewBox="0 0 12 10" fill="none">
                                                <path d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z" fill="black"></path>
                                            </svg>
                                        </div>
                                        <p class="rs-about-list-desc"> Anit- Competitive Conduct </p>
                                    </div>
                                    <div class="rs-about-list-item">
                                        <div class="rs-about-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10" viewBox="0 0 12 10" fill="none">
                                                <path d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z" fill="black"></path>
                                            </svg>
                                        </div>
                                        <p class="rs-about-list-desc"> Innovation. Strategy. Success. </p>
                                    </div>
                                </div>
                                <div class="rs-about-btn">
                                    <a class="rs-btn has-icon hover-white" href="about.php">Get Start
                                        Now
                                        <span class="icon-box">
                                 <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                       d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                       fill="white" />
                                 </svg>

                                 <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                       d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                       fill="white" />
                                 </svg>
                              </span>
                                    </a>
                                </div>
                            </div>

                            <div class="rs-about-thumb">
                                <img src="assets/images/about/39.webp" alt="image">
                                <div class="rs-about-meta-wrapper">
                                    <div class="rs-about-meta-info">
                                        <div class="rs-cta-thumb">
                                            <img src="assets/images/user/client-group.webp" alt="image">
                                        </div>
                                        <h5 class="rs-about-meta-title">Contact Our Experts</h5>
                                    </div>
                                    <p class="rs-about-meta-desc">We provide the best services to ensuring your outstanding
                                        growth Lorem
                                        ipsum dolor sit.</p>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about area end -->

        <!-- feature area start -->
        <section class="rs-feature-area rs-feature-five">
            <div class="rs-feature-bg-thumb include-bg include-bg" data-background="assets/images/bg/feature-bg-thumb-03.webp"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lx-12">
                        <div class="rs-feature-wrapper">
                            <div class="rs-feature-item wow fadeIn" data-wow-delay=".3s" data-wow-duration="1s">
                                <div class="rs-feature-icon-info">
                                    <div class="rs-feature-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 44">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M21.3556 18.2501C21.3556 18.0791 21.4235 17.9152 21.5444 17.7943C21.6652 17.6734 21.8292 17.6055 22.0001 17.6055C22.1711 17.6055 22.335 17.6734 22.4559 17.7943C22.5767 17.9152 22.6447 18.0791 22.6447 18.2501V21.3556H25.7502C25.9211 21.3556 26.0851 21.4235 26.2059 21.5444C26.3268 21.6652 26.3947 21.8292 26.3947 22.0001C26.3947 22.1711 26.3268 22.335 26.2059 22.4559C26.0851 22.5767 25.9211 22.6447 25.7502 22.6447H22.6447V25.7502C22.6447 25.9211 22.5767 26.0851 22.4559 26.2059C22.335 26.3268 22.1711 26.3947 22.0001 26.3947C21.8292 26.3947 21.6652 26.3268 21.5444 26.2059C21.4235 26.0851 21.3556 25.9211 21.3556 25.7502V22.6447H18.2501C18.0791 22.6447 17.9152 22.5767 17.7943 22.4559C17.6734 22.335 17.6055 22.1711 17.6055 22.0001C17.6055 21.8292 17.6734 21.6652 17.7943 21.5444C17.9152 21.4235 18.0791 21.3556 18.2501 21.3556H21.3556V18.2501ZM1.37512 14.9197C1.01461 14.9197 0.730591 15.2033 0.730591 15.5863H0.732137C0.731928 15.75 0.794411 15.9077 0.906763 16.0269L6.53876 22.0001L0.937614 27.9407C0.501653 28.3726 0.800114 29.0804 1.37512 29.0804H6.91972C8.57376 32.5972 11.4031 35.4265 14.9198 37.0805V42.6251C14.9198 42.9856 15.2034 43.2697 15.5863 43.2697V43.2681C15.7501 43.2683 15.9078 43.2058 16.027 43.0935L22.0001 37.4615L27.9407 43.0626C28.3726 43.4986 29.0804 43.2001 29.0804 42.6251V37.0806C32.5972 35.4266 35.4265 32.5972 37.0805 29.0805H42.6251C42.9856 29.0805 43.2697 28.7969 43.2697 28.414H43.2681C43.2683 28.2502 43.2058 28.0925 43.0935 27.9734L37.4615 22.0001L43.0626 16.0595C43.4986 15.6277 43.2001 14.9198 42.6251 14.9198H37.0806C35.4266 11.4031 32.5972 8.57376 29.0805 6.91972V1.37512C29.0805 1.01461 28.7969 0.730591 28.414 0.730591V0.732137C28.2502 0.731916 28.0925 0.794435 27.9734 0.906848L22.0001 6.53876L16.0595 0.937614C15.6277 0.501653 14.9198 0.800114 14.9198 1.37512V6.91972C11.4031 8.57376 8.57376 11.4031 6.91972 14.9198L1.37512 14.9197ZM8.3535 14.9197C9.81109 12.1179 12.118 9.811 14.9198 8.3535V9.46588H14.9214C14.9212 9.55362 14.9391 9.64046 14.9739 9.721C15.0087 9.80155 15.0597 9.8741 15.1237 9.93415L17.3897 12.0707C15.0452 13.1614 13.1613 15.0453 12.0706 17.3897L9.96423 15.1557C9.90383 15.0819 9.82778 15.0224 9.74157 14.9816C9.65537 14.9408 9.56117 14.9197 9.46579 14.9198L8.3535 14.9197ZM13.0315 18.4087L16.0023 21.5595C16.1145 21.6788 16.1769 21.8364 16.1769 22.0001C16.1769 22.1639 16.1145 22.3215 16.0023 22.4407L13.0316 25.5915C14.0107 28.0338 15.9666 29.9897 18.4088 30.9688L21.5596 27.998C21.6789 27.8859 21.8365 27.8234 22.0002 27.8234C22.164 27.8234 22.3215 27.8859 22.4408 27.998L25.5916 30.9688C28.0338 29.9898 29.9898 28.0338 30.9689 25.5916L27.9981 22.4408C27.8859 22.3215 27.8235 22.164 27.8235 22.0002C27.8235 21.8365 27.8859 21.6789 27.9981 21.5596L30.9689 18.4088C29.9899 15.9666 28.0339 14.0106 25.5917 13.0315L22.4409 16.0023C22.3216 16.1145 22.164 16.1769 22.0003 16.1769C21.8365 16.1769 21.679 16.1145 21.5597 16.0023L18.4089 13.0315C15.9665 14.0105 14.0105 15.9666 13.0315 18.4087ZM12.0707 26.6105C13.1614 28.955 15.0453 30.8388 17.3897 31.9295L15.1557 34.0359C15.0819 34.0963 15.0224 34.1724 14.9816 34.2586C14.9408 34.3448 14.9197 34.439 14.9198 34.5344V35.6467C12.118 34.1892 9.81118 31.8823 8.35359 29.0805H9.46597V29.079C9.55371 29.0791 9.64054 29.0612 9.72109 29.0264C9.80164 28.9916 9.87418 28.9406 9.93424 28.8767L12.0707 26.6105ZM9.18985 16.2088L14.6502 22.0001L9.18985 27.7915H2.84577L7.89073 22.4407C8.00292 22.3215 8.06539 22.1639 8.06539 22.0001C8.06539 21.8364 8.00292 21.6788 7.89073 21.5595L2.84577 16.2088H9.18985ZM29.0805 8.3535C31.8824 9.81118 34.1892 12.1178 35.6467 14.9197H34.5344V14.9213C34.4466 14.9212 34.3598 14.9391 34.2792 14.9738C34.1987 15.0086 34.1261 15.0596 34.0661 15.1236L31.9295 17.3897C30.8388 15.0452 28.955 13.1613 26.6105 12.0706L28.8445 9.96423C28.9183 9.90383 28.9778 9.82778 29.0186 9.74157C29.0594 9.65537 29.0805 9.56117 29.0804 9.46579L29.0805 8.3535ZM27.7915 9.18985L22.0001 14.6503L16.2088 9.18993V2.84577L21.5595 7.89073C21.6788 8.00292 21.8364 8.06539 22.0001 8.06539C22.1639 8.06539 22.3215 8.00292 22.4407 7.89073L27.7915 2.84577V9.18985ZM35.6467 29.0805C34.1892 31.8824 31.8823 34.1892 29.0805 35.6467V34.5344H29.079C29.0791 34.4466 29.0612 34.3598 29.0264 34.2792C28.9916 34.1987 28.9406 34.1261 28.8767 34.0661L26.6106 31.9295C28.955 30.8388 30.8389 28.955 31.9296 26.6105L34.036 28.8445C34.0964 28.9183 34.1725 28.9778 34.2587 29.0186C34.3449 29.0594 34.4391 29.0805 34.5345 29.0804L35.6467 29.0805ZM34.8104 27.7915L29.35 22.0001L34.8104 16.2088H41.1546L36.1096 21.5595C35.9974 21.6788 35.9349 21.8364 35.9349 22.0001C35.9349 22.1639 35.9974 22.3215 36.1096 22.4407L41.1546 27.7915H34.8104ZM16.2088 34.8104L22.0001 29.35L27.7915 34.8104V41.1546L22.4407 36.1096C22.3215 35.9974 22.1639 35.9349 22.0001 35.9349C21.8364 35.9349 21.6788 35.9974 21.5595 36.1096L16.2088 41.1546V34.8104Z">
                                            </path>
                                        </svg>
                                    </div>
                                    <span class="rs-feature-number">01</span>
                                </div>
                                <h5 class="rs-feature-title"> Customizable Plans</h5>
                                <span class="rs-feature-line"></span>
                                <p class="rs-feature-desc"> We begin by understanding your current with state goals and
                                    challenges.
                                </p>
                            </div>
                            <div class="rs-feature-item wow fadeIn" data-wow-delay=".5s" data-wow-duration="1s">
                                <div class="rs-feature-icon-info">
                                    <div class="rs-feature-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 38">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M10.5959 36.5456C10.0034 36.5456 9.52067 36.0625 9.52067 35.4686C9.52067 34.8755 10.0034 34.3925 10.5959 34.3925C11.1884 34.3925 11.6758 34.8756 11.6758 35.4686C11.6758 36.0626 11.1884 36.5456 10.5959 36.5456ZM10.5959 1.45436C11.1884 1.45436 11.6758 1.93651 11.6758 2.53042C11.6758 3.12345 11.1884 3.60657 10.5959 3.60657C10.0034 3.60657 9.52067 3.12345 9.52067 2.53042C9.52067 1.93651 10.0034 1.45436 10.5959 1.45436ZM10.5959 33.2605C9.97941 33.2605 9.42519 33.5147 9.02373 33.9232L1.98989 29.9241V8.07486L9.02373 4.07676C9.4251 4.48481 9.97941 4.73861 10.5959 4.73861C11.8144 4.73861 12.8035 3.74755 12.8035 2.53051C12.8035 1.3125 11.8144 0.322415 10.5959 0.322415C9.13189 0.322415 8.09401 1.71968 8.45992 3.09248L1.14413 7.25303C1.05726 7.30259 0.985011 7.3742 0.934672 7.46062C0.884332 7.54704 0.857686 7.64521 0.857422 7.74521V30.2539C0.857515 30.354 0.884089 30.4522 0.934446 30.5387C0.984803 30.6251 1.05715 30.6967 1.14413 30.7461L8.45992 34.9067C8.09401 36.2795 9.13215 37.6777 10.5959 37.6777C11.8144 37.6777 12.8035 36.6867 12.8035 35.4687C12.8035 34.2515 11.8143 33.2605 10.5959 33.2605ZM25.3994 36.5456C24.8069 36.5456 24.3242 36.0625 24.3242 35.4686C24.3242 34.8755 24.8068 34.3925 25.3994 34.3925C25.992 34.3925 26.4746 34.8756 26.4746 35.4686C26.4746 36.0626 25.9919 36.5456 25.3994 36.5456ZM25.3994 3.60657C24.8069 3.60657 24.3242 3.12345 24.3242 2.53042C24.3242 1.93651 24.8068 1.45436 25.3994 1.45436C25.992 1.45436 26.4746 1.93651 26.4746 2.53042C26.4746 3.12345 25.9919 3.60657 25.3994 3.60657ZM34.8511 7.25294L27.5353 3.09239C27.9013 1.72012 26.8636 0.322327 25.3994 0.322327C24.1809 0.322327 23.1917 1.31241 23.1917 2.53042C23.1917 3.74746 24.1809 4.73852 25.3994 4.73852C26.0158 4.73852 26.5749 4.48481 26.9763 4.07667L34.0101 8.07477V29.9241L26.9763 33.9232C26.5749 33.5146 26.0158 33.2605 25.3994 33.2605C24.1809 33.2605 23.1917 34.2515 23.1917 35.4686C23.1917 36.6866 24.1809 37.6776 25.3994 37.6776C26.8634 37.6776 27.9013 36.279 27.5353 34.9066L34.8511 30.746C34.9394 30.6977 35.013 30.6265 35.0643 30.5399C35.1155 30.4533 35.1426 30.3545 35.1426 30.2539V7.74513C35.1426 7.54202 35.0327 7.35423 34.8511 7.25294ZM17.9976 30.2194L6.72535 24.6507L11.1693 22.4564L17.7491 25.7063C17.9045 25.785 18.0931 25.7837 18.2509 25.7063L24.826 22.4564L29.2699 24.6507L17.9976 30.2194ZM6.72535 18.9997L11.1693 16.8054L17.7491 20.0547C17.9063 20.1339 18.0918 20.1324 18.2509 20.0547L24.826 16.8054L29.2699 18.9997L17.9976 24.5676L6.72535 18.9997ZM6.72535 13.3483L17.9976 7.78041L29.2699 13.3483L17.9976 18.9161L6.72535 13.3483ZM31.1144 24.6507C31.1144 24.8667 30.9901 25.0626 30.799 25.1587L18.2509 31.3582C18.0922 31.4346 17.9059 31.4361 17.7491 31.3572L5.19617 25.1587C4.77782 24.9503 4.77677 24.3517 5.19617 24.1437L9.8886 21.8252L5.19617 19.5072C4.77756 19.2992 4.77668 18.7008 5.19617 18.4918L9.8886 16.1738L5.19617 13.8553C4.77729 13.6476 4.77729 13.049 5.19617 12.8414L17.7491 6.64187C17.8271 6.60323 17.913 6.58313 18 6.58313C18.087 6.58313 18.1729 6.60323 18.2509 6.64187L30.799 12.8414C31.2179 13.0491 31.2179 13.6476 30.799 13.8553L26.1066 16.1738L30.799 18.4918C31.2185 18.7008 31.2176 19.2992 30.799 19.5072L26.1066 21.8252L30.799 24.1437C30.9901 24.2388 31.1144 24.4356 31.1144 24.6507Z">
                                            </path>
                                        </svg>
                                    </div>
                                    <span class="rs-feature-number">02</span>
                                </div>
                                <h5 class="rs-feature-title"> Multi-Policy Discounts</h5>
                                <span class="rs-feature-line"></span>
                                <p class="rs-feature-desc"> Our mission is to empower businesses with the insight structure and
                                    tools needed
                                    your.
                                </p>
                            </div>
                            <div class="rs-feature-item wow fadeIn" data-wow-delay=".7s" data-wow-duration="1s">
                                <div class="rs-feature-icon-info">
                                    <div class="rs-feature-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 39 44">
                                            <path d="M38.1299 14.3499L34.8829 14.2568C34.5257 13.0258 33.9981 11.8432 33.3134 10.7387L35.5382 8.53967C35.6992 8.38203 35.7873 8.17191 35.7837 7.95445C35.78 7.737 35.6848 7.52956 35.5186 7.3767L31.0581 3.2333C30.8937 3.07921 30.6711 2.99104 30.4378 2.98763C30.2044 2.98422 29.9789 3.06584 29.8094 3.21505L27.4414 5.28264C26.2515 4.64564 24.9776 4.15529 23.6519 3.82391L23.5509 0.80879C23.5445 0.591567 23.447 0.385291 23.2793 0.234128C23.1115 0.0829643 22.8868 -0.00107223 22.6533 1.03308e-05H16.3447C15.8572 1.03308e-05 15.4629 0.355107 15.4472 0.80879L15.3461 3.82391C14.0199 4.15528 12.7466 4.64639 11.5537 5.28446L9.18865 3.21596C9.01936 3.06641 8.79387 2.98449 8.56047 2.98773C8.32707 2.99097 8.10431 3.07912 7.93989 3.2333L3.48143 7.3767C3.3151 7.52957 3.21995 7.73712 3.21646 7.95464C3.21298 8.17216 3.30144 8.38225 3.46279 8.53967L5.68859 10.7351C5.00192 11.8423 4.47318 13.0263 4.11611 14.2595L0.8711 14.3499C0.637453 14.3552 0.415362 14.4456 0.2525 14.6016C0.0896384 14.7576 -0.00101154 14.9668 8.51627e-06 15.1843V21.0429C8.51627e-06 21.4975 0.382582 21.8635 0.8711 21.8772L4.11611 21.9676C4.47318 23.1999 5.00094 24.3839 5.68859 25.4921L3.46181 27.6875C3.30046 27.8449 3.212 28.055 3.21548 28.2725C3.21897 28.49 3.31412 28.6976 3.48045 28.8504L7.94087 32.9929C8.10531 33.1471 8.32806 33.2352 8.56145 33.2385C8.79484 33.2417 9.02032 33.1598 9.18963 33.0103L11.5547 30.9418C11.9255 31.1399 12.3071 31.3252 12.6946 31.4959L10.9495 38.3048H10.6777C8.9905 38.3048 7.61814 39.5818 7.61814 41.1519V43.4523C7.61814 43.7544 7.88201 44 8.20671 44H30.7923C31.117 44 31.3809 43.7544 31.3809 43.4523V41.1528C31.3809 39.5827 30.0085 38.3057 28.3213 38.3057H28.0515L26.3397 31.4803C26.7135 31.3151 27.0813 31.1362 27.4404 30.9445L29.8084 33.0121C29.9777 33.1616 30.2032 33.2435 30.4366 33.2403C30.67 33.237 30.8927 33.1489 31.0572 32.9948L35.5186 28.8514C35.8639 28.53 35.8727 28.0198 35.5382 27.6893L33.3134 25.4903C33.9985 24.3859 34.5261 23.2033 34.8829 21.9722L38.1299 21.8781C38.3633 21.8725 38.5851 21.782 38.7477 21.626C38.9103 21.4701 39.0009 21.2611 39 21.0438V15.1843C39 14.7306 38.6174 14.3645 38.1299 14.3499ZM30.2037 41.1528V42.9046H8.79529V41.1528C8.79529 40.187 9.63989 39.4011 10.6777 39.4011H28.3213C29.3591 39.4011 30.2037 40.187 30.2037 41.1528ZM12.16 38.3057L15.3775 25.7495H23.6941L26.842 38.3057H12.16ZM15.2029 24.6541L12.5504 21.45H26.4643L23.8677 24.6541H15.2029ZM14.4201 18.779H18.1262C18.4509 18.779 18.7147 18.5335 18.7147 18.2313V16.643H20.4765V18.2313C20.4765 18.5335 20.7404 18.779 21.0651 18.779H24.7712C25.0959 18.779 25.3598 18.5335 25.3598 18.2313V16.643H27.0578V20.3546H11.9422V16.6421H13.8315V18.2304C13.8315 18.5335 14.0954 18.779 14.4201 18.779ZM24.7977 25.3269L28.1163 21.2318C28.1908 21.1406 28.234 21.0265 28.234 20.9023V16.0944C28.234 15.7922 27.9701 15.5467 27.6454 15.5467H24.7702C24.4455 15.5467 24.1816 15.7922 24.1816 16.0944V17.6827H21.6527V16.0944C21.6527 15.7922 21.3888 15.5467 21.0641 15.5467H18.1262C17.8015 15.5467 17.5376 15.7922 17.5376 16.0944V17.6827H15.0087V16.0944C15.0087 15.7922 14.7448 15.5467 14.4201 15.5467H11.3536C11.0289 15.5467 10.7651 15.7922 10.7651 16.0944V20.9014C10.7651 21.0274 10.8112 21.1433 10.8877 21.2355L14.2759 25.3287L14.0101 26.3666C10.1431 24.1456 8.21946 19.7348 9.41133 15.6042C10.9014 10.4375 16.64 7.36027 22.204 8.74506C24.8987 9.416 27.151 11.0208 28.5459 13.2645C29.9408 15.5083 30.3107 18.1218 29.5897 20.6248C28.9069 22.99 27.2716 25.0348 25.0508 26.331L24.7977 25.3269ZM37.8228 20.7909L34.6377 20.8822C34.2335 20.8941 33.8961 21.146 33.796 21.5103C33.4494 22.7719 32.91 23.9807 32.1941 25.0996C31.9871 25.4227 32.0352 25.8244 32.3118 26.0982L34.4935 28.2544L30.4166 32.0408L28.0927 30.0125C27.7984 29.756 27.3678 29.7122 27.0205 29.903C26.7096 30.0746 26.3888 30.2343 26.0641 30.3849L25.3284 27.4511C27.975 26.0234 29.9291 23.6609 30.7236 20.9078C31.5271 18.1218 31.115 15.2126 29.5622 12.715C28.0103 10.2184 25.504 8.43195 22.5052 7.68524C16.3153 6.14436 9.93025 9.56935 8.27145 15.3184C7.58282 17.7064 7.80059 20.2633 8.88553 22.5162C9.89102 24.6048 11.5989 26.3538 13.7207 27.483L12.9722 30.4041C12.6318 30.248 12.2963 30.081 11.9716 29.9011C11.6244 29.7094 11.1937 29.7542 10.8985 30.0107L8.57849 32.0399L4.50261 28.2544L6.68524 26.1019C6.96285 25.828 7.01092 25.4264 6.80394 25.1023C6.08663 23.9815 5.54615 22.7705 5.19909 21.5066C5.09903 21.1424 4.7606 20.8895 4.35645 20.8786L1.17324 20.79V15.4371L4.35645 15.3486C4.7606 15.3376 5.09903 15.0857 5.19909 14.7205C5.54537 13.4572 6.08588 12.2467 6.80394 11.1248C7.01092 10.8017 6.96285 10.4 6.68524 10.1253L4.50261 7.97279L8.57849 4.18723L10.8975 6.21556C11.1918 6.47299 11.6234 6.51772 11.9706 6.32602C13.1792 5.65964 14.4799 5.15849 15.8386 4.83626C16.23 4.74315 16.5017 4.42913 16.5145 4.05304L16.6135 1.09542H22.3796L22.4787 4.05304C22.4914 4.42822 22.7632 4.74315 23.1546 4.83534C24.5132 5.15758 25.813 5.65782 27.0195 6.32328C27.3668 6.51406 27.7974 6.47025 28.0917 6.21374L30.4146 4.1854L34.4915 7.97188L32.3099 10.128C32.0332 10.4019 31.9852 10.8035 32.1921 11.1267C32.9092 12.2476 33.4478 13.4553 33.794 14.716C33.8941 15.0793 34.2325 15.3321 34.6357 15.344L37.8209 15.4353V20.7909H37.8228Z">
                                            </path>
                                        </svg>
                                    </div>
                                    <span class="rs-feature-number">03</span>
                                </div>
                                <h5 class="rs-feature-title"> Achieve Goal</h5>
                                <span class="rs-feature-line"></span>
                                <p class="rs-feature-desc"> We provide a antenna base on facts hype to help with improve returns
                                    your.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- feature area end -->


    <!-- video area start -->
    <div class="rs-video-area rs-video-one rs-video-two has-padding">
        <div class="rs-video-bg-thumb include-bg" data-background="assets/images/bg/video-bg-thumb-01.webp">
        </div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-4">
                    <div class="rs-video-wrapper text-center">
                        <div class="rs-video-play-btn rs-tween_max_btn-yes gsap-move-no">
                            <a href="https://www.youtube.com/watch?v=go7QYaQR494" class="rs-play-btn popup-video is-large is-white"><i class="ri-play-large-fill"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- video area end -->

    <!-- feature area start -->
    <section class="rs-feature-area rs-feature-eleven">
        <div class="container-fluid g-0">
            <div class="row">
                <div class="col-xl-12">
                    <div class="rs-feature-wrapper">
                        <div class="rs-feature-item wow fadeIn" data-wow-delay=".1s" data-wow-duration="1s">
                            <span class="rs-feature-number">
                       Step 1
                    </span>
                            <h5 class="rs-feature-title">Consult With Us</h5>
                            <span class="rs-feature-line"></span>
                            <p class="rs-feature-desc"> problem solving, and meaningful expression. By encouraging fresh
                                ideas, embracing.</p>
                        </div>
                        <div class="rs-feature-item wow fadeIn" data-wow-delay=".2s" data-wow-duration="1s">
                            <span class="rs-feature-number">
                       Step 2
                    </span>
                            <h5 class="rs-feature-title">Personalized Plan</h5>
                            <span class="rs-feature-line"></span>
                            <p class="rs-feature-desc"> Confidence and security With trust and reliability at the core of
                                our values</p>
                        </div>
                        <div class="rs-feature-item wow fadeIn" data-wow-delay=".3s" data-wow-duration="1s">
                            <span class="rs-feature-number">
                       Step 3
                    </span>
                            <h5 class="rs-feature-title">Quick Approval</h5>
                            <span class="rs-feature-line"></span>
                            <p class="rs-feature-desc"> Fostering collaboration, driving innovation, and leading by example,
                                effective.</p>
                        </div>
                        <div class="rs-feature-item wow fadeIn" data-wow-delay=".4s" data-wow-duration="1s">
                            <span class="rs-feature-number">
                       Step 4
                    </span>
                            <h5 class="rs-feature-title">Policy Issued</h5>
                            <span class="rs-feature-line"></span>
                            <p class="rs-feature-desc"> Innovation, and build communities where people can contribute their
                                best.</p>
                        </div>
                        <div class="rs-feature-item wow fadeIn" data-wow-delay=".5s" data-wow-duration="1s">
                            <span class="rs-feature-number">
                       Step 5
                    </span>
                            <h5 class="rs-feature-title">Ongoing Support</h5>
                            <span class="rs-feature-line"></span>
                            <p class="rs-feature-desc"> Accountability is the cornerstone of trust and performance. It means
                                taking.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- feature area end -->

    <!-- testimonial area start -->
    <section class="rs-testimonial-area section-space rs-testimonial-six rs-swiper">
        <div class="container">
            <div class="row align-items-center g-5 section-title-space">
                <div class="col-xl-6 col-lg-7">
                    <div class="section-title-wrapper">
                        <span class="section-subtitle is-white">Our Clients Testimonials</span>
                        <h2 class="section-title rs-split-text-enable split-in-left mb-10 is-white">What our customers say?</h2>
                        <p class="section-desc">Find Answers to our Question about Our Consulting Coverage Options.</p>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-5">
                    <div class="rs-testimonial-counter">
                        <div class="rs-counter-item">
                            <div class="rs-counter-number-wrapper">
                                <span class="rs-counter-number odometer" data-count="98">00</span>
                                <span class="prefix">%</span>
                            </div>
                            <span class="rs-counter-title">Business Growth Rate</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12">
                    <div class="rs-testimonial-wrapper">
                        <div class="rs-testimonial-thumb rs-image scroll_reveal reveal-active" data-dir="left">
                            <img src="assets/images/about/8.webp" alt="image">
                        </div>
                        <div class="rs-testimonial-slider-wrapper">
                            <div class="swiper" data-clone-slides="false" data-loop="true" data-speed="1500" data-autoplay="true" data-dots-dynamic="false" data-effect="false" data-delay="2000" data-item="1" data-item-xl="1" data-item-lg="1" data-item-md="1" data-item-sm="1" data-item-xs="1" data-item-mobile="1" data-margin="30">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="rs-testimonial-item">
                                            <div class="rs-testimonial-top">
                                                <div class="rs-testimonial-title-info">
                                                    <h6 class="rs-testimonial-title">Assessment Solutions</h6>
                                                </div>
                                                <div class="rs-testimonial-rating-icon">
                                                    <i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i>
                                                </div>
                                            </div>
                                            <p class="rs-testimonial-desc"> “ICEF India has transformed our examination process. Their precision and technology-driven approach ensured a seamless experience for over 50,000 candidates across the state.”</p>
                                            <div class="rs-testimonial-avater-wrapper">
                                                <div class="rs-testimonial-avater-thumb">
                                                    <img src="assets/images/user/indian-user-01.png" alt="image">
                                                </div>
                                                <div class="rs-testimonial-avater-info">
                                                    <h6 class="rs-testimonial-avater-title">Rajesh Kumar</h6>
                                                    <span class="rs-testimonial-avater-designation">Managing Director</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="rs-testimonial-item">
                                            <div class="rs-testimonial-top">
                                                <div class="rs-testimonial-title-info">
                                                    <h6 class="rs-testimonial-title">Recruitment Consulting</h6>
                                                </div>
                                                <div class="rs-testimonial-rating-icon">
                                                    <i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i>
                                                </div>
                                            </div>
                                            <p class="rs-testimonial-desc"> “The quality of candidates provided by ICEF’s recruitment team is exceptional. They understand our technical requirements and cultural fit perfectly. Highly recommended for IT hiring.”</p>
                                            <div class="rs-testimonial-avater-wrapper">
                                                <div class="rs-testimonial-avater-thumb">
                                                    <img src="assets/images/user/indian-user-02.png" alt="image">
                                                </div>
                                                <div class="rs-testimonial-avater-info">
                                                    <h6 class="rs-testimonial-avater-title">Ananya Iyer</h6>
                                                    <span class="rs-testimonial-avater-designation">CTO, TechSol Chennai</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="rs-testimonial-item">
                                            <div class="rs-testimonial-top">
                                                <div class="rs-testimonial-title-info">
                                                    <h6 class="rs-testimonial-title">Workforce Management</h6>
                                                </div>
                                                <div class="rs-testimonial-rating-icon">
                                                    <i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-half-line"></i>
                                                </div>
                                            </div>
                                            <p class="rs-testimonial-desc"> “Managing a large workforce became easy with ICEF’s integrated platform. Their real-time tracking and support system increased our operational efficiency by 30%.”</p>
                                            <div class="rs-testimonial-avater-wrapper">
                                                <div class="rs-testimonial-avater-thumb">
                                                    <img src="assets/images/user/indian-user-03.png" alt="image">
                                                </div>
                                                <div class="rs-testimonial-avater-info">
                                                    <h6 class="rs-testimonial-avater-title">Sandeep Singh</h6>
                                                    <span class="rs-testimonial-avater-designation">Operations Head</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="rs-testimonial-item">
                                            <div class="rs-testimonial-top">
                                                <div class="rs-testimonial-title-info">
                                                    <h6 class="rs-testimonial-title">IT Enablement</h6>
                                                </div>
                                                <div class="rs-testimonial-rating-icon">
                                                    <i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i>
                                                </div>
                                            </div>
                                            <p class="rs-testimonial-desc"> “Their expertise in emerging technologies and digital transformation has been a game-changer for our organization. Professional, reliable, and innovative partner.”</p>
                                            <div class="rs-testimonial-avater-wrapper">
                                                <div class="rs-testimonial-avater-thumb">
                                                    <img src="assets/images/user/indian-user-04.png" alt="image">
                                                </div>
                                                <div class="rs-testimonial-avater-info">
                                                    <h6 class="rs-testimonial-avater-title">Meera Deshmukh</h6>
                                                    <span class="rs-testimonial-avater-designation">Director, HR & Ops</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="rs-testimonial-navigation rs-swiper-btn-wrapper">
                                    <div class="rs-swiper-btn swiper-button-prev has-transparent has-border"><i class="ri-arrow-left-line"></i></div>
                                    <div class="rs-swiper-btn swiper-button-next has-transparent has-border"><i class="ri-arrow-right-line"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- testimonial area end -->



    <!-- counter area start -->
    <div class="rs-counter-area section-space-bottom rs-counter-two">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="rs-counter-wrapper">
                        <div class="rs-counter-item wow fadeIn" data-wow-delay=".3s" data-wow-duration="1s">
                            <div class="rs-counter-content">
                                <div class="rs-counter-number-wrapper">
                                    <span class="rs-counter-number odometer" data-count="25.5">00</span>
                                    <span class="prefix">K</span>
                                </div>
                                <span class="rs-counter-title">Projects Completed</span>
                            </div>
                        </div>
                        <div class="rs-counter-item wow fadeIn" data-wow-delay=".5s" data-wow-duration="1s">
                            <div class="rs-counter-content">
                                <div class="rs-counter-number-wrapper">
                                    <span class="rs-counter-number odometer" data-count="10.5">00</span>
                                    <span class="prefix">K</span>
                                </div>
                                <span class="rs-counter-title">Customer Satisfaction</span>
                            </div>
                        </div>
                        <div class="rs-counter-item wow fadeIn" data-wow-delay=".7s" data-wow-duration="1s">
                            <div class="rs-counter-content">
                                <div class="rs-counter-number-wrapper">
                                    <span class="rs-counter-number odometer" data-count="1.5">00</span>
                                    <span class="prefix">K</span>
                                </div>
                                <span class="rs-counter-title">Consulting Award</span>
                            </div>
                        </div>
                        <div class="rs-counter-item wow fadeIn" data-wow-delay=".9s" data-wow-duration="1s">
                            <div class="rs-counter-content">
                                <div class="rs-counter-number-wrapper">
                                    <span class="rs-counter-number odometer" data-count="4.5">00</span>
                                    <span class="prefix">K</span>
                                </div>
                                <span class="rs-counter-title">Strategic Partners</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- counter area end -->

    <!-- faq area start -->
    <section class="rs-faq-area section-space-top theme-secondary rs-faq-two">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="rs-faq-wrapper">
                        <div class="rs-faq-content">
                            <div class="section-title-wrapper section-title-space">
                                <span class="section-subtitle is-white">
                                    Frequently asked questions
                                </span>
                                <h2 class="section-title rs-split-text-enable split-in-left is-white mb-10">Frequently asked
                                    question</h2>
                                <p class="rs-section-desc">Find answers to our question about our consulting coverage
                                    options.</p>
                            </div>
                            <div class="rs-accordion-one">
                                <div class="accordion-wrapper">
                                    <div class="accordion" id="accordionSupport">
                                        <div class="rs-accordion-item has-bg-active active">
                                            <h4 class="accordion-header" id="headingSupportOne">
                                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSupportOne" aria-expanded="true" aria-controls="collapseSupportOne">
                                                    How do your startups with product
                                                    <span class="accordion-btn"></span>
                                                </button>
                                            </h4>
                                            <div id="collapseSupportOne" class="accordion-collapse collapse show" data-bs-parent="#accordionSupport">
                                                <div class="accordion-body">Launching a startup begins with more than just an
                                                    idea it starts with creating a product that solves a real problem.
                                                </div>
                                            </div>
                                        </div>
                                        <div class="rs-accordion-item has-bg-active">
                                            <h6 class="accordion-header" id="headingSupportTwo">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSupportTwo" aria-expanded="false" aria-controls="collapseSupportTwo">
                                                    Can your with fundraising investor
                                                    <span class="accordion-btn"></span>
                                                </button>
                                            </h6>
                                            <div id="collapseSupportTwo" class="accordion-collapse collapse" data-bs-parent="#accordionSupport">
                                                <div class="accordion-body">Securing the right investment is essential for
                                                    fueling growth and scaling a business. Our fundraising approach is designed
                                                </div>
                                            </div>
                                        </div>
                                        <div class="rs-accordion-item has-bg-active">
                                            <h6 class="accordion-header" id="headingSupportThree">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSupportThree" aria-expanded="false" aria-controls="collapseSupportThree">
                                                    What makes startup consulting
                                                    <span class="accordion-btn"></span>
                                                </button>
                                            </h6>
                                            <div id="collapseSupportThree" class="accordion-collapse collapse" data-bs-parent="#accordionSupport">
                                                <div class="accordion-body">Startup consulting helps entrepreneurs turn ideas
                                                    into thriving businesses. By combining market insights, strategy, and
                                                    execution</div>
                                            </div>
                                        </div>
                                        <div class="rs-accordion-item has-bg-active">
                                            <h6 class="accordion-header" id="headingSupportFour">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSupportFour" aria-expanded="false" aria-controls="collapseSupportFour">
                                                    Do you provide financial planning
                                                    <span class="accordion-btn"></span>
                                                </button>
                                            </h6>
                                            <div id="collapseSupportFour" class="accordion-collapse collapse" data-bs-parent="#accordionSupport">
                                                <div class="accordion-body">Financial planning is the foundation of long-term
                                                    stability and growth. It helps businesses and individuals make informed</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="rs-faq-thumb">
                            <img src="assets/images/about/20.webp" alt="image">
                            <div class="rs-faq-award">
                                <div class="rs-faq-award-thumb">
                                    <img src="assets/images/shape/award-shape.webp" alt="image">
                                </div>
                                <p class="rs-faq-award-desc">we believe that every business is uniquids our approach is never
                                    one size fits all. We tailor our strategies to fit your goals hub is culture.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- faq area end -->



    <!-- blog area style override -->
    <style>
        .rs-blog-one .rs-blog-thumb {
            height: 450px !important; 
        }
        .rs-blog-one .rs-blog-content-hover .rs-blog-desc {
            margin-bottom: 30px !important;
            font-size: 14px;
            line-height: 1.4;
        }
        .rs-blog-one .rs-blog-content-hover .rs-blog-content {
            padding-top: 80px !important;
        }
        .rs-blog-one .rs-blog-content-hover .rs-blog-title {
            padding-bottom: 15px !important;
            margin-bottom: 15px !important;
            font-size: 20px;
        }
        .rs-blog-one .rs-blog-title {
            font-size: 20px;
        }
        @media only screen and (max-width: 1399px) {
            .rs-blog-one .rs-blog-wrapper {
                gap: 15px !important;
            }
            .rs-blog-one .rs-blog-thumb {
                height: 400px !important;
            }
        }
        @media only screen and (max-width: 1199px) {
            .rs-blog-one .rs-blog-wrapper {
                grid-template-columns: repeat(2, 1fr) !important;
            }
        }
        @media only screen and (max-width: 767px) {
            .rs-blog-one .rs-blog-wrapper {
                grid-template-columns: repeat(1, 1fr) !important;
            }
        }
    </style>

    <!-- blog area start -->
    <section class="rs-blog-area rs-blog-one section-space">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-7 col-lg-7">
                    <div class="section-title-wrapper text-center section-title-space">
                        <span class="section-subtitle">
                            Read Our Blog & News
                        </span>
                        <h2 class="section-title rs-split-text-enable split-in-left mb-15">Featured news and
                            insights</h2>
                        <p class="section-desc">Read and update the latest news from us. donec eu magna quis felis.
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12">
                    <div class="rs-blog-wrapper rs-swiper">
                        <div class="swiper" data-item="3" data-item-lg="3" data-item-md="2" data-item-sm="1" data-loop="true" data-autoplay="true" data-speed="1000">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="rs-blog-item wow fadeInLeft" data-wow-delay=".3s" data-wow-duration="1s">
                                        <div class="rs-blog-thumb">
                                            <img src="assets/images/blog/blog-thumb-01.webp" alt="image">
                                        </div>

                                        <div class="rs-blog-content-wrapper">
                                            <div class="rs-blog-tag">
                                                <a href="blog-details.php" class="post-tag">September 23, 2025 </a>
                                            </div>
                                            <div class="rs-blog-content">
                                                <div class="rs-blog-meta-wrapper">
                                                    <div class="rs-blog-meta-item">
                                                        <span> <i class="ri-price-tag-3-line"></i>
                                                            Corporate</span>
                                                    </div>
                                                </div>
                                                <h5 class="rs-blog-title">
                                                    <a href="blog-details.php"> Insights That Driven Business Smarter
                                                        Forward</a>
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="rs-blog-content-hover">
                                            <div class="rs-blog-content">
                                                <div class="rs-blog-meta-wrapper">
                                                    <div class="rs-blog-meta-item">
                                                        <span> <i class="ri-price-tag-3-line"></i>
                                                            Corporate</span>
                                                    </div>
                                                </div>
                                                <h5 class="rs-blog-title">
                                                    <a href="blog-details.php"> Insights That Driven Business Smarter
                                                        Forward</a>
                                                </h5>
                                                <p class="rs-blog-desc">Consulting empowers businesses with data-driven
                                                    strategies and
                                                    innovative solutions to achieve sustainable...</p>
                                                <div class="rs-blog-btn">
                                                    <a class="rs-btn has-text is-white" href="blog-details.php">Read More
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-blog-item wow fadeInLeft" data-wow-delay=".5s" data-wow-duration="1s">
                                        <div class="rs-blog-thumb">
                                            <img src="assets/images/blog/blog-thumb-02.webp" alt="image">
                                        </div>

                                        <div class="rs-blog-content-wrapper">
                                            <div class="rs-blog-tag">
                                                <a href="blog-details.php" class="post-tag">August 26, 2025</a>
                                            </div>
                                            <div class="rs-blog-content">
                                                <div class="rs-blog-meta-wrapper">
                                                    <div class="rs-blog-meta-item">
                                                        <span> <i class="ri-price-tag-3-line"></i>
                                                            Consulting</span>
                                                    </div>
                                                </div>
                                                <h5 class="rs-blog-title">
                                                    <a href="blog-details.php"> How Strategic Planning Drives Business
                                                        Success</a>
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="rs-blog-content-hover">
                                            <div class="rs-blog-content">
                                                <div class="rs-blog-meta-wrapper">
                                                    <div class="rs-blog-meta-item">
                                                        <span> <i class="ri-price-tag-3-line"></i>
                                                            Corporate</span>
                                                    </div>
                                                </div>
                                                <h5 class="rs-blog-title">
                                                    <a href="blog-details.php"> How Strategic Planning Drives Business
                                                        Success</a>
                                                </h5>
                                                <p class="rs-blog-desc">From insights to execution, we guide businesses to
                                                    smarter
                                                    decisions and better...</p>
                                                <div class="rs-blog-btn">
                                                    <a class="rs-btn has-text is-white" href="blog-details.php">Read More
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-blog-item wow fadeInLeft" data-wow-delay=".7s" data-wow-duration="1s">
                                        <div class="rs-blog-thumb">
                                            <img src="assets/images/blog/blog-thumb-03.webp" alt="image">
                                        </div>

                                        <div class="rs-blog-content-wrapper">
                                            <div class="rs-blog-tag">
                                                <a href="blog-details.php" class="post-tag">Feb 17, 2025</a>
                                            </div>
                                            <div class="rs-blog-content">
                                                <div class="rs-blog-meta-wrapper">
                                                    <div class="rs-blog-meta-item">
                                                        <span> <i class="ri-price-tag-3-line"></i>
                                                            Corporate</span>
                                                    </div>
                                                </div>
                                                <h5 class="rs-blog-title">
                                                    <a href="blog-details.php"> Planning Your Business for Long-Term Growth</a>
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="rs-blog-content-hover">
                                            <div class="rs-blog-content">
                                                <div class="rs-blog-meta-wrapper">
                                                    <div class="rs-blog-meta-item">
                                                        <span> <i class="ri-price-tag-3-line"></i>
                                                            Corporate</span>
                                                    </div>
                                                </div>
                                                <h5 class="rs-blog-title">
                                                    <a href="blog-details.php"> Planning Your Business for Long-Term Growth</a>
                                                </h5>
                                                <p class="rs-blog-desc">Consulting transforms challenges into opportunities with
                                                    tailored
                                                    solutions and proven expertise.</p>
                                                <div class="rs-blog-btn">
                                                    <a class="rs-btn has-text is-white" href="blog-details.php">Read More
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-blog-item wow fadeInLeft" data-wow-delay=".9s" data-wow-duration="1s">
                                        <div class="rs-blog-thumb">
                                            <img src="assets/images/blog/blog-thumb-04.webp" alt="image">
                                        </div>

                                        <div class="rs-blog-content-wrapper">
                                            <div class="rs-blog-tag">
                                                <a href="blog-details.php" class="post-tag">Jan 10, 2025</a>
                                            </div>
                                            <div class="rs-blog-content">
                                                <div class="rs-blog-meta-wrapper">
                                                    <div class="rs-blog-meta-item">
                                                        <span> <i class="ri-price-tag-3-line"></i>
                                                            Analysis</span>
                                                    </div>
                                                </div>
                                                <h5 class="rs-blog-title">
                                                    <a href="blog-details.php"> Mastering the Art of Market Analysis</a>
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="rs-blog-content-hover">
                                            <div class="rs-blog-content">
                                                <div class="rs-blog-meta-wrapper">
                                                    <div class="rs-blog-meta-item">
                                                        <span> <i class="ri-price-tag-3-line"></i>
                                                            Analysis</span>
                                                    </div>
                                                </div>
                                                <h5 class="rs-blog-title">
                                                    <a href="blog-details.php"> Mastering the Art of Market Analysis</a>
                                                </h5>
                                                <p class="rs-blog-desc">Understand your competitors and market trends to stay ahead of the curve and grow.</p>
                                                <div class="rs-blog-btn">
                                                    <a class="rs-btn has-text is-white" href="blog-details.php">Read More
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
                                            </div>
                                               <!-- faq area start -->
        <section class="rs-faq-area section-space rs-faq-one theme-secondary">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-faq-wrapper">
                            <div class="rs-faq-left">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle is-white">
                                        Frequently asked questions
                                    </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left is-white mb-20">
                                        Frequently Asked
                                        Question</h2>
                                    <p class="rs-section-desc">Find answers to our question about our consulting
                                        coverage
                                        options.</p>
                                </div>
                                <div class="rs-faq-contact">
                                    <div class="rs-faq-contact-info">
                                        <h5 class="rs-faq-contact-title">Still Have Questions?</h5>
                                        <p class="rs-faq-contact-desc">We're here to help you!</p>
                                    </div>
                                    <div class="rs-faq-contact-btn">
                                        <a class="rs-btn has-icon has-bg-white has-bg-secondary"
                                            href="contact.php">Contact Us
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white" />
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white" />
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-faq-right">
                                <div class="rs-faq-content rs-accordion-one">
                                    <div class="accordion-wrapper">
                                        <div class="accordion" id="accordionExampleOne">
                                            <div class="rs-accordion-item has-bg-active active">
                                                <h4 class="accordion-header" id="headingOne">
                                                    <button class="accordion-button" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseOne"
                                                        aria-expanded="true" aria-controls="collapseOne">
                                                        How do your startups with product
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h4>
                                                <div id="collapseOne" class="accordion-collapse collapse show"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Launching a startup begins with more
                                                        than just an
                                                        idea it starts with creating a product that solves a real
                                                        problem.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingTwo">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                                        aria-expanded="false" aria-controls="collapseTwo">
                                                        Can your with fundraising investor
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseTwo" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Securing the right investment is
                                                        essential for
                                                        fueling growth and scaling a business. Our fundraising approach
                                                        is designed
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingThree">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                                        aria-expanded="false" aria-controls="collapseThree">
                                                        What makes startup consulting
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseThree" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Startup consulting helps entrepreneurs
                                                        turn ideas
                                                        into thriving businesses. By combining market insights,
                                                        strategy, and
                                                        execution</div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingFour">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseFour"
                                                        aria-expanded="false" aria-controls="collapseFour">
                                                        Do you provide financial planning
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseFour" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Financial planning is the foundation of
                                                        long-term
                                                        stability and growth. It helps businesses and individuals make
                                                        informed</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- faq area end -->


</main>

<!-- main area end -->

<!-- footer area start -->
<footer class="rs-footer-area rs-footer-one theme-secondary">
    <div class="rs-footer-shape-one">
        <img src="assets/images/shape/footer-shape-01.webp" alt="image">
    </div>
    <div class="rs-footer-shape-two">
        <img src="assets/images/shape/footer-shape-02.webp" alt="image">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="rs-footer-wrapper">
                    <div class="rs-footer-left">
                        <div class="rs-footer-widget footer-1-col-1">
                            <div class="rs-footer-widget-logo">
                                <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA"></a>
                            </div>
                            <div class="rs-footer-widget-content">
                                <p class="rs-footer-widget-desc">
                                    ICEF INDIA is a premier organization providing end-to-end solutions in Assessment, Recruitment, and Workforce Development since 2000.
                                </p>
                                <div class="rs-footer-widget-contact-info">
                                    <div class="rs-footer-content-item">
                                        <span>Call us:</span>
                                        <a href="tel:+911204221735">+91 120 422 1735</a>
                                    </div>
                                    <div class="rs-footer-content-item">
                                        <span>Email:</span>
                                        <a href="mailto:sales@icefindia.in">sales@icefindia.in</a>
                                    </div>
                                    <div class="rs-footer-content-item">
                                        <span>Hours: Mon-Fri: 8.00am - 18.00pm</span>
                                    </div>
                                </div>
                                <div class="rs-footer-widget-social">
                                    <div class="rs-footer-social theme-social has-border">
                                        <a href="#"><svg width="14" height="22" viewBox="0 0 14 22" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M11.624 11.9541L12.193 8.54137L8.63572 8.54137V6.32676C8.63572 5.39311 9.13264 4.48303 10.7258 4.48303H12.343V1.57748C12.343 1.57748 10.8755 1.34692 9.47233 1.34692C6.54282 1.34692 4.62796 2.98146 4.62796 5.94041L4.62796 8.54137H1.37158L1.37158 11.9541H4.62796L4.62796 20.2041H8.63572L8.63572 11.9541H11.624Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M17.6045 5.45036C17.5641 4.53485 17.4161 3.9055 17.204 3.3601C16.9852 2.78121 16.6486 2.26294 16.2077 1.83208C15.7768 1.39452 15.2551 1.0545 14.6829 0.839154C14.1344 0.627106 13.5083 0.479009 12.5928 0.438686C11.6705 0.394863 11.3777 0.384766 9.03843 0.384766C6.69917 0.384766 6.40637 0.394863 5.48747 0.435253C4.57199 0.475643 3.94261 0.623808 3.39738 0.835721C2.81832 1.0545 2.30005 1.39108 1.86919 1.83208C1.43163 2.26291 1.09178 2.78461 0.876264 3.3568C0.664216 3.9055 0.516152 4.53148 0.475796 5.44692C0.432006 6.36927 0.421875 6.66206 0.421875 9.00132C0.421875 11.3406 0.432006 11.6334 0.472363 12.5523C0.512753 13.4678 0.660917 14.0971 0.872999 14.6425C1.09178 15.2214 1.43163 15.7397 1.86919 16.1706C2.30005 16.6081 2.82175 16.9481 3.39395 17.1635C3.94258 17.3755 4.56856 17.5236 5.4842 17.564C6.40294 17.6045 6.6959 17.6144 9.03516 17.6144C11.3744 17.6144 11.6672 17.6045 12.5861 17.564C13.5016 17.5236 14.131 17.3756 14.6762 17.1635C15.2489 16.9421 15.7689 16.6035 16.2031 16.1693C16.6372 15.7352 16.9759 15.2152 17.1973 14.6425C17.4092 14.0939 17.5574 13.4678 17.5978 12.5523C17.6382 11.6334 17.6483 11.3406 17.6483 9.00132C17.6483 6.66206 17.6449 6.36923 17.6045 5.45036ZM16.0529 12.485C16.0159 13.3264 15.8745 13.7808 15.7567 14.0837C15.4672 14.8343 14.8715 15.4301 14.1208 15.7196C13.8179 15.8374 13.3603 15.9787 12.5221 16.0157C11.6133 16.0562 11.3408 16.0662 9.04186 16.0662C6.74296 16.0662 6.46699 16.0562 5.56148 16.0157C4.72002 15.9787 4.26563 15.8374 3.96271 15.7196C3.5892 15.5815 3.24922 15.3628 2.97322 15.0767C2.68712 14.7973 2.46834 14.4607 2.33027 14.0872C2.21247 13.7842 2.07114 13.3264 2.03421 12.4884C1.99369 11.5796 1.98373 11.3069 1.98373 9.00802C1.98373 6.70911 1.99369 6.43315 2.03421 5.5278C2.07114 4.68634 2.21247 4.23196 2.33027 3.92903C2.46834 3.55535 2.68712 3.21544 2.97665 2.93937C3.25588 2.65328 3.59246 2.4345 3.96614 2.2966C4.26907 2.17879 4.72689 2.03743 5.56491 2.00037C6.47369 1.95998 6.74639 1.94988 9.04513 1.94988C11.3475 1.94988 11.62 1.95998 12.5255 2.00037C13.367 2.03746 13.8214 2.17876 14.1243 2.29656C14.4978 2.4345 14.8378 2.65328 15.1138 2.93937C15.3999 3.21877 15.6186 3.55535 15.7567 3.92903C15.8745 4.23196 16.0159 4.68961 16.0529 5.5278C16.0933 6.43658 16.1034 6.70911 16.1034 9.00802C16.1034 11.3069 16.0933 11.5762 16.0529 12.485Z"
                                                    fill="white"></path>
                                                <path
                                                    d="M9.0335 4.57741C6.58997 4.57741 4.60742 6.55982 4.60742 9.00349C4.60742 11.4472 6.58997 13.4296 9.0335 13.4296C11.4771 13.4296 13.4596 11.4472 13.4596 9.00349C13.4596 6.55982 11.4771 4.57741 9.0335 4.57741ZM9.0335 11.8746C7.44826 11.8746 6.16237 10.5889 6.16237 9.00349C6.16237 7.41811 7.44826 6.13243 9.03347 6.13243C10.6188 6.13243 11.9046 7.41811 11.9046 9.00349C11.9046 10.5889 10.6188 11.8746 9.0335 11.8746ZM14.668 4.40239C14.668 4.97303 14.2053 5.4357 13.6345 5.4357C13.0639 5.4357 12.6013 4.97303 12.6013 4.40239C12.6013 3.83167 13.0639 3.36914 13.6346 3.36914C14.2053 3.36914 14.668 3.83164 14.668 4.40239Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M9.35332 6.88729L14.6472 0.733521H13.3928L8.79603 6.07675L5.12465 0.733521H0.890137L6.44199 8.81343L0.890137 15.2666H2.1447L6.99896 9.62397L10.8762 15.2666H15.1107L9.35332 6.88729ZM7.63502 8.88462L7.0725 8.08004L2.59674 1.67793H4.52367L8.13567 6.84464L8.69818 7.64922L13.3933 14.3651H11.4664L7.63502 8.88462Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M17.7973 17.7992V11.3532C17.7973 8.18522 17.1153 5.76522 13.4193 5.76522C11.6373 5.76522 10.4493 6.73322 9.96527 7.65722H9.92126V6.05122H6.42326V17.7992H10.0753V11.9692C10.0753 10.4292 10.3613 8.95522 12.2533 8.95522C14.1233 8.95522 14.1453 10.6932 14.1453 12.0572V17.7772H17.7973V17.7992ZM0.483266 6.05122H4.13527V17.7992H0.483266V6.05122ZM2.30927 0.199219C1.14327 0.199219 0.197266 1.14522 0.197266 2.31122C0.197266 3.47722 1.14327 4.44522 2.30927 4.44522C3.47527 4.44522 4.42127 3.47722 4.42127 2.31122C4.42127 1.14522 3.47527 0.199219 2.30927 0.199219Z"
                                                    fill="white"></path>
                                            </svg></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rs-footer-right">
                        <div class="rs-footer-widget-wrapper">
                            <div class="rs-footer-widget footer-1-col-2">
                                <h5 class="rs-footer-widget-title">About​</h5>
                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="industry-clients.php">Industry we work with</a></li>
                                        <li><a href="why-choose-us.php">Why choose us</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                        <li><a href="contact.php">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rs-footer-widget footer-1-col-3">
                                <h5 class="rs-footer-widget-title">Services</h5>
                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="it-emerging-tech-enablement.php">IT & Emerging Tech Enablement</a></li>
                                        <li><a href="assessment-and-testing.php">Assessment & Testing</a></li>
                                        <li><a href="recruitment-and-hiring.php">Recruitment & Hiring</a></li>
                                        <li><a href="exam-management.php">Exam Management</a></li>
                                        <li><a href="manpower-and-workforce.php">Manpower & Workforce</a></li>
                                        <li><a href="call-center-and-bpos.php">Call Center & BPOs</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rs-footer-widget footer-1-col-4">
                                <h5 class="rs-footer-widget-title">Quick Links</h5>

                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="#solutions">Our Solutions</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                        <li><a href="industry-clients.php#clients">Clientele</a></li>
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="rs-footer-subscribe-from">
                            <h5 class="rs-footer-subscribe-title">Subscribe Newsletter</h5>
                            <div class="rs-cta-input">
                                <input id="email2" name="name" type="text" placeholder="Enter your email">
                                <button type="submit" class="rs-btn has-icon has-bg-secondary has-sm-radius">
                                    Send Now
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white"></path>
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white"></path>
                                        </svg>
                                    </span>
                                </button>
                            </div>
                        </div>
                        <div class="rs-footer-brand">
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-07.webp" alt="image">
                            </div>
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-08.webp" alt="image">
                            </div>
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-09.webp" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="rs-footer-copyright-area rs-copyright-one">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="rs-footer-copyright-wrapper">
                        <div class="rs-footer-copyright-left">
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright-link">
                                    <a href="terms-conditions.php">Terms & Agreements</a>
                                </div>
                            </div>
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright-link">
                                    <a href="privacy-policy.php">Privacy policy</a>
                                </div>
                            </div>
                        </div>
                        <div class="rs-footer-copyright-right">
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright">
                                    <p class="underline">Copyright © <span id="year">2025</span> ICEF INDIA. All rights reserved. Designed by <a
                                            target="_blank" href="https://agumentiksoftware.com/">AGUMENTIK.</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer area end -->
    <!-- back to top -->
    <!-- Backtotop start -->
    <div class="backtotop-wrap cursor-pointer">
        <i class="ri-arrow-up-s-line"></i>
    </div>
    <!-- Backtotop end -->

    <!-- JS here -->
    <script src="assets/js/vendor/jquery-3.7.1.min.js"></script>
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/meanmenu@2.0.8/jquery.meanmenu.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/wowjs@1.1.3/dist/wow.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/magnific-popup@1.1.0/dist/jquery.magnific-popup.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/isotope-layout@3.0.6/dist/isotope.pkgd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/imagesloaded@5.0.0/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/vendor/ajax-form.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@studio-freight/lenis@1.0.34/dist/lenis.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
    <script src="assets/js/plugins/rs-scroll-trigger.min.js"></script>
    <script src="assets/js/plugins/rs-splitText.min.js"></script>
    <!-- Custom theme scripts (Restored) -->
    <script src="assets/js/plugins/rs-anim-int.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery.appear@1.0.1/jquery.appear.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-nice-select@1.1.0/js/jquery.nice-select.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/nouislider@15.7.1/dist/nouislider.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/odometer@0.4.8/odometer.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>
