<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="template-version" content="1.0.0">
    <title>About ICEF India, Mission & Vision - ICEF INDIA    </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/favicon-icef.png">
    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/animate.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="assets/css/plugins/flatpickr.min.css">
    <link rel="stylesheet" href="assets/css/plugins/nouislider.min.css">
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/vendor/odometer.min.css">
    <link rel="stylesheet" href="assets/css/vendor/spacing.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css">
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        /* =============================================
           Banner Contact Form — Form Overlaps Girl Image
        ============================================= */

        /* Right column: position:relative so the form can be overlaid */
        .rs-banner-form-wrap {
            position: relative;
            display: block;
        }

        /* Girl image: fully visible, natural width, drives wrapper height */
        .rs-banner-bg-img {
            display: block;
            width: 100%;
            height: auto;
            object-fit: cover;
            object-position: top center;
            opacity: 1;
            position: relative;
            z-index: 0;
        }

        /* Form card: positioned absolutely, centred over the girl image */
        .rs-banner-contact-form {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 3;
            background: #ffffff;
            border-radius: 8px;
            padding: 28px 24px;
            width: calc(100% - 60px);
            max-width: 400px;
            box-shadow: 0 8px 40px rgba(0, 0, 0, 0.28);
        }

        .rs-form-title {
            font-size: 20px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 4px;
            line-height: 1.3;
        }

        .rs-form-subtitle {
            font-size: 12px;
            color: #888;
            margin-bottom: 14px;
        }

        .rs-contact-form-banner .rs-form-row {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }

        .rs-contact-form-banner .rs-form-group {
            flex: 1 1 0%;
            min-width: 0;
            display: flex;
            flex-direction: column;
        }

        .rs-contact-form-banner .rs-form-group-full {
            flex: 1 1 100%;
        }

        .rs-contact-form-banner input,
        .rs-contact-form-banner select,
        .rs-contact-form-banner .nice-select,
        .rs-contact-form-banner textarea {
            width: 100% !important;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            font-size: 14px;
            color: #444;
            background: #fff !important;
            background-image: none !important;
            outline: none;
            transition: border-color 0.3s;
            font-family: inherit;
            appearance: none !important;
            -webkit-appearance: none !important;
            -moz-appearance: none !important;
            box-sizing: border-box;
        }

        .rs-contact-form-banner input,
        .rs-contact-form-banner select,
        .rs-contact-form-banner .nice-select {
            height: 45px !important;
            padding: 0 12px;
            line-height: 43px; /* adjusted for border */
        }

        .rs-contact-form-banner .nice-select {
            display: flex;
            align-items: center;
            float: none;
        }

        .rs-contact-form-banner .nice-select .current {
            display: block;
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            padding-right: 20px;
        }

        .rs-contact-form-banner .nice-select:after {
            content: "" !important;
            border-bottom: 2px solid #AB052D;
            border-right: 2px solid #AB052D;
            height: 8px;
            width: 8px;
            right: 15px;
            top: 40%; 
            transform: rotate(45deg);
        }

        .rs-contact-form-banner input::placeholder,
        .rs-contact-form-banner textarea::placeholder {
            color: #aaa;
        }

        .rs-contact-form-banner input:focus,
        .rs-contact-form-banner select:focus,
        .rs-contact-form-banner .nice-select:focus,
        .rs-contact-form-banner textarea:focus {
            border-color: #AB052D;
        }

        .rs-contact-form-banner select {
            cursor: pointer;
            color: #aaa;
        }

        .rs-contact-form-banner select option:not([disabled]) {
            color: #444;
        }

        .rs-contact-form-banner textarea {
            height: 120px !important;
            padding: 12px;
            resize: none;
            line-height: normal;
        }

        /* Button: maroon matching the site header */
        .rs-banner-form-btn {
            width: 100%;
            background: #AB052D;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 12px;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 1.5px;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            text-transform: uppercase;
        }

        .rs-banner-form-btn:hover {
            background: #8c0424;
            transform: translateY(-1px);
        }

        /* Banner left content: nudge right so it's not touching the left edge */
        .rs-banner-area .rs-banner-content {
            padding-left: 60px;
        }

        /* Hero Left Button: make it maroon */
        .rs-banner-area .rs-banner-content .rs-btn {
            background-color: #AB052D;
            border-color: #AB052D;
        }

        .rs-banner-area .rs-banner-content .rs-btn:hover {
            background-color: #8c0424;
            border-color: #8c0424;
        }

        /* ---- Responsive overrides ---- */
        @media (max-width: 1399px) {
            .rs-banner-area .rs-banner-content { padding-left: 40px; }
        }

        @media (max-width: 1199px) {
            .rs-banner-area .rs-banner-content { padding-left: 24px; }
        }

        @media (max-width: 991px) {
            .rs-banner-area .rs-banner-content { padding-left: 16px; }

            .rs-banner-contact-form {
                position: relative;
                top: auto;
                left: auto;
                transform: none;
                width: 100%;
                max-width: 100%;
                margin-top: 20px;
            }

            .rs-contact-form-banner .rs-form-row {
                flex-direction: column;
                gap: 10px;
            }
        }

        /* =============================================
           Glass Effect — Transparent Header over Banner
        ============================================= */
        @media (min-width: 992px) {

            /* Overlay Header Container — only for main header, not sticky */
            .rs-header-area.header-transparent:not(.rs-sticky-header) {
                position: absolute;
                width: 100%;
                top: 40px; /* leave space for the Top Red Bar */
                left: 0;
                z-index: 1000;
                background: transparent;
            }

            /* Top Red Bar */
            .header-transparent-parent .rs-header-top {
                background: #AB052D !important;
                position: relative;
                z-index: 1002;
                height: 40px;
                display: flex !important;
                align-items: center;
            }

            /* Sticky header — glass while not yet active */
            .header-transparent.rs-sticky-header:not(.active) {
                background: rgba(43, 57, 68, 0.4) !important;
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                position: fixed;
                width: 100%;
                top: -100px;
                z-index: 1001;
                visibility: hidden;
                opacity: 0;
                pointer-events: none;
                transition: all 0.4s ease;
            }

            /* Sticky header — fully visible when active */
            .header-transparent.rs-sticky-header.active {
                background: var(--rs-theme-secondary) !important;
                backdrop-filter: none;
                -webkit-backdrop-filter: none;
                top: 0 !important;
                position: fixed;
                width: 100%;
                visibility: visible;
                opacity: 1;
                pointer-events: auto;
            }
        }

        /* Mobile Menu Fix: hide desktop nav on small screens */
        @media (max-width: 1199px) {
            .header-menu,
            .main-menu,
            #mobile-menu,
            #mobile-menu-two {
                display: none !important;
            }
        }
    </style>
</head>

<body class="rs-smoother-yes">

        <!-- preloader start -->
    <div id="pre-load">
        <div id="loader" class="loader">
            <div class="loader-container">
                <div class="loader-icon"><img src="assets/images/logo/favicon-icef.png" alt="ICEF INDIA"></div>
            </div>
        </div>
    </div>
    <!-- preloader end -->

    <!-- preloader start -->

    <div id="rs-mouse">
        <div id="cursor-ball"></div>
    </div>

    <!-- preloader end -->

    <style>
        /* Custom Mega Menu for Solutions with Feature Image */
        .main-menu .mega-grid-two {
            grid-template-columns: repeat(6, 1fr) 300px !important;
            width: 1550px !important;
            padding: 0 !important;
            overflow: hidden;
            border-radius: 10px !important;
            background-color: var(--rs-theme-secondary) !important;
        }

        @media only screen and (max-width: 1600px) {
            .main-menu .mega-grid-two {
                width: 1350px !important;
                grid-template-columns: repeat(6, 1fr) 250px !important;
            }
        }

        @media only screen and (max-width: 1366px) {
            .main-menu .mega-grid-two {
                width: 1180px !important;
                grid-template-columns: repeat(5, 1fr) !important;
            }
            .mega-menu-feature {
                display: none !important; /* Hide feature on smaller screens to keep navigation clear */
            }
        }

        .main-menu .mega-grid-one > li, .main-menu .mega-grid-two > li {
            padding: 30px 20px !important;
            border-right: 1px solid rgba(255, 255, 255, 0.1) !important;
            position: relative;
        }

        .main-menu .mega-grid-one > li::before, .main-menu .mega-grid-two > li::before {
            content: none !important;
        }

        .main-menu .mega-grid-two > li:last-child {
            border-right: none !important;
        }

        .mega-menu-feature {
            background-color: #243039 !important;
            padding: 40px 30px !important;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
        }

        .mega-menu-feature h6.title {
            color: #AB052D !important;
            font-size: 20px !important;
            margin-bottom: 12px !important;
            font-weight: 700 !important;
            text-transform: capitalize !important;
        }

        .mega-menu-feature p {
            font-size: 14px !important;
            line-height: 1.5 !important;
            color: rgba(255, 255, 255, 0.7) !important;
            margin-bottom: 20px !important;
            white-space: normal !important;
        }

        .mega-menu-feature .feature-thumb {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
        }

        .mega-menu-feature .feature-thumb img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            transition: all 0.4s ease;
        }
        
        .mega-menu-feature:hover .feature-thumb img {
            transform: scale(1.05);
        }

        /* FAQ Section Image Resizing */
        .rs-faq-two .rs-faq-wrapper {
            grid-template-columns: 1fr 480px !important;
            gap: 30px 60px !important;
            align-items: flex-start !important;
        }
        .rs-faq-two .rs-faq-thumb {
            width: 100% !important;
            max-width: 480px !important;
        }
        .rs-faq-two .rs-faq-thumb > img {
            height: 500px !important;
            object-fit: cover !important;
            border-radius: 10px !important;
        }
        .rs-faq-two .rs-faq-award {
            width: auto !important;
            max-width: 360px !important;
            padding: 15px 20px !important;
            bottom: 15px !important;
            inset-inline-start: auto !important;
            inset-inline-end: 15px !important;
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 8px !important;
            background: rgba(255, 255, 255, 0.08) !important;
            background-image: none !important;
            backdrop-filter: blur(12px) !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
        }
        .rs-faq-award-thumb {
            display: none !important;
        }
        .rs-faq-two .rs-faq-award-desc {
            font-size: 13px !important;
            line-height: 1.4 !important;
            margin-bottom: 0 !important;
            border-inline-start: none !important;
            padding-inline-start: 0 !important;
            margin-inline-start: 0 !important;
        }
        @media only screen and (max-width: 1366px) {
            .rs-faq-two .rs-faq-wrapper {
                grid-template-columns: 1fr 400px !important;
            }
            .rs-faq-two .rs-faq-thumb > img {
                height: 450px !important;
            }
        }
        @media only screen and (max-width: 991px) {
            .rs-faq-two .rs-faq-wrapper {
                grid-template-columns: 1fr !important;
            }
            .rs-faq-two .rs-faq-thumb {
                max-width: 100% !important;
            }
        }



        /* Submenu adjustments */
        .main-menu .submenu {
            width: max-content !important;
            min-width: 140px !important;
            max-width: 350px !important;
        }

        .main-menu .submenu li {
            padding-inline-start: 20px !important;
            padding-inline-end: 15px !important;
        }

        .main-menu .submenu li a {
            white-space: nowrap !important;
        }

        /* Mega menu column titles and links */
        .main-menu .mega-grid-two > li .title {
            color: #ffffff !important;
            margin-bottom: 15px !important;
            display: block !important;
        }

        .main-menu .mega-grid-two > li ul li a {
            color: rgba(255, 255, 255, 0.7) !important;
            padding: 5px 0 !important;
        }

        .main-menu .mega-grid-two > li ul li a:hover {
            color: var(--rs-theme-primary) !important;
            padding-left: 5px !important;
        }

        /* Feature Button Styling */
        .mega-menu-feature .rs-btn {
            background-color: var(--rs-theme-primary) !important;
            color: #ffffff !important;
            padding: 14px 28px !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            border-radius: 6px !important;
            font-size: 14px !important;
            font-weight: 700 !important;
            width: fit-content !important;
            height: auto !important;
            line-height: 1 !important;
            margin-bottom: 20px !important;
        }

        .mega-menu-feature .rs-btn:hover {
            background-color: #ffffff !important;
            color: var(--rs-theme-primary) !important;
        }

        /* Sticky Header Styles */
        .rs-sticky-header.active {
            background: var(--rs-theme-secondary) !important;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            top: 0 !important;
        }

        .rs-sticky-header .header-logo img {
            max-height: 50px;
            width: auto;
        }

        .rs-sticky-header .header-wrapper {
            background: transparent !important;
            padding-top: 10px;
            padding-bottom: 10px;
        }

        /* Bridge the gap to prevent dropdown closing when moving mouse from link to menu */
        .main-menu li {
            position: relative;
        }

        .main-menu .submenu,
        .main-menu .mega-menu {
            position: absolute;
            background-color: var(--rs-theme-secondary);
            z-index: 99;
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
            /* Professional transition with slight delay for closing to make it more stable and forgiving */
            transition: opacity 0.3s ease, transform 0.3s ease, visibility 0.3s ease !important;
            transition-delay: 0.2s !important;
        }

        .main-menu li:hover > .submenu,
        .main-menu li:hover > .mega-menu {
            opacity: 1;
            visibility: visible;
            pointer-events: all;
            transition-delay: 0s !important;
        }

        /* The Bridge: Invisible pseudo-element to close the physical gap between link and menu */
        .main-menu .submenu::before,
        .main-menu .mega-menu::before {
            content: "";
            position: absolute;
            top: -50px; /* Ample space to bridge any gap */
            left: 0;
            right: 0;
            height: 50px;
            background: transparent;
            z-index: 10;
            pointer-events: auto !important; /* Forces hover capture in the gap */
        }

        /* More persistent hover colors */
        .main-menu ul li:hover > a {
            color: var(--rs-theme-primary) !important;
        }
    </style>

    <!-- header area start-->
    <header>
        <div class="container-fluid g-0">
            <!-- top start -->
            <div class="rs-header-top rs-header-top-one">
                <div class="header-top-left">
                    <span class="header-top-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="6" height="11" viewBox="0 0 6 11" fill="none">
                            <path
                                d="M0.50204 0.439454C0.811629 0.16438 1.28548 0.192407 1.56063 0.501954L5.56063 5.00195C5.81308 5.28608 5.81308 5.71392 5.56063 5.99805L1.56063 10.498C1.28548 10.8076 0.811629 10.8356 0.50204 10.5605C0.192493 10.2854 0.164466 9.81154 0.43954 9.50195L3.99618 5.5L0.43954 1.49805C0.164466 1.18846 0.192493 0.714606 0.50204 0.439454Z"
                                fill="#AB052D"></path>
                        </svg>
                    </span>
                    <div class="header-top-content">
                        <p>India's Leading Integrated Assessment & Recruitment Platform Since 2000.
                            <a href="about-mission.php">Learn More</a>
                        </p>
                    </div>
                </div>
                <div class="header-top-right">
                    <div class="header-top-meta">
                        <span class="header-top-meta-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
                                <path
                                    d="M12.1641 10.5834C11.6414 10.0673 10.9888 10.0673 10.4694 10.5834C10.0732 10.9762 9.67699 11.3691 9.28744 11.7686C9.1809 11.8785 9.091 11.9018 8.96115 11.8286C8.70479 11.6887 8.43177 11.5755 8.18539 11.4224C7.03673 10.6999 6.07452 9.77097 5.22218 8.72552C4.79934 8.20613 4.42312 7.65011 4.16009 7.02417C4.10682 6.89765 4.11681 6.81442 4.22002 6.7112C4.61622 6.32832 5.00244 5.93544 5.39198 5.54257C5.93469 4.99654 5.93469 4.35728 5.38866 3.80792C5.07902 3.49495 4.76938 3.18865 4.45974 2.87568C4.14011 2.55605 3.82381 2.23309 3.50086 1.9168C2.97813 1.40739 2.32556 1.40739 1.80617 1.92012C1.40663 2.313 1.02375 2.71586 0.617555 3.10208C0.241327 3.45833 0.0515486 3.89449 0.0115952 4.40389C-0.0516643 5.23293 0.151432 6.01535 0.437765 6.77779C1.02375 8.35595 1.91604 9.75765 2.99811 11.0428C4.45974 12.7808 6.20437 14.1558 8.24532 15.148C9.16425 15.5942 10.1165 15.9371 11.1519 15.9937C11.8644 16.0337 12.4837 15.8539 12.9798 15.2979C13.3194 14.9183 13.7023 14.572 14.0619 14.2091C14.5946 13.6697 14.5979 13.0172 14.0685 12.4845C13.4359 11.8485 12.8 11.2159 12.1641 10.5834Z"></path>
                                <path
                                    d="M11.5271 7.92979L12.7557 7.72003C12.5625 6.59135 12.0298 5.56921 11.2208 4.75682C10.3651 3.90116 9.28304 3.36178 8.0911 3.19531L7.91797 4.43054C8.84023 4.56039 9.67925 4.97657 10.3418 5.63913C10.9677 6.26506 11.3773 7.05747 11.5271 7.92979Z"></path>
                                <path
                                    d="M13.4493 2.59031C12.0309 1.17197 10.2363 0.276344 8.25531 0L8.08218 1.23523C9.79352 1.47495 11.345 2.25071 12.5703 3.47262C13.7323 4.63459 14.4947 6.10288 14.771 7.71766L15.9996 7.50791C15.6767 5.63676 14.7943 3.93874 13.4493 2.59031Z"></path>
                            </svg>
                        </span>
                        <div class="header-top-meta-content">
                            <span>Call us:</span>
                            <a href="tel:+911204221735">+91 120 422 1735</a>
                        </div>
                    </div>
                    <div class="header-top-meta">
                        <span class="header-top-meta-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"
                                fill="none">
                                <g clip-path="url(#clip0_28535_99)">
                                    <path
                                        d="M15.8603 3.17969L11.0078 8.00091L15.8603 12.8221C15.948 12.6388 16.0012 12.4361 16.0012 12.2197V3.78216C16.0012 3.56569 15.948 3.36303 15.8603 3.17969Z"
                                        fill="white"></path>
                                    <path
                                        d="M14.5947 2.375H1.40716C1.19069 2.375 0.988031 2.42822 0.804688 2.51594L7.00666 8.68666C7.55503 9.23503 8.44678 9.23503 8.99516 8.68666L15.1971 2.51594C15.0138 2.42822 14.8111 2.375 14.5947 2.375Z"
                                        fill="white"></path>
                                    <path
                                        d="M0.140938 3.17969C0.0532188 3.36303 0 3.56569 0 3.78216V12.2197C0 12.4361 0.0532188 12.6388 0.140938 12.8221L4.99341 8.00091L0.140938 3.17969Z"
                                        fill="white"></path>
                                    <path
                                        d="M10.3447 8.66211L9.658 9.34877C8.74428 10.2625 7.2575 10.2625 6.34378 9.34877L5.65716 8.66211L0.804688 13.4833C0.988031 13.571 1.19069 13.6243 1.40716 13.6243H14.5947C14.8111 13.6243 15.0138 13.571 15.1971 13.4833L10.3447 8.66211Z"
                                        fill="white"></path>
                                </g>
                                <defs>
                                    <clipPath id="clip0_28535_99">
                                        <rect width="16" height="16" fill="white"></rect>
                                    </clipPath>
                                </defs>
                            </svg>
                        </span>
                        <div class="header-top-meta-content">
                            <span>Send mail:</span>
                            <a href="mailto:sales@icefindia.in">
                                sales@icefindia.in
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- top end -->
        </div>

        
        <div class="rs-header-area rs-header-one ">
                    <div class="container-fluid g-0">
            <div class="header-wrapper">
                <div class="header-left">
                    <div class="header-logo">
                        <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA - Integrated Assessment & Recruitment Platform"></a>
                    </div>
                </div>
                <div class="header-right">
                    <div class="header-menu">
                        <nav id="mobile-menu-two" class="main-menu">
                            <ul class="multipage-menu">
                                <li><a href="index.php">Home</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">About Company</a>
                                    <ul class="submenu last-children">
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="about-mission.php#mission">Mission & Vision</a></li>
                                        <li><a href="industry-clients.php">Industry We Work With</a></li>
                                        <li><a href="industry-clients.php#clients">Client Tele</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                        <li><a href="careers-culture.php">Work Culture</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children rs-mega-menu">
                                    <a href="javascript:void(0)">Solutions</a>
                                    <ul class="mega-menu mega-grid-two">
                                        <li class="rs-menu-item" data-image="assets/images/solution/it-emerging.webp">
                                            <a href="it-emerging-tech-enablement.php" class="title">IT & Emerging Tech Enablement</a>
                                            <ul>
                                                <li data-image="assets/images/solution/iot.webp"><a href="iot-and-rfid.php">IOT & RFID Based Products</a></li>
                                                <li data-image="assets/images/solution/app-dev.webp"><a href="application-development.php">Application Development</a></li>
                                                <li data-image="assets/images/solution/software-dev.webp"><a href="customized-software-development.php">Customized Software Development</a></li>
                                                <li data-image="assets/images/solution/emerging-tech.webp"><a href="emerging-tech.php">Emerging Tech</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/assessment-testing.webp">
                                            <a href="assessment-and-testing.php" class="title">Assessment & Testing</a>
                                            <ul>
                                                <li data-image="assets/images/solution/cognitive-domain.webp"><a href="cognitive-domain.php">Cognitive/Domain</a></li>
                                                <li data-image="assets/images/solution/online-offline.webp"><a href="online-offline.php">Online/Offline</a></li>
                                                <li data-image="assets/images/solution/proctoring.webp"><a href="proctoring.php">Proctoring</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/recruitment.webp">
                                            <a href="recruitment-and-hiring.php" class="title">Recruitment & Hiring</a>
                                            <ul>
                                                <li data-image="assets/images/about/33.webp"><a href="screening.php">Screening</a></li>
                                                <li data-image="assets/images/about/37.webp"><a href="assessments.php">Assessments</a></li>
                                                <li data-image="assets/images/solution/merit-list.webp"><a href="merit-lists.php">Merit Lists</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/exam-management.webp">
                                            <a href="exam-management.php" class="title">Exam Management</a>
                                            <ul>
                                                <li data-image="assets/images/solution/question-banks.webp"><a href="question-banks.php">Question Banks</a></li>
                                                <li data-image="assets/images/solution/exam-conduct.webp"><a href="exam-conduct.php">Conduct</a></li>
                                                <li data-image="assets/images/solution/processing.webp"><a href="exam-processing.php">Processing</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/manpower-workforce.webp">
                                            <a href="manpower-and-workforce.php" class="title">Manpower & Workforce</a>
                                            <ul>
                                                <li data-image="assets/images/solution/outsourcing.webp"><a href="outsourcing.php">Outsourcing</a></li>
                                                <li data-image="assets/images/about/31.webp"><a href="staffing.php">Staffing</a></li>
                                                <li data-image="assets/images/solution/deployment.webp"><a href="deployment.php">Deployment</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/call-center.webp">
                                            <a href="call-center-and-bpos.php" class="title">Call Center & BPOs</a>
                                            <ul>
                                                <li data-image="assets/images/solution/inbound.webp"><a href="inbound-outbound.php">Inbound/Outbound</a></li>
                                                <li data-image="assets/images/solution/support.webp"><a href="support.php">Support</a></li>
                                                <li data-image="assets/images/solution/telecalling.webp"><a href="tele-calling.php">Tele-Calling</a></li>
                                            </ul>
                                        </li>
                                        <li class="mega-menu-feature">
                                            <div class="mega-feature-content">
                                                <h6 class="title">Let's Talk Business</h6>
                                                <p>Empowering businesses with smart IT solutions since 2000.</p>
                                                <a href="support.php" class="rs-btn has-icon has-md-radius hover-primary">Request Quote</a>
                                                <div class="feature-thumb mt-20">
                                                    <img id="mega-menu-target-img" src="assets/images/mega-menu-feature.png" alt="Consultation">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="why-choose-us.php">Why Choose Us</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">WhiteBoard</a>
                                    <ul class="submenu last-children">
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="faq.php">FAQs</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                    </ul>
                                </li>
                                
                                
                                <li><a href="contact.php">Support</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="header-content">
                        <div class="header-btn">
                            <a class="rs-btn has-icon is-transparent hover-primary border-hover-primary" href="contact.php">Get Free Quote</a>
                        </div>
                        <div class="header-search-wrapper">
                            <div class="header-search-icon"><i class="ri-search-line"></i></div>
                        </div>
                        <div class="header-hamburger">
                            <div class="sidebar-toggle">
                                <a class="header-bar-icon" href="javascript:void(0)"><span></span><span></span><span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                </div>

        <div id="rs-sticky-header" class="rs-sticky-header rs-header-area rs-header-one ">
                    <div class="container-fluid g-0">
            <div class="header-wrapper">
                <div class="header-left">
                    <div class="header-logo">
                        <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA - Integrated Assessment & Recruitment Platform"></a>
                    </div>
                </div>
                <div class="header-right">
                    <div class="header-menu">
                        <nav id="mobile-menu-two" class="main-menu">
                            <ul class="multipage-menu">
                                <li><a href="index.php">Home</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">About Company</a>
                                    <ul class="submenu last-children">
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="about-mission.php#mission">Mission & Vision</a></li>
                                        <li><a href="industry-clients.php">Industry We Work With</a></li>
                                        <li><a href="industry-clients.php#clients">Client Tele</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                        <li><a href="careers-culture.php">Work Culture</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children rs-mega-menu">
                                    <a href="javascript:void(0)">Solutions</a>
                                    <ul class="mega-menu mega-grid-two">
                                        <li class="rs-menu-item" data-image="assets/images/solution/it-emerging.webp">
                                            <a href="it-emerging-tech-enablement.php" class="title">IT & Emerging Tech Enablement</a>
                                            <ul>
                                                <li data-image="assets/images/solution/iot.webp"><a href="iot-and-rfid.php">IOT & RFID Based Products</a></li>
                                                <li data-image="assets/images/solution/app-dev.webp"><a href="application-development.php">Application Development</a></li>
                                                <li data-image="assets/images/solution/software-dev.webp"><a href="customized-software-development.php">Customized Software Development</a></li>
                                                <li data-image="assets/images/solution/emerging-tech.webp"><a href="emerging-tech.php">Emerging Tech</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/assessment-testing.webp">
                                            <a href="assessment-and-testing.php" class="title">Assessment & Testing</a>
                                            <ul>
                                                <li data-image="assets/images/solution/cognitive-domain.webp"><a href="cognitive-domain.php">Cognitive/Domain</a></li>
                                                <li data-image="assets/images/solution/online-offline.webp"><a href="online-offline.php">Online/Offline</a></li>
                                                <li data-image="assets/images/solution/proctoring.webp"><a href="proctoring.php">Proctoring</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/recruitment.webp">
                                            <a href="recruitment-and-hiring.php" class="title">Recruitment & Hiring</a>
                                            <ul>
                                                <li data-image="assets/images/about/33.webp"><a href="screening.php">Screening</a></li>
                                                <li data-image="assets/images/about/37.webp"><a href="assessments.php">Assessments</a></li>
                                                <li data-image="assets/images/solution/merit-list.webp"><a href="merit-lists.php">Merit Lists</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/exam-management.webp">
                                            <a href="exam-management.php" class="title">Exam Management</a>
                                            <ul>
                                                <li data-image="assets/images/solution/question-banks.webp"><a href="question-banks.php">Question Banks</a></li>
                                                <li data-image="assets/images/solution/exam-conduct.webp"><a href="exam-conduct.php">Conduct</a></li>
                                                <li data-image="assets/images/solution/processing.webp"><a href="exam-processing.php">Processing</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/manpower-workforce.webp">
                                            <a href="manpower-and-workforce.php" class="title">Manpower & Workforce</a>
                                            <ul>
                                                <li data-image="assets/images/solution/outsourcing.webp"><a href="outsourcing.php">Outsourcing</a></li>
                                                <li data-image="assets/images/about/31.webp"><a href="staffing.php">Staffing</a></li>
                                                <li data-image="assets/images/solution/deployment.webp"><a href="deployment.php">Deployment</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/call-center.webp">
                                            <a href="call-center-and-bpos.php" class="title">Call Center & BPOs</a>
                                            <ul>
                                                <li data-image="assets/images/solution/inbound.webp"><a href="inbound-outbound.php">Inbound/Outbound</a></li>
                                                <li data-image="assets/images/solution/support.webp"><a href="support.php">Support</a></li>
                                                <li data-image="assets/images/solution/telecalling.webp"><a href="tele-calling.php">Tele-Calling</a></li>
                                            </ul>
                                        </li>
                                        <li class="mega-menu-feature">
                                            <div class="mega-feature-content">
                                                <h6 class="title">Let's Talk Business</h6>
                                                <p>Empowering businesses with smart IT solutions since 2000.</p>
                                                <a href="support.php" class="rs-btn has-icon has-md-radius hover-primary">Request Quote</a>
                                                <div class="feature-thumb mt-20">
                                                    <img id="mega-menu-target-img" src="assets/images/mega-menu-feature.png" alt="Consultation">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="why-choose-us.php">Why Choose Us</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">WhiteBoard</a>
                                    <ul class="submenu last-children">
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="faq.php">FAQs</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                    </ul>
                                </li>
                                
                                
                                <li><a href="contact.php">Support</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="header-content">
                        <div class="header-btn">
                            <a class="rs-btn has-icon is-transparent hover-primary border-hover-primary" href="contact.php">Get Free Quote</a>
                        </div>
                        <div class="header-search-wrapper">
                            <div class="header-search-icon"><i class="ri-search-line"></i></div>
                        </div>
                        <div class="header-hamburger">
                            <div class="sidebar-toggle">
                                <a class="header-bar-icon" href="javascript:void(0)"><span></span><span></span><span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                </div>
    </header>
    <!-- Header area end -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const targetImg = document.getElementById('mega-menu-target-img');
            if (!targetImg) return;

            const globalDefaultImg = targetImg.getAttribute('src');
            let defaultImg = globalDefaultImg;
            const menuItems = document.querySelectorAll('.rs-mega-menu .mega-menu [data-image]');

            // Detect active page and set its image as default
            const currentPath = window.location.pathname;
            document.querySelectorAll('.rs-mega-menu .mega-menu .rs-menu-item').forEach(item => {
                const links = item.querySelectorAll('a');
                links.forEach(link => {
                    const href = link.getAttribute('href');
                    if (href && href !== '#' && currentPath.endsWith(href)) {
                        const activeImg = link.parentElement.getAttribute('data-image') || item.getAttribute('data-image');
                        if (activeImg) {
                            defaultImg = activeImg;
                            targetImg.setAttribute('src', activeImg);
                        }
                    }
                });
            });

            menuItems.forEach(item => {
                item.addEventListener('mouseenter', function(e) {
                    e.stopPropagation();
                    const newImg = this.getAttribute('data-image');
                    if (newImg && targetImg.getAttribute('src') !== newImg) {
                        targetImg.style.opacity = '0';
                        setTimeout(() => {
                            targetImg.setAttribute('src', newImg);
                            targetImg.style.opacity = '1';
                        }, 200);
                    }
                });
            });

            // Revert to default when leaving the entire mega menu grid
            const megaGrid = document.querySelector('.mega-grid-two');
            if (megaGrid) {
                megaGrid.addEventListener('mouseleave', function() {
                    targetImg.style.opacity = '0';
                    setTimeout(() => {
                        targetImg.setAttribute('src', defaultImg);
                        targetImg.style.opacity = '1';
                    }, 200);
                });
            }
        });
    </script>
    <style>
        #mega-menu-target-img {
            transition: opacity 0.3s ease;
        }
    </style>

        <!-- Offcanvas area start -->
    <div class="fix">
        <div class="offcanvas-area" data-lenis-prevent>
            <div class="offcanvas-wrapper">
                <div class="offcanvas-content">
                    <div class="offcanvas-top d-flex justify-content-between align-items-center mb-20">
                        <div class="offcanvas-logo">
                            <a class="logo-black" href="index.php"><img src="assets/images/logo/logo-icef.png" alt="logo"></a>
                            <a class="logo-white" href="index.php"><img src="assets/images/logo/logo-icef.png" alt="logo"></a>
                        </div>
                        <div class="offcanvas-close">
                            <button class="offcanvas-close-icon animation--flip" style="background: var(--rs-theme-primary); color: white; border: none; padding: 10px; border-radius: 4px; display: flex; align-items: center; justify-content: center; width: 40px; height: 40px;">
                                <i class="ri-close-line" style="font-size: 24px;"></i>
                            </button>
                        </div>
                    </div>
                    <div class="offcanvas-about mb-30 d-none d-xl-block">
                        <p>
                            ICEF INDIA is a premier organization providing end-to-end solutions in Assessment, Recruitment, and Workforce Development since 2000.
                        </p>
                    </div>
                    <div class="offcanvas-gallery d-none d-xl-block">
                        <div class="offcanvas-gallery-thumb-wrapper">
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-01.webp">
                                    <img src="assets/images/gallery/gallery-thumb-01.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-02.webp">
                                    <img src="assets/images/gallery/gallery-thumb-02.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-03.webp">
                                    <img src="assets/images/gallery/gallery-thumb-03.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-04.webp">
                                    <img src="assets/images/gallery/gallery-thumb-04.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-05.webp">
                                    <img src="assets/images/gallery/gallery-thumb-05.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-06.webp">
                                    <img src="assets/images/gallery/gallery-thumb-06.webp" alt="image">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="mobile-menu-container">
                        <div class="rs-offcanvas-menu mb-30" id="sidebar-menu-target">
                            <!-- Menu will be injected here via JS -->
                        </div>
                    </div>
                    <div class="offcanvas-contact mb-30">
                        <h4 class="offcanvas-title-meta">Contact Info</h4>
                        <ul>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="18" viewBox="0 0 14 18" fill="none">
                                        <path d="M11.8768 9.68475C11.3059 10.835 10.5331 11.9818 9.74128 13.0109C8.95198 14.0368 8.15999 14.9249 7.5643 15.5572C7.48514 15.6412 7.40956 15.7206 7.33802 15.7951C7.26648 15.7206 7.1909 15.6412 7.11174 15.5572C6.51605 14.9249 5.72406 14.0368 4.93476 13.0109C4.14299 11.9818 3.37019 10.835 2.79925 9.68475C2.22242 8.52266 1.89032 7.43373 1.89032 6.5C1.89032 3.50846 4.32934 1.08333 7.33802 1.08333C10.3467 1.08333 12.7857 3.50846 12.7857 6.5C12.7857 7.43373 12.4536 8.52266 11.8768 9.68475ZM7.33802 17.3333C7.33802 17.3333 13.8753 11.1732 13.8753 6.5C13.8753 2.91015 10.9484 0 7.33802 0C3.7276 0 0.800781 2.91015 0.800781 6.5C0.800781 11.1732 7.33802 17.3333 7.33802 17.3333Z" fill="#6D6D6D"></path>
                                        <path d="M7.33802 8.66667C6.13455 8.66667 5.15894 7.69662 5.15894 6.5C5.15894 5.30338 6.13455 4.33333 7.33802 4.33333C8.54149 4.33333 9.5171 5.30338 9.5171 6.5C9.5171 7.69662 8.54149 8.66667 7.33802 8.66667ZM7.33802 9.75C9.14323 9.75 10.6066 8.29492 10.6066 6.5C10.6066 4.70507 9.14323 3.25 7.33802 3.25C5.53281 3.25 4.0694 4.70507 4.0694 6.5C4.0694 8.29492 5.53281 9.75 7.33802 9.75Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="#"> Noida, Uttar Pradesh, India</a>
                                </div>
                            </li>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M3.65387 1.32849C3.40343 1.00649 2.92745 0.976861 2.639 1.26531L1.60508 2.29923C1.1216 2.78271 0.94387 3.46766 1.1551 4.06847C2.00338 6.48124 3.39215 8.74671 5.32272 10.6773C7.25329 12.6078 9.51876 13.9966 11.9315 14.8449C12.5323 15.0561 13.2173 14.8784 13.7008 14.3949L14.7347 13.361C15.0231 13.0726 14.9935 12.5966 14.6715 12.3461L12.3653 10.5524C12.2008 10.4245 11.9866 10.3793 11.7845 10.4298L9.59541 10.9771C9.00082 11.1257 8.37183 10.9515 7.93845 10.5181L5.48187 8.06155C5.04849 7.62817 4.87427 6.99919 5.02292 6.40459L5.57019 4.21553C5.62073 4.01336 5.57552 3.79918 5.44758 3.63468L3.65387 1.32849ZM1.88477 0.511076C2.62689 -0.231039 3.8515 -0.154797 4.49583 0.673634L6.28954 2.97983C6.6187 3.40304 6.73502 3.95409 6.60498 4.47423L6.05772 6.66329C5.99994 6.8944 6.06766 7.13888 6.2361 7.30732L8.69268 9.7639C8.86113 9.93235 9.1056 10.0001 9.33671 9.94229L11.5258 9.39502C12.0459 9.26499 12.597 9.3813 13.0202 9.71047L15.3264 11.5042C16.1548 12.1485 16.231 13.3731 15.4889 14.1152L14.455 15.1492C13.7153 15.8889 12.6089 16.2137 11.5778 15.8512C9.01754 14.9511 6.61438 13.4774 4.56849 11.4315C2.5226 9.38562 1.04895 6.98246 0.148838 4.42225C-0.213682 3.39112 0.11113 2.28472 0.85085 1.545L1.88477 0.511076Z" fill="#6D6D6D"></path>
                                        <path d="M11 0.5C11 0.223858 11.2239 0 11.5 0H15.5C15.7761 0 16 0.223858 16 0.5V4.5C16 4.77614 15.7761 5 15.5 5C15.2239 5 15 4.77614 15 4.5V1.70711L10.8536 5.85355C10.6583 6.04882 10.3417 6.04882 10.1464 5.85355C9.95118 5.65829 9.95118 5.34171 10.1464 5.14645L14.2929 1H11.5C11.2239 1 11 0.776142 11 0.5Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="tel:+911204221735"> +91 120 422 1735 </a>
                                </div>
                            </li>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M2 2C0.895431 2 0 2.89543 0 4V12L2.58386e-05 12.0103C0.00555998 13.1101 0.898859 14 2 14H7.5C7.77614 14 8 13.7761 8 13.5C8 13.2239 7.77614 13 7.5 13H2C1.53715 13 1.14774 12.6855 1.03376 12.2586L6.67417 8.7876L8 9.5831L15 5.3831V8.5C15 8.77614 15.2239 9 15.5 9C15.7761 9 16 8.77614 16 8.5V4C16 2.89543 15.1046 2 14 2H2ZM5.70808 8.20794L1 11.1052V5.3831L5.70808 8.20794ZM1 4.2169V4C1 3.44772 1.44772 3 2 3H14C14.5523 3 15 3.44772 15 4V4.2169L8 8.4169L1 4.2169Z" fill="#6D6D6D"></path>
                                        <path d="M14.2467 14.2686C15.2567 14.2686 15.8339 13.4116 15.8339 12.2442V12.0344C15.8339 10.4297 14.6402 9 12.5197 9H12.4847C10.421 9 9 10.3598 9 12.4322V12.6465C9 14.8195 10.4385 16 12.3579 16H12.4016C12.9963 16 13.4204 15.9257 13.639 15.8251V15.0949C13.3941 15.2042 12.9656 15.2742 12.4585 15.2742H12.4147C11.0812 15.2742 9.84385 14.4872 9.84385 12.6202V12.4628C9.84385 10.8057 10.9019 9.73891 12.4847 9.73891H12.524C14.0587 9.73891 15.0075 10.7883 15.0075 12.065V12.183C15.0075 13.158 14.6839 13.5734 14.3691 13.5734C14.1374 13.5734 13.9582 13.4247 13.9582 13.1537V10.9631H13.0531V11.5315H13.0225C12.9394 11.2342 12.6552 10.9019 12.0693 10.9019C11.2911 10.9019 10.8101 11.4572 10.8101 12.3011V12.8301C10.8101 13.722 11.2998 14.2642 12.0693 14.2642C12.5415 14.2642 12.9656 14.0369 13.0837 13.6215H13.1274C13.2455 14.0412 13.7439 14.2686 14.2467 14.2686ZM11.7939 12.6814V12.4541C11.7939 11.9076 12.0212 11.6627 12.3666 11.6627C12.664 11.6627 12.9394 11.8551 12.9394 12.371V12.7383C12.9394 13.3111 12.6858 13.4816 12.3754 13.4816C12.0212 13.4816 11.7939 13.2673 11.7939 12.6814Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="mailto:sales@icefindia.in">sales@icefindia.in</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="offcanvas-social">
                        <h4 class="offcanvas-title-meta">Follow Us</h4>
                        <ul>
                            <li><a href="#"><i class="ri-facebook-fill"></i></a></li>
                            <li><a href="#"><i class="ri-twitter-x-fill"></i></a></li>
                            <li><a href="#"><i class="ri-youtube-fill"></i></a></li>
                            <li><a href="#"><i class="ri-linkedin-box-fill"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas-overlay"></div>
    <div class="offcanvas-overlay-white"></div>
    <!-- Offcanvas area start -->

    <!-- Body main wrapper start -->
    <main>

        <!-- about area start -->
        <section id="about" class="rs-about-area rs-about-one" style="padding-top: 80px; padding-bottom: 40px;">
            <div class="container">
                <div class="row g-5">
                    <div class="col-xl-12">
                        <div class="rs-about-wrapper ">
                            <div class="rs-about-content-wrapper">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle">
                                        Welcome TO ICEF
                                    </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left" style="font-size: 38px;">India's Leading Consultancy Company Since 2000 for Business Process, Hiring, Assessment and Manpower Deployment</h2>
                                </div>
                                <div class="rs-about-content-inner">
                                    <div class="rs-about-content-left">
                                        <div class="rs-about-counter">
                                            <div class="rs-counter-number-wrapper">
                                                <span class="rs-counter-number odometer" data-count="26">00</span>
                                                <span class="prefix">+</span>
                                            </div>
                                            <span class="rs-counter-title">Years Of Experience</span>
                                        </div>
                                    </div>
                                    <div class="rs-about-counter-right">
                                        <p class="rs-about-desc">ICEF India serves as a pivotal assessment platform designed to streamline hiring processes across various sectors. Established with a focus on enhancing efficiency and accuracy in talent acquisition, ICEF India integrates advanced assessment methodologies to match skilled individuals with suitable job roles.</p>
                                    </div>
                                </div>
                                <div class="rs-about-btn" style="margin-top: 10px;">
                                    <a class="rs-btn has-icon is-transparent hover-primary border-hover-primary border-red"
                                        href="about-mission.php">Explore More
                                        <span class="icon-box">
                                            <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>

                                            <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="rs-about-thumb rs-image scroll_reveal reveal-active" data-dir="reveal_right">
                                <img decoding="async" src="assets/images/about/1.webp" alt="image">
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <!-- about area end -->

        <!-- brand area start -->
        <div class="rs-brand-area rs-brand-one rs-swiper" style="margin-top: 50px;">
            <div class="container-fluid g-0">
                <div class="row">
                    <div class="brand-slider">
                        <div class="swiper" data-clone-slides="false" data-loop="true" data-speed="1500"
                            data-autoplay="true" data-dots-dynamic="false" data-center-mode="false" data-effect="false"
                            data-no-gap="true" data-delay="1500" data-item="6" data-item-xl="5" data-item-lg="4"
                            data-item-md="3" data-item-sm="2" data-item-xs="2" data-item-mobile="1">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-01.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-02.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-03.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-04.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-05.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-06.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="rs-brand-item">
                                        <div class="rs-brand-thumb">
                                            <img src="assets/images/brand/brand-thumb-01.webp" alt="image">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- brand area end -->

        <!-- services area start — Wisk Aero fan scroll -->
        <div id="servicesFanSection" class="rs-services-fan-scroll">
            <!-- sticky viewport -->
            <div class="rs-services-fan-sticky rs-services-two">

                <!-- shape stays as background decoration -->
                <div class="rs-services-shape rs-services-fan-shape">
                    <img src="assets/images/shape/services-shape-01.webp" alt="image">
                </div>

                <!-- heading -->
                <div class="rs-services-fan-heading">
                    <span class="section-subtitle is-white">
                        Your Business Our Expertise
                    </span>
                    <h2 class="section-title rs-split-text-enable split-in-left is-white mb-10">Service for your development</h2>
                    <p class="section-desc">We believe that every business is uniquids our approach is never growth.</p>
                </div>

                <!-- cards stage: all 4 start stacked center, fan out to row on scroll -->
                <div class="rs-services-fan-stage" id="servicesFanStage">

                    <div class="rs-services-item rs-services-fan-card" id="svc1">
                        <div class="rs-services-thumb">
                            <img src="assets/images/services/services-thumb-03.webp" alt="image">
                            <div class="rs-services-btn">
                                <a class="rs-btn has-icon has-bg-white hover-primary has-md-radius w-100"
                                    href="services-details.php">Explore More
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="rs-services-content">
                            <h5 class="rs-services-title underline is-white"><a href="services-details.php">
                                    Marketing
                                    Consulting</a></h5>
                            <p class="rs-services-desc"> Complex data into clear and strategic insights that
                                improve
                                performance guide growth.</p>
                            <div class="rs-services-list-wrapper">
                                <h6 class="rs-services-list-title">Data Analysis</h6>
                                <div class="rs-services-list-item-wrapper">
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Regulatory Investigations </p>
                                    </div>
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Anit- Competitive Conduct</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="rs-services-item rs-services-fan-card" id="svc2">
                        <div class="rs-services-thumb">
                            <img src="assets/images/services/services-thumb-04.webp" alt="image">
                            <div class="rs-services-btn">
                                <a class="rs-btn has-icon has-bg-white hover-primary has-md-radius w-100"
                                    href="services-details.php">Explore More
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="rs-services-content">
                            <h5 class="rs-services-title underline is-white"><a href="services-details.php">
                                    Financial
                                    Insurance</a></h5>
                            <p class="rs-services-desc"> we analyze structured and unstructured data to help you
                                optimize
                                operations.</p>
                            <div class="rs-services-list-wrapper">
                                <h6 class="rs-services-list-title">Bank Cost</h6>
                                <div class="rs-services-list-item-wrapper">
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Save costs for your development </p>
                                    </div>
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Cancel anytime you want</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="rs-services-item rs-services-fan-card" id="svc3">
                        <div class="rs-services-thumb">
                            <img src="assets/images/services/services-thumb-05.webp" alt="image">
                            <div class="rs-services-btn">
                                <a class="rs-btn has-icon has-bg-white hover-primary has-md-radius w-100"
                                    href="services-details.php">Explore More
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="rs-services-content">
                            <h5 class="rs-services-title underline is-white"><a href="services-details.php">
                                    Portfolio
                                    Management</a></h5>
                            <p class="rs-services-desc"> Every number tells a story We analyze your data to
                                uncover
                                patterns and highlight</p>
                            <div class="rs-services-list-wrapper">
                                <h6 class="rs-services-list-title">CV Solutions</h6>
                                <div class="rs-services-list-item-wrapper">
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Regulatory Investigations</p>
                                    </div>
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Management System</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="rs-services-item rs-services-fan-card" id="svc4">
                        <div class="rs-services-thumb">
                            <img src="assets/images/services/services-thumb-06.webp" alt="image">
                            <div class="rs-services-btn">
                                <a class="rs-btn has-icon has-bg-white hover-primary has-md-radius w-100"
                                    href="services-details.php">Explore More
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white" />
                                        </svg>
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="rs-services-content">
                            <h5 class="rs-services-title underline is-white"><a href="services-details.php">
                                    Business
                                    Insurances</a></h5>
                            <p class="rs-services-desc"> We provide the best services ensuring your outstanding
                                growth
                                Lorem ipsum dolor.</p>
                            <div class="rs-services-list-wrapper">
                                <h6 class="rs-services-list-title">Effective Retail</h6>
                                <div class="rs-services-list-item-wrapper">
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Conversion Optimization </p>
                                    </div>
                                    <div class="rs-services-list-item">
                                        <div class="rs-services-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                viewBox="0 0 12 10" fill="none">
                                                <path
                                                    d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                    fill="black"></path>
                                            </svg>
                                        </div>
                                        <p> Anit- Competitive Conduct</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div><!-- /fan-stage -->
            </div><!-- /fan-sticky -->
        </div>
        <!-- services area end -->

        <!-- ══ SERVICES FAN SCROLL CSS ══ -->
        <style>
        /* ── SCROLL WRAPPER ── */
        .rs-services-fan-scroll {
            position: relative;
            height: 380vh; /* scroll travel = animation length */
        }

        /* ── STICKY VIEWPORT (pins while scrolling 380vh) ── */
        .rs-services-fan-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            /* exact theme-secondary color from --rs-theme-secondary: #2B3944 */
            background: var(--rs-theme-secondary, #2B3944);
        }

        /* ── BACKGROUND SHAPE ── */
        .rs-services-fan-shape {
            position: absolute;
            top: 0; left: 0;
            width: 100%; height: 100%;
            pointer-events: none;
            z-index: 0;
        }
        .rs-services-fan-shape img {
            width: 100%; height: 100%;
            object-fit: cover;
            opacity: 0.18;
        }

        /* ── HEADING ── */
        .rs-services-fan-heading {
            text-align: center;
            margin-bottom: 32px;
            position: relative;
            z-index: 10;
            padding: 0 20px;
        }
        .rs-services-fan-heading .section-subtitle.is-white {
            display: block;
            margin-bottom: 10px;
        }

        /* ── STAGE: the 4-card absolute canvas ── */
        .rs-services-fan-stage {
            position: relative;
            width: 100%;
            /* auto height — cards are absolute positioned, stage just holds z-context */
            height: 480px;
            z-index: 5;
            flex-shrink: 0;
        }

        /* ── FAN STAGE: cap image height so full card fits within 100vh ── */
        .rs-services-fan-stage .rs-services-thumb {
            height: 160px;
            overflow: hidden;
        }
        .rs-services-fan-stage .rs-services-thumb img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* ── FAN CARD base ── */
        .rs-services-fan-card {
            position: absolute !important;
            /* Start stacked center — JS sets width & position */
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            will-change: transform, left, top;
            margin: 0 !important;
            float: none !important;
            transition: none !important; /* CRITICAL: Prevent CSS transitions from fighting GSAP */
        }

        /* ── MOBILE SIMPLE SET ── */
        @media (max-width: 991px) {
            .rs-services-fan-scroll {
                height: auto !important;
            }
            .rs-services-fan-sticky {
                position: relative !important;
                top: auto !important;
                height: auto !important;
                padding: 60px 0 !important;
                display: block !important;
            }
            .rs-services-fan-stage {
                height: auto !important;
                display: flex !important;
                flex-direction: column !important;
                gap: 30px !important;
                padding: 0 15px !important;
            }
            .rs-services-fan-card {
                position: relative !important;
                left: auto !important;
                top: auto !important;
                transform: none !important;
                width: 100% !important;
                margin-bottom: 20px !important;
            }
            .rs-services-fan-stage .rs-services-thumb {
                height: auto !important;
            }
        }
        </style>

        <!-- ══ GSAP + ScrollTrigger for fan animation ══ -->
        <script>
        (function() {
            // Wait for GSAP to load (already loaded on page)
            function initServicesFan() {
                if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
                    setTimeout(initServicesFan, 100);
                    return;
                }
                gsap.registerPlugin(ScrollTrigger);

                var section = document.getElementById('servicesFanSection');
                var cards   = [
                    document.getElementById('svc1'),
                    document.getElementById('svc2'),
                    document.getElementById('svc3'),
                    document.getElementById('svc4')
                ];

                if (!section || cards.some(function(c){ return !c; })) return;

                // Match original rs-services-two grid:
                // padding: 75px each side (0px on ≤1600px), gap: 30px
                var GAP = 30; // same as original grid gap

                function calcCardW() {
                    var vw = window.innerWidth;
                    // mirror the responsive padding from the original CSS
                    var sidePad = vw > 1600 ? 75 : 0;
                    return Math.floor((vw - sidePad * 2 - GAP * 3) / 4);
                }

                var tl;

                function build() {
                    if (tl) tl.kill();
                    ScrollTrigger.getAll().forEach(function(t) {
                        if (t.vars && t.vars.id === 'servicesFan') t.kill();
                    });

                    var vw = window.innerWidth;

                    // Mobile fallback: clear GSAP styles and exit
                    if (vw < 992) {
                        cards.forEach(function(c) {
                            gsap.set(c, { clearProps: "all" });
                            c.style.width = '100%';
                        });
                        return;
                    }

                    var cardW = calcCardW();

                    // Apply the correct width to every card so they look original
                    cards.forEach(function(c) {
                        c.style.width = cardW + 'px';
                    });

                    // side padding mirrors the original wrapper padding
                    var sidePad = vw > 1600 ? 75 : 0;

                    // Final X positions for each card (left edge)
                    var finalX = [0, 1, 2, 3].map(function(i) {
                        return sidePad + i * (cardW + GAP);
                    });

                    // Final vertical center of stage
                    var stageH  = document.querySelector('.rs-services-fan-stage').offsetHeight;
                    var cardH   = cards[0].offsetHeight;
                    var finalY  = (stageH - cardH) / 2;

                    // z-index: last card on bottom, first card on top
                    cards.forEach(function(c, i) {
                        gsap.set(c, { zIndex: cards.length - i });
                    });

                    // reset to center stack
                    cards.forEach(function(c) {
                        gsap.set(c, {
                            left: '50%',
                            top:  '50%',
                            xPercent: -50,
                            yPercent: -50
                        });
                    });

                    tl = gsap.timeline({
                        id: 'servicesFan',
                        scrollTrigger: {
                            trigger: section,
                            start:   'top top',
                            end:     'bottom bottom',
                            scrub:   1.5
                        }
                    });

                    // Fan cards out to their row positions
                    cards.forEach(function(card, i) {
                        tl.to(card, {
                            left:     finalX[i] + 'px',
                            top:      finalY + 'px',
                            xPercent: 0,
                            yPercent: 0,
                            duration: 1,
                            ease:     'power2.inOut'
                        }, i * 0.08);
                    });
                }

                build();
                window.addEventListener('resize', function() {
                    ScrollTrigger.refresh();
                    build();
                });
            }

            // Delay slightly to ensure GSAP libs are ready
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', initServicesFan);
            } else {
                initServicesFan();
            }
        })();
        </script>

        <!-- services area start — Timeline Component (scroll-driven animation) -->
        <style>
        /* ── SCROLL WRAPPER ── */
        .timeline-scroll-driver {
            height: 400vh;
            position: relative;
        }

        /* ── STICKY VIEWPORT ── */
        .timeline-sticky-container {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            background-color: #2B3944;
            font-family: 'Outfit', sans-serif;
        }

        .timeline-sticky-container .rs-services-fan-shape-bg {
            position: absolute;
            top: 0; left: 0;
            width: 100%; height: 100%;
            pointer-events: none;
            z-index: 0;
        }
        .timeline-sticky-container .rs-services-fan-shape-bg img {
            width: 100%; height: 100%;
            object-fit: cover;
            opacity: 0.18;
        }

        /* ── INNER CONTAINER ── */
        .timeline-inner-container {
            --primary-bg: #2B3944;
            --accent-theme: #AB052D;
            --accent-hover: #8a0424;
            --text-dark: #FFFFFF;
            --text-muted: rgba(255, 255, 255, 0.7);
            --card-radius: 20px;
            max-width: 1200px;
            width: 100%;
            text-align: center;
            padding: 40px 20px;
            position: relative;
            z-index: 2;
            color: #FFFFFF;
        }

        .timeline-inner-container .header-custom {
            margin-bottom: 60px;
            opacity: 0; /* Hidden by default for JS animation */
            transform: translateY(-20px);
        }
        .timeline-inner-container .header-custom .section-subtitle {
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 10px;
            display: inline-block;
            font-weight: 600;
            color: rgba(255,255,255,0.7);
            font-size: 14px;
        }
        .timeline-inner-container .header-custom h2 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 20px;
            line-height: 1.2;
            color: #fff;
        }
        .timeline-inner-container .header-custom p {
            font-size: 1.1rem;
            color: rgba(255,255,255,0.7);
            max-width: 700px;
            margin: 0 auto;
            line-height: 1.6;
        }

        .timeline-inner-container .timeline {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 15px;
            margin-bottom: 60px;
            position: relative;
            width: 100%;
        }
        .timeline-inner-container .timeline-item {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .timeline-inner-container .card {
            width: 100%;
            aspect-ratio: 4/3;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            margin-bottom: 30px;
            background: rgba(255,255,255,0.08);
            will-change: transform, opacity;
            position: relative;
        }
        .timeline-inner-container .card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .timeline-inner-container .connector,
        .timeline-inner-container .label,
        .timeline-inner-container .cta-button {
            opacity: 0; /* Hidden by default */
            transform: translateY(20px);
        }

        .timeline-inner-container .connector {
            width: 1px;
            height: 80px;
            background: linear-gradient(to bottom, rgba(255,255,255,0.3), rgba(255,255,255,0.05));
            margin-bottom: 20px;
            margin-left: auto;
            margin-right: auto;
        }
        .timeline-inner-container .label { text-align: center; }
        .timeline-inner-container .year {
            font-size: 0.85rem;
            font-weight: 600;
            color: rgba(255,255,255,0.7);
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .timeline-inner-container .gen-name {
            font-size: 0.95rem;
            font-weight: 700;
            color: #FFFFFF;
            text-transform: uppercase;
            letter-spacing: 1px;
            line-height: 1.3;
        }
        .timeline-inner-container .cta-button {
            display: inline-flex;
            align-items: center;
            background-color: #AB052D;
            color: #ffffff;
            padding: 16px 32px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 700;
            font-size: 1rem;
            border: none;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(171,5,45,0.3);
        }
        .timeline-inner-container .cta-button span { margin-right: 10px; }
        .timeline-inner-container .cta-button i { font-style: normal; }

        @media (max-width: 1024px) {
            .timeline-inner-container .timeline { flex-wrap: wrap; justify-content: center; gap: 40px 20px; }
            .timeline-inner-container .timeline-item { flex: 0 0 calc(33.333% - 20px); }
        }
        @media (max-width: 768px) {
            .timeline-inner-container .timeline-item { flex: 0 0 calc(50% - 20px); }
            .timeline-inner-container .header-custom h2 { font-size: 2.5rem; }
        }
        @media (max-width: 480px) {
            .timeline-inner-container .timeline-item { flex: 0 0 100%; }
            .timeline-inner-container .connector { height: 40px; }
            .timeline-inner-container .header-custom h2 { font-size: 2rem; }
        }
        </style>

        <!-- Timeline Scroll Driver -->
        <div class="timeline-scroll-driver">
            <div class="timeline-sticky-container">
                <!-- background shape -->
                <div class="rs-services-fan-shape-bg">
                    <img src="assets/images/shape/services-shape-01.webp" alt="">
                </div>

                <div class="timeline-inner-container">
                    <header class="header-custom">
                        <span class="section-subtitle">How It Works</span>
                        <h2>Service for your development</h2>
                        <p>We believe that every business is unique and our approach aims for unparalleled growth. Explore our key offerings below.</p>
                    </header>

                    <div class="timeline" id="howItWorksTimeline" role="list">
                        <!-- Card 1 -->
                        <div class="timeline-item" role="listitem">
                            <div class="card" id="hiw-card-1"><img src="assets/images/banner/banner-thumb-02.webp" alt="IT & Emerging Tech Enablement Solution"></div>
                            <div class="connector"></div>
                            <div class="label"><div class="year">01</div><div class="gen-name">IT & Emerging Tech<br>Enablement</div></div>
                        </div>
                        <!-- Card 2 -->
                        <div class="timeline-item" role="listitem">
                            <div class="card" id="hiw-card-2"><img src="assets/images/banner/assessment-testing.webp" alt="Assessment & Testing Solution"></div>
                            <div class="connector"></div>
                            <div class="label"><div class="year">02</div><div class="gen-name">Assessment &<br>Testing</div></div>
                        </div>
                        <!-- Card 3 -->
                        <div class="timeline-item" role="listitem">
                            <div class="card" id="hiw-card-3"><img src="assets/images/banner/recruitment.webp" alt="Recruitment & Hiring Solution"></div>
                            <div class="connector"></div>
                            <div class="label"><div class="year">03</div><div class="gen-name">Recruitment &<br>Hiring</div></div>
                        </div>
                        <!-- Card 4 -->
                        <div class="timeline-item" role="listitem">
                            <div class="card" id="hiw-card-4"><img src="assets/images/banner/exam-management.webp" alt="Exam Management Solution"></div>
                            <div class="connector"></div>
                            <div class="label"><div class="year">04</div><div class="gen-name">Exam<br>Management</div></div>
                        </div>
                        <!-- Card 5 -->
                        <div class="timeline-item" role="listitem">
                            <div class="card" id="hiw-card-5"><img src="assets/images/banner/manpower.webp" alt="Manpower & Workforce Solution"></div>
                            <div class="connector"></div>
                            <div class="label"><div class="year">05</div><div class="gen-name">Manpower &<br>Workforce</div></div>
                        </div>
                        <!-- Card 6 -->
                        <div class="timeline-item" role="listitem">
                            <div class="card" id="hiw-card-6"><img src="assets/images/banner/call-center.webp" alt="Call Center & BPOs Solution"></div>
                            <div class="connector"></div>
                            <div class="label"><div class="year">06</div><div class="gen-name">Call Center &<br>BPOs</div></div>
                        </div>
                    </div><!-- /timeline -->

                    <a href="solutions.php" class="cta-button" id="hiw-explore-btn">
                        <span>Explore our solutions</span><i>&rarr;</i>
                    </a>
                </div><!-- /timeline-inner-container -->
            </div><!-- /timeline-sticky-container -->
        </div><!-- /timeline-scroll-driver -->
        <!-- services area end -->

        <!-- GSAP Scroll Animation for How It Works Section -->
        <script>
        (function() {
            function buildHIWAnimation() {
                if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
                    setTimeout(buildHIWAnimation, 100);
                    return;
                }

                if (window._hiwCtx) window._hiwCtx.revert();

                var scrollDriver = document.querySelector('.timeline-scroll-driver');
                if (!scrollDriver) return;

                window._hiwCtx = gsap.context(function() {
                    var cards = gsap.utils.toArray('.timeline-scroll-driver .card');
                    var card1 = cards[0];
                    var otherCards = cards.slice(1);
                    var connectors = gsap.utils.toArray('.timeline-scroll-driver .connector');
                    var labels = gsap.utils.toArray('.timeline-scroll-driver .label');
                    var cta = document.getElementById('hiw-explore-btn');

                    var sticky = document.querySelector('.timeline-sticky-container');
                    var vw = window.innerWidth;
                    var vh = window.innerHeight;

                    // Snapshot each card's distance from the center of the STICKY container
                    var snap = cards.map(function(card) {
                        var cr = card.getBoundingClientRect();
                        var sr = sticky.getBoundingClientRect();
                        return {
                            xToCenter: (sr.width / 2) - (cr.left - sr.left + cr.width / 2),
                            yToCenter: (sr.height / 2) - (cr.top - sr.top + cr.height / 2),
                            width: cr.width,
                            height: cr.height
                        };
                    });

                    // Ensure Full-screen cover for Card 1 (Exactly 100vh/100vw coverage)
                    var coverScale = Math.max(vw / snap[0].width, vh / snap[0].height);

                    // Fade out section headers initially so the fullscreen image is the focus
                    var sectionHeader = document.querySelector('.timeline-inner-container .header-custom');
                    gsap.set(sectionHeader, { opacity: 0, y: -20 });

                    // Hide connectors, labels, CTA
                    gsap.set([connectors, labels, cta], { opacity: 0, y: 20 });

                    // Card 1: Fixed starting state (Fullscreen Covering 100vh)
                    gsap.set(card1, {
                        x: snap[0].xToCenter,
                        y: snap[0].yToCenter,
                        scale: coverScale,
                        borderRadius: '0px',
                        zIndex: 100, // Top layer
                        transformOrigin: '50% 50%'
                    });

                    // Cards 2-6: stacked deck hidden behind card 1
                    otherCards.forEach(function(card, index) {
                        var deckOffsetX = (index + 1) * 6;
                        var deckOffsetY = (index + 1) * 4;
                        var deckScale   = 1 - ((index + 1) * 0.03);
                        gsap.set(card, {
                            x: snap[index + 1].xToCenter + deckOffsetX,
                            y: snap[index + 1].yToCenter + deckOffsetY,
                            scale: deckScale,
                            opacity: 0,
                            zIndex: 90 - index,
                            transformOrigin: '50% 50%'
                        });
                    });

                    // Timeline driven by scroll with precise scrub alignment
                    var tl = gsap.timeline({
                        scrollTrigger: {
                            trigger: '.timeline-scroll-driver',
                            start: 'top top',
                            end: 'bottom bottom',
                            scrub: 1.2, // Smoother scrub
                            invalidateOnRefresh: true, // Handle layout shifts better
                            anticipatePin: 1
                        }
                    });

                    // Phase 1: Card 1 shrinks (Zoom Out)
                    tl.fromTo(card1, {
                        scale: coverScale,
                        borderRadius: '0px'
                    }, {
                        scale: 1,
                        borderRadius: '32px',
                        ease: 'power2.inOut',
                        duration: 0.4
                    }, 0);

                    // Phase 2: Section Header fades in AFTER zoom out
                    tl.fromTo(sectionHeader, {
                        opacity: 0,
                        y: -20
                    }, {
                        opacity: 1,
                        y: 0,
                        duration: 0.2,
                        ease: 'power1.out'
                    }, 0.35);

                    // Phase 3: Other 5 cards appear and all cards spread
                    tl.to(otherCards, { opacity: 1, duration: 0.1 }, 0.55)
                      .to(cards, {
                        x: 0,
                        y: 0,
                        scale: 1,
                        ease: 'power2.inOut',
                        duration: 0.35
                    }, 0.55);

                    // Phase 4: Fade in connectors, labels, CTA (the workflow below)
                    tl.to(connectors, { opacity: 1, y: 0, stagger: 0.02, duration: 0.1, ease: 'power1.out' }, 0.85)
                      .to(labels,     { opacity: 1, y: 0, stagger: 0.02, duration: 0.1, ease: 'power1.out' }, 0.90)
                      .to(cta,        { opacity: 1, y: 0, duration: 0.1, ease: 'power1.out' }, 0.95);
                });
            }

            // Execute on load and refresh
            window.addEventListener('load', function() {
                buildHIWAnimation();
                ScrollTrigger.refresh();
            });

            var _hiwResizeTimer;
            window.addEventListener('resize', function() {
                clearTimeout(_hiwResizeTimer);
                _hiwResizeTimer = setTimeout(function() {
                    buildHIWAnimation();
                    ScrollTrigger.refresh();
                }, 250);
            });
        })();
        </script>



        <!-- why choose area start -->
        <section class="rs-why-choose-area rs-why-choose-one" style="padding-top: 60px; padding-bottom: 30px;">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-why-choose-wrapper">
                            <div class="rs-why-choose-content-wrapper">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle">
                                        Why choose us 
                                    </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left mb-20">Empowering learners, Transforming lives</h2>
                                    <p class="rs-section-desc">We will be a leading education services organisation respected globally for academic and business excellence, providing affordable and flexible learning solutions -powered by technology, innovation and passion. Learners, enterprises and communities will reward us with market leadership creating prosperity for all our stakeholders.To be the workplace of choice for top-tier talent, where passion for technology and assessment expertise converges to create a globally respected platform. We envision a future where our team is at the forefront of educational and business transformation, creating prosperity for themselves, our stakeholders, and the communities we serve.</p>
                                </div>
                                <div class="rs-why-choose-btn">
                                    <a class="rs-btn has-icon hover-secondary border-hover-primary" href="about-mission.php">Get
                                        Start Now
                                        <span class="icon-box">
                                            <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>

                                            <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="rs-why-choose-thumb">
                                <img src="assets/images/about/15.webp" alt="image">
                                <div class="rs-why-choose-meta">
                                    <div class="rs-why-choose-meta-icon">
                                        <img src="assets/images/logo/favicon-icef.png" alt="ICEF India Logo">
                                    </div>
                                    <p class="rs-why-choose-meta-desc">We ensure fastest management team -work</p>
                                    <div class="rs-why-choose-meta-btn">
                                        <a class="rs-btn has-icon has-text is-text-primary" href="contact.php">Join Now
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- why choose area end -->

        <!-- counter area start -->
        <div class="rs-counter-area rs-counter-two" style="padding-top: 30px; padding-bottom: 60px;">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-counter-wrapper">
                            <div class="rs-counter-item wow fadeIn" data-wow-delay=".3s" data-wow-duration="1s">
                                <div class="rs-counter-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 38">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M10.5959 36.5456C10.0034 36.5456 9.52067 36.0625 9.52067 35.4686C9.52067 34.8755 10.0034 34.3925 10.5959 34.3925C11.1884 34.3925 11.6758 34.8756 11.6758 35.4686C11.6758 36.0626 11.1884 36.5456 10.5959 36.5456ZM10.5959 1.45436C11.1884 1.45436 11.6758 1.93651 11.6758 2.53042C11.6758 3.12345 11.1884 3.60657 10.5959 3.60657C10.0034 3.60657 9.52067 3.12345 9.52067 2.53042C9.52067 1.93651 10.0034 1.45436 10.5959 1.45436ZM10.5959 33.2605C9.97941 33.2605 9.42519 33.5147 9.02373 33.9232L1.98989 29.9241V8.07486L9.02373 4.07676C9.4251 4.48481 9.97941 4.73861 10.5959 4.73861C11.8144 4.73861 12.8035 3.74755 12.8035 2.53051C12.8035 1.3125 11.8144 0.322415 10.5959 0.322415C9.13189 0.322415 8.09401 1.71968 8.45992 3.09248L1.14413 7.25303C1.05726 7.30259 0.985011 7.3742 0.934672 7.46062C0.884332 7.54704 0.857686 7.64521 0.857422 7.74521V30.2539C0.857515 30.354 0.884089 30.4522 0.934446 30.5387C0.984803 30.6251 1.05715 30.6967 1.14413 30.7461L8.45992 34.9067C8.09401 36.2795 9.13215 37.6777 10.5959 37.6777C11.8144 37.6777 12.8035 36.6867 12.8035 35.4687C12.8035 34.2515 11.8143 33.2605 10.5959 33.2605ZM25.3994 36.5456C24.8069 36.5456 24.3242 36.0625 24.3242 35.4686C24.3242 34.8755 24.8068 34.3925 25.3994 34.3925C25.992 34.3925 26.4746 34.8756 26.4746 35.4686C26.4746 36.0626 25.9919 36.5456 25.3994 36.5456ZM25.3994 3.60657C24.8069 3.60657 24.3242 3.12345 24.3242 2.53042C24.3242 1.93651 24.8068 1.45436 25.3994 1.45436C25.992 1.45436 26.4746 1.93651 26.4746 2.53042C26.4746 3.12345 25.9919 3.60657 25.3994 3.60657ZM34.8511 7.25294L27.5353 3.09239C27.9013 1.72012 26.8636 0.322327 25.3994 0.322327C24.1809 0.322327 23.1917 1.31241 23.1917 2.53042C23.1917 3.74746 24.1809 4.73852 25.3994 4.73852C26.0158 4.73852 26.5749 4.48481 26.9763 4.07667L34.0101 8.07477V29.9241L26.9763 33.9232C26.5749 33.5146 26.0158 33.2605 25.3994 33.2605C24.1809 33.2605 23.1917 34.2515 23.1917 35.4686C23.1917 36.6866 24.1809 37.6776 25.3994 37.6776C26.8634 37.6776 27.9013 36.279 27.5353 34.9066L34.8511 30.746C34.9394 30.6977 35.013 30.6265 35.0643 30.5399C35.1155 30.4533 35.1426 30.3545 35.1426 30.2539V7.74513C35.1426 7.54202 35.0327 7.35423 34.8511 7.25294ZM17.9976 30.2194L6.72535 24.6507L11.1693 22.4564L17.7491 25.7063C17.9045 25.785 18.0931 25.7837 18.2509 25.7063L24.826 22.4564L29.2699 24.6507L17.9976 30.2194ZM6.72535 18.9997L11.1693 16.8054L17.7491 20.0547C17.9063 20.1339 18.0918 20.1324 18.2509 20.0547L24.826 16.8054L29.2699 18.9997L17.9976 24.5676L6.72535 18.9997ZM6.72535 13.3483L17.9976 7.78041L29.2699 13.3483L17.9976 18.9161L6.72535 13.3483ZM31.1144 24.6507C31.1144 24.8667 30.9901 25.0626 30.799 25.1587L18.2509 31.3582C18.0922 31.4346 17.9059 31.4361 17.7491 31.3572L5.19617 25.1587C4.77782 24.9503 4.77677 24.3517 5.19617 24.1437L9.8886 21.8252L5.19617 19.5072C4.77756 19.2992 4.77668 18.7008 5.19617 18.4918L9.8886 16.1738L5.19617 13.8553C4.77729 13.6476 4.77729 13.049 5.19617 12.8414L17.7491 6.64187C17.8271 6.60323 17.913 6.58313 18 6.58313C18.087 6.58313 18.1729 6.60323 18.2509 6.64187L30.799 12.8414C31.2179 13.0491 31.2179 13.6476 30.799 13.8553L26.1066 16.1738L30.799 18.4918C31.2185 18.7008 31.2176 19.2992 30.799 19.5072L26.1066 21.8252L30.799 24.1437C30.9901 24.2388 31.1144 24.4356 31.1144 24.6507L22.9224 24.2152V24.2152Z">
                                        </path>
                                    </svg>
                                </div>
                                <div class="rs-counter-content">
                                    <div class="rs-counter-number-wrapper">
                                        <span class="rs-counter-number odometer" data-count="25.5">00</span>
                                        <span class="prefix">K</span>
                                    </div>
                                    <span class="rs-counter-title">Projects Completed</span>
                                </div>
                            </div>
                            <div class="rs-counter-item wow fadeIn" data-wow-delay=".5s" data-wow-duration="1s">
                                <div class="rs-counter-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 42">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M10.2804 37.4735C10.3637 37.5929 10.3963 37.7405 10.3708 37.8839C10.3454 38.0272 10.2641 38.1546 10.1447 38.238C10.0253 38.3214 9.87774 38.3539 9.73438 38.3285C9.59101 38.3031 9.46363 38.2217 9.38024 38.1023L9.34698 38.0548C9.26515 37.9354 9.2338 37.7885 9.25974 37.6461C9.28568 37.5037 9.36681 37.3772 9.48549 37.2943C9.60417 37.2114 9.75078 37.1788 9.89343 37.2034C10.0361 37.2281 10.1632 37.3081 10.2472 37.426L10.2804 37.4735ZM17.1957 31.0585C17.0552 31.0191 16.9361 30.9255 16.8647 30.7982C16.7932 30.671 16.7752 30.5206 16.8146 30.3801C16.854 30.2396 16.9476 30.1205 17.0748 30.0491C17.202 29.9776 17.3524 29.9595 17.4929 29.999L24.5166 31.9891C24.9679 32.1176 25.4516 32.0646 25.8644 31.8415C26.0649 31.7338 26.2421 31.5876 26.3858 31.4112C26.5295 31.2348 26.6369 31.0317 26.7017 30.8136C26.7174 30.7609 26.7304 30.708 26.7409 30.6551C26.7421 30.6478 26.7435 30.6405 26.745 30.6333C26.8221 30.2087 26.7402 29.7706 26.515 29.4026C26.2898 29.0345 25.937 28.7622 25.5239 28.6375C23.522 28.0418 21.5543 27.3344 19.6314 26.5187C16.1449 25.0778 15.9232 24.9873 8.99232 28.6527L13.501 35.1588L13.5879 35.0284L13.5895 35.0295L13.5901 35.0284C13.7665 34.7602 14.0256 34.5569 14.3281 34.4495C14.6306 34.342 14.9599 34.3363 15.2659 34.4332L23.6119 37.0182C25.8737 37.719 31.0783 33.8692 34.6205 31.2492C35.6292 30.5031 36.5085 29.8527 37.1512 29.4312C37.7487 29.0392 37.9579 28.6163 37.8999 28.2408C37.8609 28.0287 37.7658 27.831 37.6245 27.6682C37.4375 27.4493 37.2111 27.2675 36.957 27.1322C36.4282 26.8491 35.8325 26.7146 35.2333 26.7431C34.6341 26.7716 34.0539 26.9621 33.5544 27.2942L27.7686 31.0891C27.7649 31.1022 27.7612 31.1153 27.7573 31.1283C27.651 31.4854 27.4751 31.8179 27.2397 32.1067C27.0044 32.3954 26.7142 32.6348 26.3859 32.8109C25.7224 33.1698 24.9449 33.255 24.2194 33.0484L17.1957 31.0585ZM20.9987 0.222656V0.222656Z">
                                        </path>
                                    </svg>
                                </div>
                                <div class="rs-counter-content">
                                    <div class="rs-counter-number-wrapper">
                                        <span class="rs-counter-number odometer" data-count="10.5">00</span>
                                        <span class="prefix">K</span>
                                    </div>
                                    <span class="rs-counter-title">Customer Satisfaction</span>
                                </div>
                            </div>
                            <div class="rs-counter-item wow fadeIn" data-wow-delay=".7s" data-wow-duration="1s">
                                <div class="rs-counter-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 44">
                                        <path
                                            d="M34.3153 13.6218C35.6433 12.327 34.9107 10.0681 33.0762 9.79935L25.8828 8.74077C25.7429 8.72011 25.6101 8.66588 25.4958 8.58274C25.3814 8.49959 25.2889 8.38999 25.2261 8.26331L22.0103 1.74469C21.1881 0.0786182 18.8118 0.0792197 17.9899 1.74469L14.7727 8.26331C14.7103 8.3899 14.6182 8.49948 14.5041 8.58264C14.3901 8.6658 14.2576 8.72006 14.118 8.74077L6.92393 9.79935C5.089 10.0681 4.35707 12.3272 5.6848 13.6218L10.8901 18.698C10.9916 18.7967 11.0675 18.9185 11.1113 19.0531C11.1551 19.1877 11.1655 19.3309 11.1416 19.4704L9.9125 26.6076C9.5953 28.4413 11.5237 29.8327 13.1611 28.9742L17.5488 26.6773C17.4082 29.8743 16.9644 32.9448 14.9519 35.6373H14.0659C12.5552 35.6373 11.3268 36.8658 11.3268 38.3764V42.1352H9.43838C9.05991 42.1352 8.75363 42.4415 8.75363 42.82C8.75363 43.1984 9.05991 43.5047 9.43838 43.5047H30.5618C30.9403 43.5047 31.2466 43.1984 31.2466 42.82C31.2466 42.4415 30.9403 42.1352 30.5618 42.1352H28.6733V38.3764C28.6733 36.8658 27.445 35.6373 25.9343 35.6373H25.0482C23.0358 32.9448 22.5919 29.8743 22.4513 26.6773L26.839 28.9742C28.4822 29.8371 30.404 28.4364 30.0876 26.6076L28.8591 19.4704C28.8351 19.331 28.8453 19.1878 28.889 19.0532C28.9327 18.9186 29.0085 18.7967 29.1099 18.698L34.3153 13.6218V13.6218Z">
                                        </path>
                                    </svg>
                                </div>
                                <div class="rs-counter-content">
                                    <div class="rs-counter-number-wrapper">
                                        <span class="rs-counter-number odometer" data-count="1.5">00</span>
                                        <span class="prefix">K</span>
                                    </div>
                                    <span class="rs-counter-title">Consulting Award</span>
                                </div>
                            </div>
                            <div class="rs-counter-item wow fadeIn" data-wow-delay=".9s" data-wow-duration="1s">
                                <div class="rs-counter-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 42 38">
                                        <path
                                            d="M28.7586 31.3881C27.724 31.9585 26.6291 32.4122 25.4941 32.7407C25.4779 32.7454 25.4637 32.7552 25.4537 32.7688C25.4437 32.7824 25.4385 32.799 25.4389 32.8158V37.2317C25.4385 37.3764 25.3808 37.515 25.2785 37.6173C25.1761 37.7195 25.0374 37.7771 24.8927 37.7773H17.1068C16.9621 37.777 16.8234 37.7194 16.7211 37.6171C16.6188 37.5148 16.5612 37.3761 16.5608 37.2314V32.8158C16.5613 32.799 16.5561 32.7824 16.5461 32.7688C16.5361 32.7553 16.5219 32.7454 16.5057 32.7407C15.3707 32.4122 14.2758 31.9585 13.2412 31.3881C13.2264 31.3797 13.2093 31.3765 13.1925 31.3789C13.1757 31.3813 13.1602 31.3892 13.1483 31.4013L10.0254 34.5243C9.92242 34.6261 9.78346 34.6832 9.63866 34.6832C9.49386 34.6832 9.3549 34.6261 9.25194 34.5243L3.74601 29.0188C3.6441 28.9163 3.58689 28.7776 3.58689 28.6331C3.58689 28.4885 3.6441 28.3499 3.74601 28.2474L6.87164 25.1244C6.88331 25.1123 6.89086 25.0968 6.89324 25.0802C6.89562 25.0635 6.89269 25.0465 6.88488 25.0316C6.31336 23.9974 5.8595 22.9024 5.53179 21.7672C5.52738 21.7507 5.51762 21.7361 5.50403 21.7257C5.49044 21.7153 5.47379 21.7097 5.45668 21.7098H1.03855C0.966856 21.7098 0.895857 21.6957 0.829613 21.6683C0.76337 21.6409 0.703179 21.6007 0.652483 21.55C0.601787 21.4993 0.56158 21.4391 0.534159 21.3728C0.506738 21.3066 0.492642 21.2356 0.492676 21.1639V17.2716C0.492994 17.1269 0.550607 16.9883 0.65291 16.886C0.755213 16.7837 0.893874 16.7261 1.03855 16.7257H4.67654C4.69706 16.7257 4.71673 16.7176 4.73123 16.7031C4.74574 16.6886 4.75389 16.6689 4.75389 16.6484V14.0979V14.0979Z">
                                        </path>
                                    </svg>
                                </div>
                                <div class="rs-counter-content">
                                    <div class="rs-counter-number-wrapper">
                                        <span class="rs-counter-number odometer" data-count="4.5">00</span>
                                        <span class="prefix">K</span>
                                    </div>
                                    <span class="rs-counter-title">Strategic Partners</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- counter area end -->

        <!-- skill area start -->
        <section id="mission" class="rs-skill-area rs-skill-two section-space">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-skill-wrapper">
                            <div class="rs-skill-left">
                                <div class="rs-skill-top">
                                    <div class="section-title-wrapper">
                                        <span class="section-subtitle">
                                            Our Mission
                                        </span>
                                        <h2 class="section-title rs-split-text-enable split-in-left mb-20">
                                            Mission-driven results
                                        </h2>
                                        <p class="rs-section-desc">ICEF India's mission is to revolutionize talent assessment and development across industries by providing cutting-edge solutions that empower organizations to make informed decisions, enhance workforce capabilities, and drive sustainable growth. Through innovative assessment methodologies and a commitment to fairness and accuracy, ICEF India aims to bridge the gap between talent and opportunity, thereby fostering a dynamic and inclusive job market where individuals thrive and organizations excel.</p>
                                    </div>
                                    <div class="rs-skill-list-wrapper">
                                        <div class="rs-skill-list-item">
                                            <div class="rs-skill-list-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                    viewBox="0 0 12 10" fill="none">
                                                    <path
                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                        fill="black"></path>
                                                </svg>
                                            </div>
                                            <p class="rs-skill-list-desc"> Customized Strategy Solutions </p>
                                        </div>
                                        <div class="rs-skill-list-item">
                                            <div class="rs-skill-list-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                    viewBox="0 0 12 10" fill="none">
                                                    <path
                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                        fill="black"></path>
                                                </svg>
                                            </div>
                                            <p class="rs-skill-list-desc"> Industry-Specific Insights </p>
                                        </div>
                                        <div class="rs-skill-list-item">
                                            <div class="rs-skill-list-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                    viewBox="0 0 12 10" fill="none">
                                                    <path
                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                        fill="black"></path>
                                                </svg>
                                            </div>
                                            <p class="rs-skill-list-desc"> Startup &amp; Enterprise Support </p>
                                        </div>
                                        <div class="rs-skill-list-item">
                                            <div class="rs-skill-list-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"
                                                    viewBox="0 0 12 10" fill="none">
                                                    <path
                                                        d="M5.53798 9.63481C5.50614 9.6348 5.47466 9.62821 5.4455 9.61545C5.41633 9.60269 5.39013 9.58404 5.36852 9.56066L0.799591 4.61839C0.769134 4.58544 0.748942 4.54433 0.741488 4.50008C0.734034 4.45584 0.73964 4.41038 0.757622 4.36927C0.775603 4.32816 0.805178 4.29318 0.842729 4.26862C0.880279 4.24406 0.924175 4.23098 0.969045 4.23098H3.16828C3.2013 4.23098 3.23393 4.23807 3.26398 4.25176C3.29403 4.26545 3.32079 4.28542 3.34246 4.31034L4.86941 6.06705C5.03444 5.71429 5.35389 5.12694 5.91448 4.41123C6.74321 3.35315 8.28471 1.79705 10.922 0.392315C10.973 0.36517 11.0323 0.358125 11.0882 0.372571C11.1441 0.387016 11.1926 0.421903 11.2241 0.470342C11.2555 0.51878 11.2676 0.57725 11.2581 0.634205C11.2485 0.69116 11.218 0.742461 11.1724 0.777976C11.1624 0.785846 10.1455 1.58662 8.97521 3.05336C7.89817 4.40313 6.46643 6.61021 5.76191 9.45951C5.74954 9.50957 5.72075 9.55404 5.68015 9.58583C5.63955 9.61762 5.58947 9.6349 5.53791 9.6349L5.53798 9.63481Z"
                                                        fill="black"></path>
                                                </svg>
                                            </div>
                                            <p class="rs-skill-list-desc"> Global Expansion Planning </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="rs-skill-clip rs-text-clip-one">
                                    <h2 class="rs-text-clip-title"
                                        data-background="assets/images/about/12.webp">
                                        Mission</h2>
                                </div>
                            </div>
                            <div class="rs-skill-right">
                                <div class="rs-skill-progress-wrapper">
                                    <h5 class="rs-skill-progress-title">Achieve Goals</h5>
                                    <p class="rs-skill-progress-desc">We aim to help businesses achieve sustainable
                                        growth
                                        through effective strategies, innovative thinking, and measurable results. Our
                                        goals
                                        center around delivering value, building strong client relationships, and
                                        staying </p>
                                    <div class="rs-progress-wrapper">
                                        <div class="single-progress">
                                            <div class="progress-top">
                                                <h6 class="progress-title">Human resources</h6>
                                                <span class="progress-number">86%</span>
                                            </div>
                                            <div class="progress">
                                                <div class="progress-bar wow fadeInLeft" data-wow-duration="1s"
                                                    data-wow-delay=".3s" role="progressbar" style="width: 86%"
                                                    aria-valuenow="86" aria-valuemin="0" aria-valuemax="100">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="single-progress">
                                            <div class="progress-top">
                                                <h6 class="progress-title">Investment consulting</h6>
                                                <span class="progress-number">95%</span>
                                            </div>
                                            <div class="progress">
                                                <div class="progress-bar wow fadeInLeft" data-wow-duration="1s"
                                                    data-wow-delay=".5s" role="progressbar" style="width: 95%"
                                                    aria-valuenow="95" aria-valuemin="0" aria-valuemax="100">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="single-progress">
                                            <div class="progress-top">
                                                <h6 class="progress-title">Development</h6>
                                                <span class="progress-number">90%</span>
                                            </div>
                                            <div class="progress">
                                                <div class="progress-bar wow fadeInLeft" data-wow-duration="1s"
                                                    data-wow-delay=".7s" role="progressbar" style="width: 90%"
                                                    aria-valuenow="90" aria-valuemin="0" aria-valuemax="100">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="rs-skill-thumb rs-image scroll_reveal reveal-active"
                                    data-dir="reveal_right">
                                    <img src="assets/images/about/12.webp" alt="image">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- skill area end -->

        <!-- feature area start -->
        <section class="rs-feature-area rs-feature-one">
            <div class="rs-feature-bg-thumb include-bg" data-background="assets/images/bg/feature-bg-thumb-01.webp">
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-feature-wrapper">
                            <div class="rs-feature-item wow fadeIn" data-wow-delay=".3s" data-wow-duration="1s">
                                <div class="rs-feature-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 38">
                                        <path
                                            d="M35.8847 11.5495C35.5146 11.5495 35.1463 11.5762 34.7833 11.6289C34.8477 7.02454 29.8368 4.18955 25.9611 6.46509C24.6953 2.65196 21.1546 0.0604248 17.0599 0.0604248C11.8811 0.0604248 7.66792 4.2736 7.66792 9.45219C7.66792 10.1662 7.74732 10.8695 7.90459 11.5524C3.81104 11.6669 0.516113 15.0302 0.516113 19.1481C0.516113 23.3382 3.92732 26.747 8.12012 26.747L10.5092 26.6906C10.6421 32.9156 15.7436 37.9394 21.9999 37.9394C25.054 37.9394 27.9275 36.7581 30.0912 34.6125C30.1495 34.5547 30.1959 34.4859 30.2277 34.4101C30.2594 34.3344 30.276 34.2531 30.2763 34.1709C30.2767 34.0887 30.2608 34.0073 30.2297 33.9313C30.1985 33.8552 30.1527 33.7861 30.0949 33.7277C30.037 33.6694 29.9682 33.623 29.8925 33.5912C29.8167 33.5595 29.7354 33.5429 29.6532 33.5426C29.571 33.5422 29.4896 33.5581 29.4136 33.5892C29.3375 33.6204 29.2684 33.6662 29.21 33.724C27.2826 35.6353 24.7219 36.6879 22 36.6879C16.3506 36.6879 11.7545 32.0918 11.7545 26.4425C11.7545 20.7931 16.3506 16.197 22 16.197C27.6493 16.197 32.2454 20.7931 32.2454 26.4425C32.2454 28.129 31.8271 29.7981 31.0353 31.2687C30.9589 31.4146 30.9432 31.5848 30.9914 31.7422C31.0397 31.8997 31.1481 32.0318 31.2931 32.1099C31.4381 32.1879 31.6081 32.2057 31.7661 32.1593C31.9241 32.1129 32.0575 32.006 32.1372 31.8619C32.9826 30.2915 33.4439 28.5205 33.4882 26.7237C34.748 26.7521 35.9633 26.7464 36.1052 26.747L36.0604 26.745C40.1697 26.651 43.4837 23.2794 43.4837 19.1481C43.4837 14.9583 40.0749 11.5495 35.8847 11.5495ZM35.8847 25.4956C35.821 25.4959 34.7021 25.4907 33.4566 25.5197C32.9844 19.6105 28.0284 14.9457 21.9999 14.9457C15.9601 14.9457 10.9969 19.6281 10.5407 25.5529L8.12012 25.4957C4.61722 25.4957 1.76762 22.6483 1.76762 19.1483C1.76762 15.3704 5.0696 12.4679 8.67605 12.8285C9.1298 12.8714 9.47536 12.4362 9.3315 12.007C9.05813 11.1915 8.91943 10.3318 8.91943 9.45236C8.91943 4.96385 12.5712 1.31202 17.0599 1.31202C20.8738 1.31202 24.1334 3.90621 24.9864 7.62078H24.9864Z">
                                        </path>
                                    </svg>
                                </div>
                                <h5 class="rs-feature-title"> 26+ Years of Experience</h5>
                                <span class="rs-feature-line"></span>
                                <p class="rs-feature-desc"> With 26+ years of experience and a legacy of trust since 2000, ICEF India provides cost-effective solutions that streamline assessments and maximize workforce potential.
                                </p>
                            </div>
                            <div class="rs-feature-item wow fadeIn" data-wow-delay=".5s" data-wow-duration="1s">
                                <div class="rs-feature-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 38">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M10.5959 36.5456C10.0034 36.5456 9.52067 36.0625 9.52067 35.4686C9.52067 34.8755 10.0034 34.3925 10.5959 34.3925C11.1884 34.3925 11.6758 34.8756 11.6758 35.4686C11.6758 36.0626 11.1884 36.5456 10.5959 36.5456ZM10.5959 1.45436C11.1884 1.45436 11.6758 1.93651 11.6758 2.53042C11.6758 3.12345 11.1884 3.60657 10.5959 3.60657C10.0034 3.60657 9.52067 3.12345 9.52067 2.53042C9.52067 1.93651 10.0034 1.45436 10.5959 1.45436ZM10.5959 33.2605C9.97941 33.2605 9.42519 33.5147 9.02373 33.9232L1.98989 29.9241V8.07486L9.02373 4.07676C9.4251 4.48481 9.97941 4.73861 10.5959 4.73861C11.8144 4.73861 12.8035 3.74755 12.8035 2.53051C12.8035 1.3125 11.8144 0.322415 10.5959 0.322415C9.13189 0.322415 8.09401 1.71968 8.45992 3.09248L1.14413 7.25303C1.05726 7.30259 0.985011 7.3742 0.934672 7.46062C0.884332 7.54704 0.857686 7.64521 0.857422 7.74521V30.2539C0.857515 30.354 0.884089 30.4522 0.934446 30.5387C0.984803 30.6251 1.05715 30.6967 1.14413 30.7461L8.45992 34.9067C8.09401 36.2795 9.13215 37.6777 10.5959 37.6777C11.8144 37.6777 12.8035 36.6867 12.8035 35.4687C12.8035 34.2515 11.8143 33.2605 10.5959 33.2605ZM25.3994 36.5456C24.8069 36.5456 24.3242 36.0625 24.3242 35.4686C24.3242 34.8755 24.8068 34.3925 25.3994 34.3925C25.992 34.3925 26.4746 34.8756 26.4746 35.4686C26.4746 36.0626 25.9919 36.5456 25.3994 36.5456ZM25.3994 3.60657C24.8069 3.60657 24.3242 3.12345 24.3242 2.53042C24.3242 1.93651 24.8068 1.45436 25.3994 1.45436C25.992 1.45436 26.4746 1.93651 26.4746 2.53042C26.4746 3.12345 25.9919 3.60657 25.3994 3.60657ZM34.8511 7.25294L27.5353 3.09239C27.9013 1.72012 26.8636 0.322327 25.3994 0.322327C24.1809 0.322327 23.1917 1.31241 23.1917 2.53042C23.1917 3.74746 24.1809 4.73852 25.3994 4.73852C26.0158 4.73852 26.5749 4.48481 26.9763 4.07667L34.0101 8.07477V29.9241L26.9763 33.9232C26.5749 33.5146 26.0158 33.2605 25.3994 33.2605C24.1809 33.2605 23.1917 34.2515 23.1917 35.4686C23.1917 36.6866 24.1809 37.6776 25.3994 37.6776C26.8634 37.6776 27.9013 36.279 27.5353 34.9066L34.8511 30.746C34.9394 30.6977 35.013 30.6265 35.0643 30.5399C35.1155 30.4533 35.1426 30.3545 35.1426 30.2539V7.74513C35.1426 7.54202 35.0327 7.35423 34.8511 7.25294ZM17.9976 30.2194L6.72535 24.6507L11.1693 22.4564L17.7491 25.7063C17.9045 25.785 18.0931 25.7837 18.2509 25.7063L24.826 22.4564L29.2699 24.6507L17.9976 30.2194ZM6.72535 18.9997L11.1693 16.8054L17.7491 20.0547C17.9063 20.1339 18.0918 20.1324 18.2509 20.0547L24.826 16.8054L29.2699 18.9997L17.9976 24.5676L6.72535 18.9997ZM6.72535 13.3483L17.9976 7.78041L29.2699 13.3483L17.9976 18.9161L6.72535 13.3483ZM31.1144 24.6507C31.1144 24.8667 30.9901 25.0626 30.799 25.1587L18.2509 31.3582C18.0922 31.4346 17.9059 31.4361 17.7491 31.3572L5.19617 25.1587C4.77782 24.9503 4.77677 24.3517 5.19617 24.1437L9.8886 21.8252L5.19617 19.5072C4.77756 19.2992 4.77668 18.7008 5.19617 18.4918L9.8886 16.1738L5.19617 13.8553C4.77729 13.6476 4.77729 13.049 5.19617 12.8414L17.7491 6.64187C17.8271 6.60323 17.913 6.58313 18 6.58313C18.087 6.58313 18.1729 6.60323 18.2509 6.64187L30.799 12.8414C31.2179 13.0491 31.2179 13.6476 30.799 13.8553L26.1066 16.1738L30.799 18.4918C31.2185 18.7008 31.2176 19.2992 30.799 19.5072L26.1066 21.8252L30.799 24.1437C30.9901 24.2388 31.1144 24.4356 31.1144 24.6507L22.9224 24.2152V24.2152Z"></path>
                                    </svg>
                                </div>
                                <h5 class="rs-feature-title"> 25.5K+ Successful Projects</h5>
                                <span class="rs-feature-line"></span>
                                <p class="rs-feature-desc"> Having completed over 25.5K+ successful projects, we utilize innovative technology to deliver precision-driven insights and advanced evaluation tools for your business.
                                </p>
                            </div>
                            <div class="rs-feature-item wow fadeIn" data-wow-delay=".7s" data-wow-duration="1s">
                                <div class="rs-feature-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 44 44"
                                        fill="none">
                                        <path
                                            d="M5.29375 29.5969L3.67812 30.1194L2.30312 25.9119L0.996875 26.3381L2.37188 30.5387C2.48188 30.8894 2.72938 31.1781 3.0525 31.3431C3.37563 31.5081 3.74687 31.5425 4.10437 31.4256L5.72 30.9031C6.47625 32.285 7.40437 33.5706 8.4975 34.7325L7.50062 36.1075C7.28062 36.4031 7.19125 36.7675 7.24625 37.125C7.30125 37.4894 7.50063 37.8125 7.79625 38.0325L11.1306 40.4525C11.4331 40.6725 11.7975 40.7619 12.1619 40.7C12.5262 40.645 12.8425 40.4456 13.0556 40.15L14.0594 38.7819C15.4894 39.4694 17.0019 39.9575 18.5556 40.2463V41.9444C18.5556 42.7006 19.1744 43.3194 19.9306 43.3194H24.0556C24.8119 43.3194 25.4306 42.7006 25.4306 41.9444V40.2463C26.9844 39.9575 28.4969 39.4625 29.9338 38.775L30.9237 40.1431C31.1369 40.4456 31.4531 40.6381 31.8175 40.7C32.1887 40.7619 32.5531 40.6725 32.8487 40.4525L36.1831 38.0325C36.4856 37.8125 36.6781 37.4894 36.7331 37.125C36.7881 36.7606 36.6987 36.4031 36.4856 36.1075L35.4956 34.7256C36.5819 33.5775 37.5169 32.2919 38.2663 30.8962L39.8819 31.4256C40.2325 31.5356 40.6038 31.5081 40.9338 31.3431C41.2638 31.1712 41.5044 30.8894 41.6144 30.5387L42.9894 26.3312L41.6831 25.905L40.3081 30.1194L38.6925 29.59C38.0737 29.3838 37.3931 29.6588 37.0563 30.2431C36.357 31.5264 35.4951 32.7142 34.4919 33.7769C34.0312 34.265 33.9831 35.0075 34.375 35.53L35.3719 36.905L32.0375 39.325L31.0338 37.9431C30.8431 37.6854 30.5687 37.502 30.2577 37.4242C29.9467 37.3465 29.6183 37.3792 29.3288 37.5169C28.0019 38.1494 26.6063 38.6031 25.1831 38.8713C24.53 38.995 24.0487 39.5588 24.0487 40.2188V41.9169H19.9237V40.2188C19.9237 39.5588 19.4494 38.9881 18.7894 38.8713C17.3594 38.6031 15.9637 38.1494 14.63 37.51C14.025 37.235 13.3237 37.4069 12.9319 37.9431L11.935 39.3181L8.60063 36.8981L9.59062 35.53C9.98938 35.0006 9.94125 34.2581 9.47375 33.77C8.46719 32.7034 7.60293 31.511 6.9025 30.2225C6.5725 29.6519 5.89188 29.3769 5.27313 29.5831V29.5831Z">
                                        </path>
                                    </svg>
                                </div>
                                <h5 class="rs-feature-title"> Industry Expertise</h5>
                                <span class="rs-feature-line"></span>
                                <p class="rs-feature-desc"> We begin by understanding your current state goals
                                    challenges. </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- feature area end -->

        <!-- feature area start -->
        <section class="rs-feature-area section-space rs-feature-twelve">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-feature-wrapper">
                            <div class="rs-feature-left">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle">
                                        OUR VISION & PURPOSE
                                    </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left mb-20">Our guiding
                                        principles
                                    </h2>
                                    <p class="rs-section-desc">Our vision is to empower businesses to realize their full
                                        potential through strategic clarity, innovation, and measurable impact We aim to
                                        become
                                        the trusted consulting partner for organizations seeking sustainable growth
                                        operational
                                        excellence, and long-term value creation.</p>
                                </div>
                                <div class="rs-feature-thumb rs-image scroll_reveal reveal-active" data-dir="left">
                                    <img src="assets/images/work/working-thumb-03.webp" alt="image">
                                </div>
                            </div>
                            <div class="rs-feature-right">
                                <div class="rs-feature-list-wrapper">
                                    <div class="rs-feature-list-item wow fadeInUp" data-wow-delay=".3s"
                                        data-wow-duration="1s">
                                        <div class="rs-feature-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M24.2669 20.7386C24.2669 20.5444 24.344 20.3581 24.4814 20.2207C24.6188 20.0833 24.805 20.0062 24.9993 20.0062C25.1935 20.0062 25.3798 20.0833 25.5172 20.2207C25.6546 20.3581 25.7317 20.5444 25.7317 20.7386V24.2676H29.2607C29.455 24.2676 29.6413 24.3448 29.7786 24.4821C29.916 24.6195 29.9931 24.8058 29.9931 25C29.9931 25.1943 29.916 25.3806 29.7786 25.5179C29.6413 25.6553 29.455 25.7325 29.2607 25.7325H25.7317V29.2615C25.7317 29.4557 25.6546 29.642 25.5172 29.7794C25.3798 29.9167 25.1935 29.9939 24.9993 29.9939C24.805 29.9939 24.6188 29.9167 24.4814 29.7794C24.344 29.642 24.2669 29.4557 24.2669 29.2615V25.7325H20.7379C20.5436 25.7325 20.3573 25.6553 20.22 25.5179C20.0826 25.3806 20.0054 25.1943 20.0054 25C20.0054 24.8058 20.0826 24.6195 20.22 24.4821C20.3573 24.3448 20.5436 24.2676 20.7379 24.2676H24.2669V20.7386ZM1.5618 16.9541C1.15213 16.9541 0.829373 17.2764 0.829373 17.7116H0.831131C0.830893 17.8977 0.901896 18.0768 1.02957 18.2122L7.42957 25L1.06463 31.7507C0.569217 32.2414 0.908377 33.0458 1.5618 33.0458H7.86248C9.74206 37.0421 12.9572 40.2573 16.9535 42.1368V48.4375C16.9535 48.8472 17.2758 49.1699 17.7109 49.1699V49.1682C17.897 49.1684 18.0762 49.0974 18.2116 48.9698L24.9993 42.5698L31.75 48.9347C32.2407 49.4301 33.0451 49.0909 33.0451 48.4375V42.1369C37.0414 40.2574 40.2565 37.0422 42.1361 33.0459H48.4368C48.8465 33.0459 49.1692 32.7237 49.1692 32.2885H49.1675C49.1677 32.1024 49.0967 31.9232 48.969 31.7878L42.569 25L48.934 18.2493C49.4294 17.7586 49.0902 16.9542 48.4368 16.9542H42.1362C40.2566 12.9579 37.0415 9.74279 33.0452 7.86321V1.56253C33.0452 1.15286 32.7229 0.830106 32.2878 0.830106V0.831863C32.1016 0.831612 31.9225 0.902656 31.7871 1.0304L24.9993 7.4303L18.2486 1.06536C17.7579 0.569949 16.9535 0.90911 16.9535 1.56253V7.86321C12.9572 9.74279 9.74206 12.9579 7.86248 16.9542L1.5618 16.9541Z">
                                                </path>
                                            </svg>
                                        </div>
                                        <div class="rs-feature-list-content">
                                            <h5 class="rs-feature-list-title">Drive Inspired Impact</h5>
                                            <p class="rs-feature-list-desc"> Our marketing strategy focuses on building
                                                brand awareness </p>
                                        </div>
                                    </div>
                                    <div class="rs-feature-list-item wow fadeInUp" data-wow-delay=".5s"
                                        data-wow-duration="1s">
                                        <div class="rs-feature-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40">
                                                <path
                                                    d="M32.1852 24.9574C28.1952 24.9574 24.9607 28.1919 24.9607 32.1819C24.9607 36.1719 28.1952 39.4063 32.1852 39.4063C36.1752 39.4063 39.4096 36.1719 39.4096 32.1819C39.4048 28.1938 36.1733 24.9623 32.1852 24.9574ZM32.1852 38.0928C32.1852 38.0928Z">
                                                </path>
                                            </svg>
                                        </div>
                                        <div class="rs-feature-list-content">
                                            <h5 class="rs-feature-list-title"> Focused On The Future</h5>
                                            <p class="rs-feature-list-desc"> Workflow optimization is the process of
                                                analyzing, redesigning </p>
                                        </div>
                                    </div>
                                    <div class="rs-feature-list-item wow fadeInUp" data-wow-delay=".7s"
                                        data-wow-duration="1s">
                                        <div class="rs-feature-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 38">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M10.5959 36.5456V36.5456Z">
                                                </path>
                                            </svg>
                                        </div>
                                        <div class="rs-feature-list-content">
                                            <h5 class="rs-feature-list-title">Excellence in Everything</h5>
                                            <p class="rs-feature-list-desc"> Growth planning is the strategic process of
                                                setting clear </p>
                                        </div>
                                    </div>
                                    <div class="rs-feature-list-item wow fadeInUp" data-wow-delay=".9s"
                                        data-wow-duration="1s">
                                        <div class="rs-feature-list-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 39 44">
                                                <path
                                                    d="M38.1299 14.3499L34.8829 14.2568C34.5257 13.0258 33.9981 11.8432 33.3134 10.7387L35.5382 8.53967C35.5186 8.53967Z">
                                                </path>
                                            </svg>
                                        </div>
                                        <div class="rs-feature-list-content">
                                            <h5 class="rs-feature-list-title">Focus on the Client</h5>
                                            <p class="rs-feature-list-desc"> Brand development is the strategic process
                                                of creating, defining </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- feature area end -->

        <!-- feature area start (HR solutions) -->
        <section class="rs-feature-area rs-feature-six section-space theme-secondary">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-feature-wrapper">
                            <div class="rs-feature-sec-wrapper">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle is-white">
                                        Build Your Industries
                                    </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left mb-10 is-white">HR
                                        solutions
                                        tailored to your industry</h2>
                                    <p class="section-desc">Find answers to our question about our consulting coverage
                                        options.
                                    </p>
                                </div>
                                <div class="rs-feature-more-btn">
                                    <a class="rs-btn has-icon hover-white" href="industry.php">View All
                                        Industries
                                        <span class="icon-box">
                                            <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>

                                            <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="rs-feature-content-wrapper">
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".3s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-05.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="financial-services.php">Advanced
                                                Manufacturing</a>
                                        </h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="financial-services.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".4s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-06.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="financial-services.php">Financial Services
                                            </a>
                                        </h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="financial-services.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".5s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-07.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="financial-services.php">Energy & Natural
                                                Resources</a></h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="financial-services.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".6s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-08.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="financial-services.php">Government</a>
                                        </h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="financial-services.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".7s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-09.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="financial-services.php"> Healthcare & Life
                                                Sciences
                                            </a>
                                        </h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="financial-services.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".8s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-10.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="financial-services.php">Agribusiness</a>
                                        </h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="financial-services.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- feature area end (HR solutions) -->
        <!-- feature area start (Industries we help) -->
        <section class="rs-feature-area rs-feature-three section-space">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-feature-wrapper">
                            <div class="rs-feature-sec-wrapper">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle">
                                        Build Your Industries
                                    </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left mb-10">Industries we
                                        help</h2>
                                    <p class="section-desc">We support businesses in tech, retail, real estate, finance,
                                        healthcare, and more providing custom strategies that work in your world.</p>
                                </div>
                                <div class="rs-feature-more-btn">
                                    <a class="rs-btn has-icon hover-secondary border-hover-primary"
                                        href="industry.php">View All
                                        Industries
                                        <span class="icon-box">
                                            <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>

                                            <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                    fill="white" />
                                            </svg>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="rs-feature-content-wrapper">
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".1s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-05.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="financial-services.php">Advanced
                                                Manufacturing</a></h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="financial-services.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".2s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-06.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="financial-services.php">Financial Services
                                            </a></h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="financial-services.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".3s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-07.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="financial-services.php">Energy & Natural
                                                Resources</a></h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="financial-services.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".4s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-08.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="financial-services.php">Government</a>
                                        </h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="financial-services.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".5s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-09.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="financial-services.php"> Healthcare & Life
                                                Sciences </a>
                                        </h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="financial-services.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="rs-feature-item wow fadeIn" data-wow-delay=".6s" data-wow-duration="1s">
                                    <div class="rs-feature-info">
                                        <div class="rs-feature-thumb">
                                            <img src="assets/images/feature/feature-thumb-10.webp" alt="image">
                                        </div>
                                        <h6 class="rs-feature-title"><a href="financial-services.php">Agribusiness</a>
                                        </h6>
                                    </div>
                                    <div class="rs-feature-btn">
                                        <a class="rs-btn has-icon has-text" href="team.php">
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- feature area end (Industries we help) -->
        <!-- testimonial area start -->
        <section class="rs-testimonial-area section-space-top rs-testimonial-two rs-swiper">
            <div class="rs-testimonial-bg-thumb include-bg"
                data-background="assets/images/bg/testimonial-bg-thumb-02.webp"></div>
            <div class="rs-testimonial-shape">
                <img src="assets/images/shape/testimonial-shape-02.webp" alt="image">
            </div>
            <div class="container">
                <div class="row align-items-center g-5 section-title-space">
                    <div class="col-xl-6 col-lg-6">
                        <div class="section-title-wrapper">
                            <span class="section-subtitle is-white">
                                Our Clients Testimonials
                            </span>
                            <h2 class="section-title rs-split-text-enable split-in-left mb-10 is-white">What our
                                customers say?
                            </h2>
                            <p class="section-desc">Find Answers to our Question about Our Consulting Coverage Options.
                            </p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="rs-testimonial-counter">
                            <div class="rs-counter-item">
                                <div class="rs-counter-number-wrapper">
                                    <span class="rs-counter-number odometer" data-count="98">00</span>
                                    <span class="prefix">%</span>
                                </div>
                                <span class="rs-counter-title">Business Growth Rate</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-testimonial-wrapper">
                            <div class="rs-testimonial-thumb rs-image scroll_reveal reveal-active" data-dir="left">
                                <img src="assets/images/about/8.webp" alt="image">
                            </div>
                            <div class="rs-testimonial-slider-wrapper">
                                <div class="swiper" data-clone-slides="false" data-loop="true" data-speed="1500"
                                    data-autoplay="true" data-dots-dynamic="false" data-effect="false" data-delay="2000"
                                    data-item="1" data-item-xl="1" data-item-lg="1" data-item-md="1" data-item-sm="1"
                                    data-item-xs="1" data-item-mobile="1" data-margin="30">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <div class="rs-testimonial-item">
                                                <div class="rs-testimonial-top">
                                                    <div class="rs-testimonial-title-info">
                                                        <h6 class="rs-testimonial-title">Business Consulting</h6>
                                                        <div class="rs-testimonial-icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="60"
                                                                height="44" viewBox="0 0 60 44" fill="none">
                                                                <path
                                                                    d="M12.7244 28.0195C11.6004 34.2343 9.70513 38.7081 8.20652 41.485C7.61148 42.5648 8.82362 43.777 9.88146 43.1599C22.4434 35.8431 27.953 25.1765 28.6362 16.6036C29.2312 9.22068 24.1844 1.61742 16.5591 0.229C8.9338 -1.15942 1.61704 3.90943 0.228614 11.5347C-1.22592 19.5347 4.41591 27.2261 12.7244 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                                <path
                                                                    d="M44.0406 28.0195C42.9166 34.2343 41.0213 38.7081 39.5227 41.485C38.9277 42.5648 40.1398 43.777 41.1976 43.1599C53.7595 35.8431 59.2692 25.1765 59.9524 16.6036C60.5474 9.22068 55.5006 1.61742 47.8753 0.229C40.25 -1.15942 32.9332 3.90943 31.5448 11.5347C30.0902 19.5347 35.7321 27.2261 44.0406 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="rs-testimonial-rating-icon">
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-line"></i>
                                                    </div>
                                                </div>
                                                <p class="rs-testimonial-desc"> “As a growing business, we needed a partner who understood the complexities of the Indian market. ICEF's strategic consulting and workforce management solutions have been instrumental in our regional expansion.”
                                                </p>
                                                <div class="rs-testimonial-avater-wrapper">
                                                    <div class="rs-testimonial-avater-thumb">
                                                        <img src="assets/images/user/indian-user-01.png" alt="image">
                                                    </div>
                                                    <div class="rs-testimonial-avater-info">
                                                        <h6 class="rs-testimonial-avater-title">Vikram Malhotra</h6>
                                                        <span class="rs-testimonial-avater-designation">Founder &
                                                            CEO</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="rs-testimonial-item">
                                                <div class="rs-testimonial-top">
                                                    <div class="rs-testimonial-title-info">
                                                        <h6 class="rs-testimonial-title">Business Consulting</h6>
                                                        <div class="rs-testimonial-icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="60"
                                                                height="44" viewBox="0 0 60 44" fill="none">
                                                                <path
                                                                    d="M12.7244 28.0195C11.6004 34.2343 9.70513 38.7081 8.20652 41.485C7.61148 42.5648 8.82362 43.777 9.88146 43.1599C22.4434 35.8431 27.953 25.1765 28.6362 16.6036C29.2312 9.22068 24.1844 1.61742 16.5591 0.229C8.9338 -1.15942 1.61704 3.90943 0.228614 11.5347C-1.22592 19.5347 4.41591 27.2261 12.7244 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                                <path
                                                                    d="M44.0406 28.0195C42.9166 34.2343 41.0213 38.7081 39.5227 41.485C38.9277 42.5648 40.1398 43.777 41.1976 43.1599C53.7595 35.8431 59.2692 25.1765 59.9524 16.6036C60.5474 9.22068 55.5006 1.61742 47.8753 0.229C40.25 -1.15942 32.9332 3.90943 31.5448 11.5347C30.0902 19.5347 35.7321 27.2261 44.0406 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="rs-testimonial-rating-icon">
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-line"></i>
                                                    </div>
                                                </div>
                                                <p class="rs-testimonial-desc"> “The team at ICEF is professional and results-oriented. Their data-driven approach to assessment and recruitment has improved our operational efficiency by 40% in just one year.”
                                                </p>
                                                <div class="rs-testimonial-avater-wrapper">
                                                    <div class="rs-testimonial-avater-thumb">
                                                        <img src="assets/images/user/indian-user-02.png" alt="image">
                                                    </div>
                                                    <div class="rs-testimonial-avater-info">
                                                        <h6 class="rs-testimonial-avater-title">Priyanka Rao</h6>
                                                        <span class="rs-testimonial-avater-designation">Project
                                                            Manager</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="rs-testimonial-item">
                                                <div class="rs-testimonial-top">
                                                    <div class="rs-testimonial-title-info">
                                                        <h6 class="rs-testimonial-title">Business Consulting</h6>
                                                        <div class="rs-testimonial-icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="60"
                                                                height="44" viewBox="0 0 60 44" fill="none">
                                                                <path
                                                                    d="M12.7244 28.0195C11.6004 34.2343 9.70513 38.7081 8.20652 41.485C7.61148 42.5648 8.82362 43.777 9.88146 43.1599C22.4434 35.8431 27.953 25.1765 28.6362 16.6036C29.2312 9.22068 24.1844 1.61742 16.5591 0.229C8.9338 -1.15942 1.61704 3.90943 0.228614 11.5347C-1.22592 19.5347 4.41591 27.2261 12.7244 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                                <path
                                                                    d="M44.0406 28.0195C42.9166 34.2343 41.0213 38.7081 39.5227 41.485C38.9277 42.5648 40.1398 43.777 41.1976 43.1599C53.7595 35.8431 59.2692 25.1765 59.9524 16.6036C60.5474 9.22068 55.5006 1.61742 47.8753 0.229C40.25 -1.15942 32.9332 3.90943 31.5448 11.5347C30.0902 19.5347 35.7321 27.2261 44.0406 28.0195Z"
                                                                    fill="#3D4C57"></path>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="rs-testimonial-rating-icon">
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-fill"></i>
                                                        <i class="ri-star-line"></i>
                                                    </div>
                                                </div>
                                                <p class="rs-testimonial-desc"> “ICEF provides a highly scalable and secure environment for online examinations. Their expertise in IT enablement has allowed us to transition from offline to digital assessments with complete confidence.”
                                                </p>
                                                <div class="rs-testimonial-avater-wrapper">
                                                    <div class="rs-testimonial-avater-thumb">
                                                        <img src="assets/images/user/indian-user-03.png" alt="image">
                                                    </div>
                                                    <div class="rs-testimonial-avater-info">
                                                        <h6 class="rs-testimonial-avater-title">Sameer Deshpande</h6>
                                                        <span class="rs-testimonial-avater-designation">Developer</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- if we need navigation -->
                                    <div class="rs-testimonial-navigation rs-swiper-btn-wrapper">
                                        <div class="rs-swiper-btn swiper-button-prev has-transparent has-border"><i
                                                class="ri-arrow-left-line"></i>
                                        </div>
                                        <div class="rs-swiper-btn swiper-button-next has-transparent has-border"><i
                                                class="ri-arrow-right-line"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- testimonial area end -->
        <!-- faq area start -->
        <section class="rs-faq-area section-space rs-faq-one theme-secondary">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="rs-faq-wrapper">
                            <div class="rs-faq-left">
                                <div class="section-title-wrapper">
                                    <span class="section-subtitle is-white">
                                        Frequently asked questions
                                    </span>
                                    <h2 class="section-title rs-split-text-enable split-in-left is-white mb-20">
                                        Frequently Asked
                                        Question</h2>
                                    <p class="rs-section-desc">Find answers to our question about our consulting
                                        coverage
                                        options.</p>
                                </div>
                                <div class="rs-faq-contact">
                                    <div class="rs-faq-contact-info">
                                        <h5 class="rs-faq-contact-title">Still Have Questions?</h5>
                                        <p class="rs-faq-contact-desc">We're here to help you!</p>
                                    </div>
                                    <div class="rs-faq-contact-btn">
                                        <a class="rs-btn has-icon has-bg-white has-bg-secondary"
                                            href="contact.php">Contact Us
                                            <span class="icon-box">
                                                <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white" />
                                                </svg>

                                                <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                        fill="white" />
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-faq-right">
                                <div class="rs-faq-content rs-accordion-one">
                                    <div class="accordion-wrapper">
                                        <div class="accordion" id="accordionExampleOne">
                                            <div class="rs-accordion-item has-bg-active active">
                                                <h4 class="accordion-header" id="headingOne">
                                                    <button class="accordion-button" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseOne"
                                                        aria-expanded="true" aria-controls="collapseOne">
                                                        How do your startups with product
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h4>
                                                <div id="collapseOne" class="accordion-collapse collapse show"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Launching a startup begins with more
                                                        than just an
                                                        idea it starts with creating a product that solves a real
                                                        problem.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingTwo">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                                        aria-expanded="false" aria-controls="collapseTwo">
                                                        Can your with fundraising investor
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseTwo" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Securing the right investment is
                                                        essential for
                                                        fueling growth and scaling a business. Our fundraising approach
                                                        is designed
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingThree">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                                        aria-expanded="false" aria-controls="collapseThree">
                                                        What makes startup consulting
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseThree" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Startup consulting helps entrepreneurs
                                                        turn ideas
                                                        into thriving businesses. By combining market insights,
                                                        strategy, and
                                                        execution</div>
                                                </div>
                                            </div>
                                            <div class="rs-accordion-item has-bg-active">
                                                <h6 class="accordion-header" id="headingFour">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseFour"
                                                        aria-expanded="false" aria-controls="collapseFour">
                                                        Do you provide financial planning
                                                        <span class="accordion-btn"></span>
                                                    </button>
                                                </h6>
                                                <div id="collapseFour" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExampleOne">
                                                    <div class="accordion-body">Financial planning is the foundation of
                                                        long-term
                                                        stability and growth. It helps businesses and individuals make
                                                        informed</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- faq area end -->
    </main>
    <!-- Body main wrapper end -->

    <!-- footer area start -->
<footer class="rs-footer-area rs-footer-one theme-secondary">
    <div class="rs-footer-shape-one">
        <img src="assets/images/shape/footer-shape-01.webp" alt="image">
    </div>
    <div class="rs-footer-shape-two">
        <img src="assets/images/shape/footer-shape-02.webp" alt="image">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="rs-footer-wrapper">
                    <div class="rs-footer-left">
                        <div class="rs-footer-widget footer-1-col-1">
                            <div class="rs-footer-widget-logo">
                                <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA"></a>
                            </div>
                            <div class="rs-footer-widget-content">
                                <p class="rs-footer-widget-desc">
                                    ICEF INDIA is a premier organization providing end-to-end solutions in Assessment, Recruitment, and Workforce Development since 2000.
                                </p>
                                <div class="rs-footer-widget-contact-info">
                                    <div class="rs-footer-content-item">
                                        <span>Call us:</span>
                                        <a href="tel:+911204221735">+91 120 422 1735</a>
                                    </div>
                                    <div class="rs-footer-content-item">
                                        <span>Email:</span>
                                        <a href="mailto:sales@icefindia.in">sales@icefindia.in</a>
                                    </div>
                                    <div class="rs-footer-content-item">
                                        <span>Hours: Mon-Fri: 8.00am - 18.00pm</span>
                                    </div>
                                </div>
                                <div class="rs-footer-widget-social">
                                    <div class="rs-footer-social theme-social has-border">
                                        <a href="#"><svg width="14" height="22" viewBox="0 0 14 22" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M11.624 11.9541L12.193 8.54137L8.63572 8.54137V6.32676C8.63572 5.39311 9.13264 4.48303 10.7258 4.48303H12.343V1.57748C12.343 1.57748 10.8755 1.34692 9.47233 1.34692C6.54282 1.34692 4.62796 2.98146 4.62796 5.94041L4.62796 8.54137H1.37158L1.37158 11.9541H4.62796L4.62796 20.2041H8.63572L8.63572 11.9541H11.624Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M17.6045 5.45036C17.5641 4.53485 17.4161 3.9055 17.204 3.3601C16.9852 2.78121 16.6486 2.26294 16.2077 1.83208C15.7768 1.39452 15.2551 1.0545 14.6829 0.839154C14.1344 0.627106 13.5083 0.479009 12.5928 0.438686C11.6705 0.394863 11.3777 0.384766 9.03843 0.384766C6.69917 0.384766 6.40637 0.394863 5.48747 0.435253C4.57199 0.475643 3.94261 0.623808 3.39738 0.835721C2.81832 1.0545 2.30005 1.39108 1.86919 1.83208C1.43163 2.26291 1.09178 2.78461 0.876264 3.3568C0.664216 3.9055 0.516152 4.53148 0.475796 5.44692C0.432006 6.36927 0.421875 6.66206 0.421875 9.00132C0.421875 11.3406 0.432006 11.6334 0.472363 12.5523C0.512753 13.4678 0.660917 14.0971 0.872999 14.6425C1.09178 15.2214 1.43163 15.7397 1.86919 16.1706C2.30005 16.6081 2.82175 16.9481 3.39395 17.1635C3.94258 17.3755 4.56856 17.5236 5.4842 17.564C6.40294 17.6045 6.6959 17.6144 9.03516 17.6144C11.3744 17.6144 11.6672 17.6045 12.5861 17.564C13.5016 17.5236 14.131 17.3756 14.6762 17.1635C15.2489 16.9421 15.7689 16.6035 16.2031 16.1693C16.6372 15.7352 16.9759 15.2152 17.1973 14.6425C17.4092 14.0939 17.5574 13.4678 17.5978 12.5523C17.6382 11.6334 17.6483 11.3406 17.6483 9.00132C17.6483 6.66206 17.6449 6.36923 17.6045 5.45036ZM16.0529 12.485C16.0159 13.3264 15.8745 13.7808 15.7567 14.0837C15.4672 14.8343 14.8715 15.4301 14.1208 15.7196C13.8179 15.8374 13.3603 15.9787 12.5221 16.0157C11.6133 16.0562 11.3408 16.0662 9.04186 16.0662C6.74296 16.0662 6.46699 16.0562 5.56148 16.0157C4.72002 15.9787 4.26563 15.8374 3.96271 15.7196C3.5892 15.5815 3.24922 15.3628 2.97322 15.0767C2.68712 14.7973 2.46834 14.4607 2.33027 14.0872C2.21247 13.7842 2.07114 13.3264 2.03421 12.4884C1.99369 11.5796 1.98373 11.3069 1.98373 9.00802C1.98373 6.70911 1.99369 6.43315 2.03421 5.5278C2.07114 4.68634 2.21247 4.23196 2.33027 3.92903C2.46834 3.55535 2.68712 3.21544 2.97665 2.93937C3.25588 2.65328 3.59246 2.4345 3.96614 2.2966C4.26907 2.17879 4.72689 2.03743 5.56491 2.00037C6.47369 1.95998 6.74639 1.94988 9.04513 1.94988C11.3475 1.94988 11.62 1.95998 12.5255 2.00037C13.367 2.03746 13.8214 2.17876 14.1243 2.29656C14.4978 2.4345 14.8378 2.65328 15.1138 2.93937C15.3999 3.21877 15.6186 3.55535 15.7567 3.92903C15.8745 4.23196 16.0159 4.68961 16.0529 5.5278C16.0933 6.43658 16.1034 6.70911 16.1034 9.00802C16.1034 11.3069 16.0933 11.5762 16.0529 12.485Z"
                                                    fill="white"></path>
                                                <path
                                                    d="M9.0335 4.57741C6.58997 4.57741 4.60742 6.55982 4.60742 9.00349C4.60742 11.4472 6.58997 13.4296 9.0335 13.4296C11.4771 13.4296 13.4596 11.4472 13.4596 9.00349C13.4596 6.55982 11.4771 4.57741 9.0335 4.57741ZM9.0335 11.8746C7.44826 11.8746 6.16237 10.5889 6.16237 9.00349C6.16237 7.41811 7.44826 6.13243 9.03347 6.13243C10.6188 6.13243 11.9046 7.41811 11.9046 9.00349C11.9046 10.5889 10.6188 11.8746 9.0335 11.8746ZM14.668 4.40239C14.668 4.97303 14.2053 5.4357 13.6345 5.4357C13.0639 5.4357 12.6013 4.97303 12.6013 4.40239C12.6013 3.83167 13.0639 3.36914 13.6346 3.36914C14.2053 3.36914 14.668 3.83164 14.668 4.40239Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M9.35332 6.88729L14.6472 0.733521H13.3928L8.79603 6.07675L5.12465 0.733521H0.890137L6.44199 8.81343L0.890137 15.2666H2.1447L6.99896 9.62397L10.8762 15.2666H15.1107L9.35332 6.88729ZM7.63502 8.88462L7.0725 8.08004L2.59674 1.67793H4.52367L8.13567 6.84464L8.69818 7.64922L13.3933 14.3651H11.4664L7.63502 8.88462Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M17.7973 17.7992V11.3532C17.7973 8.18522 17.1153 5.76522 13.4193 5.76522C11.6373 5.76522 10.4493 6.73322 9.96527 7.65722H9.92126V6.05122H6.42326V17.7992H10.0753V11.9692C10.0753 10.4292 10.3613 8.95522 12.2533 8.95522C14.1233 8.95522 14.1453 10.6932 14.1453 12.0572V17.7772H17.7973V17.7992ZM0.483266 6.05122H4.13527V17.7992H0.483266V6.05122ZM2.30927 0.199219C1.14327 0.199219 0.197266 1.14522 0.197266 2.31122C0.197266 3.47722 1.14327 4.44522 2.30927 4.44522C3.47527 4.44522 4.42127 3.47722 4.42127 2.31122C4.42127 1.14522 3.47527 0.199219 2.30927 0.199219Z"
                                                    fill="white"></path>
                                            </svg></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rs-footer-right">
                        <div class="rs-footer-widget-wrapper">
                            <div class="rs-footer-widget footer-1-col-2">
                                <h5 class="rs-footer-widget-title">About​</h5>
                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="industry-clients.php">Industry we work with</a></li>
                                        <li><a href="why-choose-us.php">Why choose us</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                        <li><a href="contact.php">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rs-footer-widget footer-1-col-3">
                                <h5 class="rs-footer-widget-title">Services</h5>
                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="it-emerging-tech-enablement.php">IT & Emerging Tech Enablement</a></li>
                                        <li><a href="assessment-and-testing.php">Assessment & Testing</a></li>
                                        <li><a href="recruitment-and-hiring.php">Recruitment & Hiring</a></li>
                                        <li><a href="exam-management.php">Exam Management</a></li>
                                        <li><a href="manpower-and-workforce.php">Manpower & Workforce</a></li>
                                        <li><a href="call-center-and-bpos.php">Call Center & BPOs</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rs-footer-widget footer-1-col-4">
                                <h5 class="rs-footer-widget-title">Quick Links</h5>

                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="#solutions">Our Solutions</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                        <li><a href="industry-clients.php#clients">Clientele</a></li>
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="rs-footer-subscribe-from">
                            <h5 class="rs-footer-subscribe-title">Subscribe Newsletter</h5>
                            <div class="rs-cta-input">
                                <input id="email2" name="name" type="text" placeholder="Enter your email">
                                <button type="submit" class="rs-btn has-icon has-bg-secondary has-sm-radius">
                                    Send Now
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white"></path>
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white"></path>
                                        </svg>
                                    </span>
                                </button>
                            </div>
                        </div>
                        <div class="rs-footer-brand">
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-07.webp" alt="image">
                            </div>
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-08.webp" alt="image">
                            </div>
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-09.webp" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="rs-footer-copyright-area rs-copyright-one">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="rs-footer-copyright-wrapper">
                        <div class="rs-footer-copyright-left">
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright-link">
                                    <a href="terms-conditions.php">Terms & Agreements</a>
                                </div>
                            </div>
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright-link">
                                    <a href="privacy-policy.php">Privacy policy</a>
                                </div>
                            </div>
                        </div>
                        <div class="rs-footer-copyright-right">
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright">
                                    <p class="underline">Copyright © <span id="year">2025</span> ICEF INDIA. All rights reserved. Designed by <a
                                            target="_blank" href="https://agumentiksoftware.com/">AGUMENTIK.</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer area end -->

        <!-- back to top -->
    <!-- Backtotop start -->
    <div class="backtotop-wrap cursor-pointer">
        <i class="ri-arrow-up-s-line"></i>
    </div>
    <!-- Backtotop end -->

    <!-- JS here -->
    <script src="assets/js/vendor/jquery-3.7.1.min.js"></script>
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/meanmenu@2.0.8/jquery.meanmenu.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/wowjs@1.1.3/dist/wow.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/magnific-popup@1.1.0/dist/jquery.magnific-popup.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/isotope-layout@3.0.6/dist/isotope.pkgd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/imagesloaded@5.0.0/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/vendor/ajax-form.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@studio-freight/lenis@1.0.34/dist/lenis.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
    <script src="assets/js/plugins/rs-scroll-trigger.min.js"></script>
    <script src="assets/js/plugins/rs-splitText.min.js"></script>
    <!-- Custom theme scripts (Restored) -->
    <script src="assets/js/plugins/rs-anim-int.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery.appear@1.0.1/jquery.appear.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-nice-select@1.1.0/js/jquery.nice-select.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/nouislider@15.7.1/dist/nouislider.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/odometer@0.4.8/odometer.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>
</body>

</html>
