<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="template-version" content="1.0.0">
    <title>Articles - ICEF INDIA    </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/favicon-icef.png">
    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/animate.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="assets/css/plugins/flatpickr.min.css">
    <link rel="stylesheet" href="assets/css/plugins/nouislider.min.css">
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/vendor/odometer.min.css">
    <link rel="stylesheet" href="assets/css/vendor/spacing.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css">
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        /* =============================================
           Banner Contact Form — Form Overlaps Girl Image
        ============================================= */

        /* Right column: position:relative so the form can be overlaid */
        .rs-banner-form-wrap {
            position: relative;
            display: block;
        }

        /* Girl image: fully visible, natural width, drives wrapper height */
        .rs-banner-bg-img {
            display: block;
            width: 100%;
            height: auto;
            object-fit: cover;
            object-position: top center;
            opacity: 1;
            position: relative;
            z-index: 0;
        }

        /* Form card: positioned absolutely, centred over the girl image */
        .rs-banner-contact-form {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 3;
            background: #ffffff;
            border-radius: 8px;
            padding: 28px 24px;
            width: calc(100% - 60px);
            max-width: 400px;
            box-shadow: 0 8px 40px rgba(0, 0, 0, 0.28);
        }

        .rs-form-title {
            font-size: 20px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 4px;
            line-height: 1.3;
        }

        .rs-form-subtitle {
            font-size: 12px;
            color: #888;
            margin-bottom: 14px;
        }

        .rs-contact-form-banner .rs-form-row {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }

        .rs-contact-form-banner .rs-form-group {
            flex: 1 1 0%;
            min-width: 0;
            display: flex;
            flex-direction: column;
        }

        .rs-contact-form-banner .rs-form-group-full {
            flex: 1 1 100%;
        }

        .rs-contact-form-banner input,
        .rs-contact-form-banner select,
        .rs-contact-form-banner .nice-select,
        .rs-contact-form-banner textarea {
            width: 100% !important;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            font-size: 14px;
            color: #444;
            background: #fff !important;
            background-image: none !important;
            outline: none;
            transition: border-color 0.3s;
            font-family: inherit;
            appearance: none !important;
            -webkit-appearance: none !important;
            -moz-appearance: none !important;
            box-sizing: border-box;
        }

        .rs-contact-form-banner input,
        .rs-contact-form-banner select,
        .rs-contact-form-banner .nice-select {
            height: 45px !important;
            padding: 0 12px;
            line-height: 43px; /* adjusted for border */
        }

        .rs-contact-form-banner .nice-select {
            display: flex;
            align-items: center;
            float: none;
        }

        .rs-contact-form-banner .nice-select .current {
            display: block;
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            padding-right: 20px;
        }

        .rs-contact-form-banner .nice-select:after {
            content: "" !important;
            border-bottom: 2px solid #AB052D;
            border-right: 2px solid #AB052D;
            height: 8px;
            width: 8px;
            right: 15px;
            top: 40%; 
            transform: rotate(45deg);
        }

        .rs-contact-form-banner input::placeholder,
        .rs-contact-form-banner textarea::placeholder {
            color: #aaa;
        }

        .rs-contact-form-banner input:focus,
        .rs-contact-form-banner select:focus,
        .rs-contact-form-banner .nice-select:focus,
        .rs-contact-form-banner textarea:focus {
            border-color: #AB052D;
        }

        .rs-contact-form-banner select {
            cursor: pointer;
            color: #aaa;
        }

        .rs-contact-form-banner select option:not([disabled]) {
            color: #444;
        }

        .rs-contact-form-banner textarea {
            height: 120px !important;
            padding: 12px;
            resize: none;
            line-height: normal;
        }

        /* Button: maroon matching the site header */
        .rs-banner-form-btn {
            width: 100%;
            background: #AB052D;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 12px;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 1.5px;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            text-transform: uppercase;
        }

        .rs-banner-form-btn:hover {
            background: #8c0424;
            transform: translateY(-1px);
        }

        /* Banner left content: nudge right so it's not touching the left edge */
        .rs-banner-area .rs-banner-content {
            padding-left: 60px;
        }

        /* Hero Left Button: make it maroon */
        .rs-banner-area .rs-banner-content .rs-btn {
            background-color: #AB052D;
            border-color: #AB052D;
        }

        .rs-banner-area .rs-banner-content .rs-btn:hover {
            background-color: #8c0424;
            border-color: #8c0424;
        }

        /* ---- Responsive overrides ---- */
        @media (max-width: 1399px) {
            .rs-banner-area .rs-banner-content { padding-left: 40px; }
        }

        @media (max-width: 1199px) {
            .rs-banner-area .rs-banner-content { padding-left: 24px; }
        }

        @media (max-width: 991px) {
            .rs-banner-area .rs-banner-content { padding-left: 16px; }

            .rs-banner-contact-form {
                position: relative;
                top: auto;
                left: auto;
                transform: none;
                width: 100%;
                max-width: 100%;
                margin-top: 20px;
            }

            .rs-contact-form-banner .rs-form-row {
                flex-direction: column;
                gap: 10px;
            }
        }

        /* =============================================
           Glass Effect — Transparent Header over Banner
        ============================================= */
        @media (min-width: 992px) {

            /* Overlay Header Container — only for main header, not sticky */
            .rs-header-area.header-transparent:not(.rs-sticky-header) {
                position: absolute;
                width: 100%;
                top: 40px; /* leave space for the Top Red Bar */
                left: 0;
                z-index: 1000;
                background: transparent;
            }

            /* Top Red Bar */
            .header-transparent-parent .rs-header-top {
                background: #AB052D !important;
                position: relative;
                z-index: 1002;
                height: 40px;
                display: flex !important;
                align-items: center;
            }

            /* Sticky header — glass while not yet active */
            .header-transparent.rs-sticky-header:not(.active) {
                background: rgba(43, 57, 68, 0.4) !important;
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                position: fixed;
                width: 100%;
                top: -100px;
                z-index: 1001;
                visibility: hidden;
                opacity: 0;
                pointer-events: none;
                transition: all 0.4s ease;
            }

            /* Sticky header — fully visible when active */
            .header-transparent.rs-sticky-header.active {
                background: var(--rs-theme-secondary) !important;
                backdrop-filter: none;
                -webkit-backdrop-filter: none;
                top: 0 !important;
                position: fixed;
                width: 100%;
                visibility: visible;
                opacity: 1;
                pointer-events: auto;
            }
        }

        /* Mobile Menu Fix: hide desktop nav on small screens */
        @media (max-width: 1199px) {
            .header-menu,
            .main-menu,
            #mobile-menu,
            #mobile-menu-two {
                display: none !important;
            }
        }
    </style>
</head>

<body class="rs-smoother-yes">

        <!-- preloader start -->
    <div id="pre-load">
        <div id="loader" class="loader">
            <div class="loader-container">
                <div class="loader-icon"><img src="assets/images/logo/favicon-icef.png" alt="ICEF INDIA"></div>
            </div>
        </div>
    </div>
    <!-- preloader end -->

    <!-- preloader start -->

    <div id="rs-mouse">
        <div id="cursor-ball"></div>
    </div>

    <!-- preloader end -->

    <style>
        /* Custom Mega Menu for Solutions with Feature Image */
        .main-menu .mega-grid-two {
            grid-template-columns: repeat(6, 1fr) 300px !important;
            width: 1550px !important;
            padding: 0 !important;
            overflow: hidden;
            border-radius: 10px !important;
            background-color: var(--rs-theme-secondary) !important;
        }

        @media only screen and (max-width: 1600px) {
            .main-menu .mega-grid-two {
                width: 1350px !important;
                grid-template-columns: repeat(6, 1fr) 250px !important;
            }
        }

        @media only screen and (max-width: 1366px) {
            .main-menu .mega-grid-two {
                width: 1180px !important;
                grid-template-columns: repeat(5, 1fr) !important;
            }
            .mega-menu-feature {
                display: none !important; /* Hide feature on smaller screens to keep navigation clear */
            }
        }

        .main-menu .mega-grid-one > li, .main-menu .mega-grid-two > li {
            padding: 30px 20px !important;
            border-right: 1px solid rgba(255, 255, 255, 0.1) !important;
            position: relative;
        }

        .main-menu .mega-grid-one > li::before, .main-menu .mega-grid-two > li::before {
            content: none !important;
        }

        .main-menu .mega-grid-two > li:last-child {
            border-right: none !important;
        }

        .mega-menu-feature {
            background-color: #243039 !important;
            padding: 40px 30px !important;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
        }

        .mega-menu-feature h6.title {
            color: #AB052D !important;
            font-size: 20px !important;
            margin-bottom: 12px !important;
            font-weight: 700 !important;
            text-transform: capitalize !important;
        }

        .mega-menu-feature p {
            font-size: 14px !important;
            line-height: 1.5 !important;
            color: rgba(255, 255, 255, 0.7) !important;
            margin-bottom: 20px !important;
            white-space: normal !important;
        }

        .mega-menu-feature .feature-thumb {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
        }

        .mega-menu-feature .feature-thumb img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            transition: all 0.4s ease;
        }
        
        .mega-menu-feature:hover .feature-thumb img {
            transform: scale(1.05);
        }

        /* FAQ Section Image Resizing */
        .rs-faq-two .rs-faq-wrapper {
            grid-template-columns: 1fr 480px !important;
            gap: 30px 60px !important;
            align-items: flex-start !important;
        }
        .rs-faq-two .rs-faq-thumb {
            width: 100% !important;
            max-width: 480px !important;
        }
        .rs-faq-two .rs-faq-thumb > img {
            height: 500px !important;
            object-fit: cover !important;
            border-radius: 10px !important;
        }
        .rs-faq-two .rs-faq-award {
            width: auto !important;
            max-width: 360px !important;
            padding: 15px 20px !important;
            bottom: 15px !important;
            inset-inline-start: auto !important;
            inset-inline-end: 15px !important;
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 8px !important;
            background: rgba(255, 255, 255, 0.08) !important;
            background-image: none !important;
            backdrop-filter: blur(12px) !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
        }
        .rs-faq-award-thumb {
            display: none !important;
        }
        .rs-faq-two .rs-faq-award-desc {
            font-size: 13px !important;
            line-height: 1.4 !important;
            margin-bottom: 0 !important;
            border-inline-start: none !important;
            padding-inline-start: 0 !important;
            margin-inline-start: 0 !important;
        }
        @media only screen and (max-width: 1366px) {
            .rs-faq-two .rs-faq-wrapper {
                grid-template-columns: 1fr 400px !important;
            }
            .rs-faq-two .rs-faq-thumb > img {
                height: 450px !important;
            }
        }
        @media only screen and (max-width: 991px) {
            .rs-faq-two .rs-faq-wrapper {
                grid-template-columns: 1fr !important;
            }
            .rs-faq-two .rs-faq-thumb {
                max-width: 100% !important;
            }
        }



        /* Submenu adjustments */
        .main-menu .submenu {
            width: max-content !important;
            min-width: 140px !important;
            max-width: 350px !important;
        }

        .main-menu .submenu li {
            padding-inline-start: 20px !important;
            padding-inline-end: 15px !important;
        }

        .main-menu .submenu li a {
            white-space: nowrap !important;
        }

        /* Mega menu column titles and links */
        .main-menu .mega-grid-two > li .title {
            color: #ffffff !important;
            margin-bottom: 15px !important;
            display: block !important;
        }

        .main-menu .mega-grid-two > li ul li a {
            color: rgba(255, 255, 255, 0.7) !important;
            padding: 5px 0 !important;
        }

        .main-menu .mega-grid-two > li ul li a:hover {
            color: var(--rs-theme-primary) !important;
            padding-left: 5px !important;
        }

        /* Feature Button Styling */
        .mega-menu-feature .rs-btn {
            background-color: var(--rs-theme-primary) !important;
            color: #ffffff !important;
            padding: 14px 28px !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            border-radius: 6px !important;
            font-size: 14px !important;
            font-weight: 700 !important;
            width: fit-content !important;
            height: auto !important;
            line-height: 1 !important;
            margin-bottom: 20px !important;
        }

        .mega-menu-feature .rs-btn:hover {
            background-color: #ffffff !important;
            color: var(--rs-theme-primary) !important;
        }

        /* Sticky Header Styles */
        .rs-sticky-header.active {
            background: var(--rs-theme-secondary) !important;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            top: 0 !important;
        }

        .rs-sticky-header .header-logo img {
            max-height: 50px;
            width: auto;
        }

        .rs-sticky-header .header-wrapper {
            background: transparent !important;
            padding-top: 10px;
            padding-bottom: 10px;
        }

        /* Bridge the gap to prevent dropdown closing when moving mouse from link to menu */
        .main-menu li {
            position: relative;
        }

        .main-menu .submenu,
        .main-menu .mega-menu {
            position: absolute;
            background-color: var(--rs-theme-secondary);
            z-index: 99;
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
            /* Professional transition with slight delay for closing to make it more stable and forgiving */
            transition: opacity 0.3s ease, transform 0.3s ease, visibility 0.3s ease !important;
            transition-delay: 0.2s !important;
        }

        .main-menu li:hover > .submenu,
        .main-menu li:hover > .mega-menu {
            opacity: 1;
            visibility: visible;
            pointer-events: all;
            transition-delay: 0s !important;
        }

        /* The Bridge: Invisible pseudo-element to close the physical gap between link and menu */
        .main-menu .submenu::before,
        .main-menu .mega-menu::before {
            content: "";
            position: absolute;
            top: -50px; /* Ample space to bridge any gap */
            left: 0;
            right: 0;
            height: 50px;
            background: transparent;
            z-index: 10;
            pointer-events: auto !important; /* Forces hover capture in the gap */
        }

        /* More persistent hover colors */
        .main-menu ul li:hover > a {
            color: var(--rs-theme-primary) !important;
        }
    </style>

    <!-- header area start-->
    <header>
        <div class="container-fluid g-0">
            <!-- top start -->
            <div class="rs-header-top rs-header-top-one">
                <div class="header-top-left">
                    <span class="header-top-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="6" height="11" viewBox="0 0 6 11" fill="none">
                            <path
                                d="M0.50204 0.439454C0.811629 0.16438 1.28548 0.192407 1.56063 0.501954L5.56063 5.00195C5.81308 5.28608 5.81308 5.71392 5.56063 5.99805L1.56063 10.498C1.28548 10.8076 0.811629 10.8356 0.50204 10.5605C0.192493 10.2854 0.164466 9.81154 0.43954 9.50195L3.99618 5.5L0.43954 1.49805C0.164466 1.18846 0.192493 0.714606 0.50204 0.439454Z"
                                fill="#AB052D"></path>
                        </svg>
                    </span>
                    <div class="header-top-content">
                        <p>India's Leading Integrated Assessment & Recruitment Platform Since 2000.
                            <a href="about-mission.php">Learn More</a>
                        </p>
                    </div>
                </div>
                <div class="header-top-right">
                    <div class="header-top-meta">
                        <span class="header-top-meta-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
                                <path
                                    d="M12.1641 10.5834C11.6414 10.0673 10.9888 10.0673 10.4694 10.5834C10.0732 10.9762 9.67699 11.3691 9.28744 11.7686C9.1809 11.8785 9.091 11.9018 8.96115 11.8286C8.70479 11.6887 8.43177 11.5755 8.18539 11.4224C7.03673 10.6999 6.07452 9.77097 5.22218 8.72552C4.79934 8.20613 4.42312 7.65011 4.16009 7.02417C4.10682 6.89765 4.11681 6.81442 4.22002 6.7112C4.61622 6.32832 5.00244 5.93544 5.39198 5.54257C5.93469 4.99654 5.93469 4.35728 5.38866 3.80792C5.07902 3.49495 4.76938 3.18865 4.45974 2.87568C4.14011 2.55605 3.82381 2.23309 3.50086 1.9168C2.97813 1.40739 2.32556 1.40739 1.80617 1.92012C1.40663 2.313 1.02375 2.71586 0.617555 3.10208C0.241327 3.45833 0.0515486 3.89449 0.0115952 4.40389C-0.0516643 5.23293 0.151432 6.01535 0.437765 6.77779C1.02375 8.35595 1.91604 9.75765 2.99811 11.0428C4.45974 12.7808 6.20437 14.1558 8.24532 15.148C9.16425 15.5942 10.1165 15.9371 11.1519 15.9937C11.8644 16.0337 12.4837 15.8539 12.9798 15.2979C13.3194 14.9183 13.7023 14.572 14.0619 14.2091C14.5946 13.6697 14.5979 13.0172 14.0685 12.4845C13.4359 11.8485 12.8 11.2159 12.1641 10.5834Z"></path>
                                <path
                                    d="M11.5271 7.92979L12.7557 7.72003C12.5625 6.59135 12.0298 5.56921 11.2208 4.75682C10.3651 3.90116 9.28304 3.36178 8.0911 3.19531L7.91797 4.43054C8.84023 4.56039 9.67925 4.97657 10.3418 5.63913C10.9677 6.26506 11.3773 7.05747 11.5271 7.92979Z"></path>
                                <path
                                    d="M13.4493 2.59031C12.0309 1.17197 10.2363 0.276344 8.25531 0L8.08218 1.23523C9.79352 1.47495 11.345 2.25071 12.5703 3.47262C13.7323 4.63459 14.4947 6.10288 14.771 7.71766L15.9996 7.50791C15.6767 5.63676 14.7943 3.93874 13.4493 2.59031Z"></path>
                            </svg>
                        </span>
                        <div class="header-top-meta-content">
                            <span>Call us:</span>
                            <a href="tel:+911204221735">+91 120 422 1735</a>
                        </div>
                    </div>
                    <div class="header-top-meta">
                        <span class="header-top-meta-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"
                                fill="none">
                                <g clip-path="url(#clip0_28535_99)">
                                    <path
                                        d="M15.8603 3.17969L11.0078 8.00091L15.8603 12.8221C15.948 12.6388 16.0012 12.4361 16.0012 12.2197V3.78216C16.0012 3.56569 15.948 3.36303 15.8603 3.17969Z"
                                        fill="white"></path>
                                    <path
                                        d="M14.5947 2.375H1.40716C1.19069 2.375 0.988031 2.42822 0.804688 2.51594L7.00666 8.68666C7.55503 9.23503 8.44678 9.23503 8.99516 8.68666L15.1971 2.51594C15.0138 2.42822 14.8111 2.375 14.5947 2.375Z"
                                        fill="white"></path>
                                    <path
                                        d="M0.140938 3.17969C0.0532188 3.36303 0 3.56569 0 3.78216V12.2197C0 12.4361 0.0532188 12.6388 0.140938 12.8221L4.99341 8.00091L0.140938 3.17969Z"
                                        fill="white"></path>
                                    <path
                                        d="M10.3447 8.66211L9.658 9.34877C8.74428 10.2625 7.2575 10.2625 6.34378 9.34877L5.65716 8.66211L0.804688 13.4833C0.988031 13.571 1.19069 13.6243 1.40716 13.6243H14.5947C14.8111 13.6243 15.0138 13.571 15.1971 13.4833L10.3447 8.66211Z"
                                        fill="white"></path>
                                </g>
                                <defs>
                                    <clipPath id="clip0_28535_99">
                                        <rect width="16" height="16" fill="white"></rect>
                                    </clipPath>
                                </defs>
                            </svg>
                        </span>
                        <div class="header-top-meta-content">
                            <span>Send mail:</span>
                            <a href="mailto:sales@icefindia.in">
                                sales@icefindia.in
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- top end -->
        </div>

        
        <div class="rs-header-area rs-header-one ">
                    <div class="container-fluid g-0">
            <div class="header-wrapper">
                <div class="header-left">
                    <div class="header-logo">
                        <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA - Integrated Assessment & Recruitment Platform"></a>
                    </div>
                </div>
                <div class="header-right">
                    <div class="header-menu">
                        <nav id="mobile-menu-two" class="main-menu">
                            <ul class="multipage-menu">
                                <li><a href="index.php">Home</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">About Company</a>
                                    <ul class="submenu last-children">
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="about-mission.php#mission">Mission & Vision</a></li>
                                        <li><a href="industry-clients.php">Industry We Work With</a></li>
                                        <li><a href="industry-clients.php#clients">Client Tele</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                        <li><a href="careers-culture.php">Work Culture</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children rs-mega-menu">
                                    <a href="javascript:void(0)">Solutions</a>
                                    <ul class="mega-menu mega-grid-two">
                                        <li class="rs-menu-item" data-image="assets/images/solution/it-emerging.webp">
                                            <a href="it-emerging-tech-enablement.php" class="title">IT & Emerging Tech Enablement</a>
                                            <ul>
                                                <li data-image="assets/images/solution/iot.webp"><a href="iot-and-rfid.php">IOT & RFID Based Products</a></li>
                                                <li data-image="assets/images/solution/app-dev.webp"><a href="application-development.php">Application Development</a></li>
                                                <li data-image="assets/images/solution/software-dev.webp"><a href="customized-software-development.php">Customized Software Development</a></li>
                                                <li data-image="assets/images/solution/emerging-tech.webp"><a href="emerging-tech.php">Emerging Tech</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/assessment-testing.webp">
                                            <a href="assessment-and-testing.php" class="title">Assessment & Testing</a>
                                            <ul>
                                                <li data-image="assets/images/solution/cognitive-domain.webp"><a href="cognitive-domain.php">Cognitive/Domain</a></li>
                                                <li data-image="assets/images/solution/online-offline.webp"><a href="online-offline.php">Online/Offline</a></li>
                                                <li data-image="assets/images/solution/proctoring.webp"><a href="proctoring.php">Proctoring</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/recruitment.webp">
                                            <a href="recruitment-and-hiring.php" class="title">Recruitment & Hiring</a>
                                            <ul>
                                                <li data-image="assets/images/about/33.webp"><a href="screening.php">Screening</a></li>
                                                <li data-image="assets/images/about/37.webp"><a href="assessments.php">Assessments</a></li>
                                                <li data-image="assets/images/solution/merit-list.webp"><a href="merit-lists.php">Merit Lists</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/exam-management.webp">
                                            <a href="exam-management.php" class="title">Exam Management</a>
                                            <ul>
                                                <li data-image="assets/images/solution/question-banks.webp"><a href="question-banks.php">Question Banks</a></li>
                                                <li data-image="assets/images/solution/exam-conduct.webp"><a href="exam-conduct.php">Conduct</a></li>
                                                <li data-image="assets/images/solution/processing.webp"><a href="exam-processing.php">Processing</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/manpower-workforce.webp">
                                            <a href="manpower-and-workforce.php" class="title">Manpower & Workforce</a>
                                            <ul>
                                                <li data-image="assets/images/solution/outsourcing.webp"><a href="outsourcing.php">Outsourcing</a></li>
                                                <li data-image="assets/images/about/31.webp"><a href="staffing.php">Staffing</a></li>
                                                <li data-image="assets/images/solution/deployment.webp"><a href="deployment.php">Deployment</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/call-center.webp">
                                            <a href="call-center-and-bpos.php" class="title">Call Center & BPOs</a>
                                            <ul>
                                                <li data-image="assets/images/solution/inbound.webp"><a href="inbound-outbound.php">Inbound/Outbound</a></li>
                                                <li data-image="assets/images/solution/support.webp"><a href="support.php">Support</a></li>
                                                <li data-image="assets/images/solution/telecalling.webp"><a href="tele-calling.php">Tele-Calling</a></li>
                                            </ul>
                                        </li>
                                        <li class="mega-menu-feature">
                                            <div class="mega-feature-content">
                                                <h6 class="title">Let's Talk Business</h6>
                                                <p>Empowering businesses with smart IT solutions since 2000.</p>
                                                <a href="support.php" class="rs-btn has-icon has-md-radius hover-primary">Request Quote</a>
                                                <div class="feature-thumb mt-20">
                                                    <img id="mega-menu-target-img" src="assets/images/mega-menu-feature.png" alt="Consultation">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="why-choose-us.php">Why Choose Us</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">WhiteBoard</a>
                                    <ul class="submenu last-children">
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="faq.php">FAQs</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                    </ul>
                                </li>
                                
                                
                                <li><a href="contact.php">Support</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="header-content">
                        <div class="header-btn">
                            <a class="rs-btn has-icon is-transparent hover-primary border-hover-primary" href="contact.php">Get Free Quote</a>
                        </div>
                        <div class="header-search-wrapper">
                            <div class="header-search-icon"><i class="ri-search-line"></i></div>
                        </div>
                        <div class="header-hamburger">
                            <div class="sidebar-toggle">
                                <a class="header-bar-icon" href="javascript:void(0)"><span></span><span></span><span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                </div>

        <div id="rs-sticky-header" class="rs-sticky-header rs-header-area rs-header-one ">
                    <div class="container-fluid g-0">
            <div class="header-wrapper">
                <div class="header-left">
                    <div class="header-logo">
                        <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA - Integrated Assessment & Recruitment Platform"></a>
                    </div>
                </div>
                <div class="header-right">
                    <div class="header-menu">
                        <nav id="mobile-menu-two" class="main-menu">
                            <ul class="multipage-menu">
                                <li><a href="index.php">Home</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">About Company</a>
                                    <ul class="submenu last-children">
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="about-mission.php#mission">Mission & Vision</a></li>
                                        <li><a href="industry-clients.php">Industry We Work With</a></li>
                                        <li><a href="industry-clients.php#clients">Client Tele</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                        <li><a href="careers-culture.php">Work Culture</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children rs-mega-menu">
                                    <a href="javascript:void(0)">Solutions</a>
                                    <ul class="mega-menu mega-grid-two">
                                        <li class="rs-menu-item" data-image="assets/images/solution/it-emerging.webp">
                                            <a href="it-emerging-tech-enablement.php" class="title">IT & Emerging Tech Enablement</a>
                                            <ul>
                                                <li data-image="assets/images/solution/iot.webp"><a href="iot-and-rfid.php">IOT & RFID Based Products</a></li>
                                                <li data-image="assets/images/solution/app-dev.webp"><a href="application-development.php">Application Development</a></li>
                                                <li data-image="assets/images/solution/software-dev.webp"><a href="customized-software-development.php">Customized Software Development</a></li>
                                                <li data-image="assets/images/solution/emerging-tech.webp"><a href="emerging-tech.php">Emerging Tech</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/assessment-testing.webp">
                                            <a href="assessment-and-testing.php" class="title">Assessment & Testing</a>
                                            <ul>
                                                <li data-image="assets/images/solution/cognitive-domain.webp"><a href="cognitive-domain.php">Cognitive/Domain</a></li>
                                                <li data-image="assets/images/solution/online-offline.webp"><a href="online-offline.php">Online/Offline</a></li>
                                                <li data-image="assets/images/solution/proctoring.webp"><a href="proctoring.php">Proctoring</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/recruitment.webp">
                                            <a href="recruitment-and-hiring.php" class="title">Recruitment & Hiring</a>
                                            <ul>
                                                <li data-image="assets/images/about/33.webp"><a href="screening.php">Screening</a></li>
                                                <li data-image="assets/images/about/37.webp"><a href="assessments.php">Assessments</a></li>
                                                <li data-image="assets/images/solution/merit-list.webp"><a href="merit-lists.php">Merit Lists</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/exam-management.webp">
                                            <a href="exam-management.php" class="title">Exam Management</a>
                                            <ul>
                                                <li data-image="assets/images/solution/question-banks.webp"><a href="question-banks.php">Question Banks</a></li>
                                                <li data-image="assets/images/solution/exam-conduct.webp"><a href="exam-conduct.php">Conduct</a></li>
                                                <li data-image="assets/images/solution/processing.webp"><a href="exam-processing.php">Processing</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/manpower-workforce.webp">
                                            <a href="manpower-and-workforce.php" class="title">Manpower & Workforce</a>
                                            <ul>
                                                <li data-image="assets/images/solution/outsourcing.webp"><a href="outsourcing.php">Outsourcing</a></li>
                                                <li data-image="assets/images/about/31.webp"><a href="staffing.php">Staffing</a></li>
                                                <li data-image="assets/images/solution/deployment.webp"><a href="deployment.php">Deployment</a></li>
                                            </ul>
                                        </li>
                                        <li class="rs-menu-item" data-image="assets/images/solution/call-center.webp">
                                            <a href="call-center-and-bpos.php" class="title">Call Center & BPOs</a>
                                            <ul>
                                                <li data-image="assets/images/solution/inbound.webp"><a href="inbound-outbound.php">Inbound/Outbound</a></li>
                                                <li data-image="assets/images/solution/support.webp"><a href="support.php">Support</a></li>
                                                <li data-image="assets/images/solution/telecalling.webp"><a href="tele-calling.php">Tele-Calling</a></li>
                                            </ul>
                                        </li>
                                        <li class="mega-menu-feature">
                                            <div class="mega-feature-content">
                                                <h6 class="title">Let's Talk Business</h6>
                                                <p>Empowering businesses with smart IT solutions since 2000.</p>
                                                <a href="support.php" class="rs-btn has-icon has-md-radius hover-primary">Request Quote</a>
                                                <div class="feature-thumb mt-20">
                                                    <img id="mega-menu-target-img" src="assets/images/mega-menu-feature.png" alt="Consultation">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="why-choose-us.php">Why Choose Us</a></li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0)">WhiteBoard</a>
                                    <ul class="submenu last-children">
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="faq.php">FAQs</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                    </ul>
                                </li>
                                
                                
                                <li><a href="contact.php">Support</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="header-content">
                        <div class="header-btn">
                            <a class="rs-btn has-icon is-transparent hover-primary border-hover-primary" href="contact.php">Get Free Quote</a>
                        </div>
                        <div class="header-search-wrapper">
                            <div class="header-search-icon"><i class="ri-search-line"></i></div>
                        </div>
                        <div class="header-hamburger">
                            <div class="sidebar-toggle">
                                <a class="header-bar-icon" href="javascript:void(0)"><span></span><span></span><span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                </div>
    </header>
    <!-- Header area end -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const targetImg = document.getElementById('mega-menu-target-img');
            if (!targetImg) return;

            const globalDefaultImg = targetImg.getAttribute('src');
            let defaultImg = globalDefaultImg;
            const menuItems = document.querySelectorAll('.rs-mega-menu .mega-menu [data-image]');

            // Detect active page and set its image as default
            const currentPath = window.location.pathname;
            document.querySelectorAll('.rs-mega-menu .mega-menu .rs-menu-item').forEach(item => {
                const links = item.querySelectorAll('a');
                links.forEach(link => {
                    const href = link.getAttribute('href');
                    if (href && href !== '#' && currentPath.endsWith(href)) {
                        const activeImg = link.parentElement.getAttribute('data-image') || item.getAttribute('data-image');
                        if (activeImg) {
                            defaultImg = activeImg;
                            targetImg.setAttribute('src', activeImg);
                        }
                    }
                });
            });

            menuItems.forEach(item => {
                item.addEventListener('mouseenter', function(e) {
                    e.stopPropagation();
                    const newImg = this.getAttribute('data-image');
                    if (newImg && targetImg.getAttribute('src') !== newImg) {
                        targetImg.style.opacity = '0';
                        setTimeout(() => {
                            targetImg.setAttribute('src', newImg);
                            targetImg.style.opacity = '1';
                        }, 200);
                    }
                });
            });

            // Revert to default when leaving the entire mega menu grid
            const megaGrid = document.querySelector('.mega-grid-two');
            if (megaGrid) {
                megaGrid.addEventListener('mouseleave', function() {
                    targetImg.style.opacity = '0';
                    setTimeout(() => {
                        targetImg.setAttribute('src', defaultImg);
                        targetImg.style.opacity = '1';
                    }, 200);
                });
            }
        });
    </script>
    <style>
        #mega-menu-target-img {
            transition: opacity 0.3s ease;
        }
    </style>

        <!-- Offcanvas area start -->
    <div class="fix">
        <div class="offcanvas-area" data-lenis-prevent>
            <div class="offcanvas-wrapper">
                <div class="offcanvas-content">
                    <div class="offcanvas-top d-flex justify-content-between align-items-center mb-20">
                        <div class="offcanvas-logo">
                            <a class="logo-black" href="index.php"><img src="assets/images/logo/logo-icef.png" alt="logo"></a>
                            <a class="logo-white" href="index.php"><img src="assets/images/logo/logo-icef.png" alt="logo"></a>
                        </div>
                        <div class="offcanvas-close">
                            <button class="offcanvas-close-icon animation--flip" style="background: var(--rs-theme-primary); color: white; border: none; padding: 10px; border-radius: 4px; display: flex; align-items: center; justify-content: center; width: 40px; height: 40px;">
                                <i class="ri-close-line" style="font-size: 24px;"></i>
                            </button>
                        </div>
                    </div>
                    <div class="offcanvas-about mb-30 d-none d-xl-block">
                        <p>
                            ICEF INDIA is a premier organization providing end-to-end solutions in Assessment, Recruitment, and Workforce Development since 2000.
                        </p>
                    </div>
                    <div class="offcanvas-gallery d-none d-xl-block">
                        <div class="offcanvas-gallery-thumb-wrapper">
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-01.webp">
                                    <img src="assets/images/gallery/gallery-thumb-01.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-02.webp">
                                    <img src="assets/images/gallery/gallery-thumb-02.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-03.webp">
                                    <img src="assets/images/gallery/gallery-thumb-03.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-04.webp">
                                    <img src="assets/images/gallery/gallery-thumb-04.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-05.webp">
                                    <img src="assets/images/gallery/gallery-thumb-05.webp" alt="image">
                                </a>
                            </div>
                            <div class="offcanvas-popup-thumb">
                                <a class="popup-image" href="assets/images/gallery/gallery-thumb-06.webp">
                                    <img src="assets/images/gallery/gallery-thumb-06.webp" alt="image">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="mobile-menu-container">
                        <div class="rs-offcanvas-menu mb-30" id="sidebar-menu-target">
                            <!-- Menu will be injected here via JS -->
                        </div>
                    </div>
                    <div class="offcanvas-contact mb-30">
                        <h4 class="offcanvas-title-meta">Contact Info</h4>
                        <ul>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="18" viewBox="0 0 14 18" fill="none">
                                        <path d="M11.8768 9.68475C11.3059 10.835 10.5331 11.9818 9.74128 13.0109C8.95198 14.0368 8.15999 14.9249 7.5643 15.5572C7.48514 15.6412 7.40956 15.7206 7.33802 15.7951C7.26648 15.7206 7.1909 15.6412 7.11174 15.5572C6.51605 14.9249 5.72406 14.0368 4.93476 13.0109C4.14299 11.9818 3.37019 10.835 2.79925 9.68475C2.22242 8.52266 1.89032 7.43373 1.89032 6.5C1.89032 3.50846 4.32934 1.08333 7.33802 1.08333C10.3467 1.08333 12.7857 3.50846 12.7857 6.5C12.7857 7.43373 12.4536 8.52266 11.8768 9.68475ZM7.33802 17.3333C7.33802 17.3333 13.8753 11.1732 13.8753 6.5C13.8753 2.91015 10.9484 0 7.33802 0C3.7276 0 0.800781 2.91015 0.800781 6.5C0.800781 11.1732 7.33802 17.3333 7.33802 17.3333Z" fill="#6D6D6D"></path>
                                        <path d="M7.33802 8.66667C6.13455 8.66667 5.15894 7.69662 5.15894 6.5C5.15894 5.30338 6.13455 4.33333 7.33802 4.33333C8.54149 4.33333 9.5171 5.30338 9.5171 6.5C9.5171 7.69662 8.54149 8.66667 7.33802 8.66667ZM7.33802 9.75C9.14323 9.75 10.6066 8.29492 10.6066 6.5C10.6066 4.70507 9.14323 3.25 7.33802 3.25C5.53281 3.25 4.0694 4.70507 4.0694 6.5C4.0694 8.29492 5.53281 9.75 7.33802 9.75Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="#"> Noida, Uttar Pradesh, India</a>
                                </div>
                            </li>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M3.65387 1.32849C3.40343 1.00649 2.92745 0.976861 2.639 1.26531L1.60508 2.29923C1.1216 2.78271 0.94387 3.46766 1.1551 4.06847C2.00338 6.48124 3.39215 8.74671 5.32272 10.6773C7.25329 12.6078 9.51876 13.9966 11.9315 14.8449C12.5323 15.0561 13.2173 14.8784 13.7008 14.3949L14.7347 13.361C15.0231 13.0726 14.9935 12.5966 14.6715 12.3461L12.3653 10.5524C12.2008 10.4245 11.9866 10.3793 11.7845 10.4298L9.59541 10.9771C9.00082 11.1257 8.37183 10.9515 7.93845 10.5181L5.48187 8.06155C5.04849 7.62817 4.87427 6.99919 5.02292 6.40459L5.57019 4.21553C5.62073 4.01336 5.57552 3.79918 5.44758 3.63468L3.65387 1.32849ZM1.88477 0.511076C2.62689 -0.231039 3.8515 -0.154797 4.49583 0.673634L6.28954 2.97983C6.6187 3.40304 6.73502 3.95409 6.60498 4.47423L6.05772 6.66329C5.99994 6.8944 6.06766 7.13888 6.2361 7.30732L8.69268 9.7639C8.86113 9.93235 9.1056 10.0001 9.33671 9.94229L11.5258 9.39502C12.0459 9.26499 12.597 9.3813 13.0202 9.71047L15.3264 11.5042C16.1548 12.1485 16.231 13.3731 15.4889 14.1152L14.455 15.1492C13.7153 15.8889 12.6089 16.2137 11.5778 15.8512C9.01754 14.9511 6.61438 13.4774 4.56849 11.4315C2.5226 9.38562 1.04895 6.98246 0.148838 4.42225C-0.213682 3.39112 0.11113 2.28472 0.85085 1.545L1.88477 0.511076Z" fill="#6D6D6D"></path>
                                        <path d="M11 0.5C11 0.223858 11.2239 0 11.5 0H15.5C15.7761 0 16 0.223858 16 0.5V4.5C16 4.77614 15.7761 5 15.5 5C15.2239 5 15 4.77614 15 4.5V1.70711L10.8536 5.85355C10.6583 6.04882 10.3417 6.04882 10.1464 5.85355C9.95118 5.65829 9.95118 5.34171 10.1464 5.14645L14.2929 1H11.5C11.2239 1 11 0.776142 11 0.5Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="tel:+911204221735"> +91 120 422 1735 </a>
                                </div>
                            </li>
                            <li class="d-flex gap-15">
                                <div class="offcanvas-contact-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M2 2C0.895431 2 0 2.89543 0 4V12L2.58386e-05 12.0103C0.00555998 13.1101 0.898859 14 2 14H7.5C7.77614 14 8 13.7761 8 13.5C8 13.2239 7.77614 13 7.5 13H2C1.53715 13 1.14774 12.6855 1.03376 12.2586L6.67417 8.7876L8 9.5831L15 5.3831V8.5C15 8.77614 15.2239 9 15.5 9C15.7761 9 16 8.77614 16 8.5V4C16 2.89543 15.1046 2 14 2H2ZM5.70808 8.20794L1 11.1052V5.3831L5.70808 8.20794ZM1 4.2169V4C1 3.44772 1.44772 3 2 3H14C14.5523 3 15 3.44772 15 4V4.2169L8 8.4169L1 4.2169Z" fill="#6D6D6D"></path>
                                        <path d="M14.2467 14.2686C15.2567 14.2686 15.8339 13.4116 15.8339 12.2442V12.0344C15.8339 10.4297 14.6402 9 12.5197 9H12.4847C10.421 9 9 10.3598 9 12.4322V12.6465C9 14.8195 10.4385 16 12.3579 16H12.4016C12.9963 16 13.4204 15.9257 13.639 15.8251V15.0949C13.3941 15.2042 12.9656 15.2742 12.4585 15.2742H12.4147C11.0812 15.2742 9.84385 14.4872 9.84385 12.6202V12.4628C9.84385 10.8057 10.9019 9.73891 12.4847 9.73891H12.524C14.0587 9.73891 15.0075 10.7883 15.0075 12.065V12.183C15.0075 13.158 14.6839 13.5734 14.3691 13.5734C14.1374 13.5734 13.9582 13.4247 13.9582 13.1537V10.9631H13.0531V11.5315H13.0225C12.9394 11.2342 12.6552 10.9019 12.0693 10.9019C11.2911 10.9019 10.8101 11.4572 10.8101 12.3011V12.8301C10.8101 13.722 11.2998 14.2642 12.0693 14.2642C12.5415 14.2642 12.9656 14.0369 13.0837 13.6215H13.1274C13.2455 14.0412 13.7439 14.2686 14.2467 14.2686ZM11.7939 12.6814V12.4541C11.7939 11.9076 12.0212 11.6627 12.3666 11.6627C12.664 11.6627 12.9394 11.8551 12.9394 12.371V12.7383C12.9394 13.3111 12.6858 13.4816 12.3754 13.4816C12.0212 13.4816 11.7939 13.2673 11.7939 12.6814Z" fill="#6D6D6D"></path>
                                    </svg>
                                </div>
                                <div class="offcanvas-contact-text">
                                    <a href="mailto:sales@icefindia.in">sales@icefindia.in</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="offcanvas-social">
                        <h4 class="offcanvas-title-meta">Follow Us</h4>
                        <ul>
                            <li><a href="#"><i class="ri-facebook-fill"></i></a></li>
                            <li><a href="#"><i class="ri-twitter-x-fill"></i></a></li>
                            <li><a href="#"><i class="ri-youtube-fill"></i></a></li>
                            <li><a href="#"><i class="ri-linkedin-box-fill"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas-overlay"></div>
    <div class="offcanvas-overlay-white"></div>
    <!-- Offcanvas area start -->

    <!-- Body main wrapper start -->
    <main>

        <!-- blog area start -->
        <section class="rs-blog-area rs-blog-two section-space">
            <div class="container">
                <!-- Search Bar Row -->
                <div class="row mb-40">
                    <div class="col-xl-12">
                        <div class="rs-search-container d-flex justify-content-end">
                            <form action="javascript:void(0)" method="GET" class="rs-search-form" onsubmit="return false;">
                                <div class="rs-search-input-group">
                                    <input type="text" id="articleSearchInput" placeholder="Search articles..." name="search">
                                    <button type="button">
                                        <i class="ri-search-line"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <style>
                    .rs-search-container {
                        margin-bottom: 20px;
                    }
                    .rs-search-form {
                        width: 100%;
                        max-width: 350px;
                    }
                    .rs-search-input-group {
                        position: relative;
                        display: flex;
                        align-items: center;
                    }
                    .rs-search-input-group input {
                        width: 100%;
                        height: 55px;
                        padding: 10px 60px 10px 25px;
                        border: 1px solid #E5E9F2;
                        border-radius: 50px;
                        background: #fff;
                        font-size: 16px;
                        color: #1a1a1a;
                        transition: all 0.3s ease;
                        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
                    }
                    .rs-search-input-group input:focus {
                        border-color: #AB052D;
                        outline: none;
                        box-shadow: 0 5px 20px rgba(171, 5, 45, 0.1);
                    }
                    .rs-search-input-group button {
                        position: absolute;
                        right: 5px;
                        top: 5px;
                        width: 45px;
                        height: 45px;
                        background: #AB052D;
                        color: #fff;
                        border: none;
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-size: 20px;
                        transition: all 0.3s ease;
                        cursor: pointer;
                    }
                    .rs-search-input-group button:hover {
                        background: #1a1a1a;
                        transform: scale(1.05);
                    }
                    @media (max-width: 767px) {
                        .rs-search-form {
                            max-width: 100%;
                        }
                    }
                </style>

                <div class="row g-5">
                    <!-- row-1 -->
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="rs-blog-item wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
                            <div class="rs-blog-thumb">
                                <a href="blog-details.php"><img src="assets/images/blog/blog-thumb-01.webp" alt="image"
                                        style="aspect-ratio: 415/285; object-fit: cover; width: 100%;"></a>
                                <div class="rs-blog-meta">
                                    <div class="rs-blog-meta-inner">
                                        
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-price-tag-3-line"></i></div>
                                            <span> Corporate </span>
                                        </div>
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-calendar-line"></i></div>
                                            <span> August 20, 2025</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-blog-content">
                                <h5 class="rs-blog-title"><a href="blog-details.php">Smarter Thinking for Smarter
                                        Business Solutions</a></h5>
                                <p class="rs-blog-desc">This retains a dynamic action oriented feel and aligns with
                                    consulting core.</p>
                                <div class="rs-blog-btn">
                                    <a class="rs-btn has-icon has-text has-text-underline fw-5"
                                        href="blog-details.php">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="rs-blog-item wow fadeInUp" data-wow-delay=".5s" data-wow-duration="1s">
                            <div class="rs-blog-thumb">
                                <a href="blog-details.php"><img src="assets/images/blog/blog-thumb-02.webp" alt="image"
                                        style="aspect-ratio: 415/285; object-fit: cover; width: 100%;"></a>
                                <div class="rs-blog-meta">
                                    <div class="rs-blog-meta-inner">
                                        
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-price-tag-3-line"></i></div>
                                            <span> Consulting </span>
                                        </div>
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-calendar-line"></i></div>
                                            <span> August 20, 2025</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-blog-content">
                                <h5 class="rs-blog-title"><a href="blog-details.php">From the Minds of Business Growth
                                        Strategists</a></h5>
                                <p class="rs-blog-desc">Consulting empowers businesses with data-driven strategies and
                                    innovative solutions</p>
                                <div class="rs-blog-btn">
                                    <a class="rs-btn has-icon has-text has-text-underline fw-5"
                                        href="blog-details.php">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="rs-blog-item wow fadeInUp" data-wow-delay=".7s" data-wow-duration="1s">
                            <div class="rs-blog-thumb">
                                <a href="blog-details.php"><img src="assets/images/blog/blog-thumb-03.webp" alt="image"
                                        style="aspect-ratio: 415/285; object-fit: cover; width: 100%;"></a>
                                <div class="rs-blog-meta">
                                    <div class="rs-blog-meta-inner">
                                        
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-price-tag-3-line"></i></div>
                                            <span> Corporate </span>
                                        </div>
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-calendar-line"></i></div>
                                            <span> August 20, 2025</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-blog-content">
                                <h5 class="rs-blog-title"><a href="blog-details.php">Insights That Drive Business
                                        Smarter Forward</a></h5>
                                <p class="rs-blog-desc">Consulting empowers businesses with data-driven strategies and
                                    innovative solutions</p>
                                <div class="rs-blog-btn">
                                    <a class="rs-btn has-icon has-text has-text-underline fw-5"
                                        href="blog-details.php">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- row-2 -->
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="rs-blog-item wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
                            <div class="rs-blog-thumb">
                                <a href="blog-details.php"><img src="assets/images/blog/blog-thumb-04.webp" alt="image"
                                        style="aspect-ratio: 415/285; object-fit: cover; width: 100%;"></a>
                                <div class="rs-blog-meta">
                                    <div class="rs-blog-meta-inner">
                                        
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-price-tag-3-line"></i></div>
                                            <span> IT Solutions </span>
                                        </div>
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-calendar-line"></i></div>
                                            <span> August 20, 2025</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-blog-content">
                                <h5 class="rs-blog-title"><a href="blog-details.php">Actionable Insights for Real World
                                        Results</a></h5>
                                <p class="rs-blog-desc">Helping companies thrive through expert consulting, smart
                                    strategies.</p>
                                <div class="rs-blog-btn">
                                    <a class="rs-btn has-icon has-text has-text-underline fw-5"
                                        href="blog-details.php">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="rs-blog-item wow fadeInUp" data-wow-delay=".5s" data-wow-duration="1s">
                            <div class="rs-blog-thumb">
                                <a href="blog-details.php"><img src="assets/images/blog/blog-thumb-05.webp" alt="image"
                                        style="aspect-ratio: 415/285; object-fit: cover; width: 100%;"></a>
                                <div class="rs-blog-meta">
                                    <div class="rs-blog-meta-inner">
                                        
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-price-tag-3-line"></i></div>
                                            <span> Corporate </span>
                                        </div>
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-calendar-line"></i></div>
                                            <span> August 20, 2025</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-blog-content">
                                <h5 class="rs-blog-title"><a href="blog-details.php">Mastering Markets, Models &
                                        Momentum</a></h5>
                                <p class="rs-blog-desc">We help businesses unlock potential with clear strategies,
                                    expert</p>
                                <div class="rs-blog-btn">
                                    <a class="rs-btn has-icon has-text has-text-underline fw-5"
                                        href="blog-details.php">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="rs-blog-item wow fadeInUp" data-wow-delay=".7s" data-wow-duration="1s">
                            <div class="rs-blog-thumb">
                                <a href="blog-details.php"><img src="assets/images/blog/blog-thumb-06.webp" alt="image"
                                        style="aspect-ratio: 415/285; object-fit: cover; width: 100%;"></a>
                                <div class="rs-blog-meta">
                                    <div class="rs-blog-meta-inner">
                                        
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-price-tag-3-line"></i></div>
                                            <span> Corporate </span>
                                        </div>
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-calendar-line"></i></div>
                                            <span> August 20, 2025</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-blog-content">
                                <h5 class="rs-blog-title"><a href="blog-details.php">Strategic Thinking for a Changing
                                        World</a></h5>
                                <p class="rs-blog-desc">From insights to execution, we guide businesses to smarter</p>
                                <div class="rs-blog-btn">
                                    <a class="rs-btn has-icon has-text has-text-underline fw-5"
                                        href="blog-details.php">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- row-3 (New Row) -->
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="rs-blog-item wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
                            <div class="rs-blog-thumb">
                                <a href="blog-details.php"><img src="assets/images/blog/blog-thumb-02.webp" alt="image"
                                        style="aspect-ratio: 415/285; object-fit: cover; width: 100%;"></a>
                                <div class="rs-blog-meta">
                                    <div class="rs-blog-meta-inner">
                                        
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-price-tag-3-line"></i></div>
                                            <span> Business </span>
                                        </div>
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-calendar-line"></i></div>
                                            <span> August 20, 2025</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-blog-content">
                                <h5 class="rs-blog-title"><a href="blog-details.php">Navigating Business Challenges with
                                        Ease</a></h5>
                                <p class="rs-blog-desc">Our experts provide guidance to help businesses navigate
                                    complexities smoothly.</p>
                                <div class="rs-blog-btn">
                                    <a class="rs-btn has-icon has-text has-text-underline fw-5"
                                        href="blog-details.php">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="rs-blog-item wow fadeInUp" data-wow-delay=".5s" data-wow-duration="1s">
                            <div class="rs-blog-thumb">
                                <a href="blog-details.php"><img src="assets/images/blog/blog-thumb-04.webp" alt="image"
                                        style="aspect-ratio: 415/285; object-fit: cover; width: 100%;"></a>
                                <div class="rs-blog-meta">
                                    <div class="rs-blog-meta-inner">
                                        
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-price-tag-3-line"></i></div>
                                            <span> Innovation </span>
                                        </div>
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-calendar-line"></i></div>
                                            <span> August 20, 2025</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-blog-content">
                                <h5 class="rs-blog-title"><a href="blog-details.php">Innovation: The Key to
                                        Scalability</a></h5>
                                <p class="rs-blog-desc">Leveraging technology to build scalable and efficient business
                                    processes.</p>
                                <div class="rs-blog-btn">
                                    <a class="rs-btn has-icon has-text has-text-underline fw-5"
                                        href="blog-details.php">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="rs-blog-item wow fadeInUp" data-wow-delay=".7s" data-wow-duration="1s">
                            <div class="rs-blog-thumb">
                                <a href="blog-details.php"><img src="assets/images/blog/blog-thumb-01.webp" alt="image"
                                        style="aspect-ratio: 415/285; object-fit: cover; width: 100%;"></a>
                                <div class="rs-blog-meta">
                                    <div class="rs-blog-meta-inner">
                                        
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-price-tag-3-line"></i></div>
                                            <span> Growth </span>
                                        </div>
                                        <div class="rs-blog-meta-item">
                                            <div class="rs-blog-meta-icon"><i class="ri-calendar-line"></i></div>
                                            <span> August 20, 2025</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="rs-blog-content">
                                <h5 class="rs-blog-title"><a href="blog-details.php">Future-Proofing Your Business
                                        Strategy</a></h5>
                                <p class="rs-blog-desc">How to prepare for market shifts and stay ahead of the
                                    competition effectively.</p>
                                <div class="rs-blog-btn">
                                    <a class="rs-btn has-icon has-text has-text-underline fw-5"
                                        href="blog-details.php">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- pagination style -->
                <div class="row justify-content-center">
                    <div class="col-xl-6">
                        <div class="pagination-wrapper mt-40">
                            <div class="common-pagination text-center">
                                <nav>
                                    <ul>
                                        <li><a class="current">1</a></li>
                                        <li><a href="#">2</a></li>
                                        <li><a href="#">3</a></li>
                                        <li><a class="is-next" href="#"></a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- pagination style end -->
            </div>
        </section>
        <!-- blog area end -->

    </main>
    <!-- Body main wrapper end -->

    <!-- footer area start -->
<footer class="rs-footer-area rs-footer-one theme-secondary">
    <div class="rs-footer-shape-one">
        <img src="assets/images/shape/footer-shape-01.webp" alt="image">
    </div>
    <div class="rs-footer-shape-two">
        <img src="assets/images/shape/footer-shape-02.webp" alt="image">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="rs-footer-wrapper">
                    <div class="rs-footer-left">
                        <div class="rs-footer-widget footer-1-col-1">
                            <div class="rs-footer-widget-logo">
                                <a href="index.php"><img src="assets/images/logo/logo-icef.png" alt="ICEF INDIA"></a>
                            </div>
                            <div class="rs-footer-widget-content">
                                <p class="rs-footer-widget-desc">
                                    ICEF INDIA is a premier organization providing end-to-end solutions in Assessment, Recruitment, and Workforce Development since 2000.
                                </p>
                                <div class="rs-footer-widget-contact-info">
                                    <div class="rs-footer-content-item">
                                        <span>Call us:</span>
                                        <a href="tel:+911204221735">+91 120 422 1735</a>
                                    </div>
                                    <div class="rs-footer-content-item">
                                        <span>Email:</span>
                                        <a href="mailto:sales@icefindia.in">sales@icefindia.in</a>
                                    </div>
                                    <div class="rs-footer-content-item">
                                        <span>Hours: Mon-Fri: 8.00am - 18.00pm</span>
                                    </div>
                                </div>
                                <div class="rs-footer-widget-social">
                                    <div class="rs-footer-social theme-social has-border">
                                        <a href="#"><svg width="14" height="22" viewBox="0 0 14 22" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M11.624 11.9541L12.193 8.54137L8.63572 8.54137V6.32676C8.63572 5.39311 9.13264 4.48303 10.7258 4.48303H12.343V1.57748C12.343 1.57748 10.8755 1.34692 9.47233 1.34692C6.54282 1.34692 4.62796 2.98146 4.62796 5.94041L4.62796 8.54137H1.37158L1.37158 11.9541H4.62796L4.62796 20.2041H8.63572L8.63572 11.9541H11.624Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M17.6045 5.45036C17.5641 4.53485 17.4161 3.9055 17.204 3.3601C16.9852 2.78121 16.6486 2.26294 16.2077 1.83208C15.7768 1.39452 15.2551 1.0545 14.6829 0.839154C14.1344 0.627106 13.5083 0.479009 12.5928 0.438686C11.6705 0.394863 11.3777 0.384766 9.03843 0.384766C6.69917 0.384766 6.40637 0.394863 5.48747 0.435253C4.57199 0.475643 3.94261 0.623808 3.39738 0.835721C2.81832 1.0545 2.30005 1.39108 1.86919 1.83208C1.43163 2.26291 1.09178 2.78461 0.876264 3.3568C0.664216 3.9055 0.516152 4.53148 0.475796 5.44692C0.432006 6.36927 0.421875 6.66206 0.421875 9.00132C0.421875 11.3406 0.432006 11.6334 0.472363 12.5523C0.512753 13.4678 0.660917 14.0971 0.872999 14.6425C1.09178 15.2214 1.43163 15.7397 1.86919 16.1706C2.30005 16.6081 2.82175 16.9481 3.39395 17.1635C3.94258 17.3755 4.56856 17.5236 5.4842 17.564C6.40294 17.6045 6.6959 17.6144 9.03516 17.6144C11.3744 17.6144 11.6672 17.6045 12.5861 17.564C13.5016 17.5236 14.131 17.3756 14.6762 17.1635C15.2489 16.9421 15.7689 16.6035 16.2031 16.1693C16.6372 15.7352 16.9759 15.2152 17.1973 14.6425C17.4092 14.0939 17.5574 13.4678 17.5978 12.5523C17.6382 11.6334 17.6483 11.3406 17.6483 9.00132C17.6483 6.66206 17.6449 6.36923 17.6045 5.45036ZM16.0529 12.485C16.0159 13.3264 15.8745 13.7808 15.7567 14.0837C15.4672 14.8343 14.8715 15.4301 14.1208 15.7196C13.8179 15.8374 13.3603 15.9787 12.5221 16.0157C11.6133 16.0562 11.3408 16.0662 9.04186 16.0662C6.74296 16.0662 6.46699 16.0562 5.56148 16.0157C4.72002 15.9787 4.26563 15.8374 3.96271 15.7196C3.5892 15.5815 3.24922 15.3628 2.97322 15.0767C2.68712 14.7973 2.46834 14.4607 2.33027 14.0872C2.21247 13.7842 2.07114 13.3264 2.03421 12.4884C1.99369 11.5796 1.98373 11.3069 1.98373 9.00802C1.98373 6.70911 1.99369 6.43315 2.03421 5.5278C2.07114 4.68634 2.21247 4.23196 2.33027 3.92903C2.46834 3.55535 2.68712 3.21544 2.97665 2.93937C3.25588 2.65328 3.59246 2.4345 3.96614 2.2966C4.26907 2.17879 4.72689 2.03743 5.56491 2.00037C6.47369 1.95998 6.74639 1.94988 9.04513 1.94988C11.3475 1.94988 11.62 1.95998 12.5255 2.00037C13.367 2.03746 13.8214 2.17876 14.1243 2.29656C14.4978 2.4345 14.8378 2.65328 15.1138 2.93937C15.3999 3.21877 15.6186 3.55535 15.7567 3.92903C15.8745 4.23196 16.0159 4.68961 16.0529 5.5278C16.0933 6.43658 16.1034 6.70911 16.1034 9.00802C16.1034 11.3069 16.0933 11.5762 16.0529 12.485Z"
                                                    fill="white"></path>
                                                <path
                                                    d="M9.0335 4.57741C6.58997 4.57741 4.60742 6.55982 4.60742 9.00349C4.60742 11.4472 6.58997 13.4296 9.0335 13.4296C11.4771 13.4296 13.4596 11.4472 13.4596 9.00349C13.4596 6.55982 11.4771 4.57741 9.0335 4.57741ZM9.0335 11.8746C7.44826 11.8746 6.16237 10.5889 6.16237 9.00349C6.16237 7.41811 7.44826 6.13243 9.03347 6.13243C10.6188 6.13243 11.9046 7.41811 11.9046 9.00349C11.9046 10.5889 10.6188 11.8746 9.0335 11.8746ZM14.668 4.40239C14.668 4.97303 14.2053 5.4357 13.6345 5.4357C13.0639 5.4357 12.6013 4.97303 12.6013 4.40239C12.6013 3.83167 13.0639 3.36914 13.6346 3.36914C14.2053 3.36914 14.668 3.83164 14.668 4.40239Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M9.35332 6.88729L14.6472 0.733521H13.3928L8.79603 6.07675L5.12465 0.733521H0.890137L6.44199 8.81343L0.890137 15.2666H2.1447L6.99896 9.62397L10.8762 15.2666H15.1107L9.35332 6.88729ZM7.63502 8.88462L7.0725 8.08004L2.59674 1.67793H4.52367L8.13567 6.84464L8.69818 7.64922L13.3933 14.3651H11.4664L7.63502 8.88462Z"
                                                    fill="white"></path>
                                            </svg></a>
                                        <a href="#"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M17.7973 17.7992V11.3532C17.7973 8.18522 17.1153 5.76522 13.4193 5.76522C11.6373 5.76522 10.4493 6.73322 9.96527 7.65722H9.92126V6.05122H6.42326V17.7992H10.0753V11.9692C10.0753 10.4292 10.3613 8.95522 12.2533 8.95522C14.1233 8.95522 14.1453 10.6932 14.1453 12.0572V17.7772H17.7973V17.7992ZM0.483266 6.05122H4.13527V17.7992H0.483266V6.05122ZM2.30927 0.199219C1.14327 0.199219 0.197266 1.14522 0.197266 2.31122C0.197266 3.47722 1.14327 4.44522 2.30927 4.44522C3.47527 4.44522 4.42127 3.47722 4.42127 2.31122C4.42127 1.14522 3.47527 0.199219 2.30927 0.199219Z"
                                                    fill="white"></path>
                                            </svg></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rs-footer-right">
                        <div class="rs-footer-widget-wrapper">
                            <div class="rs-footer-widget footer-1-col-2">
                                <h5 class="rs-footer-widget-title">About​</h5>
                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="about-mission.php">About ICEF India</a></li>
                                        <li><a href="industry-clients.php">Industry we work with</a></li>
                                        <li><a href="why-choose-us.php">Why choose us</a></li>
                                        <li><a href="careers-culture.php#careers">Careers</a></li>
                                        <li><a href="contact.php">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rs-footer-widget footer-1-col-3">
                                <h5 class="rs-footer-widget-title">Services</h5>
                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="it-emerging-tech-enablement.php">IT & Emerging Tech Enablement</a></li>
                                        <li><a href="assessment-and-testing.php">Assessment & Testing</a></li>
                                        <li><a href="recruitment-and-hiring.php">Recruitment & Hiring</a></li>
                                        <li><a href="exam-management.php">Exam Management</a></li>
                                        <li><a href="manpower-and-workforce.php">Manpower & Workforce</a></li>
                                        <li><a href="call-center-and-bpos.php">Call Center & BPOs</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="rs-footer-widget footer-1-col-4">
                                <h5 class="rs-footer-widget-title">Quick Links</h5>

                                <div class="rs-footer-widget-link">
                                    <ul>
                                        <li><a href="#solutions">Our Solutions</a></li>
                                        <li><a href="case-study.php">Case Study</a></li>
                                        <li><a href="industry-clients.php#clients">Clientele</a></li>
                                        <li><a href="articles.php">Articles</a></li>
                                        <li><a href="awards.php">Awards & Recognition</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="rs-footer-subscribe-from">
                            <h5 class="rs-footer-subscribe-title">Subscribe Newsletter</h5>
                            <div class="rs-cta-input">
                                <input id="email2" name="name" type="text" placeholder="Enter your email">
                                <button type="submit" class="rs-btn has-icon has-bg-secondary has-sm-radius">
                                    Send Now
                                    <span class="icon-box">
                                        <svg class="icon-first" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white"></path>
                                        </svg>

                                        <svg class="icon-second" width="16" height="16" viewBox="0 0 16 16"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.0743 8.70831L0.916528 8.70831L0.916528 6.87526L12.0737 6.87461L7.15722 1.95816L8.45358 0.661793L15.5836 7.79179L8.45358 14.9218L7.15722 13.6254L12.0743 8.70831Z"
                                                fill="white"></path>
                                        </svg>
                                    </span>
                                </button>
                            </div>
                        </div>
                        <div class="rs-footer-brand">
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-07.webp" alt="image">
                            </div>
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-08.webp" alt="image">
                            </div>
                            <div class="rs-footer-brand-thumb">
                                <img src="assets/images/brand/brand-thumb-09.webp" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="rs-footer-copyright-area rs-copyright-one">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="rs-footer-copyright-wrapper">
                        <div class="rs-footer-copyright-left">
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright-link">
                                    <a href="terms-conditions.php">Terms & Agreements</a>
                                </div>
                            </div>
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright-link">
                                    <a href="privacy-policy.php">Privacy policy</a>
                                </div>
                            </div>
                        </div>
                        <div class="rs-footer-copyright-right">
                            <div class="rs-footer-copyright-item">
                                <div class="rs-footer-copyright">
                                    <p class="underline">Copyright © <span id="year">2025</span> ICEF INDIA. All rights reserved. Designed by <a
                                            target="_blank" href="https://agumentiksoftware.com/">AGUMENTIK.</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer area end -->

        <!-- back to top -->
    <!-- Backtotop start -->
    <div class="backtotop-wrap cursor-pointer">
        <i class="ri-arrow-up-s-line"></i>
    </div>
    <!-- Backtotop end -->

    <!-- JS here -->
    <script src="assets/js/vendor/jquery-3.7.1.min.js"></script>
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/meanmenu@2.0.8/jquery.meanmenu.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/wowjs@1.1.3/dist/wow.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/magnific-popup@1.1.0/dist/jquery.magnific-popup.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/isotope-layout@3.0.6/dist/isotope.pkgd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/imagesloaded@5.0.0/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/vendor/ajax-form.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@studio-freight/lenis@1.0.34/dist/lenis.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
    <script src="assets/js/plugins/rs-scroll-trigger.min.js"></script>
    <script src="assets/js/plugins/rs-splitText.min.js"></script>
    <!-- Custom theme scripts (Restored) -->
    <script src="assets/js/plugins/rs-anim-int.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery.appear@1.0.1/jquery.appear.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-nice-select@1.1.0/js/jquery.nice-select.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/nouislider@15.7.1/dist/nouislider.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/odometer@0.4.8/odometer.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>

    <script>
        document.getElementById('articleSearchInput').addEventListener('input', function(e) {
            const term = e.target.value.toLowerCase();
            const articles = document.querySelectorAll('.rs-blog-item');
            let foundCount = 0;

            articles.forEach(article => {
                const title = article.querySelector('.rs-blog-title').innerText.toLowerCase();
                const desc = article.querySelector('.rs-blog-desc').innerText.toLowerCase();
                const col = article.closest('.col-xl-4, .col-lg-6, .col-md-6');

                if (title.includes(term) || desc.includes(term)) {
                    col.style.display = 'block';
                    foundCount++;
                } else {
                    col.style.display = 'none';
                }
            });

            // Hide pagination if searching
            const pagination = document.querySelector('.pagination-wrapper');
            if (pagination) {
                pagination.style.display = term.length > 0 ? 'none' : 'block';
            }
        });
    </script>

</body>

</html>
